import * as moment from 'moment';
import { NgbDateStruct, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';

/**
 * @param pickedDateVal Value from Date Picker
 * @param pickedTimeVal Value from Time Picker
 */

export const combineDateTime = (
  pickedDateVal: string,
  pickedTimeVal: string
) => {
  const datePicker = moment(pickedDateVal).toObject();
  const timePicker = moment(pickedTimeVal, 'hh:mm a').toObject();
  const newMomentDate = moment()
    .set({
      date: datePicker.date,
      hours: timePicker.hours,
      milliseconds: timePicker.milliseconds,
      minutes: timePicker.minutes,
      months: datePicker.months,
      seconds: timePicker.seconds,
      years: datePicker.years,
    })
    .utc()
    .format();
  return newMomentDate;
};

/**
 * @param birthdate Patient's birthdate (must include years)
 */

export const getAge = (birthdate: string | object) => {
  return moment().diff(birthdate, 'years');
};

/**
 * @desc Change time string to MM/DD/YYYY
 */

export const getTwoMonDayFourYear = (time: string) => {
  return moment(time).format('MM/DD/YYYY');
};

/**
 * @desc Takes in Moment object and returns MM/DD/YYYY
 */

export const toDateSlashes = date => {
  if ((date as moment.Moment)['_isAMomentObject']) {
    return (date as moment.Moment).format('MM/DD/YYYY');
  }
  return moment(date).format('MM/DD/YYYY');
};

export const setNgbStructAsMomentObj = (dateObj: NgbDateStruct) => {
  if (!dateObj) {
      return null;
  }

  const {
      day,
      year,
      month,
  } = dateObj;

  return moment(`${year}-${month}-${day}`, 'YYYY-MM-DD');
};

export const setNgbTimeStructAsMomentObj = (timeObj: NgbTimeStruct) => {
  if (!timeObj) {
    return null;
  }

  return moment(timeObj);
};
