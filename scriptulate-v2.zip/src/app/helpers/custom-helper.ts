import { FormGroup, FormControl, FormArray } from '@angular/forms';

export const setDrugName = (drugName: string) => {
    const containsNumber = (str: string) => /\d/.test(str);
    if (!drugName) {
        return null;
    }
    let drug_name = null, dosage = null;
    if (containsNumber(drugName)) {
        const temp = drugName.split(' ');
        drug_name = temp[0];
        dosage = temp.pop();
        temp.splice(0, 1);
        if (!containsNumber(dosage)) {
        dosage = temp.join(' ');
        }
    } else {
        drug_name = drugName;
    }
    return { drug_name, dosage };
};

export const sortByFirstAndLastNames = (listOfUsers: Array<any>) => {
    return listOfUsers
        .sort((a, b) => {
            a = a.last_name || '';
            b = b.last_name || '';
            return (a.localeCompare(b));
        })
        .sort((a, b) => {
            a = a.first_name || '';
            b = b.first_name || '';
            return (a.localeCompare(b));
        });
};

export const validateAllFormFields = (formGroup: FormGroup  ) => {
    let control = null;
    Object.keys(formGroup.controls).forEach(field => {
        control = formGroup.get(field);
        if (control instanceof FormControl) {
            control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
            validateAllFormFields(control);
        }
    });
};

