import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonService } from '@app/core/services';
import { Router } from '@angular/router';
@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit, AfterViewInit {
  editProfile: boolean;

  constructor(public router: Router, private commonService: CommonService) {
    this.router = router;
  }

  ngAfterViewInit() {}

  isShow(url: string): boolean {
    const state = false;
    /*
  if (url == '/editprofile' || url == '/medicalhistory' || url == '/dashboard') {
    state = false;
  } */
    return state;
  }

  ngOnInit() {}
}
