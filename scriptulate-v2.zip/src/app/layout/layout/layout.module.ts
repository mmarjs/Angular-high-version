import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { HeaderComponent } from '../../common/modules/header/header.component';
import { FooterComponent } from '../../common/modules/footer/footer.component';
import { SidebarComponent } from '../../common/modules/sidebar/sidebar.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material';
import { AuthService } from '../../core/services';
import { AuthGuard } from '../../common/guards/auth.guard';
import { SharedModule } from 'app/common/modules/shared/shared.module';
@NgModule({
  imports: [CommonModule, MatMenuModule, MatButtonModule, LayoutRoutingModule, SharedModule],
  declarations: [
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent
  ],
  providers: [AuthGuard, AuthService]
})
export class LayoutModule { }
