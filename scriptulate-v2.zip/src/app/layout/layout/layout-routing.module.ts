import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { AuthGuard } from '../../common/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        data: {
          breadcrumb: 'Dashboard'
        },
        loadChildren: '@app/modules/dashboard/dashboard.module#DashboardModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'reports',
        data: {
          breadcrumb: 'Reports'
        },
        loadChildren: '@app/modules/reports/sidebar-reports.module#SidebarReportsModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'mypatient',
        data: {
          breadcrumb: 'My Patient'
        },
        loadChildren:
          '@app/modules/profiledetail/profiledetail.module#ProfiledetailModule',
        canActivate: [AuthGuard]
      },

      {
        path: 'editprofile',
        // data: {
        //   breadcrumb: 'Edit Profile'
        // },
        loadChildren:
          '@app/common/modules/editprofile/editprofile.module#EditprofileModule',
        canActivate: [AuthGuard]
      },

      // {
      //   path: 'medicalhistory',
      //   loadChildren:
      //     '@app/modules/patient-nav/medical-history/medical-history.module#MedicalHistoryModule',
      //   canActivate: [AuthGuard]
      // },

      {
        path: 'patient-nav',
        loadChildren:
          '@app/modules/patient-nav/patient-nav.module#PatientNavModule',
        data: {
          breadcrumb: 'Patient Home',
        },
        canActivate: [AuthGuard]
      },
      // {
      //   path: 'patient-nav/checklists',
      //   loadChildren:
      //     '@app/modules/patient-nav/patient-nav.module#PatientNavModule',
      //   canActivate: [AuthGuard]
      // }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
