/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { FormControl, AbstractControl } from '@angular/forms';
import { AbstractClassPart } from '@angular/compiler/src/output/output_ast';

/**
 ** @name custom validators
 ** @desc password and confirm password match validator
 */
export class PasswordValidation {
  static passValidator(control: AbstractControl) {
    if (control && (control.value !== null || control.value !== undefined)) {
      const cnfpassValue = control.value;

      const passControl = control.root.get('password');
      if (passControl) {
        const passValue = passControl.value;
        if (passValue !== cnfpassValue) {
          return {
            isError: true,
          };
        }
      }
    }
    return null;
  }
}
