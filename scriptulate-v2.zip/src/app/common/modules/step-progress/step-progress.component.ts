import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-step-progress',
  templateUrl: './step-progress.component.html',
  styleUrls: ['./step-progress.component.scss']
})
export class StepProgressComponent implements OnInit {
  @Input() stepNum: number;
  @Input() curVal: number;
  @Input() height: number;
  // stepNum: number = 10;
  // curVal: number = 5; 
  mNums = [];
  constructor() { }

  ngOnInit() {
    this.mNums = [];
    for (var i = 1; i < this.stepNum + 1; i++) {
      this.mNums.push(i);
    }
    this.height = this.height == null ? 1 : this.height;
  }

  myHeight() {
    return  `${this.height}rem`;
  }

}
