import { Component, OnInit } from '@angular/core';
import { AuthService } from '@app/core/services';
import { Router } from '@angular/router';
import { LoginService } from '@app/modules/login/service/login.service';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
	role: string;
	user_id: number;
	selectNum = 0;
	name: string;

	constructor(private router: Router, private authService: AuthService, private loginService: LoginService) {}

	ngOnInit() {
		this.authService.myProfile.subscribe((myProfile: any) => {
			this.role = myProfile['role'];
			this.user_id = myProfile['id'];
			this.name = myProfile['first_name'] + ' ' + myProfile['last_name'];
		});
	}

	editProfile() {
		this.router.navigate(['editprofile']);
	}

	logoutUser() {
		this.loginService.logout();
	}

	getTabActive(id: number): String {
		return this.selectNum === id ? 'active' : 'activeno';
	}

	routeToMyPatients() {
		this.router.navigate(['/mypatient']);
	}
	routeToDashboard() {
		this.router.navigate(['/dashboard']);
	}

	routeToMedicalHistory() {
		this.router.navigate(['/medicalhistory']);
	}
}
