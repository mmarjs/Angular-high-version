import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '@app/core/services/commonService/common.service';
import { AuthService } from '@app/core/services';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  img1 = [true, true, true, true, true, true];
  img2 = [false, false, false, false, false, false];

  selectNum = 0;

  public role: string;
  constructor(
    public router: Router,
    public commonService: CommonService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.authService.myProfile.subscribe((myProfile: any) => {
      this.role = myProfile['role'];
    });
  }
  routeToMyPatients() {
    this.router.navigate(['/mypatient']);
    // this.router.navigate(['patientnav'], { queryParams: { patient_id:id } , skipLocationChange: true});
  }
  routeToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  routeToMedicalHistory() {
    this.router.navigate(['/medicalhistory'], { skipLocationChange: false });
  }

  toggle_img(id: number) {
    for (var i = 0; i < 6; ++i) {
      this.img1[i] = true;
      this.img2[i] = false;  
    }
    this.img1[id] = false;
    this.img2[id] = true;
  }

  toggleTab(id: number) {
    this.selectNum = id;
  }

  getTabActive(id: number): string {
    return this.selectNum === id ? 'active' : 'activeno';
  }
}
