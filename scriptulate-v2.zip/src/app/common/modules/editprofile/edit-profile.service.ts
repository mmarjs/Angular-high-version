import { Injectable } from '@angular/core';
import { ProfileData } from './profileData';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';

@Injectable({
	providedIn: 'root'
})
export class EditProfileService {
	public profileData: ProfileData;
	private headers = new HttpHeaders().set('content-Type', 'application/json');

	BASE_URL = EnvironemntConfig.BASE_URL;
	constructor(
		private httpResourceService: HttpResourceService,
		private http: HttpClient
	) {}

	editProfile(params) {
		const url = RelativeUrlConfig.GET_PROFILE;
		return this.httpResourceService.get(url, params);
	}

	saveProfile(id, params) {
		const url = RelativeUrlConfig.PROFILE;
		return this.httpResourceService.put(`${url}/${id}`, params);
	}
}
