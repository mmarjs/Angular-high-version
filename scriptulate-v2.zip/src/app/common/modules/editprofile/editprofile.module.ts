import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ProfileModule} from '../../../modules/profile/profile.module';
import { EditprofileRoutingModule } from './editprofile-routing.module';
import { EditprofileComponent } from './editprofile.component';


@NgModule({
  imports: [
    CommonModule,
    EditprofileRoutingModule,
    ProfileModule
  ],
  declarations: [EditprofileComponent]
})
export class EditprofileModule { }
