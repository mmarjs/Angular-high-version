import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../core/services';
import { EditProfileService } from './edit-profile.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as Reducers from '@app/reducers';

@Component({
	selector: 'app-editprofile',
	templateUrl: './editprofile.component.html',
	styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
	public profileData = [];
	editProfile: boolean;
	public role$: Observable<object>;
	public user$: Observable<object>;

	constructor(
		public router: Router,
		private editProfileService: EditProfileService,
		private commonService: CommonService,
		private store: Store<Reducers.State>
	) {
		/* this.editProfile=this.commonService.IS_EDITPROFILE;
		console.log('from edit profile component');
		console.log(this.commonService.IS_EDITPROFILE);*/
	}
	ngOnInit() {
		this.user$ = this.store.select((state: Reducers.State) => state.auth.user);
	}

	public routeToDashboard() {
		this.router.navigate(['dashboard']);
	}

	resultSuccessCallback(res) {
		this.profileData = res.body;
	//	console.log(this.profileData);
	}
}
