import { EditprofileModule } from './editprofile.module';

describe('EditprofileModule', () => {
  let editprofileModule: EditprofileModule;

  beforeEach(() => {
    editprofileModule = new EditprofileModule();
  });

  it('should create an instance', () => {
    expect(editprofileModule).toBeTruthy();
  });
});
