export class ProfileData {
    public npi:Number;
    public email:string;
    public profileDetail:any;
    public firstName:string;
    public middleName:string;
    public lastName:string;
    public dob:any;
    public phone:Number;
    public fax:Number;
    public addressLine1:string;
    public addressLine2:string;
    public ssn:any;
    public city:string;
    public deaId:string;
    public zip:Number;
    public state:string;
    public licenseState:string;
    public licenseNumber:Number;
    public secretQuestion:string;
    public answer:string;
}