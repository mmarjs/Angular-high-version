import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-my-progress',
  templateUrl: './my-progress.component.html',
  styleUrls: ['./my-progress.component.scss']
})
export class MyProgressComponent implements OnInit {
  @Input() lString: string;
  @Input() rString: string;
  @Input() valNum: number;

  constructor() {}

  ngOnInit() {}

  getHeigh() {
    return `${100 - this.valNum}%`;
  }
}
