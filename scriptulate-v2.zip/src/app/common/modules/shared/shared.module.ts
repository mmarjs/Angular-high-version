import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { AlertComponent } from './components/alert/alert.component';
import { ContractComponent } from './components/contract/contract.component';
import { PdfViewerComponent } from './components/pdf-viewer/pdf-viewer.component';
import { NgxLoadingModule } from 'ngx-loading';
import {
  PatientHeaderComponent,
  PatientHealthHeaderComponent,
  ModalTitleTopbarComponent,
} from 'app/common/modules/shared/components/headers';

import { MatDialogModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { AlertPopupComponent } from './components/alert-popup/alert-popup.component';
import { TodoComponent } from './components/todo/todo.component';
import { MomentModule } from 'ngx-moment';
import { TodoCreateModalComponent } from './components/todo-create-modal/todo-create-modal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbDatepickerModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NewSharedModule } from '@app/shared/shared.module';
import { ImportPatientCsvComponent } from '@app/modules/profiledetail/import-patientcsv/import-patientcsv.component';
import { DragDropDirective } from '@app/modules/profiledetail/import-patientcsv/drag-drop.directive';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
@NgModule({
  declarations: [
    DragDropDirective,
    TodoCreateModalComponent,
    AlertComponent,
    ContractComponent,
    PdfViewerComponent,
    PatientHeaderComponent,
    PatientHealthHeaderComponent,
    ModalTitleTopbarComponent,
    AlertPopupComponent,
    TodoComponent,
    ImportPatientCsvComponent,
    BreadcrumbComponent
  ],
  imports: [
    CommonModule,
    MatDialogModule,
    MatMenuModule,
    MomentModule,
    FormsModule,
    ReactiveFormsModule,
    NgbDatepickerModule,
    NgbModule,
    NewSharedModule,
    RouterModule
  ],
  exports: [
    AlertComponent,
    ContractComponent,
    PdfViewerComponent,
    FlexLayoutModule,
    NgxLoadingModule,
    PatientHeaderComponent,
    PatientHealthHeaderComponent,
    ModalTitleTopbarComponent,
    AlertPopupComponent,
    TodoComponent,
    TodoCreateModalComponent,
    BreadcrumbComponent
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [ImportPatientCsvComponent,PdfViewerComponent, AlertPopupComponent,TodoCreateModalComponent]
})
export class SharedModule {}
