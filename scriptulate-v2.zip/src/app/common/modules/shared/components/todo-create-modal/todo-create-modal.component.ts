import {
  Component,
  OnInit,
  OnDestroy,
  Input,
} from '@angular/core';
import { FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Store } from '@ngrx/store';
import { Subject, Observable } from 'rxjs';
import { takeUntil, map, distinctUntilChanged, debounceTime } from 'rxjs/operators';
import matchSorter from 'match-sorter';
import * as Reducers from 'app/reducers';
import { Doctor } from 'app/modules/profiledetail/patient-request/models';
import { addUrineEntry } from 'app/reducers/urine/urine.actions';
import { combineDateTime, setNgbStructAsMomentObj, setNgbTimeStructAsMomentObj } from 'app/helpers';
import { doctorIdsAndNames } from 'app/reducers/doctor/doctor.reducer';
import { NgbActiveModal, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { ngbDateValidator } from 'app/shared/validators/ngb-date.validator';
import { addTodo } from '@app/reducers/todo/todo.actions';

interface TodoModalData {
  patientId: string;
  doctorId: string;
}

@Component({
  selector: 'app-todo-create-modal',
  templateUrl: './todo-create-modal.component.html'
})
class TodoCreateModalComponent implements OnInit, OnDestroy {
  @Input() data: any;
  doctors$: Observable<any>;
  doctors :any
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();

  patientId: any;
  doctorId: any;
  params: any;

  reasons = [
    {name: 'Diagnostic Imaging', value: 'DI'},
    {name: 'Diversion', value: 'DV'},
    {name: 'EKG', value: 'EKG'},
    {name: 'Pain Contract', value: 'PC'},
    {name: 'Physical Therapy', value: 'PT'},
    {name: 'UDT', value: 'UDT'},
    {name: 'Other', value: 'OTH'},
  ];

  frequencies = [
    {name: 'Days', value: 'd'},
    {name: 'Weeks', value: 'w'},
    {name: 'Months', value: 'M'},
    {name: 'Years', value: 'y'},
  ];

  createForm: FormGroup = new FormGroup({
    rules: new FormArray([new FormControl()]),
    reason: new FormControl('',[Validators.required]),
    number: new FormControl('',[Validators.required]),
    freq: new FormControl('',[Validators.required]),
    commentCtrl: new FormControl(),
  });

  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
    public ngbCalendar: NgbCalendar,
  ) {}

  closeModal = (): void => this.activeModal.close();
  
  onSubmit(): void {
    const unit =this.createForm.get('number').value;
    const freq = this.createForm.get('freq').value;
    const reason = this.createForm.get('reason').value
    const comment = this.createForm.get('commentCtrl').value;
    if(unit && freq && reason){
      const due_date = moment().add(unit,freq).format('MM/DD/YYYY');
      this.params = {
        comment:  this.reasons.filter(obj=>obj.value==reason)[0].name,
        details: {comment},
        status: 'Initiated',
        patient_id: +this.patientId,
        requested_by_user_id: +this.doctorId,
        is_completed:'false',
        name: reason,
        due_date: due_date
      };

      if (
        this.params.due_date &&
        this.params.name 
      ) {
        this.store.dispatch(addTodo({ payload: this.params }));
        this.closeModal();
      } else {
        return;
      }
    }
  }

  ngOnInit() {
    this.doctorId = this.data.doctorId;
    this.patientId = this.data.patientId;
    this.doctors$ = this.store.pipe(map(doctorIdsAndNames));
    this.doctors$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((collection): void => {
        this.doctors = collection;
      });
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.unsubscribe();
  }
}

export { TodoCreateModalComponent, TodoModalData };
