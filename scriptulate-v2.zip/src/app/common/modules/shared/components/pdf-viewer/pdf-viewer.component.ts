import '@libs/wv-resources/webviewer.min.js';

import {
    AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild,
    ViewEncapsulation
} from '@angular/core';
import { MatDialogRef } from '@angular/material';

declare const WebViewer: any;

@Component({
  selector: 'app-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PdfViewerComponent implements OnInit, AfterViewInit {

  @ViewChild('pdfviewer')
  viewer: ElementRef;

  wvInstance: any;

  @Input()
  filename: string;

  @Input()
  fileurl: string;

  @Input()
  editable: boolean = true;

  @Output()
  onSave = new EventEmitter();

  @Output()
  onCancel = new EventEmitter();

  constructor(public dialogRef: MatDialogRef<PdfViewerComponent>) { }

  ngOnInit() { }

  ngAfterViewInit() {

    WebViewer({
      path: 'libs/wv-resources',
      initialDoc: this.fileurl,
    }, this.viewer.nativeElement).then(instance => {
      this.wvInstance = instance;
    });

  }

  close(file?) {
    this.dialogRef.close(file);
  }

  save() {
    const doc = this.wvInstance.docViewer.getDocument();
    const annotManager = this.wvInstance.annotManager;
    const xfdfString = annotManager.exportAnnotations();

    doc.getFileData({ xfdfString })
      .then((data) => {
        const arr = new Uint8Array(data);
        const blob = new Blob([arr], { type: 'application/pdf' });
        const file = new File([blob], this.filename, {
          type: 'application/pdf'
        });
        this.onSave.emit(file);
        this.close(file);
      });
  }
}
