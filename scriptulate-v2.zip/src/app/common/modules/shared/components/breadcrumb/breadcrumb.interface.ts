export interface IBreadCrumb {
    label: string;
    url: string;
    patientId: string;
}