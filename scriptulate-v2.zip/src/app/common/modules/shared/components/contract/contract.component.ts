import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { PdfViewerComponent } from '../pdf-viewer/pdf-viewer.component';

@Component({
  selector: 'app-contract',
  templateUrl: './contract.component.html',
  styleUrls: ['./contract.component.scss']
})
export class ContractComponent implements OnInit {

  _contract: any;

  get contract() {
    return this._contract;
  }

  @Input()
  set contract(value) {
    this._contract = value;
    if (!this.contract)
      return;
    if (this.contract.is_ended)
      this.status = 'ended';
    else if (this.contract.active)
      this.status = 'active';
    else if (this.contract.signed_document_id)
      this.status = 'inactive';
    else {
      this.status = 'pending';
    }
  }

  status = '';

  constructor(private dialog: MatDialog) { }

  ngOnInit() {}

  openContract() {
    const ref = this.dialog.open(PdfViewerComponent, {
      panelClass: 'pdf-viewer-modal'
    });
    ref.componentInstance.editable = false;
    ref.componentInstance.fileurl = this.contract.signed_document ? this.contract.signed_document.file_location : this.contract.document.file_location;
  }
}
