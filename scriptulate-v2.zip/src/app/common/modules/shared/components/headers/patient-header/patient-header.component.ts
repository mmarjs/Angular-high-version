import { Component, Input } from '@angular/core';
import { Observable } from 'rxjs';
import * as Reducers from 'app/reducers';
import { Store, select } from '@ngrx/store';
// import { ActivatedRoute } from '@angular/router';
import { Patient } from '@app/reducers/patient/patient.reducer';

@Component({
  selector: 'app-patient-header',
  templateUrl: './patient-header.component.html',
  styleUrls: ['./patient-header.component.scss'],
})
class PatientHeaderComponent {
  @Input() imageSrc = '/assets/images/profile.png';
  @Input() lastPDMPSync;
  @Input() patientId;
  patient$: Observable<Patient>;

  constructor(
    private store: Store<Reducers.State>,
    // private route: ActivatedRoute
  ) {
    // this.route.queryParams.subscribe(({ patient_id }): void => {
    //   this.patient$ = this.store.pipe(
    //     select((state: Reducers.State) => state.patient.entities[patient_id])
    //   );
    // });
      this.patient$ = this.store.pipe(
        select((state: Reducers.State) => state.patient.entities[this.patientId])
      );
  }

}

export { PatientHeaderComponent };
