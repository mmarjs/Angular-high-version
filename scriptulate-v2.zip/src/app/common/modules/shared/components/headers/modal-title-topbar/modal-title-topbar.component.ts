import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-modal-title-topbar',
  templateUrl: './modal-title-topbar.component.html',
})
class ModalTitleTopbarComponent {
  @Output() close: EventEmitter<any> = new EventEmitter();
  @Input() title: string;
  @Input() headings: 'h5' | 'h3' = 'h3';
  @Input() topbarClasses: string;
  @Input() leftColClasses: string;
  @Input() middleColClasses: string;
  @Input() middleColStyles: object;
  @Input() rightColClasses: string;
  closeIconSrc = '/assets/images/close.svg';

  handleCloseClick = () => {
    this.close.emit();
  }
}

export { ModalTitleTopbarComponent };
