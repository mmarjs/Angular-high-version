import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { PusherService } from 'app/core/services/pusherService/pusher.service';
import * as Reducers from 'app/reducers';
import { removeAlert } from 'app/reducers/alert/alert.actions';
import { selectAlerts } from 'app/reducers/alert/alert.reducer';
import { selectedPatient, Patient } from 'app/reducers/patient/patient.reducer';
import { Observable } from 'rxjs';
import { User } from '@app/reducers/auth/auth.reducer';
import { getTodos } from '@app/reducers/todo/todo.reducer';
import { fetchTodos, removeTodo, addTodo } from '@app/reducers/todo/todo.actions';
import { AuthService } from '@app/core/services';

@Component({
  selector: 'app-patient-health-header',
  templateUrl: './patient-health-header.component.html',
  styleUrls: ['./patient-health-header.component.scss'],
  styles: [':host { width: 100% }'],
})

class PatientHealthHeaderComponent implements OnInit {
  @Input() linkToHome: Boolean = false;
  @Input() showAddTodo: Boolean = false;
  @Input() src = '/assets/images/profile.png';
  @Input() showPatientId: Boolean = false;
  @Input() disableNewOrder: Boolean = false;
  @Input() showNewOrderButton: Boolean = true;
  @Input() renderNewOrder: Boolean = true;
  @Input() passPatientId: string;
  @Output() handleNewOrderClick: EventEmitter<any> = new EventEmitter();

  alerts$: Observable<any>;
  patient$: Observable<Patient>;
  role$: Observable<User['role']>;
  patientId: string;
  age: number;
  todos$: Observable<any>;

  constructor(
    private store: Store<Reducers.State>,
    private route: ActivatedRoute,
    private router: Router,
    private pusherService: PusherService,
    private authService: AuthService
  ) {
    this.route.queryParams.subscribe(({ patient_id }): void => {
      if (patient_id) {
        this.patientId = patient_id;
      }
      this.patient$ = this.store.pipe(select(selectedPatient, { patient_id: this.patientId }));
    });

    this.role$ = this.store.pipe(select((state: Reducers.State) => state.auth.user.role));
    this.alerts$ = this.store.pipe(select(selectAlerts));
    this.pusherService.alertsSubscribe();
    this.todos$ = this.store.select(getTodos);
  }

  newOrderClick = (): void => {
    this.handleNewOrderClick.emit();
  }

  // goHome = (): void => {
  //   let paramPatientId = this.patientId;
  //   if (this.passPatientId) {
  //     paramPatientId = this.passPatientId;
  //   }
  //   this.router.navigate(['patient-nav'], {
  //     queryParams: { patient_id: paramPatientId },
  //     skipLocationChange: true,
  //   });
  // }

  closeAlert = (alert) => {
    this.store.dispatch(removeAlert(alert));
  }

  ngOnInit() {
    if (this.passPatientId) {
      this.patient$ = this.store.pipe(select(selectedPatient, { patient_id: this.passPatientId }));
    }
    this.store.dispatch(fetchTodos({payload: this.authService.user.id}));
  }

  /**openTodo(todo) {
    const ref = this.dialog.open(UrineCreateModalComponent, { data: { todo } });
    ref.afterClosed().subscribe(mark_as_completed => {
      if (mark_as_completed) {
        this.removeTodo(todo);
      }
    });
  }**/

  removeTodo(todo) {
    this.store.dispatch(removeTodo(todo));
  }

}

export { PatientHealthHeaderComponent };
