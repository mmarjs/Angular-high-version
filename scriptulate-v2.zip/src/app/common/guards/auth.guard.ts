import { Injectable } from '@angular/core';
import {
	CanActivate,
	ActivatedRouteSnapshot,
	RouterStateSnapshot,
	Router
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { AuthService } from '@app/core/services/authService/auth.service';
import { map, catchError } from 'rxjs/operators';
import { LoginService } from '@app/modules/login/service/login.service';

@Injectable({
	providedIn: 'root'
})
export class AuthGuard implements CanActivate {
	constructor(
		private authService: AuthService,
		private router: Router,
		private loginService: LoginService
	) { }

	canActivate(
		_next: ActivatedRouteSnapshot,
		state: RouterStateSnapshot,
	): Observable<boolean> | Promise<boolean> | boolean {
		return this.authService.myProfile.pipe(
			map((user: any) => {
				if(state.url == '/profilestatus'){
					return true;
				}
				if (!user || user === {}){
					this.router.navigate(['profile']);
					return false;
				}
				if (!user.email_verified && state.url !== '/profilestatus') {
					this.router.navigate(['/profilestatus']);
					return false;
				}
				if (user.require_profile_complete && state.url !== '/editprofile') {
					this.router.navigate(['/editprofile']);
					return false;
				}
				return true;
			}),
			catchError(_error => {
				return of(false);
			})
		);
	}
}
