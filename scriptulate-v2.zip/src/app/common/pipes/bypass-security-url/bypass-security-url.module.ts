import { NgModule } from '@angular/core';
import { BypassSecurityUrlPipe } from './bypass-security-url.pipe';

@NgModule({
  declarations: [BypassSecurityUrlPipe],
  exports: [BypassSecurityUrlPipe],
})
export class BypassSecurityUrlPipeModule {}
