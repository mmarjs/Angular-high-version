import { Injectable } from '@angular/core';
import { AuthService, CommonService } from '@app/core/services';

import {
	HttpRequest,
	HttpHandler,
	HttpEvent,
	HttpResponse,
	HttpErrorResponse,
	HttpInterceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { LoginService } from '@app/modules/login/service/login.service';
import { Router } from '@angular/router';

@Injectable()
export class ResInterceptor implements HttpInterceptor {
	constructor(private loginService: LoginService,private router: Router) {}

	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		return next.handle(request).pipe(
			map((event: HttpEvent<any>) => {
				return event;
			}),
			catchError((error: HttpErrorResponse) => {
				if (error.status === 401) {
					this.loginService.logout();
				}else if (error.status === 403) {
					if(error['errorCode']=='SCRIP-404'){
						this.router.navigate(['profile']);
					}
				}
				return throwError(error);
			})
		);
	}
}
