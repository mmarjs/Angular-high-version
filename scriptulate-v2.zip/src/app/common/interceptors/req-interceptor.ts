import { Observable } from 'rxjs';

import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '@app/modules/login/service/login.service';

import { AuthService } from '../../core/services';

@Injectable({
	providedIn: 'root'
})
export class ReqInterceptor implements HttpInterceptor {
	constructor(private authService: AuthService, private router: Router, private loginService: LoginService) { }

	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		if (this.authService.checkTokenExpiry()) {
			request = request.clone({
				setHeaders: {
					Authorization: `Bearer ${this.authService.getToken()}`,
					access_token: this.authService.getToken() || '',
					id_token: this.authService.getIDToken() || ''
				}
			});
		} else {
			this.loginService.logout();
		}

		return next.handle(request);
	}
}
