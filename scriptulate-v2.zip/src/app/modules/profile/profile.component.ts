/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '@app/core/services';
import { LoginService } from '../login/service/login.service';

@Component({
  selector: 'app-profile',
  templateUrl: './html/profile.component.html',
  styleUrls: ['./scss/profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user_id: Number;
  public role: String;

  constructor(
    private loginService: LoginService,
    private route: ActivatedRoute
  ) {}
  /*
   ** @name: ngOnInit
   ** @desc: invoked when the directive is instantiated
   */
  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
      this.user_id = parseInt(params.get('user_id'), 10);
      this.role = params.get('role');
    });
  }

  logoutUser() {
    this.loginService.logout();
  }
}
