/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '@app/core/config/environmentConfig';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root',
})
/**
 * @author Nishtha Jain
 * @name ProfileService
 * @desc This is the service file for profile module it will call methods of httpresourceservice
 */
export class ProfileService {
  BASE_URL_PROFILE_MANAGEMENT = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) {}

  updateProfile(user_id, params) {
    const url = `${RelativeUrlConfig.PROFILE}/${user_id}`;
    return this.httpResourceService.put(url, params);
  }

  createProfile(params) {
    const url = RelativeUrlConfig.PROFILE;
    return this.httpResourceService.post(url, params);
  }
}
