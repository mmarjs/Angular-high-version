import { Component, Input, OnInit } from '@angular/core';
import {
	FormBuilder,
	FormGroup,
	Validators,
	FormArray,
	FormControl
} from '@angular/forms';
import { Router } from '@angular/router';
import { AppUser } from '@app/core/config/constants';
import { EditProfileService } from '../../../common/modules/editprofile/edit-profile.service';
import { Messages } from '../../../core/config/messages';
import { EditPatientProfileService } from '../../profiledetail/edit-patientprofile/edit-patient-profile.service';
import { ProfileService } from '../service/profile.service';
import { AuthService } from '@app/core/services';
import { Store, Action } from '@ngrx/store';
import * as Reducers from '@app/reducers';
import { updateUser } from '@app/reducers/auth/auth.actions';
import { validateAllFormFields } from '@app/helpers';
import { createPatient, createPatientSuccess } from '@app/reducers/patient/patient.actions';
import { Actions, ofType } from '@ngrx/effects';
import { addPatient } from '@app/reducers/doctor/doctor.actions';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { RegisterService } from '@app/modules/register/service/register.service';
import { Role } from 'angular-google-charts/lib/models/role.model';
import { User } from '@app/reducers/auth/auth.reducer';
@Component({
	selector: 'app-profile-fields',
	templateUrl: './create-field.component.html',
	styleUrls: ['./create-field.component.css']
})
export class CreateFieldComponent implements OnInit {
	@Input() role: string;
	@Input() user_id: string;
	@Input() profile: string;
	@Input() profileId: string;
	@Input() isCustomClassAdded?: boolean;
	@Input() isPatientCustomClassAdded?: boolean;
	profileForm: FormGroup;
	/*
		createnpi:FormArray;
		createdeaid:FormArray;
		createlicenseNumber:FormArray;
		createdriverlicensenumber:FormArray;
		createdriverstate:FormArray;
	*/
	public profileData = [];
	public dataUpdated;

	// profileApproved=Constants.IS_PROFILE_APPROVED;
	questions = [
		'what is the name of your first pet?',
		'what is your first teacher name?'
	];
	requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
	firstNameErrorMessage = Messages.FIRSTNAME_ERROR_MESSAGE;
	lastNameErrorMessage = Messages.LASTNAME_ERROR_MESSAGE;
	cityErrorMessage = Messages.CITY_ERROR_MESSAGE;
	stateErrorMessage = Messages.STATE_ERROR_MESSAGE;
	ssnErrorMessage = Messages.SSN_ERROR_MESSAGE;
	npiErrorMessage = Messages.NPI_ERROR_MESSAGE;
	drivingLicenseStateErrorMessage = Messages.STATE_ERROR_MESSAGE;
	phoneErrorMessage = Messages.PHONE_ERROR_MESSAGE;
	dobErrorMessage = Messages.DOB_ERROR_MESSAGE;
	postalcodeErrorMessage = Messages.POSTALCODE_ERROR_MESSAGE;
	faxErrorMessage = Messages.FAX_ERROR_MESSAGE;
	emailErrorMessage = Messages.EMAIL_ERROR_MESSAGE;
	licenseStateErrorMessage = Messages.STATE_ERROR_MESSAGE;
	licenseNumberErrorMessage = Messages.LICENSE_ERROR_MESSAGE;
	deaErrorMessage = Messages.DEA_ERROR_MESSAGE;

	public ssnMask = [
		/\d/,
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
		/\d/,
		/\d/
	];
	public dobMask = [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
	public phoneMask = [
		'(',
		/[1-9]/,
		/\d/,
		/\d/,
		')',
		'-',
		/\d/,
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
		/\d/,
		/\d/
	];

	npi: Number;
	email: string;
	firstName: string;
	middleName: string;
	lastName: string;
	dob: any;
	doctorDeatil: any;
	phone: Number;
	fax: Number;
	addressLine1: string;
	addressLine2: string;
	ssn: any;
	city: string;
	patientEmail: string;
	zip: Number;
	deaId: string;
	state: string;
	driverLicenseState: string;
	driverLicenseNumber: Number;
	licenseState: string;
	licenseNumber: Number;
	secretQuestion: string;
	answer: string;
	doctorId: number;
	loggedUserRole: string;

	states = [
    {name: 'AL'},
    {name: 'AK'},
    {name: 'AS'},
    {name: 'AZ'},
    {name: 'AR'},
    {name: 'CA'},
    {name: 'CO'},
    {name: 'CT'},
    {name: 'DE'},
    {name: 'DC'},
    {name: 'FM'},
    {name: 'FL'},
    {name: 'GA'},
    {name: 'GU'},
    {name: 'HI'},
    {name: 'ID'},
    {name: 'IL'},
    {name: 'IN'},
    {name: 'IA'},
    {name: 'KS'},
    {name: 'KY'},
    {name: 'LA'},
    {name: 'ME'},
    {name: 'MH'},
    {name: 'MD'},
    {name: 'MA'},
    {name: 'MI'},
    {name: 'MN'},
    {name: 'MS'},
    {name: 'MO'},
    {name: 'MT'},
    {name: 'NE'},
    {name: 'NV'},
    {name: 'NH'},
    {name: 'NJ'},
    {name: 'NM'},
    {name: 'NY'},
    {name: 'NC'},
    {name: 'ND'},
    {name: 'MP'},
    {name: 'OH'},
    {name: 'OK'},
    {name: 'OR'},
    {name: 'PW'},
    {name: 'PA'},
    {name: 'PR'},
    {name: 'RI'},
    {name: 'SC'},
    {name: 'SD'},
    {name: 'TN'},
    {name: 'TX'},
    {name: 'UT'},
    {name: 'VT'},
    {name: 'VI'},
    {name: 'VA'},
    {name: 'WA'},
    {name: 'WV'},
    {name: 'WI'},
    {name: 'WY'},
  ]
  roles;
  groups;
  user :User={};
  doctorFormGroup: FormGroup;
  PatientFormGroup: FormGroup;
	constructor(
		private editPatientProfileService: EditPatientProfileService,
		private editProfileService: EditProfileService,
		private profileService: ProfileService,
		private fb: FormBuilder,
		private router: Router,
		private authService: AuthService,
		private store: Store<Reducers.State>,
		private actions$: Actions,
		private activeModal: NgbActiveModal,
		private registerService: RegisterService,
	) { }

	ngOnInit() {
		this.registerService.fetchRoles({}).subscribe(res => {
			this.roles = res['body'] as Role[];
			this.onRoleChange(this.profileForm.controls['role'].value);
		});
		this.registerService.fetchGroups({}).subscribe(res => {
			this.groups = res['body'];
			const userLogged = this.authService.user;
			if(!(userLogged && userLogged.groups)){
				this.profileForm.controls['groups'].setValue(this.groups[0].id);
			}
		});
		const userLogged = this.authService.user;
		if (userLogged && userLogged.role!='Patient') {
			this.doctorId = userLogged.id;
			this.loggedUserRole = userLogged.role;
		} else {
			this.loggedUserRole = this.role;
		}
		let user = this.user;

		if(userLogged){
			user.groups=userLogged.groups;
			user.role= this.role;
		}

		if(this.user_id && this.profile=='edit'){
			user=userLogged;
		}

		this.profileForm = this.fb.group({
			role: new FormControl( {value: this.role? this.role: user && user.groups &&  user.groups.length>0 ? user.groups[0].roles[0] : 'Physician',disabled: this.profile=='edit'&& !user.require_profile_complete},[Validators.required]),
			groups: new FormControl({
									value: user && user.groups &&  user.groups.length>0 ? user.groups[0].id : '',
									disabled: userLogged &&  userLogged.role!='Patient' && !user.require_profile_complete},
									[Validators.required])
		});
		
		this.doctorFormGroup=new FormGroup({
				npi: new FormControl(
					user ? user.npi : '',
					this.role === AppUser.doctor
						? [Validators.required, Validators.pattern('^[1-9]{1}[0-9]{9}$')]
						: []
				),
				firstName: new FormControl(
					user ? user.first_name : '',
					[Validators.required, Validators.pattern('^[a-zA-Z\-]+$')]
				),
				middleName: new FormControl(''),
				lastName: new FormControl(
					user ? user.last_name : '',
					[Validators.required, Validators.pattern('^[a-zA-Z\- ]+$')]
				),
				addressLine1: new FormControl(
					user ? user.address_line : '',
					(this.role == AppUser.doctor || this.role == AppUser.phamarcy)
						? [Validators.required]
						: []
				),
				addressLine2: new FormControl(user ? user.address_line2 : ''),
				city: new FormControl(
					user ? user.address_city : '',
					(this.role == AppUser.doctor || this.role == AppUser.phamarcy)
						? [Validators.required, Validators.pattern('^[ A-Za-z0-9_@./#&+-]*$')]
						: [Validators.pattern('^[ A-Za-z0-9_@./#&+-]*$')]
				),
				state: new FormControl(user ? user.address_state : '', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
				postalCode: new FormControl(
					user ? user.address_zip : '',
					(this.role == AppUser.doctor || this.role == AppUser.phamarcy)
						? [Validators.required, Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')]
						: [Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')]
				),
				dob: new FormControl(user ? user.birthdate : '', this.role == AppUser.patient ? [Validators.required] : []),
				phone: new FormControl(
					user ? user.phone_number : '',
					[
						Validators.required,
						(this.role === AppUser.doctor || this.role === AppUser.phamarcy)
							? Validators.pattern('^[(][0-9]{3}[)]-[0-9]{3}-[0-9]{4}$')
							: Validators.pattern('^[(][0-9]{3}[)]-[0-9]{3}-[0-9]{4}$')
					],
				),
				fax: new FormControl(user ? user.fax_number : '', [Validators.pattern('^[(][0-9]{3}[)]-[0-9]{3}-[0-9]{4}$')]),
				email: new FormControl(user && user.email ? user.email : this.authService.getEmail(), [Validators.required,Validators.pattern('^[A-Za-z0-9+_.-]+@(.+)')]),
				licenseNumber: new FormControl(
					'',
					this.role == AppUser.patient
						? [Validators.required, Validators.pattern('^[A-Za-z0-9]+$')]
						: [Validators.pattern('^[A-Za-z0-9]+$')]
				),
				licenseState: new FormControl(user ? user.license_state : '', [Validators.pattern('^[a-zA-Z]+$')]),
				deaId: new FormControl(
					user ? user.dea_id : '',
					(this.role == AppUser.doctor || this.role == AppUser.phamarcy)
						? [Validators.required, Validators.pattern('^[A-Z]{2}[0-9]{7}$')]
						: [Validators.pattern('^[A-Z]{2}[0-9]{7}$')]
				),
				driverLicenseNumber: new FormControl('', [Validators.pattern('^[0-9]+$')]),
				driverLicenseState: new FormControl('', [Validators.pattern('^[a-zA-Z]+$')]),
				ssn: new FormControl(
					user ? user.ssn : '',
					[Validators.pattern('^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$')]
				)
				//   secretQuestion: ['', Validators.required],
				//   answer: ['', Validators.required]
			});
		
			this.PatientFormGroup=new FormGroup({
				firstName: new FormControl(
					user ? user.first_name : '',
					[Validators.required, Validators.pattern('^[a-zA-Z\-]+$')]
				),
				middleName: new FormControl(''),
				lastName: new FormControl(
					user ? user.last_name : '',
					[Validators.required, Validators.pattern('^[a-zA-Z\- ]+$')]
				),
				addressLine1: new FormControl(user ? user.address_line : '', [Validators.required]),
				addressLine2: new FormControl(user ? user.address_line2 : ''),
				city: new FormControl(user ? user.address_city : '', [Validators.required,Validators.pattern('^[ A-Za-z0-9_@./#&+-]*$')]),
				state: new FormControl(user ? user.address_state : '', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
				postalCode: new FormControl(user ? user.address_zip : '', [Validators.required,Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')]),
				dob: new FormControl(user ? user.birthdate : '', [Validators.required]),
				phone: new FormControl(
					user ? user.phone_number : '',
					[Validators.required],
				),
				fax: new FormControl(user ? user.fax_number : '', [Validators.pattern('^[(][0-9]{3}[)]-[0-9]{3}-[0-9]{4}$')]),
				driverLicenseNumber: new FormControl('', [Validators.pattern('^[0-9]+$')]),
				driverLicenseState: new FormControl('', [Validators.pattern('^[a-zA-Z]+$')]),
				email: new FormControl(user ? user.email : '', [Validators.pattern('^[A-Za-z0-9+_.-]+@(.+)')]),
				ssn: new FormControl(
					user ? user.ssn : '',
					[
						Validators.pattern(
							'^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$'
						)
					]
				)
			});
			this.onRoleChange(this.role);
	}

	onRoleChange(roleSected){
		this.role = roleSected;
		this.profileForm.removeControl('roleGroupForm');
		if (this.role !== 'Patient') {
			this.profileForm.registerControl("roleGroupForm",this.doctorFormGroup);
		} else{
			this.profileForm.registerControl("roleGroupForm",this.PatientFormGroup);
		}
	}
	onSubmit() {
		if (this.profileForm.valid) {
			const FormData = this.profileForm.value;

			// least resistance solution, the codebase is really bad
			// sorry
			const payloadRequest = {
				first_name: FormData.roleGroupForm.firstName,
				last_name: FormData.roleGroupForm.lastName,
				birthdate: FormData.roleGroupForm.dob,
				npi: FormData.roleGroupForm.npi,
				dea_id: FormData.roleGroupForm.deaId,
				address_line: FormData.roleGroupForm.addressLine1,
				address_state: FormData.roleGroupForm.state,
				address_city: FormData.roleGroupForm.city,
				address_zip: FormData.roleGroupForm.postalCode,
				phone_number: FormData.roleGroupForm.phone,
				ssn: FormData.roleGroupForm.ssn,
				groups: {id:FormData.groups, roles:[FormData.role]},
				email: FormData.roleGroupForm.email,
			};

			this.profileService
				.createProfile({
					...payloadRequest,
					require_profile_complete: false
				})
				.subscribe(
					response => {
						this.updateSuccessCallback(response);
					},
					error => {
						console.error(error);
					}
				);
		} else {
			validateAllFormFields(this.profileForm);
		}
	}

	onPatientSaveSubmit() {
		if (this.profileForm.valid) {
			const FormData = this.profileForm.value;

			// least resistance solution, the codebase is really bad
			// sorry
			const payloadRequest = {
				first_name: FormData.roleGroupForm.firstName,
				last_name: FormData.roleGroupForm.lastName,
				birthdate: FormData.roleGroupForm.dob,
				npi: FormData.roleGroupForm.npi,
				dea_id: FormData.roleGroupForm.deaId,
				address_line: FormData.roleGroupForm.addressLine1,
				address_state: FormData.roleGroupForm.state,
				address_city: FormData.roleGroupForm.city,
				address_zip: FormData.roleGroupForm.postalCode,
				ssn: FormData.roleGroupForm.ssn,
				groups: {id:FormData.groups, roles:[FormData.role]},
				email: FormData.value.roleGroupForm.email || ''
			};

			this.profileService
				.updateProfile(this.user_id, {
					...payloadRequest
				})
				.subscribe(
					response => {
						this.navigateToDashboard();
					},
					error => {
						console.error(error);
					}
				);
		} else {
			validateAllFormFields(this.profileForm);
		}
	}

	afterCreationUpdateMyPatients = (): void => {
		this.actions$.pipe(ofType(createPatientSuccess)).subscribe(({ payload }) => {
			if (payload.id) {
				this.store.dispatch(addPatient({
					doctorId: this.doctorId,
					patientId: payload.id,
					birthdate: payload.birthdate
				}));
			}
		});
	}

	onSubmitPatient() {
		if (this.profileForm.valid) {
			const formValue = this.profileForm;

			// least resistance solution, the codebase is really bad
			// sorry
			const payloadRequest = {
				first_name: formValue.value.roleGroupForm.firstName,
				last_name: formValue.value.roleGroupForm.lastName,
				birthdate: formValue.value.roleGroupForm.dob,
				npi: formValue.value.roleGroupForm.npi,
				address_line: formValue.value.roleGroupForm.addressLine1,
				address_state: formValue.value.roleGroupForm.state,
				address_city: formValue.value.roleGroupForm.city,
				address_zip: formValue.value.roleGroupForm.postalCode,
				password: '',
				groups: {id:formValue.value.groups, roles:['Patient']},
				role:'Patient',
				ssn: formValue.value.roleGroupForm.ssn,
				email: formValue.value.roleGroupForm.email || ''
			};
			this.store.dispatch(createPatient({
				payload: payloadRequest,
			}));

			if (this.loggedUserRole === 'Doctor') {
				this.afterCreationUpdateMyPatients();
			}

			this.navigateToDashboard();
			this.activeModal.close();
		} else {
			validateAllFormFields(this.profileForm);
		}
	}

	onUpdate() {
		if (this.role === 'Patient') {
			if (this.profileForm.valid) {
				const formValue = this.profileForm;

				// least resistance solution, the codebase is really bad
				// sorry
				const payloadRequest = {
					first_name: formValue.value.roleGroupForm.firstName,
					last_name: formValue.value.roleGroupForm.lastName,
					birthdate: formValue.value.roleGroupForm.dob,
					npi: formValue.value.roleGroupForm.npi,
					dea_id: formValue.value.roleGroupForm.deaId,
					address_line: formValue.value.roleGroupForm.addressLine1,
					address_state: formValue.value.roleGroupForm.state,
					address_city: formValue.value.roleGroupForm.city,
					address_zip: formValue.value.roleGroupForm.postalCode,
					ssn: formValue.value.roleGroupForm.ssn,
					phone_number: formValue.value.roleGroupForm.phone,
					fax_number: formValue.value.roleGroupForm.fax,
					role:  formValue.value.role,
					groups: {id:formValue.value.groups, roles:['Patient']},
				};

				this.editPatientProfileService.saveProfile(payloadRequest).subscribe(
					response => {
						this.updateSuccessCallback(response);
					},
					error => {
						console.error(error);
					}
				);
			} else {
				validateAllFormFields(this.profileForm);
			}
		} else {
			if (this.profileForm.valid) {
				const formValue = this.profileForm;
				// least resistance solution, the codebase is really bad
				// sorry
				const payloadRequest = {
					first_name: formValue.value.roleGroupForm.firstName,
					last_name: formValue.value.roleGroupForm.lastName,
					birthdate: formValue.value.roleGroupForm.dob,
					npi: formValue.value.roleGroupForm.npi,
					dea_id: formValue.value.roleGroupForm.deaId,
					address_line: formValue.value.roleGroupForm.addressLine1,
					address_state: formValue.value.roleGroupForm.state,
					address_city: formValue.value.roleGroupForm.city,
					address_zip: formValue.value.roleGroupForm.postalCode,
					ssn: formValue.value.roleGroupForm.ssn,
					phone_number: formValue.value.roleGroupForm.phone,
					fax_number: formValue.value.roleGroupForm.fax,
					role: formValue.value.role,
					groups: {id:formValue.value.groups, roles:[formValue.value.role]},
				};

				this.editProfileService.saveProfile(this.authService.user.id, payloadRequest).subscribe(
					response => {
						this.updateSuccessCallback(response);
					},
					error => {
						console.error(error);
					}
				);
			} else {
				validateAllFormFields(this.profileForm);
			}
		}
	}

	private updateSuccessCallback(response) {
		this.store.dispatch(updateUser({ user: response.body }));
		this.router.navigate(['dashboard']);
	}

	private profileSuccessCallback(response) {
		this.router.navigate(['profilestatus']);
	}
	private navigateToDashboard() {
		this.router.navigate(['dashboard']);
	}
	onSaveClick() {
		this.router.navigate(['dashboard']);
		// this.router.navigate(['mypatient']);
	}
}
