/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import {
  MatNativeDateModule,
  MatDatepickerModule,
  MatIconModule,
} from '@angular/material';
import { CreateFieldComponent } from './create-field/create-field.component';
import { MatInputModule, MatAutocompleteModule } from '@angular/material';
import { MatDialogModule, MatButtonModule } from '@angular/material';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    ProfileRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatInputModule,
    MatAutocompleteModule,
    MatDialogModule,
    MatButtonModule,
  ],
  exports: [CreateFieldComponent],
  declarations: [ProfileComponent, CreateFieldComponent],
  providers: [ NgbActiveModal ]
})
export class ProfileModule {}
