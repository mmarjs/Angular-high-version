/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
} from '@angular/forms';
import { Messages } from '@app/core/config/messages';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from './service/login.service';
import { AuthService } from '@app/core/services';
import { CommonService } from '@app/core/services/commonService/common.service';
import { NgxLoadingComponent } from 'ngx-loading';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { UserIdleService } from 'angular-user-idle';
import { AppSession } from '@app/core/config/appSession';

interface User {
  email: string;
  id: number;
  role_id: number;
  role?: string;
  verified: boolean;
}

interface Payload {
  user: User;
  access_token: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './html/login.component.html',
  styleUrls: ['./scss/login.component.scss'],
})
export class LoginComponent implements OnInit {
  // declare letiables
  public role: String;
  public loading = false;
  public customLoadingTemplate: NgxLoadingComponent;

  loginForm: FormGroup;
  requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
  errValue = 'invalid_grant';
  showError = false;
  errorMessage = '';
  isSignin = true;
  user_id = null;
  token = null;
  isPasswordReset = false;

  constructor(
    public commonService: CommonService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private loginService: LoginService,
    private authService: AuthService,
    private _snackBar: MatSnackBar,
    private router: Router,
    private store: Store<{ auth: any }>,
    private userIdleService: UserIdleService
  ) {}

  /*
   ** @name: ngOnInit
   ** @desc: invoked when the directive is instantiated
   */
  ngOnInit() {
    if(this.authService.checkAuth()){
        AppSession.loadingSpinner=true;
        this.router.navigate(['dashboard']);
    }
  }

  login() {
    this.loading = true;
    AppSession.loadingSpinner=true;
    this.loginService.login("dashboard");
  }

  signUp() {
    this.router.navigate(['/register']);
  }

  showLoader() {
    this.loading = true;
  }

  getLoading(){
    return AppSession.loadingSpinner;
  }

  forgotPWD() {
    this.isSignin = !this.isSignin;
  }
  /**
   * @name validateAllFormFields
   * @desc to validate form fields on submit
   */

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
