/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'user/:user_id/password/reset', component: LoginComponent },
];
/**
 ** @name: LoginRoutingModule
 ** @desc: the routing Module of login component
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginRoutingModule {}
