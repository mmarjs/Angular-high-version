/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import createAuth0Client from '@auth0/auth0-spa-js';
import Auth0Client from '@auth0/auth0-spa-js/dist/typings/Auth0Client';
import { from, of, Observable, BehaviorSubject, combineLatest, throwError } from 'rxjs';
import { tap, catchError, concatMap, shareReplay } from 'rxjs/operators';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { Router } from '@angular/router';
import { AuthService } from '@app/core/services';
import { AppSession } from '@app/core/config/appSession';
import { environment } from 'environments/environment';
import { HttpParams } from '@angular/common/http';

@Injectable({
providedIn: 'root',
})
export class LoginService {
// Create an observable of Auth0 instance of client
 auth0Client$ = (from(
                createAuth0Client({
                  domain: environment.auth.domain,
                  client_id: environment.auth.clientID,
                  redirect_uri: `${window.location.origin}`,
                  audience: environment.auth.audience
                  })
                ) as Observable<Auth0Client>).pipe(
                  shareReplay(1), // Every subscription receives the same shared value
                  catchError(err => throwError(err))
);
// Define observables for SDK methods that return promises by default
// For each Auth0 SDK method, first ensure the client instance is ready
// concatMap: Using the client instance, call SDK method; SDK returns a promise
// from: Convert that resulting promise into an observable
isAuthenticated$ = this.auth0Client$.pipe(
                    concatMap((client: Auth0Client) => from(client.isAuthenticated()))
);

handleRedirectCallback$ = this.auth0Client$.pipe(
                    concatMap((client: Auth0Client) => from(client.handleRedirectCallback()))
);

getAccessToken$ = this.auth0Client$.pipe(
                    concatMap((client: Auth0Client) => from(client.getTokenSilently()))
);

getIDTokenClaims$ = this.auth0Client$.pipe(
    concatMap((client: Auth0Client) => from(client.getIdTokenClaims()))
);


getUser$ = this.auth0Client$.pipe(
  concatMap((client: Auth0Client) => from(client.getUser()))
);

constructor(private router: Router, private authService: AuthService) {
    
}

public initSetupAuth0(){
// On initial load, check authentication state with authorization server
    // Set up local auth streams if user is already authenticated
    this.localAuthSetup();
    // Handle redirect from Auth0 login
    this.handleAuthCallback();
}

private localAuthSetup() {
  // This should only be called on app initialization
  // Set up local authentication streams
  const checkAuth$ = this.isAuthenticated$.pipe(
  concatMap((loggedIn: boolean) => {
  if (loggedIn) {
    // If authenticated, get user and set in app
    // NOTE: you could pass options here if needed
    return this.getUser$;
  }
  // If not authenticated, return stream that emits 'false'
  return of(loggedIn);
  })
  );
  checkAuth$.subscribe();
}

private  handleAuthCallback() {
  // Call when app reloads after user logs in with Auth0
  const httpParams = new HttpParams({ fromString:  window.location.search.split('?')[1] });
  const code: string = httpParams.get('code');
  const state: string = httpParams.get('state');
  if(code&&state){
    AppSession.loadingSpinner=true;
    let targetRoute: string; // Path to redirect to after login processsed
    const authComplete$ = this.handleRedirectCallback$.pipe(
    // Have client, now call method to handle auth callback redirect
    tap(cbRes => {
      // Get and set target redirect route from callback results
      targetRoute = cbRes.appState && cbRes.appState.target ? cbRes.appState.target : '/';
    }),
    concatMap(() => { 
        // Redirect callback complete; get user and login status
        return combineLatest([
        this.getUser$,
        this.isAuthenticated$,
        this.getAccessToken$,
        this.getIDTokenClaims$
        ]);
      })
    );
    // Subscribe to authentication completion observable
    // Response will be an array of user and login status
    authComplete$.subscribe(([userDet, loggedIn, access_token, idTokenClaims]) => {
      // Redirect to target route after callback processing
      //this.authService.setAuth()
      AppSession.loadingSpinner=true;
     // console.log(userDet, loggedIn, access_token, idTokenClaims);
      let expiresAt = idTokenClaims.exp*1000;
      let user = {...userDet};
      let authObj ={access_token,id_token:idTokenClaims.__raw,expiresAt, user};
      if(!user.email_verified){
        this.router.navigate(['profilestatus']).then(()=>AppSession.loadingSpinner=false);
      }else{
        this.authService.setAuth(authObj).then(()=>{
          if(!this.authService.user){
            this.router.navigate(['profile']).then(()=>AppSession.loadingSpinner=false);
          }else{
          this.router.navigate([targetRoute]).then(()=>AppSession.loadingSpinner=false);
          }
        });
      }
    });
  }
}


login(redirectPath: string = '/') {
  AppSession.loadingSpinner=true;
  // A desired redirect path can be passed to login method
  // (e.g., from a route guard)
  // Ensure Auth0 client instance exists
  this.auth0Client$.subscribe(async (client: Auth0Client) => {
  // Call method to log in
  await client.loginWithRedirect({
      redirect_uri: `${window.location.origin}`,
      appState: { target: redirectPath }
    })
  });
}

logout() {
  // Ensure Auth0 client instance exists
  this.auth0Client$.subscribe((client: Auth0Client) => {
    // Call method to log out
    client.logout({
      client_id: environment.auth.clientID,
      returnTo: `${window.location.origin}`
    });
    this.authService.removeAuth();
  });
}
}
