/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxLoadingModule } from 'ngx-loading';
import { MatCheckboxModule } from '@angular/material';

/**
 ** @name LoginModule
 ** @desc the login Module
 */

@NgModule({
  imports: [
    CommonModule,
    LoginRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    NgxLoadingModule.forRoot({
      backdropBackgroundColour: 'rgba(0,0,0,0.4)',
    }),
  ],
  declarations: [LoginComponent],
})
export class LoginModule {}
