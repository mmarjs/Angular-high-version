import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ProfileModule} from '../profile/profile.module';
import { CreatepharmacistprofileRoutingModule } from './createpharmacistprofile-routing.module';
import { CreatePharmacistProfileComponent } from './create-pharmacist-profile.component';

@NgModule({
  imports: [
    CommonModule,
    CreatepharmacistprofileRoutingModule,
    ProfileModule
  ],
  declarations: [CreatePharmacistProfileComponent]
})
export class CreatepharmacistprofileModule { }
