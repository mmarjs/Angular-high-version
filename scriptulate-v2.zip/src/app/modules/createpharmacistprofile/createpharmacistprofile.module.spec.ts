import { CreatepharmacistprofileModule } from './createpharmacistprofile.module';

describe('CreatepharmacistprofileModule', () => {
  let createpharmacistprofileModule: CreatepharmacistprofileModule;

  beforeEach(() => {
    createpharmacistprofileModule = new CreatepharmacistprofileModule();
  });

  it('should create an instance', () => {
    expect(createpharmacistprofileModule).toBeTruthy();
  });
});
