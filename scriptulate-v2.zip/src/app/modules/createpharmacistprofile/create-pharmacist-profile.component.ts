import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../core/services';
import { LoginService } from '../login/service/login.service';
@Component({
  selector: 'app-create-pharmacist-profile',
  templateUrl: './create-pharmacist-profile.component.html',
  styleUrls: ['./create-pharmacist-profile.component.css']
})
export class CreatePharmacistProfileComponent implements OnInit {

  constructor(private loginService:LoginService) { }

  ngOnInit() {
  }
  logoutUser(){
    this.loginService.logout();
  }

}
