import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatePharmacistProfileComponent } from './create-pharmacist-profile.component';

const routes: Routes = [
  {path: '', component: CreatePharmacistProfileComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreatepharmacistprofileRoutingModule { }
