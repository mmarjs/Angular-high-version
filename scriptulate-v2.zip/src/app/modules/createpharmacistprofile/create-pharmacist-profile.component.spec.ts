import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePharmacistProfileComponent } from './create-pharmacist-profile.component';

describe('CreatePharmacistProfileComponent', () => {
  let component: CreatePharmacistProfileComponent;
  let fixture: ComponentFixture<CreatePharmacistProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePharmacistProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePharmacistProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
