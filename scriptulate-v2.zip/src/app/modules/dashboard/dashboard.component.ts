import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import * as Reducers from '@app/reducers/index';
import { fetchMedicationMeta } from '@app/reducers/medication/medication.actions';
import { Store } from '@ngrx/store';
import { combineLatest, Observable } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';
import { MatDialog } from '@angular/material';
import { IdMeComponent } from './id-me/id-me.component';
import { LoginService } from '../login/service/login.service';
import { UserIdleService } from 'angular-user-idle';

@Component({
  selector: 'app-dashboard',
  templateUrl: './html/dashboard.component.html',
  styleUrls: [
    '../profiledetail/mydialog/mydialog.component.scss',
    './scss/dashboard.component.scss'
  ]
})
export class DashboardComponent implements OnInit {
  profile$: Observable<object>;
  medicationLoaded$: Observable<object>;
  medicationLoading$: Observable<number>;
  menuName: string;
  role: any;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private store: Store<Reducers.State>,
    private _snackBar: MatSnackBar,
    private dialog: MatDialog,
    private loginService: LoginService,
    private userIdleService: UserIdleService
  ) {
    this.menuName = "Today's Patient";
  }

  ngOnInit() {
    // setTimeout(() => this.dialog.open(IdMeComponent), 1000);
    //Start watching for user inactivity.
    this.userIdleService.startWatching();
    this.userIdleService.onTimerStart().subscribe(count => console.log(count));
    // Start watch when time is up.
    this.userIdleService.onTimeout().subscribe(() => this.loginService.logout());
    const profile$ = this.store.select(state => state.auth.user);
    const medicationLoaded$ = this.store.select(
      state => state.medication.loaded
    );
    this.medicationLoading$ = this.store.select(
      state => state.medication.loading_progress
    );

    combineLatest(profile$, this.medicationLoading$, medicationLoaded$)
      .pipe(
        map(data => data),
        debounceTime(0),
        map(data => data)
      )
      .subscribe(([profile, medicationLoading, medicationLoaded]) => {
        if (medicationLoading !== 100 && !medicationLoaded) {
          this.store.dispatch(fetchMedicationMeta());
          return;
        }

        if (medicationLoading === 100 && !medicationLoaded) {
          this._snackBar.open('Failed to load your environment data.', null, {
            verticalPosition: 'bottom',
            horizontalPosition: 'end'
          });

          return;
        }

        if (profile.require_profile_complete) {
          return this.router.navigate(['profile'], {
            queryParams: {
              role: profile['role'],
              user_id: profile['id']
            }
          });
        } else if (profile.role) {
          this.router.navigate([`dashboard/${profile['role'].toLowerCase()}`], {
            /*	queryParams: {	my_user_id: profile['id'] } */
          });
        }
      });
  }
}
