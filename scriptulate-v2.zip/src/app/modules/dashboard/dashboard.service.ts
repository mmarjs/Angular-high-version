/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../core/config/RelativeUrlConfig';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
/**
 * @author Rajat Mathur
 * @name MyDashboardService
 * @desc This is a configuration file and contains the enviroment specific configuration
 */
export class MyDashboardService {
  BASE_URL = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) {}

  /**
   * @name getMyPatients
   * @desc Search Patients
   * @param params
   */
  getMyPatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_DIALOG;
    return this.httpResourceService.post(url, params);
  }
  getMyPatient(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_PATIENT;
    return this.httpResourceService.get(url, params);
  }

  getMyDischargePatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_DISCHARGE_PATIENTS;

    return this.httpResourceService.get(url, params);
  }

  getMyActivePatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_ACTIVE_PATIENTS;
    return this.httpResourceService.get(url, params);
  }
}
