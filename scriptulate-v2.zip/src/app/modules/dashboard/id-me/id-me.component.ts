import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { BindIDme } from './load-button';

@Component({
  selector: 'app-id-me',
  templateUrl: './id-me.component.html',
  styleUrls: ['./id-me.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class IdMeComponent implements OnInit, AfterViewInit {

  // <script src="https://s3.amazonaws.com/idme/developer/idme-buttons/assets/js/idme-wallet-button.js"></script>

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
    BindIDme();
  }

}
