import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IdMeComponent } from './id-me.component';

describe('IdMeComponent', () => {
  let component: IdMeComponent;
  let fixture: ComponentFixture<IdMeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IdMeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IdMeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
