import { IDme } from "./util";

const domain = "https://s3.amazonaws.com/idme/developer/idme-buttons/";

export const BindIDme = () => {
    const button = document.getElementById('idme-wallet-button');
    console.log(button);
    const scope = button.getAttribute("data-scope");
    const client = button.getAttribute("data-client-id");
    const redirect = button.getAttribute("data-redirect");
    const response = button.getAttribute("data-response");
    const state = button.getAttribute("data-state");
    const display = button.getAttribute("data-display");
    const logo = button.getAttribute("data-logo");
    const hero = button.getAttribute("data-hero");
    const text = button.getAttribute("data-text");
    const verify = button.getAttribute("data-show-verify");
    const hlp = button.getAttribute("data-hlp");
    const type = button.getAttribute("data-type");
    const country = button.getAttribute("data-country");
    const language = button.getAttribute("data-language");
    const multiple = scope.split(",").length > 1;

    // build widget parameters
    let params = "";

    if (scope && multiple) {
        params += "&scopes=" + scope;
    } else {
        params += "&scope=" + scope;
    }

    if (hlp) params += "&hlp=" + hlp;
    if (hero) params += "&hero_url=" + hero;
    if (logo) params += "&logo_url=" + logo;
    if (state) params += "&state=" + state;
    if (client) params += "&client_id=" + client;
    if (redirect) params += "&redirect_uri=" + redirect;
    if (response) params += "&response_type=" + response;
    if (country) params += "&country=" + country;
    if (language) params += "&language=" + language;

    if (type) {
        params += "&type=" + type
    } else {
        params += "&type=button"
    }

    let buttonLink = null;

    if (hlp) {
        buttonLink = hlp;
    } else if (multiple) {
        buttonLink = "https://groups.id.me/?" + params;
    } else {
        buttonLink = "https://api.id.me/oauth/authorize?" + params;
    }

    const container = document.createElement("span");
    const trigger = document.createElement("div");
    const buttonElem = document.createElement("a");
    // const description = document.createElement("span");

    container.id = "idme-verification";
    trigger.className = "idme-trigger";
    buttonElem.className = "idme-trigger-link idme-unify-button";
    // description.className = "idme-description"

    // description.innerHTML = 'Verification by ID.me • <a href="https://www.id.me/about" target="_new">What is ID.me?</a>'

    // display offer text if present
    if (text) {
        const offer = document.createElement("span");

        offer.className = "idme-text";
        offer.innerHTML = text;

        trigger.appendChild(offer);
    }

    // toggle popup user experience
    if (display === "popup") {
        const clickHandler = function () {
            new IDme.Util.Popup(buttonLink, 775, 850, window.innerWidth, window.innerHeight);
        };

        buttonElem.href = "javascript:void(0);";
        buttonElem.onclick = clickHandler;
    } else {
        buttonElem.href = buttonLink;
        buttonElem.target = "_parent";
    }

    buttonElem.innerHTML = '<img src="' + domain + 'assets/img/verify-with-idme.png" alt="ID.me Logo"/>';

    trigger.appendChild(buttonElem);

    // display what is ID.me show verify true
    if (verify) {
        const description = document.createElement("span");

        description.className = "idme-description";
        description.innerHTML = 'Verification by ID.me • <a href="https://www.id.me/about" target="_new">What is ID.me?</a>';

        trigger.appendChild(description);
    }

    container.appendChild(trigger);

    // insert after widget
    button.parentNode.insertBefore(container, button.nextSibling);

    // remove widget
    button.remove();

    window['IDme'] = IDme;
}
