// Query parameter management
function Query(input) {
    this.input = input;

    this.fetch = function (key, defaultValue) {
        key = key.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var input = "[\\?&]" + key + "=([^&#]*)";
        var regex = new RegExp(input);
        var token = regex.exec(this.input);

        if (token == null) {
            return (defaultValue !== undefined) ? defaultValue : null
        } else {
            return token[1];
        }
    };
}

function Popup(link, width, height, parentWidth, parentHeight) {
    var screenLeft = window.screenLeft !== undefined ? window.screenLeft : screen['left'];
    var screenTop = window.screenTop !== undefined ? window.screenTop : screen['top'];

    var left = ((parentWidth / 2) - (width / 2)) + screenLeft;
    var top = ((parentHeight / 2) - (height / 2)) + screenTop;

    var opened = window.open(link, "", 'scrollbars=yes, width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);

    if (window.focus) opened.focus();
}

export const IDme = {
    Util: {
        Popup: Popup,
        Query: Query
    }
};
