/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '@app/core/config/environmentConfig';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { Observable } from 'rxjs';
import { AuthService } from '@app/core/services';
@Injectable({
  providedIn: 'root',
})
export class DoctorService {
  BASE_URL = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService, private authService: AuthService) {}

  getDoctors(){
    var user = this.authService.user;
    return this.httpResourceService.get(RelativeUrlConfig.PROFILE,{})
  }

  getDoctorsAndPharmacists() {
    var user = this.authService.user;
    return this.httpResourceService.get(RelativeUrlConfig.PROFILE,{})
  }

  addMyPatient(doctorId, patientId, birthdate) {
    let url = RelativeUrlConfig.ADD_MY_PATIENT;
    url = url.replace('{{patient_id}}', patientId);
    url = url.replace('{{doctor_id}}', doctorId);
    url = url.replace('{{birthdate}}', birthdate);
    return this.httpResourceService.post(url, {});
  }

  getMyPatients(doctorId): Observable<any> {
    let url = RelativeUrlConfig.MY_ACTIVE_PATIENTS;
    url = url.replace('{{doctor_id}}', doctorId);
    return this.httpResourceService.get(url, {});
  }

  createPrescription(formData: any) {
    const url: string = RelativeUrlConfig.CREATE_PRESCRIPTION;
    return this.httpResourceService.post(url, formData);
  }

  getPrescriptions(params: any) {
    const url: string = RelativeUrlConfig.GET_PRESCRIPTIONS;
    return this.httpResourceService.get(url, params);
  }

  syncPrescriptions(patientId, doctorId) {
    const url: string = RelativeUrlConfig.SYNC_PRESCRIPTIONS;
    return this.httpResourceService.post(url, {
      patient_id: patientId,
      doctor_id: doctorId,
    });
  }

  getPdmpReports({ doctor_id, patient_id }) {
    const url: string = RelativeUrlConfig.FILES;
    return this.httpResourceService.get(url, {
      uploaded_for_user_id: patient_id,
      uploaded_by_user_id: doctor_id,
      file_category: ['pdmp_report','chart_report']
    });
  }

  getApprissReports({ doctor_id, patient_id }) {
    const url: string = RelativeUrlConfig.FILES;
    return this.httpResourceService.get(url, {
      uploaded_for_user_id: patient_id,
      uploaded_by_user_id: doctor_id,
      file_category: 'appriss_report',
    });
  }

  getContractDocs({ doctor_id, patient_id }) {
    const url: string = RelativeUrlConfig.FILES;
    return this.httpResourceService.get(url, {
      uploaded_for_user_id: patient_id,
      uploaded_by_user_id: doctor_id,
      file_category: 'agreement',
    });
  }

  getChecklistReports({ doctor_id, patient_id }) {
    const url: string = RelativeUrlConfig.FILES;
    return this.httpResourceService.get(url, {
      uploaded_for_user_id: patient_id,
      uploaded_by_user_id: doctor_id,
      file_category: 'checklist',
    });
  }

  getChecklists = ({ patient_id, doctor_id }) => {
    const url: string = RelativeUrlConfig.CHECKLISTS;
    return this.httpResourceService.get(
      url,
      {
        patient_id,
        created_by_user_id: doctor_id,
      },
    );
  }

  getAppointments({ doctor_id }) {
    const url: string = RelativeUrlConfig.APPOINTMENTS;
    return this.httpResourceService.get(url, {
      requested_by_user_id: doctor_id,
    });
  }

  createChecklist({ check_list_result, note, doctor_id, patient_id }) {
    const url = RelativeUrlConfig.CHECKLISTS;

    return this.httpResourceService.post(url, {
      check_list_result,
      note,
      patient_id,
      created_by_user_id: doctor_id,
    });
  }

  createAppointments(result:{payload:[{date, patient_id, doctor_id }]}) {
    const url = RelativeUrlConfig.APPOINTMENTS;
    let appointments = [];
    result.payload.forEach(element => {
      appointments.push({date:element.date,  
                         patient_id:element.patient_id,
                         requested_by_user_id:element.doctor_id})
    });
    return this.httpResourceService.post(url,appointments);
  }


  createAppointment({date,  patient_id,  doctor_id}) {
    return this.createAppointments({payload:[{date, patient_id, doctor_id }]});
  }

  createNote = (postData) => {
    const url = RelativeUrlConfig.NOTE;
    return this.httpResourceService.post(url, postData);
  }

  getNotes = ({ patient_id, doctor_id }) => {
    const url = RelativeUrlConfig.NOTE;
    const urlParams = {
      patient_id: patient_id,
      created_by_user_id: doctor_id,
    };
    return this.httpResourceService.get(url, urlParams);
  }

  getNotesChecklistsCombined = (params) => {
    const url = RelativeUrlConfig.FETCH_NOTES_CHECKLISTS_COMBINED;
    return this.httpResourceService.get(url, params);
  }
}
