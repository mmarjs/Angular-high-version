import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  fetchAllPatient,
  patientSearch
} from '@app/reducers/patient/patient.actions';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './html/dashboard-pharmacist.component.html',
  styleUrls: [
    '../profiledetail/mydialog/mydialog.component.scss',
    './scss/dashboard.component.scss'
  ]
})
export class DashboardPharmacistComponent implements OnInit {
  patients$: Observable<object>;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private store: Store<{ patient: any }>
  ) {
    this.patients$ = store.pipe(select(state => state.patient.searchList));
  }

  ngOnInit() {
    this.store.dispatch(fetchAllPatient());
  }

  createPatientProfile() {
    this.router.navigate(['createpatientprofile']);
  }

  public patientSearchOnChange(obj) {
    this.store.dispatch(patientSearch(obj));
  }

  showdata(id) {
    this.router.navigate(['patient-nav'], {
      queryParams: { patient_id: id },
      skipLocationChange: true
    });
  }

  getLastSSN= (ssn_str: string) => {
    if (!ssn_str) {
      return 'N/A';
    }
    if (ssn_str.length === 0) {
      return 'N/A';
    }

    const tmp = ssn_str.split('-');
    if (tmp && tmp.length) {
      return tmp[tmp.length - 1];
    } else {
      return ssn_str;
    }
  }
}
