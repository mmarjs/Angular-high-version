import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { DashboardDoctorComponent } from './dashboard-doctor.component';
import { DashboardPatientComponent } from './dashboard-patient.component';
import { DashboardPharmacistComponent } from './dashboard-pharmacist.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'patient',
    data: {
      breadcrumb: 'Patient',
    },
    component: DashboardPatientComponent
  },
  {
    path: 'doctor',
    data: {
      breadcrumb: 'Doctor',
    },
    component: DashboardDoctorComponent
  },
  {
    path: 'pharmacist',
    data: {
      breadcrumb: 'Pharmacist',
    },
    component: DashboardPharmacistComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
