import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import * as Reducers from '@app/reducers/index';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { VideoViewComponent } from './video-view/video-view.component';
import { selectAlerts, alertsFetched } from '@app/reducers/alert/alert.reducer';
import { PusherService } from '@app/core/services/pusherService/pusher.service';
import { removeAlert, getAlerts } from '@app/reducers/alert/alert.actions';
import { getPatientPrescriptionsById } from '@app/reducers/prescription/prescription.reducer';
import { Constants } from '@app/core/config/constants';
import { getTodos } from '@app/reducers/todo/todo.reducer';
import { fetchTodos, removeTodo } from '@app/reducers/todo/todo.actions';
import { getContracts, updateContract } from '@app/reducers/contracts/contracts.actions';
import { TodoDialogComponent } from './todo-dialog/todo-dialog.component';
import { ContractsService } from '@app/core/services/contractsService/contracts.service';
import { UploadService, AuthService } from '@app/core/services';
import { DoctorsPharmacistsState } from '@app/reducers/doctor/doctor.reducer';
import { selectContracts, contractsFetched } from '@app/reducers/contracts/contracts.reducer';

@Component({
  selector: 'app-dashboard',
  templateUrl: './html/dashboard-patient.component.html',
  styleUrls: ['../profiledetail/mydialog/mydialog.component.scss', './scss/dashboard.component.scss']
})
export class DashboardPatientComponent implements OnInit {
  m_prescriptions$: Observable<object>;
  me$: Observable<object>;
  m_medication$: Observable<object>;
  alerts$: Observable<any>;
  menuName: string;
  dateValue: string;
  searchText: string;
  m_takingPres = [];
  m_pastPres = [];
  m_frequencies = [];

  m_videos = [
    {
      id: 'mh6dyPHWAMA',
      url: 'https://www.youtube.com/watch?v=mh6dyPHWAMA',
      title: 'Keep Your Family Safe From Unused Opioid Pain Medicines',
      thumbenail: 'https://img.youtube.com/vi/mh6dyPHWAMA/default.jpg'
    },
    {
      id: 'WZdaVj68_Hw',
      url: 'https://www.youtube.com/watch?v=WZdaVj68_Hw',
      title: 'Opioids plus Benzos: A Dangerous Combination',
      thumbenail: 'https://img.youtube.com/vi/WZdaVj68_Hw/default.jpg'
    },
    {
      id: 'SkAqOditKN0',
      url: 'https://www.youtube.com/watch?v=SkAqOditKN0',
      title: 'Managing Chronic Pain without Narcotics| UCLA Health',
      thumbenail: 'https://img.youtube.com/vi/SkAqOditKN0/default.jpg'
    },
    {
      id: 'DNh13zCQ_lQ',
      url: 'https://www.youtube.com/watch?v=DNh13zCQ_lQ',
      title: 'Chronic Pain And Fibromyalgia Exercise Program',
      thumbenail: 'https://img.youtube.com/vi/DNh13zCQ_lQ/default.jpg'
    }
  ];

  todos$: Observable<any>;
  contracts = [];
  doctorsAndPharmacists$: Observable<any>;
  doctors_and_pharmacists: DoctorsPharmacistsState;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public dialog: MatDialog,
    public pusherService: PusherService,
    private contractsService: ContractsService,
    private uploadService: UploadService,
    private store: Store<Reducers.State>,
    private authService: AuthService
  ) {
    this.m_medication$ = this.store.select((state: Reducers.State) => state.medication);
    this.me$ = store.pipe(select(state => state.auth.user));
    this.alerts$ = store.select(selectAlerts);
    this.todos$ = store.select(getTodos);
    this.doctorsAndPharmacists$ = this.store
      .select((state: Reducers.State) => {
        const { doctors, doctors_and_pharmacists } = state.doctor;
        return { doctors, doctors_and_pharmacists };
      });
  }

  ngOnInit() {
    this.store.select(alertsFetched).subscribe(isFetched => {
      if (!isFetched) {
        this.store.dispatch(getAlerts());
      }
    });
    this.store.dispatch(fetchTodos({payload: this.authService.user.id}));
    this.store.select(contractsFetched).subscribe(isFetched => {
      if (!isFetched) {
        this.store.dispatch(getContracts());
      }
    });
    this.store.select(selectContracts).subscribe(
      contracts => {
        if (contracts) {
          this.contracts = contracts;
        }
      }
    );
    this.me$.subscribe(myProfile => {
      if (myProfile['id']) {
        this.m_prescriptions$ = this.store.select(state =>
          getPatientPrescriptionsById(state, { patient_id: myProfile['id'] })
        );
        this.checkTakingDrugs();
      }
    });
    this.m_medication$.subscribe(medication => {
      if (medication) {
        this.m_frequencies = medication['drug_frequency'];
      }
    });
    this.doctorsAndPharmacists$.subscribe(({ doctors_and_pharmacists }) => {
      this.doctors_and_pharmacists = doctors_and_pharmacists;
    });
    this.pusherService.alertsSubscribe();
    this.pusherService.todosSubscribe();
  }

  checkTakingDrugs() {
    this.m_takingPres = [];
    this.m_pastPres = [];
    this.m_prescriptions$.subscribe((prescriptions: [any]) => {
      if (prescriptions) {
        prescriptions.forEach((p, i) => {
          if (this.isTakingDrug(p)) {
            this.m_takingPres.push(p);
          }
          if (!this.isTakingDrug(p)) {
            this.m_pastPres.push(p);
          }
        });
      }
    });
  }

  getFrequency(prescription) {
    const { frequency } = prescription;
    for (let i = 0; i < this.m_frequencies.length; i++) {
      if (this.m_frequencies[i].abbreviation === frequency) {
        return this.m_frequencies[i].description;
      }
    }
  }

  isTakingDrug = (prescription): boolean => {
    const today = new Date().getTime();
    const delta =
      new Date(prescription.date_prescribed).getTime() +
      (parseInt(prescription.number_of_days, 10) + Constants.PRESCRIPTION_BUFFER) * 24 * 3600 * 1000;
    return today < delta ? true : false;
  }

  getCompletionDate(start, diff) {
    const date_msec = Date.parse(start);
    const diff_msec = parseInt(diff, 10) * 24 * 3600 * 1000;
    return new Date(date_msec + diff_msec);
  }

  closeAlert(alert: any) {
    this.store.dispatch(removeAlert(alert));
  }

  openVideoView(v_url): void {
    this.dialog.open(VideoViewComponent, {
      width: '60vw',
      height: '40vw',
      panelClass: 'video_modal',
      data: {
        url: v_url
      }
    });
  }

  openTodo(todo) {
    if (todo.name === 'SIGN_CONTRACT') {
      const contract = this.contracts.find(c => todo.requested_by_user_id === c.doctor_id && todo.patient_id === c.patient_id);
      const { doctor, patient } = contract;
      const ref = this.dialog.open(TodoDialogComponent, { data: { todo, ...contract } });
      ref.afterClosed().subscribe(async file => {
        if (!file) {
          return;
        }
        const { result } = await this.uploadService.upload({
          file_name: file.name,
          uploaded_by_user_id: patient.id,
          uploaded_for_user_id: doctor.id,
          file_category: 'agreement',
          file,
          file_type: file.type
        });
        if (!result) {
          return;
        }
        this.store.dispatch(updateContract(contract.id, {
          active: true,
          started_at: new Date(),
          signed_document_id: result.body.id
        }));
        this.store.dispatch(removeTodo(todo));
      });
    } else {
      const ref = this.dialog.open(TodoDialogComponent, { data: { todo } });
      ref.afterClosed().subscribe(mark_as_completed => {
        if (mark_as_completed) {
          this.removeTodo(todo);
        }
      });
    }
  }

  removeTodo(todo) {
    this.store.dispatch(removeTodo(todo));
  }

  handlePrescriberPharmacistInfo = (id) => {
    if (!id) {
      return 'N/A';
    }
    const user = this.doctors_and_pharmacists.entities[id];
    const { first_name, last_name } = user;
    return `${first_name} ${last_name}`;
  }
}
