import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-video-view',
  templateUrl: './video-view.component.html',
  styleUrls: ['./video-view.component.scss']
})
export class VideoViewComponent implements OnInit {
  m_url = '';
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { 
    this.m_url = `https://www.youtube.com/embed/${data.url}`;
  }

  ngOnInit() {

  }

}
