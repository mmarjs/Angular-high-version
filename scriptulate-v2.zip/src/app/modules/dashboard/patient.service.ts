import { Injectable } from '@angular/core';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  constructor(private httpResourceService: HttpResourceService) {}

  fetchAll(params: any): Observable<any> {
    const url = RelativeUrlConfig.FETCH_ALL_PATIENTS;
    return this.httpResourceService.get(url, params);
  }

  searchPatient(obj: any): Observable<any> {
    const url = RelativeUrlConfig.SEARCH_PATIENTS;
    return this.httpResourceService.post(url, obj);
  }
}
