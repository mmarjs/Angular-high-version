export class MyPatient {
  public id: Number;
  public firstName: String;
  public middleName: String;
  public lastName: String;
  public dob: any;
  public addressLine1: String;
  public ssn: any;
}
