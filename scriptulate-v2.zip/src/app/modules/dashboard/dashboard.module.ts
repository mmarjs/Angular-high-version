import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { DashboardDoctorComponent } from './dashboard-doctor.component';
import { DashboardPatientComponent } from './dashboard-patient.component';

import { DashboardPharmacistComponent } from './dashboard-pharmacist.component';

import { EffectsModule } from '@ngrx/effects';
import {
  MatDialogModule,
  MatButtonModule,
  MatDatepickerModule,
  MatInputModule,
  MatFormFieldModule,
  MatIconModule,
} from '@angular/material';
import { NgPipesModule } from 'ngx-pipes';
import { MomentModule } from 'ngx-moment';

import { MydialogComponent } from '../profiledetail/mydialog/mydialog.component';
import { NewPatientProfileComponent } from '../profiledetail/new-patientprofile/new-patientprofile.component';
import { ProfiledetailModule } from '../profiledetail/profiledetail.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { UserFilterPipe } from './dashboard.filter';
import { TextMaskModule } from 'angular2-text-mask';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { DoctorEffects } from '@app/reducers/doctor/doctor.effects';
import { PatientEffects } from '@app/reducers/patient/patient.effects';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { VideoViewComponent } from './video-view/video-view.component';
import { TodoDialogComponent } from './todo-dialog/todo-dialog.component';
import { SharedModule } from '@app/common/modules/shared/shared.module';
import { BypassSecurityUrlPipeModule } from '@app/common/pipes/bypass-security-url/bypass-security-url.module';
import { IdMeComponent } from './id-me/id-me.component';
import { AngularSvgIconModule } from 'angular-svg-icon';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MatDialogModule,
    MatButtonModule,
    ProfiledetailModule,
    FormsModule,
    ReactiveFormsModule,
    MatMenuModule,
    TextMaskModule,
    MatDatepickerModule,
    MatDialogModule,
    MatFormFieldModule,
    MatProgressBarModule,
    MatInputModule,
    MatIconModule,
    NgPipesModule,
    MomentModule,
    EffectsModule.forFeature([DoctorEffects, PatientEffects]),
    SharedModule,
    BypassSecurityUrlPipeModule,
    AngularSvgIconModule,
  ],
  entryComponents: [MydialogComponent, VideoViewComponent, TodoDialogComponent, IdMeComponent, NewPatientProfileComponent],
  declarations: [
    DashboardComponent,
    DashboardDoctorComponent,
    DashboardPatientComponent,
    DashboardPharmacistComponent,
    UserFilterPipe,
    EditProfileComponent,
    VideoViewComponent,
    TodoDialogComponent,
    IdMeComponent
  ],
})
export class DashboardModule {}
