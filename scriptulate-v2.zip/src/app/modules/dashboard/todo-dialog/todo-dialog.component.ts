import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { PdfViewerComponent } from '@app/common/modules/shared/components/pdf-viewer/pdf-viewer.component';

@Component({
  selector: 'app-todo-dialog',
  templateUrl: './todo-dialog.component.html',
  styleUrls: ['./todo-dialog.component.scss']
})
export class TodoDialogComponent implements OnInit {
  todo: any;
  contract: any;
  document: any;
  title: string;

  filename = '';
  fileUploaded: File;

  @ViewChild('file')
  file: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<TodoDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.todo = this.data.todo;
    if (this.todo.name === 'SIGN_CONTRACT') {
      const { doctor, document, ...contract } = this.data;
      this.contract = contract;
      this.document = document;
      this.title = `Sign the Pain Contract from ${doctor.first_name}`;
    } else {
      this.title = this.todo.comment;
    }
  }

  cancel() {
    this.dialogRef.close();
  }

  upload() {
    this.file.nativeElement.click();
  }

  onUploaded() {
    this.fileUploaded = this.file.nativeElement.files[0];
    this.file.nativeElement.value = null;
    const { name } = this.fileUploaded;
    this.filename = name.length > 30 ? name.substring(0, 30) + '...' : name;
  }

  submit() {
    if (this.todo.name === 'SIGN_CONTRACT') {
      if (!this.fileUploaded)
        return;
      this.dialogRef.close(this.fileUploaded);
    } else {
      this.dialogRef.close(true);
    }
  }

  openPDF(attachment?) {
    const ref = this.dialog.open(PdfViewerComponent, {
      panelClass: 'pdf-viewer-modal'
    });
    if (attachment) {
      ref.componentInstance.fileurl = attachment.url;
      ref.componentInstance.filename = attachment.name;
      ref.componentInstance.editable = false;
    } else {
      ref.componentInstance.fileurl = this.document.file_location;
      ref.componentInstance.filename = this.document.file_name;
    }
    ref.afterClosed().subscribe(res => {
      if (!res)
        return;
      this.fileUploaded = res;
      const { name } = this.fileUploaded;
      this.filename = name.length > 30 ? name.substring(0, 30) + '...' : name;
    });
  }
}
