import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { PdfHelperService } from '../../core/services/pdf-helper/pdf-helper.service';
import { sortByFirstAndLastNames } from '@app/helpers';
import {
  getMyPatients,
  addPatient,
  createAppointment,
  getAppointmentForPatient,
  addPatientSuccess,
  syncPrescriptions,
  addApprissReport
} from '@app/reducers/doctor/doctor.actions';
import {
  myActivePatients,
  myTodayPatients,
  myPatientsFetched,
} from '@app/reducers/doctor/doctor.reducer';
import * as Reducers from '@app/reducers/index';
import {
  fetchAllPatient,
  patientSearch
} from '@app/reducers/patient/patient.actions';
import { Store, select } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { MydialogComponent } from '../profiledetail/mydialog/mydialog.component';
import {
  TodoCreateModalComponent
} from '@app/common/modules/shared/components/todo-create-modal/todo-create-modal.component';
import { PainScreeningDialogComponent } from 'app/modules/profiledetail/pain-screening-dialog/pain-screening-dialog.component';
import { StatePdmpReportComponent } from '../profiledetail/state-pdmp-report/state-pdmp-report.component';
import {
  ContractsDialogComponentComponent
} from '../profiledetail/contracts-dialog-component/contracts-dialog-component.component';
import {
  DiversionInitiateModalComponent,
  // DiversionCompleteModalComponent,
} from 'app/modules/profiledetail/patient-request/modals/diversion-initiate-modal/diversion-initiate-modal.component';
import { UrineCreateModalComponent } from 'app/modules/profiledetail/patient-request/modals/urine-create-modal/urine-create-modal.component';
import { MyappointmentComponent } from '../profiledetail/myappointment/myappointment.component';
import { MyshortcutsComponent } from '../profiledetail/myshortcuts/myshortcuts.component';
import { SetAppointmentComponent } from '@app/modules/profiledetail/set-appointment/set-appointment.component';
import { selectAlerts, Alert, alertsFetched } from '@app/reducers/alert/alert.reducer';
import { getTodos } from '@app/reducers/todo/todo.reducer';
import { listTodos } from '@app/reducers/todo/todo.actions';
import { PusherService } from '@app/core/services/pusherService/pusher.service';
import { removeAlert, getAlerts } from '@app/reducers/alert/alert.actions';
import { selectContracts, contractsFetched } from '@app/reducers/contracts/contracts.reducer';
import { getContracts } from '@app/reducers/contracts/contracts.actions';
import { Patient, formatSearchlistWithLatestAppointment } from '@app/reducers/patient/patient.reducer';
import { MaterialService } from '@app/core/services';
import * as _ from 'lodash';
import matchSorter from 'match-sorter';
import { combineLatest } from 'rxjs';
import { Doctor, selectDoctor, State, AppointmentsState } from '@app/reducers/doctor/doctor.reducer';
import { takeUntil } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Actions, ofType } from '@ngrx/effects';
import { User } from '@app/reducers/auth/auth.reducer';
import { AuthService } from '@app/core/services';
import * as moment from 'moment';
import { NewNoteDialogComponent } from '../profiledetail/new-note-dialog/new-note-dialog.component';
@Component({
  selector: 'app-dashboard',
  templateUrl: './html/dashboard-doctor.component.html',
  styleUrls: [
    '../profiledetail/mydialog/mydialog.component.scss',
    './scss/dashboard.component.scss'
  ]
})
export class DashboardDoctorComponent implements OnInit, OnDestroy {
  activePatients$: Observable<Array<Patient>>;
  alerts$: Observable<any>;
  contracts$: Observable<any>;
  me$: Observable<object>;
  patients$: Observable<Array<Patient>>;
  showPatients$: Observable<Array<Patient>>;
  todayPatients$: Observable<Array<Patient>>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();

  dateValue: string;
  doctorAppointments: AppointmentsState;
  doctorId: number;
  menuName: string;
  activePatients: Array<Patient>;
  alerts: Array<Alert>;
  searchList: Array<any>;
  searchText: string;
  selectedTime: '';
  testModel: '';
  todayPatients: Array<Patient>;
  ACTIVE_PATIENTS = 'Active Patients';
  TODAYS_PATIENTS = 'Today\'s Patients';
  user : User;
  todos$: Observable<any>;
  todayTodos: [];
  upcommingTodos: [];
  today = moment();
  shortcut_options: object[] = [
    {
      option_name: 'UDT Screen',
      checked: false
    },
    {
      option_name: 'Diversion Check',
      checked: false
    },
    {
      option_name: 'Pain Contract(s)',
      checked: false
    },
    {
      option_name: 'PEG Scores',
      checked: false
    },
    {
      option_name: 'Checklists',
      checked: false
    },
    {
      option_name: 'Reminders',
      checked: false
    },
    {
      option_name: 'Notes',
      checked: false
    },
    {
      option_name: 'Sync PDMP Reports',
      checked: true
    },
    {
      option_name: 'View State PDMP',
      checked: true
    }
  ];


  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public dialog: MatDialog,
    public modal: NgbModal,
    public pusherService: PusherService,
    private store: Store<Reducers.State>,
    private matService: MaterialService,
    private actions$: Actions,
    private authService: AuthService,
    private pdfHelperService: PdfHelperService,
    public bootstrapModal: NgbModal,
  ) {
    this.menuName = this.ACTIVE_PATIENTS;
    this.activePatients$ = store.select(myActivePatients);
    this.todayPatients$ = store.select(myTodayPatients);
    this.me$ = store.select(state => state.auth.user);
    this.alerts$ = store.select(selectAlerts);
    this.showPatients$ = this.activePatients$;
    this.contracts$ = store.select(selectContracts);
    this.store.select(selectDoctor).subscribe(({ appointments }) => {
      this.doctorAppointments = appointments;
      // console.log("DoctorAppointments", this.doctorAppointments)
    });
    this.todos$ = this.store.select(getTodos);
    this.todos$.subscribe(items => {
      this.todayTodos = items.filter(elem => moment(elem.due_date).isSame(moment().format('YYYY-MM-DD'), 'day'));
      this.upcommingTodos = items.filter(elem => moment(elem.due_date).isAfter(moment().format('YYYY-MM-DD'), 'day'));
    })

    this.matService.registerIcon('three_dots', 'assets/svgs/three_dots.svg');
    this.matService.registerIcon('thin_plus', 'assets/svgs/thin_plus.svg');
    this.matService.registerIcon('arrow_down', 'assets/images/arrow_down.svg');
  }

  createPatientProfile() {
    this.router.navigate(['createpatientprofile']);
  }

  showdata(id) {
    this.router.navigate(['patient-nav'], {
      queryParams: { patient_id: id },
      // skipLocationChange: true
    });
  }
  openMyDialog = (): void => {
    const mydialogRef = this.modal.open(
      MydialogComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.componentInstance.data = {
      doctor: this.me$,
      patients: this.patients$,
      patientSearchOnChange: searchObj =>{
        this.store.dispatch(patientSearch(searchObj));
      },
      addPatient: (doctor, patient) => {
        this.store.dispatch(addPatient({
          doctorId: doctor.id,
          patientId: patient.id, 
          birthdate: patient.birthdate }));
        this.afterAddPatientSuccessResetList();
        this.dialog.closeAll();
      },
    };

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }
  
  openAppointmentDialog = (): void => {
    const mydialogRef = this.modal.open(
      MyappointmentComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.componentInstance.data = {
      doctor: this.me$,
      patients: this.patients$,
      patientSearchOnChange: searchObj =>{
        this.store.dispatch(patientSearch(searchObj));
      },
      addPatient: (doctor, patient) => {
        this.store.dispatch(addPatient({
          doctorId: doctor.id,
          patientId: patient.id, 
          birthdate: patient.birthdate }));
        this.afterAddPatientSuccessResetList();
        this.dialog.closeAll();
      },
    };

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }

  handleSync(){
    this.searchList.forEach(patient => {
      this.store.dispatch(
        syncPrescriptions({ patientId: patient.id, doctorId: this.doctorId })
      );
    })
  }

  handleDownloadSync(){

  }

  handleOptionClick(option_name: string, patient: any){
    switch(option_name){
      case 'Sync PDMP Reports':
        this.store.dispatch(
          syncPrescriptions({ patientId: patient.id, doctorId: this.doctorId })
        );
        break;
      case 'View State PDMP':
        // const fileName = `Scriptulate_PDMPReport_${new Date().getTime()}.pdf`;
        // this.pdfHelperService.generatePdf(document.body, fileName).subscribe(pdf => {
        //     this.store.dispatch(addApprissReport({
        //         file_name: fileName,
        //         uploaded_by_user_id: this.doctorId,
        //         uploaded_for_user_id: + patient_id,
        //         file_category: 'pdmp_report',
        //         file_type: 'application/pdf',
        //         file: pdf.output('blob'),
        //     }));
        // });

        // this.patient['reportChecked'] = true;
        const statePdmpReportRef = this.bootstrapModal.open(
          StatePdmpReportComponent,
          { windowClass: 'ngb-modal-size-94rem', backdrop: 'static' },
        );

        statePdmpReportRef.componentInstance.data = {
          patient: patient,
          doctorId: this.doctorId,
        };

        statePdmpReportRef.result.then(res => {
          return;
        }).catch(err => { });
        break;
      case 'Notes':
        const newNoteRef = this.bootstrapModal.open(NewNoteDialogComponent, { size: 'lg' });
        newNoteRef.componentInstance.data = {
          patientId: patient.id,
          doctorId: this.doctorId,
        };
        newNoteRef.result.then(res => {
          return;
        }).catch(err => console.error(err));
        break;
      case 'Reminders':
        if(this.user && this.user.role=='Doctor'){
          const urineCreateRef = this.modal.open(TodoCreateModalComponent, { size: 'lg' });
          urineCreateRef.componentInstance.data = {
            patientId: patient.id,
            doctorId: this.doctorId,
          };
          urineCreateRef.result
            .then(res => {urineCreateRef.close(); return; })
            .catch(err => console.error(err));
        }
        break;
      case 'Checklists':
        this.router.navigate(['patient-nav/checklists'], {
          queryParams: { patient_id: patient.id },
          skipLocationChange: true
        });
        break;
      case 'PEG Scores':
        const pegPainScreeningModalRef = this.bootstrapModal.open(PainScreeningDialogComponent, { windowClass: 'ngb-modal-size-1140' });
        pegPainScreeningModalRef.componentInstance.data = {
          patientId: patient.id,
          doctorId: this.doctorId,
        };
        pegPainScreeningModalRef.result.then(res => {
          return;
        }).catch(err => console.error(err));
        break;
      case 'Pain Contract(s)':
        const pastReportsRef = this.bootstrapModal.open(
          ContractsDialogComponentComponent,
          { size: 'lg', backdrop: 'static', windowClass: 'ngb-modal-past-reports' },
        );
        pastReportsRef.componentInstance.data = {
          patient_id: patient.id,
          doctor_id: this.doctorId,
        };
    
        pastReportsRef.result.then(res => {
          return;
        }).catch(err => console.error(err));
        break;
      case 'Diversion Check':
        const diversionInitiateModalRef = this.modal.open(DiversionInitiateModalComponent, { size: 'lg' });
        diversionInitiateModalRef.componentInstance.data = {
          patientId: patient.id,
          doctorId: this.doctorId,
        };

        diversionInitiateModalRef.result
          .then(res => { return; })
          .catch(err => console.error(err));
        break;
      case 'UDT Screen':
        const urineCreateRef = this.modal.open(UrineCreateModalComponent, { size: 'lg' });
        urineCreateRef.componentInstance.data = {
          patientId: patient.id,
          doctorId: this.doctorId,
        };

        urineCreateRef.result
          .then(res => { return; })
          .catch(err => console.error(err));
            break;
        }
  }
  handleCustomizeOptionsClick = () => {
    const mydialogRef = this.modal.open(
      MyshortcutsComponent, { size: 'lg' }
    );

    mydialogRef.componentInstance.data = {
      shortcut_options: this.shortcut_options
    };

    mydialogRef.result.then(_res => {
      if(_res){
        
      }
    }).catch(_err => {});
  }

  showAppointmentDialog(patient) {
    const setAppointmentRef = this.modal.open(SetAppointmentComponent, { size: 'lg' });
    setAppointmentRef.componentInstance.data = {
      patient,
    };
    setAppointmentRef.result.then(res => {
      if (res) {
        if (!res.date || !res.patient_id) {
          return;
        }
        const { date, patient_id } = res;
      
        this.store.dispatch(createAppointment({payload: [{
          patient_id,
          date,
          doctor_id: this.doctorId
          }]}));
      }
    }).catch(_err => {});
  }

  closeAlert(alert: any) {
    this.store.dispatch(removeAlert(alert));
  }

  trackByPatient = (index, patient) => {
    return patient;
  }

  setPatientList = (type) => {
    this.activePatients$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(data => (this.activePatients = data));
    this.todayPatients$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(data => (this.todayPatients = data));
    if (type === this.TODAYS_PATIENTS) {
      this.searchList = this.todayPatients;
      this.menuName = this.TODAYS_PATIENTS;
      return;
    }
    this.searchList = this.activePatients;
    this.menuName = this.ACTIVE_PATIENTS;
  }

  searchPatientOnChange = (searchValue: string) => {
    if (this.menuName === this.ACTIVE_PATIENTS) {
      if (_.isEmpty(searchValue)) {
        this.searchList = this.activePatients;
      } else {
        this.searchList = matchSorter(this.activePatients, searchValue, {
          keys: ['first_name', 'last_name']
        });
      }
    }

    if (this.menuName === this.TODAYS_PATIENTS) {
        if (_.isEmpty(searchValue)) {
          this.searchList = this.todayPatients;
        } else {
          this.searchList = matchSorter(this.todayPatients, searchValue, {
            keys: ['first_name', 'last_name']
          });
        }
    }
  }

  afterAddPatientSuccessResetList = () => {
    this.actions$.pipe(ofType(addPatientSuccess)).subscribe(action => {
      if (action.type) {
        this.store.dispatch(fetchAllPatient());
        this.setPatientList(this.ACTIVE_PATIENTS);
      }
    });
  }

  ngOnInit() {
    var options =  JSON.parse(localStorage.getItem("options"));
    if(options){
      this.shortcut_options = options;
    }
    combineLatest(
      this.store.select((state: Reducers.State) => state.patient),
      this.me$,
      this.store.select(myPatientsFetched),
      this.store.select(alertsFetched),
      this.store.select(contractsFetched),
      this.store.pipe(select(formatSearchlistWithLatestAppointment)),
    ).subscribe(([
      patientState,
      user,
      areMyPatientsFetched,
      areAlertsFetched,
      areContractsFetched,
      formattedPatients,
    ]: [ any, Doctor, boolean, boolean, boolean, any ]) => {
      if (!patientState.fetched) {
        this.store.dispatch(fetchAllPatient());
      }

      if (user.id) {
        this.user = user;
        this.doctorId = user.id;

        if (!areMyPatientsFetched) {
          this.store.dispatch(getMyPatients({ doctorId: user.id }));
        }

        this.store.dispatch(getAppointmentForPatient({
          doctor_id: user.id
        }));
      }

      this.patients$ = formattedPatients;
      this.setPatientList(this.ACTIVE_PATIENTS);

      if (!areAlertsFetched) {
        this.store.dispatch(getAlerts());
      }

      if (!areContractsFetched) {
        this.store.dispatch(getContracts());
      }

    });
    this.pusherService.alertsSubscribe();
    this.afterAddPatientSuccessResetList();
    const date = new Date();
    this.dateValue = date.toLocaleDateString();
    this.store.dispatch(listTodos({payload: this.authService.user.id}));
  }

  onDatePickerChange(event){
    this.setPatientList(this.ACTIVE_PATIENTS);
    this.dateValue = event;
    const { ids, entities } = this.doctorAppointments;
    let id = null;
    let appointment = null;
    const appointmentsByDate = [];
    if (!this.searchList) {
      return [];
    }
    for (let i = 0; i < ids.length; i++) {
      id = ids[i];
      if (!entities[id]) {
        break;
      }
      appointment = entities[id];
      if (moment(this.dateValue).isSame(moment(appointment.date), 'day')) {
        appointmentsByDate.push(appointment);
      }
    }
    const appointmentPatientsByDate = _.map(appointmentsByDate, 'patient_id');
    this.searchList= sortByFirstAndLastNames(_.filter(
      this.searchList,
      p => (appointmentPatientsByDate.includes(p.id)),
    ));
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
