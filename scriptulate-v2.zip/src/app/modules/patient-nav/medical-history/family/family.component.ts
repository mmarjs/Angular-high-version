import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-family',
  templateUrl: './family.component.html',
  styleUrls: ['./family.component.scss']
})
export class FamilyComponent implements OnInit {

  mConditions1 = [{title:"Alcoholism",selected:[]},{title:"Anemia",selected:[]},{title:"Anehtesia Problem",selected:[]},{title:"Arthritis",selected:[]},{title:"Asthma",selected:[]},{title:"Birth Defects",selected:[]},{title:"Bleeding Problem",selected:[]}];
  mConditions2 = [{title:"Cenetic Disease",selected:[]},{title:"Glaucoma",selected:[]},{title:"Hay Fever",selected:[]},{title:"Hearing Problems",selected:[]},{title:"Heart Attack",selected:[]},{title:"High Blood Pressure",selected:[]},{title:"High Cholestrol",selected:[]}];
  dropList = [{item_id:1,item_title:"Mom"},{item_id:2,item_title:"Daughter"},{item_id:3,item_title:"Dad"},{item_id:4,item_title:"Son"},{item_id:5,item_title:"Brother"},{item_id:6,item_title:"Other"},{item_id:7,item_title:"Sister"}];
  dropSettings = {};
  selectedItems = [];

  constructor() { }

  ngOnInit() {
    this.dropSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_title',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: false
    };
  }

  onSelect(i: any) {
    console.log(i);
  }

  onSelectAll(i: any) {
    console.log(i);
  }

}
