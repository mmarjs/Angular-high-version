import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.scss']
})
export class SocialComponent implements OnInit {
  mDays = [];
  mYears = []
  mWeeks = [];
  cigarettes = [{id:"cig_1",value:"Yes"},{id:"cig_2",value:"Never"},{id:"cig_3",value:"Quit"}];
  tbProducts = [{id:"pro_1",value:"Pipe"},{id:"pro_2",value:"Cigar"},{id:"pro_3",value:"Snuff"},{id:"pro_4",value:"Chew"}];
  qYesNo = [{id:"q_1",value:"Yes"},{id:"q_2",value:"No"}];
  aYesNo = [{id:"a_1",value:"Yes"},{id:"a_2",value:"No"}];
  oYesNo = [{id:"o_1",value:"Yes"},{id:"o_2",value:"No"}];
  dYesNo = [{id:"d_1",value:"Yes"},{id:"d_2",value:"No"}];
  nYesNo = [{id:"n_1",value:"Yes"},{id:"n_2",value:"No"}];
  mSubstance = {
    tobacco: {
      smoke: "",
      products: "",
      quitting: ""
    },
    alcohol: {
      drink: "",
      other: ""
    },
    drug: {
      drugs: "",
      needles: ""
    }
  }

  constructor() { }

  ngOnInit() {
    for(let i = 0; i < 31; i++) {
      this.mDays.push(i);
      if (i < 11) {
        this.mYears.push(i);
        this.mWeeks.push(i);
      }
    }
  }

}
