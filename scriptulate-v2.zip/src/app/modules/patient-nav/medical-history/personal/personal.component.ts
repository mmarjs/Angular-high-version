import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-personal',
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.scss'],
  // encapsulation: ViewEncapsulation.Native
})
export class PersonalComponent implements OnInit {
  indicateProblems = [
            {id:1,value:"Congenital Hear Disease"}, 
            {id:2,value:"Coagulation (Bleeding/Clotting Disorder)"}, 
            {id:3,value:"Myocardial Infarction (Heart Attack)"}, 
            {id:4,value:"Cancer (Malignancy)"},
            {id:5,value:"Hypertension (High Blood Pressure)"}, 
            {id:6,value:"Depression (Suicide Attempt)"}, 
            {id:7,value:"Diabetes"}, 
            {id:8,value:"Alcoholism"},
            {id:9,value:"High Sholestrol"}, 
            {id:10,value:"Abnormal Pap Smear"}, 
            {id:11,value:"Stroke"}, 
            {id:12,value:"Blood Transfusion"},
            {id:13,value:"Thyroid Problem"}
          ];
  drugs = [];
  mMedicalProblemData = [
    [{id: 1, key: "constitutional", title: "CONSTITUTIONAL", data: [{id: 1, value: "Fevers/Chills/Sweats"},{id: 2, value: "Unexplained Weight Loss/Gain"},{id: 3, value: "Fatigue/Weakness"},{id: 4, value: "Excessive thirst or urination"}]},
    {id: 2, key: "genitourinary", title: "GENITOURINARY", data: [{id: 1, value: "Nightime Urination"},{id: 2, value: "Leaking Urine"},{id: 3, value: "Unusual Vaginal Bleeding"},{id: 4, value: "Discharge Penis or Vagina"},{id: 5, value: "Sexual Function Problems"}]},
    {id: 3, key: "skin", title: "SKIN", data: [{id: 1, value: "Rash or Mole Change"}]}],
    [{id: 4, key: "eyes", title: "EYES", data: [{id: 1, value: "Change in Vision"}]},
    {id: 5, key: "breast", title: "BREAST", data: [{id: 1, value: "Breast Lump/Discharge"}]},
    {id: 6, key: "feeling", title: "EARS/NOSE/THROAT/MOUTH", data: [{id: 1, value: "Difficulty Hearing/Ringing in Ears"},{id: 2, value: "Problems with Teeth/Gum"},{id: 3, value: "Hay Fever/Allergies"}]},
    {id: 7, key: "musculo", title: "MUSCULO-SKELETAL", data: [{id: 1, value: "Breast Lump/Discharge"}]}],
    [{id: 8, key: "gastrointenstinal", title: "GASTROINTENSTINAL", data: [{id: 1, value: "Difficulty Hearing/Ringing in Ears"},{id: 2, value: "Problems with Teeth/Gum"},{id: 3, value: "Hay Fever/Allergies"}]},
    {id: 9, key: "neurological", title: "NEUROLOGICAL", data: [{id: 1, value: "Headaches"},{id: 2, value: "Dizziness"},{id: 3, value: "Numbness"},{id: 4, value: "Memory Loss"},{id: 5, value: "Loss of coordination"}]},
    {id: 10, key: "respiratory", title: "RESPIRATORY", data: [{id: 1, value: "Cough/Wheeze"},{id: 2, value: "Difficulty Breathing"}]}],
    [{id: 11, key: "cardiovascular", title: "CARDIOVASCULAR", data: [{id: 1, value: "Chest Pain/Discomfort"},{id: 2, value: "Leg Pain w/Exercise"},{id: 3, value: "Palpitations"}]},
    {id: 12, key: "psychiatric", title: "PSYCHIATRIC", data: [{id: 1, value: "Anxiety/stress"},{id: 2, value: "Problems with sleep"},{id: 3, value: "Depressions"}]},
    {id: 13, key: "blood", title: "BLOOD/LYMPHATIC", data: [{id: 1, value: "Unexplained lumps"},{id: 2, value: "Easy Bruising/Bleeding"}]}]
  ];

  mNumbers = [];
  mYesNo = [{id:1,value:"Yes"},{id:2,value:"No"}];

  mMedicalProblem = {
    indecated: {
      value: "",
      specify: "",
      date: ""
    },
    other: "",
    current: {
      constitutional: "",
      genitourinary: "",
      skin: "",
      eyes: "",
      breast: "",
      feeling: "",
      musculo: "",
      gastrointenstinal: "",
      neurological: "",
      respiratory: "",
      cardiovascular: "",
      psychiatric: "",
      blood: "",
      other: ""
    }
  }

  mGynocology = {
    pregnanciesNum : 0,
    deliveriesNum : 0,
    concernsPeriods : 2,
    abortionsNum : 0,
    miscarriagesNum : 0,
    concernsMenopause : 1,
    note : ""
  }

  mImmunizations = {
    hepatitisA : "",
    hepatitisB : "",
    tetanus : "",
    measles : "",
    mumps : "",
    rubella : "",
    mmr : "",
    varicella : "",
    pneumovax : ""
  }
  

  constructor() { }

  ngOnInit() {
    this.drugs = [{value: 1, viewValue: "Drug 1"},{value: 2, viewValue: "Drug 2"},{value: 3, viewValue: "Drug 3"}]
    
    for(let i = 0; i < 100; i++) {
      this.mNumbers.push(i);
    }

  }

}
