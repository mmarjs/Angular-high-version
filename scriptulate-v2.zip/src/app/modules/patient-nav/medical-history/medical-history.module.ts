import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MedicalHistoryRoutingModule } from './medical-history-routing.module';
import { MedicalHistoryComponent } from './medical-history.component';
import { MatTabsModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatRadioModule } from '@angular/material';
import { PersonalComponent } from './personal/personal.component';
import { FamilyComponent } from './family/family.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SocialComponent } from './social/social.component';
import { AssessmentComponent } from './assessment/assessment.component';

@NgModule({
  imports: [
    CommonModule,
    MedicalHistoryRoutingModule,
    MatTabsModule,
    MatInputModule,
    MatSelectModule,
    FormsModule, ReactiveFormsModule,
    MatRadioModule,
    NgMultiSelectDropDownModule.forRoot(),
  ],
  declarations: [MedicalHistoryComponent, PersonalComponent, FamilyComponent, SocialComponent, AssessmentComponent]
})
export class MedicalHistoryModule { }
