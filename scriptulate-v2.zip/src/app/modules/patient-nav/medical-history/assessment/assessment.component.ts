import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assessment',
  templateUrl: './assessment.component.html',
  styleUrls: ['./assessment.component.scss']
})
export class AssessmentComponent implements OnInit {

  types = [{id:1,value:"Never"},{id:2,value:"Seldom"}, {id:3,value:"Sometimes"}, {id:4,value:"Offen"}, {id:5,value:"Very Offen"}];
  functionalGoal = [{id:1,value:"Walk longer"}, {id:2,value:"Sit for longer"}, {id:3,value:"Ability to have more mobileity"}];
  improvedLive = [{id:1,value:"Putting on clothes"}, {id:2,value:"Doing dishes"}, {id:3,value:"Putting on shoes/socks"}, {id:4,value:"Dressing ability"}];
  familyMember = [{id:1,value:"Mother"}, {id:2,value:"Father"}, {id:3,value:"Sister"}, {id:4,value:"Brother"}, {id:5,value:"Grandmother"}, {id:6,value:"Grandfather"}];
  yesNo = [{id:1, value:"Yes"},{id:2, value:"No"}];
  numbers = [1,2,3,4,5,6,7,8,9,10];

  treatments = [{id:1, value:"Opiod only"}, {id:2, value:"Opiod and other medications"}];
  improvePain = [{id:1, value:"Medication"}, {id:2, value:"Rest"}, {id:3, value:"Exercise"}];
  painWorse = [{id:1, value:"Lying down"}, {id:2, value:"Walking"}, {id:3, value:"Exercise"}];
  effectsOpiods = [{id:1, value:"Constipation"}, {id:2, value:"Dry Mouth"}, {id:3, value:"Respiratory diseases"}, {id:4, value:"Seizures"}, {id:5, value:"Hallucinations"}, 
                    {id:6, value:"Altered Mood"}, {id:7, value:"Itching"}, {id:8, value:"Drowsiness"}, {id:9, value:"Tolerance"}, {id:10, value:"Nausea/Vomiting"}, {id:11, value:"Addiction"}];
  awares = [{id:1, value:"I must keep opiods in a safe place at home"},{id:2, value:"Dispose only at a doctor's office or pharmacy"}, {id:3, value:"Will never leave opiods where others have access"}, {id:4, value:"Never give drugs prescrived to me to anyone else"}];
  
  mEmotions = {
    mood: "",
    bored: "",
    impatient: "",
    canthandle: "",
    alone: "",
    remaining: ""
  }

  mPersonal = {
    legal_problem: "",
    meeting: "",
    hurt: "",
    sex_abused: "",
    alcohol_problem: "",
    goals: {
      functional: 1,
      improved: 1
    }
  }

  mRelationships = {
    inhouse: "",
    medication: "",
    close_friend: "",
    bad_temper: "",
    deserve: "",
    suggested: "",
    support_system: 1,
    chronic_pain: 1
  }

  mPainManagement = {
    options: {
      medication: "",
      countedPain: "",
      concerned: "",
      takenMore: "",
      consumed: "",
      runOut: "",
      borrow: ""
    },
    pain_impacted: {
      work: "",
      family: "",
      life: ""
    },
    knowledge_pain: {
      causes: "",
      preference: "",
      improve: "",
      worse: "",
      engage: "",
      discuss: "",
      aware_effect: "",
      aware: ""
    }
  }

  constructor() { }

  ngOnInit() {

  }

}
