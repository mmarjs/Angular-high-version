import {
  NgModule,
  NO_ERRORS_SCHEMA,
  CUSTOM_ELEMENTS_SCHEMA
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientNavRoutingModule } from './patient-nav-routing.module';
import { PatientNavComponent } from './patient-nav.component';
import { SharedModule } from 'app/common/modules/shared/shared.module';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [CommonModule, PatientNavRoutingModule, SharedModule,NgbDatepickerModule,],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  declarations: [PatientNavComponent],
})
export class PatientNavModule {}
