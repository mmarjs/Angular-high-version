import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
	MatMenuModule,
	MatTableModule,
	MatPaginatorModule,
	MatDialogModule,
} from '@angular/material';
import { SharedModule } from 'app/common/modules/shared/shared.module';
import { MedicationComponent } from './medication.component';
import { MedicationRoutingModule } from './medication-routing.module';
import { PrescriptionTableComponent } from './prescription-table/prescription-table.component';
import { NewPrescriptionDialogComponent } from './new-prescription-dialog/new-prescription-dialog.component';

@NgModule({
	declarations: [
		MedicationComponent,
		PrescriptionTableComponent,
		NewPrescriptionDialogComponent,
	],
	imports: [
		CommonModule,
		MedicationRoutingModule,
		SharedModule,
		MatMenuModule,
		MatTableModule,
		MatPaginatorModule,
		MatDialogModule,
	],
	entryComponents: [
		NewPrescriptionDialogComponent,
	],
})

export class MedicationModule {}
