import { Component } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
} from '@angular/material';

@Component({
  selector: 'app-new-prescription-dialog',
  templateUrl: './new-prescription-dialog.component.html',
  styleUrls: [
    '../../../../../app/common/modules/styles/dialogs.scss',
    './new-prescription-dialog.component.scss',
  ],
  styles: [
    ':host {}'
  ],
})

class NewPrescriptionDialogComponent {
  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<NewPrescriptionDialogComponent>,
  ) {}
}

export {
  NewPrescriptionDialogComponent,
};
