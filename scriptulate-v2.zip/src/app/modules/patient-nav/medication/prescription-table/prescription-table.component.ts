import {
  Component, OnInit, ViewChild
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import {
  MatPaginator, MatSort, MatTable,
  MatTableDataSource,
  MatDialog,
} from '@angular/material';
import * as Reducers from 'app/reducers/index';
import { getPatientPrescriptionsById } from 'app/reducers/prescription/prescription.reducer';
import { prescriptionColumns } from './prescription-table.model';
import { NewPrescriptionDialogComponent } from '../new-prescription-dialog/new-prescription-dialog.component';

@Component({
  selector: 'app-prescription-table',
  templateUrl: './prescription-table.component.html',
  styleUrls: [
    '../medication.component.scss',
    './prescription-table.component.scss',
  ],
})

class PrescriptionTableComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<any>;

  patientPrescriptions$: Observable<any>;
  dataSource: any;
  displayedColumns = prescriptionColumns;
  patientId: number;
  resultsLength = 0;

  constructor(
    private route: ActivatedRoute,
    private store: Store<Reducers.State>,
    private dialog: MatDialog,
  ) {
    this.route.queryParams.subscribe(({ patient_id }) => {
      this.patientId = patient_id;
    });
    this.patientPrescriptions$ = this.store.select(
      state => getPatientPrescriptionsById(state, { patient_id: this.patientId }),
    );
    this.patientPrescriptions$.subscribe((data: any) => {
      this.dataSource = new MatTableDataSource(data);

    });
  }

  openNewPrescription() {
		const dialogRef = this.dialog.open(NewPrescriptionDialogComponent);
    dialogRef.afterClosed().subscribe();
  }

  ngOnInit() {}
}

export {
  PrescriptionTableComponent,
};
