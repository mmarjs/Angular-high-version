export const prescriptionColumns: String[] = [
  'drug_name',
  'date_prescribed',
  'status',
  'prescribed_by_user_id',
  'comment',
  // 'diagnosis',
];