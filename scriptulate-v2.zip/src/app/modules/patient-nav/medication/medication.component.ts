import { Component } from '@angular/core';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import {
	getPrescriptions,
} from '@app/reducers/doctor/doctor.actions';
import { MatDialog } from '@angular/material';
import { NewPrescriptionDialogComponent } from './new-prescription-dialog/new-prescription-dialog.component';

@Component({
	selector: 'app-medication',
	templateUrl: './medication.component.html',
	styleUrls: [
		'../patient-nav.component.scss',
		'./medication.component.scss',
	],
})

export class MedicationComponent {
	role$: Observable<string>;
	constructor(
		private store: Store<Reducers.State>,
		public dialog: MatDialog,
	) {
		this.role$ = this.store.select((state: Reducers.State) => state.auth.user['role']);
		this.store.dispatch(getPrescriptions({ patient_id: 'all' }));
	}

	openNewPrescription() {
		const dialogRef = this.dialog.open(NewPrescriptionDialogComponent);
		dialogRef.afterClosed().subscribe();
	}
}