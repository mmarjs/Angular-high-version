import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientNavComponent } from './patient-nav.component';

const routes: Routes = [
    {
      path: '',
      component: PatientNavComponent,
    },
    {
      path: 'checklists',
      data: {
        breadcrumb: 'Checklists',
      },
      loadChildren: './checklists/checklists.module#ChecklistsModule',
    },
    // {
    //   path: 'medicalhistory',
    //   data: {
    //     breadcrumb: 'Medical history',
    //   },
    //   loadChildren: './medical-history/medical-history.module#MedicalHistoryModule',
    // },
    {
      path: 'medication',
      loadChildren: './medication/medication.module#MedicationModule',
    },
    {
      path: 'reports',
      data: {
        breadcrumb: 'Reports',
      },
      loadChildren: './reports/reports.module#ReportsModule',
    },
    {
      path: 'summary',
      data: {
        breadcrumb: 'Summary',
      },
      loadChildren: './summary/summary.module#SummaryModule',
    },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class PatientNavRoutingModule {}