import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppSession } from '@app/core/config/appSession';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '@app/core/services';

@Component({
	selector: 'app-summary',
	templateUrl: './summary.component.html',
	styleUrls: ['./summary.component.scss']
})

export class SummaryComponent implements OnInit {
	constructor(
		private route: ActivatedRoute,
		public bootstrapModal: NgbModal,
		private authService: AuthService,
	) {}

	ngOnInit() {
		
	}
}