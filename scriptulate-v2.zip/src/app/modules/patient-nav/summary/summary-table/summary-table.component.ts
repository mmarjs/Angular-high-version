import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthService, PatientLastVisitService } from '@app/core/services';
import { ActivatedRoute } from '@angular/router';
import { trigger, transition, style, animate, state } from '@angular/animations';
import { Store, select } from '@ngrx/store';
import * as moment from 'moment';
import { diversionsFetchedByPatient, selectDiversions, DiversionEntry } from 'app/reducers/diversion/diversion.reducer';
import { selectUser, selectRole } from '@app/reducers/auth/auth.reducer';
import { CommonService } from '@app/core/services/commonService/common.service';
import * as _ from 'lodash';
import { selectAlerts } from '@app/reducers/alert/alert.reducer';
import { PusherService } from '@app/core/services/pusherService/pusher.service';
import { urinesFetchedByPatient, selectUrineEntries, Urine } from '@app/reducers/urine/urine.reducer';
import { fetchUrineEntries } from '@app/reducers/urine/urine.actions';
import { fetchDiversionEntries } from '@app/reducers/diversion/diversion.actions';
import { selectPdmpReports, ApprissReport, pastReportFetchedByPatient,selectContractDocs } from '@app/reducers/doctor/doctor.reducer';
import { getPdmpReports } from '@app/reducers/doctor/doctor.actions';
import { PDMPReportService } from '../../../profiledetail/pdmpreport/pdmpreport.service';

import * as Reducers from '@app/reducers';
import { getScreeningsByIdAndType, selectFetchedScreenings,getLastPainScreening,Screening} from '@app/reducers/screening/screening.reducer';

import { fetchScreenings } from '@app/reducers/screening/screening.actions';
import { isPatientScreeningsFetched } from '@app/reducers/screening/screening.reducer';

import { Observable, Subject } from 'rxjs';

import { takeUntil } from 'rxjs/operators';
import { AppSession } from '@app/core/config/appSession';

import {
  getPrescriptions,
  syncPrescriptions,
  getDoctorsAndPharmacists,
  getNotesChecklistsCombined,
  getContractDocs,
} from '@app/reducers/doctor/doctor.actions';
import {
  doctorsFetched,
  Doctor,
  DoctorsState,
  DoctorsPharmacistsState,
  selectDoctorsAndOrPharmacists,
  formatNotesWithPreview,
  notesFetchedByPatient,
} from '@app/reducers/doctor/doctor.reducer';
import { Timestamp } from 'rxjs/internal/operators/timestamp';

@Component({
  selector: 'app-summary-table',
  templateUrl: './summary-table.component.html',
  styleUrls: [
    './summary-table.component.scss',
    '../../../profiledetail/profiledetail.component.scss',
    '../../../../../assets/scss/tables.scss',
    '../../../../../app/common/modules/styles/shared.scss',
  ],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('300ms', style({ opacity: 1 })),
      ]),
      transition(':leave', [
        style({ opacity: 1 }),
        animate('100ms', style({ opacity: 0 })),
      ]),
    ]),
  ],
  encapsulation: ViewEncapsulation.None,
})

class SummaryTableComponent implements OnInit {
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  doctor$: Observable<object>;
  role$: Observable<string>;
  diversions: DiversionEntry[];
  last_screening: Screening;
  painScreenings$: Observable<any>;
  data: DiversionEntry[];
  collectionSize: number;
  alerts$: Observable<object>;
  diversions$: Observable<object>;
  urines$: Observable<object>;
  screenings$: Observable<object>;
  contracts$: Observable<object>;
  doctorId: number;
  doctor: Doctor;
  patientId: number;
  urines: Urine[];
  dataDisplay= [];
  isShown=false;
  page = 1;
  pageSize = 5;
  pastReports$: Observable<Array<ApprissReport>>;
  pastReports: Array<ApprissReport> = [];

  pastDocuments$: Observable<Array<ApprissReport>>;
  pastDocuments: Array<ApprissReport> = [];

  sortDateByNewest: Boolean = null;
  sortTimeByLatest: Boolean = null;
  sortStatusByNewest: Boolean = null;
  sortTypeByAlph: Boolean = null;
  btnText: string = 'Show';
 
  constructor(
    private store: Store<Reducers.State>,
    public commonService: CommonService,                
    private pusherService: PusherService,
    private authService: AuthService,
    private route: ActivatedRoute,
    public patientLastVisitService: PatientLastVisitService,
  ) 
  {
    this.diversions$ = this.store.select( 
      (state:Reducers.State) => state.diversion
    );
    this.urines$ = this.store.select( 
      (state:Reducers.State) => state.urine
    );
    this.screenings$ = this.store.select(
      (state:Reducers.State) => state.screening
    );
    this.contracts$ = this.store.select(
      (state:Reducers.State) => state.contract
    );         
    
  }

  ngOnInit() {
    this.pusherService.alertsSubscribe();
    this.alerts$ = this.store.select(selectAlerts);

    this.route.queryParams.subscribe(params => {
      const { patient_id } = params;
      this.patientId = parseInt(patient_id, 10);     
      this.pusherService.subscribe(patient_id);
    });
    this.role$ = this.store.select(selectRole);
    this.doctor$ = this.store.select(selectUser);
    this.doctor$.subscribe((user: any) => {
      if(user)
      {
        this.doctorId = user.id;
        this.doctor = user;
        this.fetchUrines({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        });                
        
        this.fetchDiversions({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        });

        this.fetchScreenings({
          patient_id: this.patientId        
        });

        this.fetchContractDocs({patient_id: this.patientId,
            doctor_id: this.doctorId});        
        
        this.fetchPDMPReportsCheck({
          patient_id: this.patientId,
              doctor_id: this.doctorId});        
      }
    });
    
    const cache = this.patientLastVisitService.isPatientCached(this.patientId);

    if (cache[this.patientId]) {
      const isRecent = this.patientLastVisitService.isPatientVisitRecent(this.patientId);

      if (!isRecent) {
        
        this.store.dispatch(fetchUrineEntries({
          patientId: this.patientId,
        }));
        
        this.store.dispatch(fetchDiversionEntries({
          patientId: this.patientId,
        }));
        
        this.store.dispatch(fetchScreenings({ patientId: this.patientId }));

        
        this.store.dispatch(getContractDocs({
          patient_id: this.patientId,
          doctor_id: this.doctorId
        }));

        this.store.dispatch(getPdmpReports({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        }));
        
        this.patientLastVisitService.updatePatientTimeStamp(this.patientId);
      }
    }
  }

  trackByIndex = (index, entry) => index;
  
  
  
  sortByDate = () => {
    this.sortDataByKey('date', this.sortDateByNewest);
    this.sortDateByNewest = !this.sortDateByNewest;
    this.sortTimeByLatest = null;
    this.sortStatusByNewest = null;
    this.sortTypeByAlph = null;
  }
  
  sortDataByKey = (key: string, condition: any) => {
    if (condition === null) {
      condition = true;
    }
    if (!condition) {
      this.dataDisplay = _.orderBy(this.dataDisplay, key, 'asc');
      return;
    }
    if (condition) {
      this.dataDisplay = _.orderBy(this.dataDisplay, key, 'desc');
      return;
    }
  }

  sortByTime = () => {
    let firstDate = null;
    let secondDate = null;
    this.data = this.data.sort((a, b) => {
      firstDate = moment(a.date).format('hh:mm:ss a').toString();
      secondDate = moment(b.date).format('hh:mm:ss a').toString();
      if (this.sortTimeByLatest) {
        return firstDate.localeCompare(secondDate);
      }
      if (!this.sortTimeByLatest) {
        return secondDate.localeCompare(firstDate);
      }
    });
    this.sortTimeByLatest = !this.sortTimeByLatest;
    this.sortDateByNewest = null;
    this.sortStatusByNewest = null;
  }

  sortByStatus = () => {
    this.sortDataByKey('status', this.sortStatusByNewest);
    this.sortStatusByNewest = !this.sortStatusByNewest;
    this.sortDateByNewest = null;
    this.sortTimeByLatest = null;
    this.sortTypeByAlph = null;
  }
  sortByType = () => {
    this.sortDataByKey('type', this.sortTypeByAlph);
    this.sortTypeByAlph = !this.sortTypeByAlph;
    this.sortStatusByNewest = null;
    this.sortTimeByLatest = null;
  }



  fetchUrines = (props): void => {
    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this.store.select(
      state => urinesFetchedByPatient(
        state, { patient_id: patient_id }
    )).subscribe(isFetched => {
      if (!isFetched) {
        this.store.dispatch(fetchUrineEntries({
          patientId: patient_id,
        }));
      }
      else
      {
        this.store
          .select(state => selectUrineEntries(state, {
            patient_id,
            doctor_id,
          }))
          .subscribe((data: any) => {
            if (data) {
              this.urines = data;
              let urineslength = this.urines.length;
              let summ =  {'date':this.urines[urineslength-1].date,'type':"UDT",'status':this.urines[urineslength-1].status};            
              this.dataDisplay.push(summ);
              var resArr = [];
              this.dataDisplay.forEach(function(item){
                var i = resArr.findIndex(x => x.type == item.type);
                if(i <= -1){
                  resArr.push({date: item.date, type: item.type, status: item.status});
                }
              });
              this.dataDisplay = resArr;
            }
          });
      }
    });
  }

  fetchDiversions = (props): void => {
    
    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this.store.select(
      state => diversionsFetchedByPatient(
        state, { patient_id: patient_id }
    )).subscribe(isFetched => {
      if (!isFetched) 
      {
        this.store.dispatch(fetchDiversionEntries({
          patientId: patient_id,
        }));
      }
      else
      {            
        this.store
          .select(state => selectDiversions(state, {
            patient_id: this.patientId,
            doctor_id : this.doctorId,
          }))
          .subscribe((data: any) => {
            if (data) 
            {                                       
                let summ =  {'date':data[data.length-1].date,'type':"Diversion",'status':data[data.length-1].status};            
                this.dataDisplay.push(summ);
                var resArr = [];
                this.dataDisplay.forEach(function(item){
                  var i = resArr.findIndex(x => x.type == item.type);
                  if(i <= -1){
                    resArr.push({date: item.date, type: item.type, status: item.status});
                  }
                });
                this.dataDisplay = resArr;            
            }              
          });
        }
      });
  }

  fetchScreenings = (props): void => {
    if (!props.patient_id) {
      return;
    }
    const { patient_id } = props;
    this.store.select(state => isPatientScreeningsFetched(state, {
      patient_id: patient_id
    })).subscribe(isFetched => {
      if (!isFetched) {
        this.store.dispatch(fetchScreenings({ patientId: this.patientId }));
      }
      else
      {
        this.store
          .select(state => getScreeningsByIdAndType(state, {
            patient_id: this.patientId,
            doctor_id : this.doctorId,
            type:'pain'
          }))
          .subscribe((data: any) => {
            if (data) 
            {                        
              let summ =  {'date':data["lastPainScreening"].date,'type':"PEG",'status':data["lastPainScreening"].score};            
              this.dataDisplay.push(summ);                                       
              var resArr = [];
              this.dataDisplay.forEach(function(item){
                var i = resArr.findIndex(x => x.type == item.type);
                if(i <= -1){
                  resArr.push({date: item.date, type: item.type, status: item.status});
                }
              });
              this.dataDisplay = resArr;    
            }
          });
      }      
    });
  }

  fetchPainScreenings = (props): void => {

    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this.store.select(
      state => isPatientScreeningsFetched(
        state, { patient_id: patient_id }
    )).subscribe(isFetched => {
      if (!isFetched) 
      {
        
      }
      else
      {            
        this.store
          .select(state => selectDiversions(state, {
            patient_id: this.patientId,
            doctor_id : this.doctorId,
          }))
          .subscribe((data: any) => {
            if (data) 
            {                                       
                let summ =  {'date':data[data.length-1].date,'type':"Diversion",'status':data[data.length-1].status};            
                this.dataDisplay.push(summ);
                var resArr = [];
                this.dataDisplay.forEach(function(item){
                  var i = resArr.findIndex(x => x.type == item.type);
                  if(i <= -1){
                    resArr.push({date: item.date, type: item.type, status: item.status});
                  }
                });
                this.dataDisplay = resArr;            
            }              
          });
        }
      });
  }
  fetchPDMPReportsCheck = (props): void => {

    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this .store.dispatch(getPdmpReports({
      patient_id: this.patientId,
      doctor_id: this.doctorId,
    }));
    this.store
      .select(state => pastReportFetchedByPatient(state, {
        patient_id: this.patientId,
      }))
      .subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(getPdmpReports({
            patient_id: this.patientId,
            doctor_id: this.doctorId,
          }));
        }
        else
        {         
          this.pastReports$ = this.store.select(state => selectPdmpReports(state, { patient_id: this.patientId }));

          this.pastReports$
            .pipe(takeUntil(this.unsubscribe$))
            .subscribe(reports => {
              if (reports.length>0) {
                this.pastReports = _.orderBy(reports, 'createdAt', 'desc');

                let summ =  {'date':this.pastReports[0].createdAt,'type':"PDMP Check",'status':"Saved"};            
                this.dataDisplay.push(summ);
                var resArr = [];
                this.dataDisplay.forEach(function(item){
                  var i = resArr.findIndex(x => x.type == item.type);
                  if(i <= -1){
                    resArr.push({date: item.date, type: item.type, status: item.status});
                  }
                });
                this.dataDisplay = resArr;
              }
            });
        }
      });
  }
  fetchContractDocs = (props): void => {
    this.store.dispatch(getContractDocs({
      patient_id: this.patientId,
      doctor_id: this.doctorId,
    }));
    this.store
      .select(state => pastReportFetchedByPatient(state, {
        patient_id: this.patientId,
      }))
      .subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(getContractDocs({
            patient_id: this.patientId,
            doctor_id: this.doctorId,
          }));
        }
        this.pastReports$ = this.store.select(state => selectContractDocs(state, { patient_id: this.patientId }));

        this.pastReports$
          .pipe(takeUntil(this.unsubscribe$))
          .subscribe(reports => {
          if (reports) {

            if (reports.length>0) {
              this.pastReports = _.orderBy(reports, 'createdAt', 'desc');

              let summ =  {'date':this.pastReports[0].createdAt,'type':"Pain Contracts",'status':"Initiated"};            
              this.dataDisplay.push(summ);
              var resArr = [];
              this.dataDisplay.forEach(function(item){
                var i = resArr.findIndex(x => x.type == item.type);
                if(i <= -1){
                  resArr.push({date: item.date, type: item.type, status: item.status});
                }
              });
              this.dataDisplay = resArr;              
            }
          }
        });
      });
  }
  showClick = () => {
    this.isShown = !this.isShown;
    this.btnText = (this.isShown) ? "Show" : "Hide";

  }
}

export { SummaryTableComponent };
