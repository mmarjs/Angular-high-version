import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SummaryRoutingModule } from './summary-routing.module';
import { SummaryComponent } from './summary.component';
import { SummaryTableComponent } from './summary-table/summary-table.component';
import {
	MatButtonToggleModule,
	MatIconModule,
	MatDialogModule,
	MatRadioModule,
	MatDatepickerModule,
	MatNativeDateModule,
	MatButtonModule,
	MatInputModule
} from '@angular/material';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/common/modules/shared/shared.module';
import { AngularSvgIconModule } from 'angular-svg-icon';

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		SummaryRoutingModule,
		ReactiveFormsModule,
		MatButtonToggleModule,
		MatDatepickerModule,
		MatNativeDateModule,
		MatIconModule,
		MatDialogModule,
		MatRadioModule,
		MatButtonModule,
		MatInputModule,
		SharedModule,
		AngularSvgIconModule,
		NgbPaginationModule
	],
	entryComponents:[ ],
	declarations: [SummaryComponent, SummaryTableComponent],
	providers:[],

})
export class SummaryModule {}