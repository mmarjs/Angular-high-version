import { PatientNavModule } from './patient-nav.module';

describe('PatientNavModule', () => {
  let patientNavModule: PatientNavModule;

  beforeEach(() => {
    patientNavModule = new PatientNavModule();
  });

  it('should create an instance', () => {
    expect(patientNavModule).toBeTruthy();
  });
});
