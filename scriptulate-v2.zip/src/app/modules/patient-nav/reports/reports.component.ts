import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppSession } from '@app/core/config/appSession';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '@app/core/services';
import { SummaryReportsComponent } from './summary-report/summary-report.component';
import {FormControl} from '@angular/forms';

@Component({
	selector: 'app-reports',
	templateUrl: './reports.component.html',
	styleUrls: ['../patient-nav.component.scss', './reports.component.scss']
})
export class ReportsComponent implements OnInit {

	doctorId: number;
  	patientId: number;
	is_history:boolean;
	isShown:boolean;
	sortByStatus:any;
	selectedSummary: boolean = false;
	selectedDetail: boolean = false;
	date = new Date();
	currentMonth = this.date.setMonth(this.date.getMonth() - 1);
	afterMonth = new Date();

	properties: any[] = [
		{
			label: 'UDT screens',
			checked: true,
			value: 'udt'
		},
		{
			label: 'Diversion checks',
			checked: false,
			value: 'diversion'
		},
		{
			label: 'Pain Contract(s)',
			checked: false,
			value: 'pain'
		},
		{
			label: 'PEG Scores',
			checked: false,
			value: 'peg'
		},
		{
			label: 'Checklists',
			checked: false,
			value: 'checklists'
		},
		{
			label: 'Reminders',
			checked: false,
			value: 'reminder'
		},
		{
			label: 'Notes',
			checked: false,
			value: 'note'
		},
		{
			label: 'State PDMP Reports',
			checked: false,
			value: 'state'
		},
		{
			label: 'Summary PDMP Reports',
			checked: false,
			value: 'summary'
		},
	];

	constructor(
		private route: ActivatedRoute,
		public bootstrapModal: NgbModal,
		private authService: AuthService,
	) {}

	openPdmpPastReport = (): void => {
		if (!this.isPropertyUnchecked()) {
		    const pastReportsRef = this.bootstrapModal.open(
		      SummaryReportsComponent,
		      { size: 'lg', backdrop:'static',windowClass: 'ngb-modal-past-reports' },
		    );
		    pastReportsRef.componentInstance.data = {
		      patient_id: this.patientId,
		      doctor_id: this.doctorId,
		    };

		    pastReportsRef.result.then(res => {
		      return;
		    }).catch(err => console.error(err));
		}
	}

	ngOnInit() {
		this.route.queryParams.subscribe(params => {
			const { patient_id } = params;

      		this.patientId = parseInt(patient_id, 10);
		});
		this.doctorId = this.authService.user.id
	}
 	selecteSummary () {
 		this.selectedSummary = !this.selectedSummary;
 	}
 	selecteDetail() {
 		this.selectedDetail = !this.selectedDetail;	
 	}

 	isPropertyUnchecked(){
 		return this.properties.filter(item => {
 			return item.checked ? true : false;
 		}).length ? false : true;
 	}
}