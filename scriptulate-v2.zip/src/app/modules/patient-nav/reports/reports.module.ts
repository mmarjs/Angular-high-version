import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import {
	MatButtonToggleModule,
	MatIconModule,
	MatDialogModule,
	MatRadioModule,
	MatDatepickerModule,
	MatNativeDateModule,
	MatButtonModule,
	MatInputModule
} from '@angular/material';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/common/modules/shared/shared.module';
import { SummaryReportsComponent } from './summary-report/summary-report.component';


@NgModule({
	imports: [
		CommonModule,
		ReportsRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		MatButtonToggleModule,
		MatDatepickerModule,
		MatNativeDateModule,
		MatIconModule,
		MatDialogModule,
		MatRadioModule,
		MatButtonModule,
		MatInputModule,
		MatSlideToggleModule,
		MatCheckboxModule,
		SharedModule,
	],
	entryComponents:[ SummaryReportsComponent],
	declarations: [ReportsComponent, SummaryReportsComponent],
	providers:[]
})
export class ReportsModule {}