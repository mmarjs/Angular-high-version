import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { PDMPReportService } from '../../../profiledetail/pdmpreport/pdmpreport.service';
import { Observable, Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import * as Reducers from '@app/reducers';
import { selectPdmpReports, ApprissReport, pastReportFetchedByPatient } from '@app/reducers/doctor/doctor.reducer';
import { getPdmpReports } from '@app/reducers/doctor/doctor.actions';
import * as _ from 'lodash';
import { takeUntil } from 'rxjs/operators';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

declare var require: any
const FileSaver = require('file-saver');

@Component({
  selector: 'app-summary-reports',
  templateUrl: './summary-report.component.html',
  styleUrls: [
    '../../../profiledetail/mydialog/mydialog.component.scss',
    './summary-report.component.scss',
  ],
})
export class SummaryReportsComponent implements OnInit, OnDestroy {
  @Input() data: any;
  pastReports$: Observable<Array<ApprissReport>>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  pastReports: Array<ApprissReport> = [];

  masterSelected = false;
	is_history:boolean;
	isShown:boolean;
	sortByStatus:any;
  primary: any

  constructor(
    private pdmpService: PDMPReportService,
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
  ) {}

  onNoClick = (): void => {
    this.activeModal.close();
  }

  onDownload = (report_id): void => {
    const url = this.pdmpService.downloadPDMPReports({ reportId: report_id });
    window.open(url, '_blank');
  }

  ngOnInit(): void {
    this.store
      .select(state => pastReportFetchedByPatient(state, {
        patient_id: this.data.patient_id,
      }))
      .subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(getPdmpReports({
            patient_id: this.data.patient_id,
            doctor_id: this.data.doctor_id,
          }));
        }
        this.pastReports$ = this.store.select(state => selectPdmpReports(state, { patient_id: this.data.patient_id }));

        this.pastReports$
          .pipe(takeUntil(this.unsubscribe$))
          .subscribe(reports => {
          if (reports) {
            this.pastReports = _.orderBy(reports, 'createdAt', 'desc');
            this.pastReports = this.pastReports.map(item => {
              return {
                ...item,
                isChecked: false
              }
            })
          }
        });
      });
  }

  downloadAllPdf (){
    this.pastReports.forEach((item: any) => {
      if ( item.isChecked == true ) {
         this.downloadPdf(item.file_location, item.file_name);
         this.onNoClick();
       } 
    })
  }

  downloadPdf(pdfUrl: string, pdfName: string ) {
    //const pdfUrl = './assets/sample.pdf';
    //const pdfName = 'your_pdf_file';
    FileSaver.saveAs(pdfUrl, pdfName);
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

  onCheckAll(){
    this.pastReports.forEach((item: any) => {
      item.isChecked = this.masterSelected;
    })
  }
}
