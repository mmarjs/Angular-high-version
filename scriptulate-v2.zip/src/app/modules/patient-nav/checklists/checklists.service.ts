import { Injectable } from '@angular/core';
import { HttpResourceService } from '@app/core/services';
import { EnvironemntConfig } from '@app/core/config/environmentConfig';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { HttpClient } from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class ChecklistsService {
	constructor(private httpSerive: HttpResourceService, private httpClient: HttpClient) {}

	/**
	 * get all checklist with normalized = true
	 */
	fetchAllChecklistTemplates() {
		const url = RelativeUrlConfig.CHECK_LIST_TEMPLATES;
		return this.httpSerive.get(url, {});
	}
	async fetchNote(questionCheckList) {
		const url = RelativeUrlConfig.CHECK_LIST_NOTE;
		return await this.httpSerive.post(url, questionCheckList).toPromise();
	}
}
