import { createCheckList, getChecklistReports } from 'app/reducers/doctor/doctor.actions';
import { keyBy } from 'lodash';
import * as moment from 'moment';
import { Observable } from 'rxjs';

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { AppSession } from '@app/core/config/appSession';
import { AnswerValue } from '@app/core/config/constants';
import { UploadService } from '@app/core/services';
import * as Reducers from '@app/reducers';
import { Patient } from '@app/reducers/patient/patient.reducer';
import { Store } from '@ngrx/store';

import { PdfHelperService } from '../../../../core/services/pdf-helper/pdf-helper.service';
import { AddNoteComponent } from '../add-note/add-note.component';
import { ChecklistsService } from '../checklists.service';

@Component({
	selector: 'app-checklist',
	templateUrl: './checklist.component.html',
	styleUrls: ['../../patient-nav.component.scss', './checklist.component.scss']
})
export class ChecklistComponent implements OnInit {
	patient_id: number;
	doctor_id: number;
	patient$: Observable<Patient>;
	patientInfo: any = {};
	PainContractDate: any;
	check_list: any;
	role = '';
	m_listItems: any = [];
	m_selItem = null;

	m_answer = AnswerValue;
	showQuestions: any = [];
	nextQuestion: any;
	questionSet: any;
	questionLinks: any;
	all_templates: any = [];
	showDoneBtn: Boolean;
	checkListNotes: any;

	btnText: string = 'Show';
	isShown: boolean = true;
	constructor(
		private pdfHelperService: PdfHelperService,
		private router: Router,
		private dialog: MatDialog,
		private store: Store<Reducers.State>,
		private uploader: UploadService,
		private checklist: ChecklistsService
	) { }

	ngOnInit() {
		const {
			select_index,
			all_templates,
			doctor_id,
			patient_id
		} = window.history.state;
		this.patient_id = parseInt(patient_id, 10);
		this.doctor_id = parseInt(doctor_id, 10);
		this.all_templates = all_templates;

		this.patient$ = this.store.select(
			(state: Reducers.State) =>
				state.patient.entities[this.patient_id.toString()]
		);

		this.setUpCheckList(all_templates[select_index]);
	}

	async setUpCheckList(selectedCheckList) {
		this.check_list = selectedCheckList;
		this.showDoneBtn = false;
		this.showQuestions = [];

		const questions = this.check_list.questions.map(q => {
			q.answer_value = null;
			return q;
		});
		this.checkListNotes = {};
		this.checkListNotes[this.check_list.checkListNoteTitle] = {};
		this.checkListNotes[this.check_list.checkListNoteTitle].Response = { Question: [] };
		this.checkListNotes[this.check_list.checkListNoteTitle].StaticText = selectedCheckList.StaticText;
		this.questionSet = keyBy(questions, 'id');
		this.questionLinks = this.check_list.question_links;
		this.nextQuestion = questions.find((q: any) => q.is_first_question);
		this.store.select((state: Reducers.State) => {
			this.patientInfo = state.patient.entities[this.patient_id.toString()]
		}).subscribe();
		this.store.select((state: Reducers.State) => {
			let entitiesArr = Object.values(state['contract'].entities);
			const contract = entitiesArr.filter(item => item.patient_id == this.patient_id && item.doctor_id == this.doctor_id);
			if (contract.length > 0) {
				const datePattern = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
				let date = moment(contract[0].started_at, datePattern);
				this.PainContractDate = date.format('M/D/YY');
			} else {
				this.PainContractDate = '';
			}
		}).subscribe();
	}

	/**
	 * @param dob date of birthday for selected patient
	 */
	getAgeFromDOB(dob: string) {
		if (typeof dob == 'undefined') {
			return 30;
		}
		const ary = dob.split('/');
		const today = new Date();
		return today.getFullYear() - parseInt(ary[ary.length - 1], 10);
	}

	async onNextAction(fetchNotes) {
		if (!fetchNotes) {
			this.store.dispatch(
				createCheckList({
					check_list_result: {
						responses: this.showQuestions,
						check_list_title: this.check_list.title
					},
					note: null,
					patient_id: this.patient_id,
					doctor_id: this.doctor_id
				})
			);
			this.exportToPDF();
		} else {
			this.checkListNotes[this.check_list.checkListNoteTitle].PatientInfo = {
				name: this.patientInfo.first_name + ' ' + this.patientInfo.last_name,
				DOB: this.patientInfo.birthdate,
				Gender: this.patientInfo.gender,
				Diagnosis: [
					"Diabetes",
					"Chronic Pain",
					"Hypertension"
				],
				PainContractDate: this.PainContractDate
			}
			let note = await this.checklist.fetchNote(this.checkListNotes);
			const confirmDlg = this.dialog.open(AddNoteComponent, {
				width: '50%',
				height: '20rem',
				data: {
					note: note.body.note,
					is_subState: false
				}
			});

			confirmDlg.afterClosed().subscribe(result => {
				if (result) {


					this.store.dispatch(
						createCheckList({
							check_list_result: {
								responses: this.showQuestions,
								check_list_title: this.check_list.title
							},
							note: result,
							patient_id: this.patient_id,
							doctor_id: this.doctor_id
						})
					);
					this.exportToPDF();
				}
			});
		}
	}

	onAnswer({ value }, question) {
		setTimeout(function () {
			window.scrollTo(0, document.body.scrollHeight);
		}, 100);
		const { id: questionId } = question;
		this.showDoneBtn = false;
		const findIndex = this.showQuestions.findIndex(q => q.id === questionId);

		if (findIndex !== -1) {
			if (this.showQuestions[findIndex].answer_value === value) {
				return;
			}
			this.showQuestions = this.showQuestions.slice(0, findIndex);
			this.checkListNotes[this.check_list.checkListNoteTitle].Response.Question
				= this.checkListNotes[this.check_list.checkListNoteTitle].
					Response.Question.slice(0, findIndex);
		}
		question.answer_value = value;
		const nextQuestionId = this.questionLinks[`${questionId}|${value}`];

		if (!nextQuestionId && question.is_last_question) {
			this.checkListNotes[this.check_list.checkListNoteTitle].Response.Question.push({
				Number: question.id,
				Answer: value
			})
			this.showQuestions.push(question);
			this.showDoneBtn = true;
			this.nextQuestion = null;
			return;
		} else {
			this.checkListNotes[this.check_list.checkListNoteTitle].Response.Question.push({
				Number: question.id,
				Answer: value
			})
			this.showQuestions.push(question);
			this.nextQuestion = this.questionSet[nextQuestionId];
		}
	}

	onSubNote(question) {
		const subNote =
			question.answer_value === 'YES'
				? question.positive_result_text
				: question.negative_result_text;

		const confirmDlg = this.dialog.open(AddNoteComponent, {
			width: '50%',
			height: '20rem',
			data: {
				note: subNote,
				is_subState: true
			}
		});

		confirmDlg.afterClosed().subscribe(result => {
			if (result) {
				question.answer_value === 'YES'
					? (question.positive_result_text = result)
					: (question.negative_result_text = result);
				const findIndex = this.showQuestions.findIndex(q => q.id === question.id);
				this.checkListNotes[this.check_list.checkListNoteTitle].Response.Question[findIndex].ExtraNotes = result;
				document.getElementById('taNote' + findIndex).innerText = result;
				document.getElementById('taNote' + findIndex).style.display = 'block';
			}
			else {
				const findIndex = this.showQuestions.findIndex(q => q.id === question.id);
				document.getElementById('taNote' + findIndex).innerText = "";
			}

		});
	}

	showClick = () => {
		this.isShown = !this.isShown;
		this.btnText = (this.isShown) ? "Show" : "Hide";

	}

	public exportToPDF() {
		setTimeout(() => (AppSession.loadingSpinner = true), 0);
		const data = document.getElementById('checklist_wrapper');
		const fileName = `CL_${this.check_list.title.replace(
			/\s/g,
			'_'
		)}_${new Date().getTime()}.pdf`;

		this.pdfHelperService.generatePdf(data, fileName).subscribe(
			pdf => {
				this.uploader
					.upload({
						file_name: fileName,
						uploaded_by_user_id: this.doctor_id,
						uploaded_for_user_id: this.patient_id,
						file_category: 'checklist',
						file_type: 'application/pdf',
						file: pdf.output('blob')
					})
					.then(({ success }) => {
						this.store.dispatch(
							getChecklistReports({
								patient_id: this.patient_id,
								doctor_id: this.doctor_id
							})
						);

						if (success) {
							setTimeout(() => (AppSession.loadingSpinner = false), 0);
							this.router.navigate(['/patient-nav/checklists'], {
								queryParams: { is_history: true, patient_id: this.patient_id }
							});
						}
					})
					.catch(err => {
						setTimeout(() => (AppSession.loadingSpinner = false), 0);
						console.error(err);
					});
			},
			(err => {
				setTimeout(() => (AppSession.loadingSpinner = false), 0);
				console.error(err);
			}));
	}
}
