import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChecklistsComponent } from './checklists.component';
import { ChecklistComponent } from './checklist/checklist.component';

const routes: Routes = [
  { path: '', component: ChecklistsComponent },
  { 
    path: 'checklist', 
    component: ChecklistComponent,
    data: {
      breadcrumb: 'Checklist',
    },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChecklistsRoutingModule { }
