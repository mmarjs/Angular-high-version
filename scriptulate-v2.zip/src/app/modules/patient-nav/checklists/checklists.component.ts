import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppSession } from '@app/core/config/appSession';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ChecklistsService } from './checklists.service';
import { selectCLHistory, Checklist } from '@app/reducers/doctor/doctor.reducer';
import { getChecklistReports } from '@app/reducers/doctor/doctor.actions';
import { selectRole } from '@app/reducers/auth/auth.reducer';
import * as moment from 'moment';

@Component({
	selector: 'app-checklists',
	templateUrl: './checklists.component.html',
	styleUrls: ['../patient-nav.component.scss', './checklists.component.scss']
})
export class ChecklistsComponent implements OnInit {
	loading: Boolean = false;
	patientId = '';
	patient$: Observable<object>;
	pastChecklist$: any;
	pastChecklists: Array<Checklist>;
	role = '';
	m_checkLists = [];
	doctor_id: number;
	is_history = false;

	public role$: Observable<string>;

	m_colors = [
		'#435877',
		'#74c5ca',
		'#778ca1',
		'#62878f',
		'#85869b',
		'#997a89',
		'#7d9e97',
		'#758673',
		'#7d5357',
		'#976856',
		'#bb9860'
	];

	constructor(
		private checklistService: ChecklistsService,
		public router: Router,
		private route: ActivatedRoute,
		private store: Store<Reducers.State>
	) {}

	ngOnInit() {
		this.loading = true;
		// this.role = this.commonService.getRole();
		this.role$ = this.store.select(selectRole);

		this.route.queryParams.subscribe(params => {
			this.is_history = params.is_history;
			this.patientId = params.patient_id;
			this.patient$ = this.store.select(
				(state: Reducers.State) => state.patient.entities[params.patient_id]
			);
			this.store
				.select((state: Reducers.State) => state.auth.user)
				.subscribe(user => {
					this.doctor_id = user.id;
				});

			this.store.dispatch(
				getChecklistReports({
					patient_id: params.patient_id,
					doctor_id: params.doctor_id
				})
			);

			this.pastChecklist$ = this.store.select((state: Reducers.State) =>
				selectCLHistory(state, { patient_id: parseInt(this.patientId, 10) })
			).subscribe((data): void => {
				this.pastChecklists = data.sort((a, b) => moment(b.createdAt).unix() - moment(a.createdAt).unix());
			});
		});

		this.getCheckLists();
	}

	getCheckLists() {
		setTimeout(() => (AppSession.loadingSpinner = true), 0);
		this.checklistService
			.fetchAllChecklistTemplates()
			.subscribe((resp: any) => {
				if (resp.ok) {
					this.m_checkLists = resp.body;
					this.m_checkLists.sort((a, b) => (a.id > b.id ? 0 : -1));
					this.m_checkLists = this.assignColorAndRoute(this.m_checkLists);
					setTimeout(() => (AppSession.loadingSpinner = false), 0);
				}
			});
	}

	assignColorAndRoute = (list) => {
		let route = null;
		return list.map((checklist, idx) => {
			const { question_count, title } = checklist;
			route = title.replace(/\s/g, '-');
			return {
				...checklist,
				color: this.m_colors[idx % this.m_colors.length],
				enabled: question_count > 0 ? true : false,
				route,
			};
		});
	}

	getAgeFromDOB(dob: string) {
		if (typeof dob === 'undefined') {
			return 30;
		}
		const ary = dob.split('/');
		const today = new Date();
		return today.getFullYear() - parseInt(ary[ary.length - 1], 10);
	}

	onNavigateTo(idx) {
		this.router.navigate(['/patient-nav/checklists/checklist'], {
			state: {
				select_index: idx,
				patient_id: this.patientId,
				all_templates: this.m_checkLists,
				doctor_id: this.doctor_id
			}
		});
	}

	goHome() {
		this.router.navigate(['patient-nav'], {
			queryParams: { patient_id: this.patientId },
			skipLocationChange: true
		});
	}
}
