import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChecklistsRoutingModule } from './checklists-routing.module';
import { ChecklistsComponent } from './checklists.component';
import { ChecklistComponent } from './checklist/checklist.component';
import {
	MatButtonToggleModule,
	MatIconModule,
	MatDialogModule,
	MatRadioModule,
	MatButtonModule,
	MatInputModule
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddNoteComponent } from './add-note/add-note.component';
import { SharedModule } from 'app/common/modules/shared/shared.module';
@NgModule({
	imports: [
		CommonModule,
		ChecklistsRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		MatButtonToggleModule,
		MatIconModule,
		MatDialogModule,
		MatRadioModule,
		MatButtonModule,
		MatInputModule,
		SharedModule,
	],
	entryComponents: [AddNoteComponent],
	declarations: [ChecklistsComponent, ChecklistComponent, AddNoteComponent]
})
export class ChecklistsModule {}
