import { ChecklistsModule } from './checklists.module';

describe('ChecklistsModule', () => {
  let checklistsModule: ChecklistsModule;

  beforeEach(() => {
    checklistsModule = new ChecklistsModule();
  });

  it('should create an instance', () => {
    expect(checklistsModule).toBeTruthy();
  });
});
