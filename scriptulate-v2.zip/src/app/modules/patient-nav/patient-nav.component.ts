import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PusherService } from '@app/core/services/pusherService/pusher.service';
import * as Reducers from '@app/reducers';
import { selectAlerts } from '@app/reducers/alert/alert.reducer';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { User } from '@app/reducers/auth/auth.reducer';
import { combineLatest } from 'rxjs';
import { selectedPatient } from 'app/reducers/patient/patient.reducer';
import { TodoCreateModalComponent } from '@app/common/modules/shared/components/todo-create-modal/todo-create-modal.component';
@Component({
  selector: 'app-patient-nav',
  templateUrl: './patient-nav.component.html',
  styleUrls: ['./patient-nav.component.scss'],
})
export class PatientNavComponent implements OnInit {
  loading: Boolean = false;
  patientId = '';
  patientInfo: any = {};
  role = '';
  user : User;
  pageId = '';

  listItems = [
    {
      id: 'list_summary',
      title: 'Summary',
      icon: 'icon_summary.png',
      route: '/patient-nav/summary',
      color: '#6c8bba',
      isDisabled: false,
    },
    // {
    //   id: 'list_pers_info',
    //   title: 'Personal Info',
    //   icon: 'icon_personal_info.png',
    //   route: '/patientnav',
    //   color: '#778ca1',
    //   isDisabled: false,
    // },
    // {
    //   id: 'list_medication',
    //   title: 'Medication',
    //   icon: 'icon_medication.png',
    //   route: '/patient-nav/medication',
    //   color: '#79a2ab',
    //   isDisabled: false,
    // },
    // {
    //   id: 'list_test_labs',
    //   title: 'Test/Labs',
    //   icon: 'icon_test_labs.png',
    //   route: '/patient-nav',
    //   color: '#85869b',
    //   isDisabled: false,
    // },
    // {
    //   id: 'list_dr_notes',
    //   title: 'Dr. Notes',
    //   icon: 'icon_dr_note.png',
    //   route: '/patient-nav',
    //   color: '#987a89',
    //   isDisabled: false,
    // },
    // {
    //   id: 'list_medical_history',
    //   title: 'Medical History',
    //   icon: 'icon_medical_history.png',
    //   route: '/patient-nav/medicalhistory',
    //   color: '#7d9e97',
    //   isDisabled: false,
    // },
    // {
    //   id: 'list_social_history',
    //   title: 'Social History',
    //   icon: 'icon_social_history.png',
    //   route: '/patient-nav/socialhistory',
    //   color: '#91a190',
    //   isDisabled: false,
    // },
    {
      id: 'list_checklists',
      title: 'Checklists',
      icon: 'icon_checklist.png',
      route: '/patient-nav/checklists',
      // skip: true,
      color: '#ac797e',
      isDisabled: false,
    },    
    {
      id: 'list_controlled_sub',
      title: 'Controlled Substance History',
      icon: 'icon_controlled_history.png',
      // route: '/mypatient/patient-nav/profiledetail',
      route: '/mypatient/profiledetail',
      // skip: true,
      color: '#b27c68',
      isDisabled: false,
    },
    {
      id: 'list_reports',
      title: 'Reports',
      icon: 'icon_reports.png',
      route: '/patient-nav/reports',
      color: '#ba9860',
      isDisabled: false,
    },
  ];
  patient$: Observable<object>;
  alerts$: Observable<any>;
  me$: Observable<object>;
  constructor(
    public router: Router,
    private route: ActivatedRoute,
    private store: Store<Reducers.State>,
    private pusherService: PusherService,
    private modal: NgbModal
  ) {
    this.me$ = this.store.select(state => state.auth.user);
    this.route.queryParams.subscribe(params => {
      const { patient_id } = params;
      this.patientId = patient_id;
      this.alerts$ = this.store.pipe(select(selectAlerts));
      this.patient$= this.store.pipe(select(selectedPatient, { patient_id: this.patientId }));;
    });
  }

  newOrderClick = (): void => {
    if(this.user && this.user.role=='Doctor'){
      const urineCreateRef = this.modal.open(TodoCreateModalComponent, { size: 'lg' });

      urineCreateRef.componentInstance.data = {
        patientId: this.patientId,
        doctorId: this.user.id,
      };

      urineCreateRef.result
        .then(res => {urineCreateRef.close(); return; })
        .catch(err => console.error(err));
    }
  }


  ngOnInit() {
    combineLatest(
      this.me$,
    ).subscribe(([
      user,
    ]: [User]) => {
      if (user.id) {
        this.user = user;
      }

    });
    this.pusherService.alertsSubscribe();
  }




  getBackgroundImg(icon: string): string {
    return `url('assets/images/${icon}')`;
  }
}
