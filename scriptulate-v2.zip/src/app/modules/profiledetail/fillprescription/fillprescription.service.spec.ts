import { TestBed, inject } from '@angular/core/testing';

import { FillprescriptionService } from './fillprescription.service';

describe('FillprescriptionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FillprescriptionService]
    });
  });

  it('should be created', inject([FillprescriptionService], (service: FillprescriptionService) => {
    expect(service).toBeTruthy();
  }));
});
