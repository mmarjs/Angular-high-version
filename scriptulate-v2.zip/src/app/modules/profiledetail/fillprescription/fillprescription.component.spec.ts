import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FillprescriptionComponent } from './fillprescription.component';

describe('FillprescriptionComponent', () => {
  let component: FillprescriptionComponent;
  let fixture: ComponentFixture<FillprescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FillprescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FillprescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
