import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root'
})
export class FillprescriptionService {
  BASE_URL_FILLED_PRESCRIPTION = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) { }

  saveFilledPrescription(params){
    const url = this.BASE_URL_FILLED_PRESCRIPTION + RelativeUrlConfig.SAVE_FILLED_PRESCRIPTION;
    return this.httpResourceService.post(url,params);
  }
  fetchFilledPrescription(params) {
    const url = this.BASE_URL_FILLED_PRESCRIPTION + RelativeUrlConfig.FETCH_FILLED_PRESCRIPTION;
    return this.httpResourceService.get(url, params);
  }
  fetchPrescriptionFilledByPharmacist(params){
    const url = this.BASE_URL_FILLED_PRESCRIPTION + RelativeUrlConfig.FETCH_FILLED_DATA;
    return this.httpResourceService.get(url, params);

  }
  fetchDoctorData(params){
    const url = this.BASE_URL_FILLED_PRESCRIPTION + RelativeUrlConfig.FETCH_PRESCRIBED_BY_INFO;
    return this.httpResourceService.get(url, params);

  }

  fetchPharmacistData(params){
    const url = this.BASE_URL_FILLED_PRESCRIPTION + RelativeUrlConfig.FETCH_FILLED_BY_INFO;
    return this.httpResourceService.get(url, params);
  }

}
