import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';
import { Messages } from '../../../core/config/messages';
import { FillprescriptionService } from './fillprescription.service';
import { DrugInfoService } from '../drug-info/drug-info.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { EventEmitter } from 'events';

@Component({
  selector: 'app-fillprescription',
  templateUrl: './fillprescription.component.html',
  styleUrls: ['./fillprescription.component.css']
})
export class FillprescriptionComponent implements OnInit {
  @Input() data: any;
  @Output() passCallback = new EventEmitter();
  fillPrescriptionForm: FormGroup;
  public prescriptionData = [];
  public drug = [];
  public pData = [];
  public dData = [];
  public patientInfo = [];
  patientId: String;
  drugId: String;
  public error = false;
  public presStatus;
  prescriptionID: String;
  requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
  pillIdErrorMessage = Messages.PILL_ID;
  numberFilledErrorMessage = Messages.PILL_QUANTITY;

  constructor(
    public drugInfoService: DrugInfoService,
    public fillPrescriptionService: FillprescriptionService,
    private fb: FormBuilder,
    private activeModal: NgbActiveModal,
  ) {}

  firstName: string;
  speciality: string;
  phone: Number;
  addressLine1: string;
  addressLine2: string;
  address: string;
  deaId: string;
  prescription_id: string;
  drug_id: string;

  drug_name: string;
  dosage: Number;
  diagnosis: String;
  prescribed_date: String;
  number_of_days: Number;
  number_of_refill: Number;
  icd_code: Number;
  number_prescribed: Number;
  date_prescribed: String;
  prescribed_by: string;
  remaining: Number;
  MME_D: string;
  quantity: string;
  prescriptionStatus;

  ngOnInit() {
    const d = Date.now();
    this.patientId = this.data.dataKey;
    this.pData = this.data.dataKey5;
    this.dData = this.data.dataKey6;
    this.drug = this.data.dataKey1;
    this.patientInfo = this.data.dataKey2;
    this.presStatus = this.data.dataKey8;

    this.fillPrescriptionForm = this.fb.group({
      numberFilled: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      notes: ['', Validators.required],
      firstName: [''],
      prescriptionID: [''],
      filled_on: [d],
      speciality: [''],
      phone: [''],
      address: [''],
      deaId: [''],
      number_of_days: [''],
      prescriptionId: [''],
      pillId: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      drugName: [''],
      dosage: [''],
      diagnosis: [''],
      numberPrescribed: [''],
      icd_10: [''],
      datePrescribed: [''],
      prescribedBy: [''],
      remaining: [''],
      MME_D: [''],
      quantity: [''],
      linkedDrug: ['']
    });

    const myFormValueChanges$ = this.fillPrescriptionForm.controls[
      'numberFilled'
    ].valueChanges;
    myFormValueChanges$.subscribe(numberFilled =>
      this.updateRemaining(numberFilled)
    );

    this.firstName = this.dData['firstName'];
    this.prescriptionID = this.pData['_id'];
    this.speciality = 'cardiologist';
    this.deaId = this.dData['profileDetail'][0].deaId;
    this.phone = this.dData['phone'];
    this.prescription_id = 'P123';
    this.addressLine1 = this.dData['addressLine1'];
    this.addressLine2 = this.dData['addressLine2'];
    this.address = this.addressLine1.concat(' ');
    this.address = this.address.concat(this.addressLine2);
    const drugName = this.getDrugDetailsFromId(this.pData['drug_id']);
    this.drug_name = drugName;
    this.number_prescribed = this.pData['number_of_days'] * this.pData['count'];
    this.dosage = this.pData['dosage'];
    this.diagnosis = this.pData['diagnosis'];
    this.number_of_days = this.pData['number_of_days'];
    this.icd_code = this.pData['icd_code'];
    this.remaining = this.pData['remaining_pill_count'];
    this.date_prescribed = this.pData['date_prescribed'];
    const appointmentDate = this.date_prescribed;

    var fields = appointmentDate.split('T');

    const presdate = fields[0];
    var fields = presdate.split('-');

    const year = fields[0];
    const month = fields[1];
    const dd = fields[2];

    this.prescribed_date = month + '/' + dd + '/' + year;
    this.prescribed_by = this.dData['firstName'];
    this.MME_D = this.pData['mme'];
    this.quantity = this.pData['quantity'];
    this.prescriptionStatus = this.presStatus['prescriptionStatus'];

    this.fillPrescriptionForm.controls['firstName'].setValue(this.firstName);
    this.fillPrescriptionForm.controls['phone'].setValue(this.phone);
    this.fillPrescriptionForm.controls['deaId'].setValue(this.deaId);
    this.fillPrescriptionForm.controls['address'].setValue(this.address);
    this.fillPrescriptionForm.controls['speciality'].setValue(this.speciality);
    this.fillPrescriptionForm.controls['prescriptionId'].setValue(
      this.prescription_id
    );
    this.fillPrescriptionForm.controls['phone'].setValue(this.phone);
    this.fillPrescriptionForm.controls['pillId'].setValue(this.drug_id);
    this.fillPrescriptionForm.controls['drugName'].setValue(this.drug_name);
    this.fillPrescriptionForm.controls['prescribedBy'].setValue(
      this.prescribed_by
    );
    this.fillPrescriptionForm.controls['dosage'].setValue(this.dosage);
    this.fillPrescriptionForm.controls['datePrescribed'].setValue(
      this.date_prescribed
    );
    this.fillPrescriptionForm.controls['numberPrescribed'].setValue(
      this.number_prescribed
    );
    this.fillPrescriptionForm.controls['icd_10'].setValue(this.icd_code);
    this.fillPrescriptionForm.controls['diagnosis'].setValue(this.diagnosis);
    this.fillPrescriptionForm.controls['remaining'].setValue(this.remaining);
    this.fillPrescriptionForm.controls['MME_D'].setValue(this.MME_D);
    this.fillPrescriptionForm.controls['quantity'].setValue(this.quantity);
  }

  onSubmit() {
    const fillPrescriptionData = this.fillPrescriptionForm.value;

    fillPrescriptionData['prescriptionID'] = this.prescriptionID;
    fillPrescriptionData['number_of_days'] = this.pData['number_of_days'];
    if (this.fillPrescriptionForm.valid) {
      this.fillPrescriptionService
        .saveFilledPrescription(fillPrescriptionData)
        .subscribe(
          response => {
            this.saveSuccessCallback(response);
          },
          error => {
            console.error(error);
          }
        );
    } else {
      this.validateAllFormFields(this.fillPrescriptionForm);
    }
  }

  private updateRemaining(numberFilled) {
    const remaining = this.pData['remaining_pill_count'] - numberFilled;
    if (remaining < 0) {
      this.error = true;
    } else {
      this.error = false;
    }
    this.fillPrescriptionForm.controls['remaining'].setValue(remaining);
  }

  saveSuccessCallback = (res) => {
    this.passCallback.emit(res);
    this.activeModal.dismiss(this.data);
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  getDrugDetailsFromId(drugId) {
    const Obj = this.drug.find(e => e._id === drugId);
    return Obj.name;
  }

  onNoClick = (): void => {
    this.activeModal.dismiss(this.data);
  }

  getDrugIdFromId(drugId) {
    for (const item of this.drug) {
      if (drugId === item._id) {
        return item.rxcui;
      }
    }
  }
}
