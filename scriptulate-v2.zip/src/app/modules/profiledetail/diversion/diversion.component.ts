import { Component, OnInit, Inject } from '@angular/core';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { setDialogs } from '../../../core/config/setDialogs';
import {
	FormBuilder,
	FormGroup,
	Validators,
	FormControl
} from '@angular/forms';
import { Messages } from '../../../core/config/messages';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { DiversionService } from './diversion.service';
import { Diversion } from './diversion';
import { ActivatedRoute } from '@angular/router';
@Component({
	selector: 'app-diversion',
	templateUrl: './diversion.component.html',
	styleUrls: ['./diversion.component.css']
})
export class DiversionComponent implements OnInit {
	diversionForm: FormGroup;
	BASE_URL_ADD_DIVERSION = EnvironemntConfig.BASE_URL;
	requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
	diversions: Diversion[];
	patientId: string;

	constructor(
		private route: ActivatedRoute,
		public dialogRef: MatDialogRef<CustomDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private diversionService: DiversionService,
		private fb: FormBuilder,
		private httpResourceService: HttpResourceService
	) {
		{
			setDialogs.isDiversion = !setDialogs.isDiversion;
			this.patientId = data.dataKey;
			console.log(this.patientId);
		}
	}

	ngOnInit() {
		this.diversionForm = this.fb.group({
			patientId: this.patientId,
			date: ['', Validators.required],
			type: ['', Validators.required],
			performed_by: ['', Validators.required],
			result: ['', Validators.required],
			comment: ['', Validators.required]
		});
	}
	onNoClick() {
		this.dialogRef.close();
	}
	closeDialog(params) {
		this.dialogRef.close(params);
	}
	onClick() {
		if (this.diversionForm.valid) {
			console.log('inside the onclick');
			this.diversionService.saveDiversion(this.diversionForm.value).subscribe(
				response => {
					console.log('inside the response');
					console.log(this.diversionForm.value);
					this.diversionSuccessCallback(response);
				},
				error => {
					console.log(error);
				}
			);
		} else {
			this.validateAllFormFields(this.diversionForm);
		}
	}

	diversionSuccessCallback(response) {
		console.log(response.body);
		const params = response.body;
		this.closeDialog(params);
	}

	validateAllFormFields(formGroup: FormGroup) {
		Object.keys(formGroup.controls).forEach(field => {
			const control = formGroup.get(field);
			if (control instanceof FormControl) {
				control.markAsTouched({ onlySelf: true });
			} else if (control instanceof FormGroup) {
				this.validateAllFormFields(control);
			}
		});
	}
}
