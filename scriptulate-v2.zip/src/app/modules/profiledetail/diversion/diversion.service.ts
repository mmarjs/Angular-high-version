import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DiversionService {
  BASE_URL_ADD_DIVERSION = EnvironemntConfig.BASE_URL;
  
  constructor(private httpResourceService: HttpResourceService,private http: HttpClient) { }

  saveDiversion(params){
    const url = this.BASE_URL_ADD_DIVERSION + RelativeUrlConfig.SAVE_DIVERSION;
    return this.httpResourceService.post(url,params);
  }
  fetchDiversion(params) {
    const url = this.BASE_URL_ADD_DIVERSION + RelativeUrlConfig.FETCH_DIVERSION;
    return this.httpResourceService.get(url,params);
    }

}

