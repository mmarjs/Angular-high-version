export interface Diversion {
    date:String,
    type:String,
    performed_by:String,
    result:String,
    comment: String;
}
