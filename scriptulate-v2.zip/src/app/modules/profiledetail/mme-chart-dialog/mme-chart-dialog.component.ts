import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-mme-chart-dialog',
  templateUrl: './mme-chart-dialog.component.html',
  styleUrls: [
    '../../../../app/common/modules/styles/shared.scss',
    '../../../../app/common/modules/styles/dialogs.scss',
    '../mme-chart/mme-chart.component.scss',
  ],
})
export class MmeChartDialogComponent implements OnInit {
  @Input() data: any;
  datasets: Array<any>;

  constructor(
    private activeModal: NgbActiveModal,
  ) {}

  closeDialog() {
    this.activeModal.close();
  }

  ngOnInit() {
    this.datasets = this.data.chartMmeData;
  }
}
