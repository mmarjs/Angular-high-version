import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { AddPrescriptionService } from '../add-prescription/service/add-prescription.service';
import { ProfiledetailService } from '../profiledetail.service';
import { DrugInfoService } from '../drug-info/drug-info.service';
import {ActivatedRoute} from '@angular/router';
import {Router} from '@angular/router';
import { CommonService } from '../../../core/services/commonService/common.service';
import { FillprescriptionComponent } from '../fillprescription/fillprescription.component';
import {DrugInfoComponent}from '../drug-info/drug-info.component';
@Component({
  selector: 'app-filled-patient',
  templateUrl: './filled-patient.component.html',
  styleUrls: ['./filled-patient.component.css']
})
export class FilledPatientComponent implements OnInit {
  patientId:string;
  public drug = [];
  public pres = [];
  public firstPres=[];
  public remPres=[];
  public patientInfo = [];
  public  distinctResult = [];
  public panelExpanded_dropdown_action: Boolean = false;
  panelExpanded2: Boolean = false;
  
  showMoreDrugs=false;
  noOfDrugs;
  constructor( public commonService: CommonService,public dialog: MatDialog,private router:Router,private route:ActivatedRoute,private profiledetailService: ProfiledetailService, public drugInfoService: DrugInfoService, public prescriptionService: AddPrescriptionService) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      console.log(params); 

      this.patientId =params.PatientId;
      console.log(this.patientId); 
    });

    let params = { "patientId":this.patientId }

    this.drugInfoService.getDrugs(params).subscribe(
      res => {
        this.drugSuccessCallback(res);

      },
      error => {
        console.log(error);
      }
    )
    /**
     * 
     */
    this.profiledetailService.getPatientInfo(params).subscribe(res => {
      this.patientSuccessCallback(res);
    });

    /**
     * 
     */
    
    let params1 = { "patientId": this.patientId, "type": "ALL_PRESCRIPTIONS" }
    this.prescriptionService.readPrescription(params1).subscribe(
      res => {
        this.resultSuccessCallback(res);

      },
      error => {
        console.log(error);
      }
    );
    /**
     * 
     */

  }

  readPrescription() {
    let params1 = { "patientId": this.patientId, "type": "ALL_PRESCRIPTIONS" }
    this.prescriptionService.readPrescription(params1).subscribe(
      res => {
        this.resultSuccessCallback(res);

      },
      error => {
        console.log(error);
      }
    );
  }


  public routeToProfileDetails() {
    this.router.navigate(['mypatient/profiledetail'], { queryParams: { patient_id: this.patientId } });
  }

  drugSuccessCallback(res) {

    this.drug = res.body;

    console.log("display body");
    console.log(this.drug);

  }
  patientSuccessCallback(detail) {

    this.patientInfo = detail.body;
    console.log("display body");
    console.log(this.patientInfo);

  }
  resultSuccessCallback(res) {

    this.pres=res.body;
    console.log("prescriptions",this.pres);
  
  
    let distinct=[];
    distinct=this.pres;
    this.distinctResult=this.commonService.getDistinctResults(distinct);
    console.log("distinct data result",this.distinctResult);
    let count=0;
    this.firstPres.length=0;
    this.remPres.length=0;
     //for(let item of res.body){
      for(let item of this.distinctResult){
       console.log("item of body",item);
       if(count<6){
         console.log("count",count);
         this.firstPres.push(item) ;
       }
       if(count>=6){
         this.remPres.push(item) ;
       }
       count=count+1;
     }
     console.log("first six",this.firstPres);
     console.log("next six",this.remPres);
     //this.pres = res.body;
     this.noOfDrugs=this.distinctResult.length;
     console.log("No of drugs",this.noOfDrugs);
     if(this.noOfDrugs>6){
       this.showMoreDrugs=true;
       console.log("show drug status",this.showMoreDrugs);
     }
     if(this.noOfDrugs<6){
       this.showMoreDrugs=false;
       console.log("show drug status",this.showMoreDrugs);
     }
     console.log(this.pres);
   

  }
  getDrugNameFromId(drugId) {
   for (let item of this.drug) {
      if (drugId == item._id) {
        return item.name;
      }
   }
    /*const Obj = this.drug.find(e => e.name === drugId);
    console.log("name",Obj.name);
    return Obj.name;*/

  }
 /* openDialog2(drug_id): void {
    const dialogRef = this.dialog.open(FillprescriptionComponent, {
   
      width: '97%',
      height: '100%',
      data: {
        dataKey: this.patientId,
        dataKey2: this.patientInfo,
        dataKey3: this.pres,
        dataKey1:this.drug,
        dataKey5:drug_id
      }

    });

  }*/
  openDialog2(id):void{
    const dialogRef = this.dialog.open(DrugInfoComponent, {
      width: '95%',
      height: '80%',
      data: {
        dataKey: this.patientId,
        dataKey2: this.patientInfo,
        dataKey3: this.pres,
        dataKey4: id,
        dataKey5:this.drug
      }

    });
  }








}
