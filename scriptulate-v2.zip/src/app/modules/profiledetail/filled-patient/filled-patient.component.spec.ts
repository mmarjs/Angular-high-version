import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilledPatientComponent } from './filled-patient.component';

describe('FilledPatientComponent', () => {
  let component: FilledPatientComponent;
  let fixture: ComponentFixture<FilledPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilledPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilledPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
