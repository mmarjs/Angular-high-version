import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { PDMPReportService } from '../pdmpreport/pdmpreport.service';
import { Observable, Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import * as Reducers from '@app/reducers';
import { selectPdmpReports, ApprissReport, pastReportFetchedByPatient } from '@app/reducers/doctor/doctor.reducer';
import { getPdmpReports } from '@app/reducers/doctor/doctor.actions';
import * as _ from 'lodash';
import { takeUntil } from 'rxjs/operators';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-past-reports',
  templateUrl: './past-reports.component.html',
  styleUrls: [
    '../mydialog/mydialog.component.scss',
    './past-reports.component.scss',
  ],
})
export class PastReportsComponent implements OnInit, OnDestroy {
  @Input() data: any;
  pastReports$: Observable<Array<ApprissReport>>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  pastReports: Array<ApprissReport> = [];

  constructor(
    private pdmpService: PDMPReportService,
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
  ) {}

  onNoClick = (): void => {
    this.activeModal.close();
  }

  onDownload = (report_id): void => {
    const url = this.pdmpService.downloadPDMPReports({ reportId: report_id });
    window.open(url, '_blank');
  }

  ngOnInit(): void {
    this.store
      .select(state => pastReportFetchedByPatient(state, {
        patient_id: this.data.patient_id,
      }))
      .subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(getPdmpReports({
            patient_id: this.data.patient_id,
            doctor_id: this.data.doctor_id,
          }));
        }
        this.pastReports$ = this.store.select(state => selectPdmpReports(state, { patient_id: this.data.patient_id }));

        this.pastReports$
          .pipe(takeUntil(this.unsubscribe$))
          .subscribe(reports => {
          if (reports) {
            this.pastReports = _.orderBy(reports, 'createdAt', 'desc');
          }
        });
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
