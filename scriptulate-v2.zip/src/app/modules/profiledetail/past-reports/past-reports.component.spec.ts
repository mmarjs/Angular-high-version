import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PastReportsComponent } from './past-reports.component';

describe('PastReportsComponent', () => {
  let component: PastReportsComponent;
  let fixture: ComponentFixture<PastReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PastReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
