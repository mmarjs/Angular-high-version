import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractsDialogComponentComponent } from './contracts-dialog-component.component';

describe('ContractsDialogComponentComponent', () => {
  let component: ContractsDialogComponentComponent;
  let fixture: ComponentFixture<ContractsDialogComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContractsDialogComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractsDialogComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
