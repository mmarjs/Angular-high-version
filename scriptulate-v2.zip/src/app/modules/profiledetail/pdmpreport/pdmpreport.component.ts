//
//  Created by Dmytro Udovytskyi on 4/26/19.
//  Copyright © 2019 Scriptulate, Inc. All rights reserved.
//

import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import html2canvas from 'html2canvas';
import * as jspdf from 'jspdf';
import * as lodash from 'lodash';
import { Observable, Subject, Subscription } from 'rxjs';
import { Doctor, DoctorsPharmacistsState } from '@app/reducers/doctor/doctor.reducer';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { Prescription } from '@app/reducers/prescription/prescription.reducer';
import * as moment from 'moment';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Store, select } from '@ngrx/store';
import * as Reducers from '@app/reducers/index';
import { addApprissReport } from '@app/reducers/doctor/doctor.actions';
import { HttpClient } from '@angular/common/http';
import { selectApprissReports, apprissReportFetchedByPatient, ApprissReport } from '@app/reducers/doctor/doctor.reducer';
import * as _ from 'lodash';
import { takeUntil } from 'rxjs/operators';
import { DoctorService } from '@app/modules/dashboard/doctor.service';
import { CommonService } from '@app/core/services/commonService/common.service';

@Component({
  selector: 'app-pdmpreport',
  templateUrl: './pdmpreport.component.html',
  styleUrls: ['./pdmpreport.component.scss'],
})
export class PDMPReportComponent implements OnInit {
  @Input() data: any;
  patientId: string;
  latestNarcanDate;
  noErrorWhileCreating: string="";
  @ViewChild("reportImage") image: ElementRef;
  patient: any;
  doctor$: Observable<object>;
  doctor: Doctor;
  doctors_and_pharmacists: DoctorsPharmacistsState;
  onReportSave: any;
  isTakingOrCompletedPrescriptions: Array<Prescription>;
  combinedCurrTakingOrCompleted: Array<Prescription>;
  currTakingTableData: any = [];
  isTakingOrCompletedTableData: any = [];
  lastFivePrescriptions: Array<Prescription>;
  apprissReports$: Subscription;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  pastReport: ApprissReport;
  downloading: boolean=false;
  lastPDMPSync:any='NA'
  hasImage: boolean=false;
  paymentTypes = {
    1: { type: 'Private Pay' },
    2: { type: 'Medicaid' },
    3: { type: 'Medicare' },
    4: { type: 'Commercial Insurance' },
    5: { type: 'Military Installations and VA' },
    6: { type: 'Workers\' Compensation' },
    7: { type: 'Indian Nations' },
    99: { type: 'Other' },
  };
  today = moment(new Date());

  constructor(
    private activeModal: NgbActiveModal,
    public commonService: CommonService,
    private store: Store<Reducers.State>,
    private httpClient: HttpClient,
    private doctorService: DoctorService
  ) {
  }

  getPaymentType = transactionId => {
    if (this.paymentTypes[transactionId]) {
      return this.paymentTypes[transactionId].type;
    }
    return 'N/A';
  }

  getLatestNarcanDate = prescriptions => {
    if ( !prescriptions ) {
      this.latestNarcanDate = null;
      return;
    }
    let filtered = prescriptions.filter(p => p.is_taking === true);
    filtered = filtered.filter(p => p.nalaxone || false);
    const narcanPrescriptions = lodash.sortBy(filtered, p => p.date_prescribed);
    const lastNarcanPrescription = lodash.last(narcanPrescriptions);

    if (lastNarcanPrescription) {
      this.latestNarcanDate = moment(
        lastNarcanPrescription.formatted_date_prescribed,
        ['MM/DD/YYYY']
      ).format('MMM D, YYYY');
    }
  }

  onClickAddNote = () => {
    var rowNotes = document.getElementById('rowNotes');    
    rowNotes.style.display='block';
    var rowNotePreview = document.getElementById('rowNotePreview');    
    rowNotePreview.style.display='none';
    var rowAddNotes = document.getElementById('rowAddNotes');
    rowAddNotes.style.display='none';
    }

  onClickSaveNote = () => {

    var rowNotes = document.getElementById('rowNotes');    
    rowNotes.style.display='none';
    var rowNotePreview = document.getElementById('rowNotePreview');    
    rowNotePreview.style.display='block';

    var taNotes = document.getElementById('taNotes');    
    var notes = document.getElementById('notes');
    notes.innerText =  (taNotes as HTMLTextAreaElement).value;
    if(notes.innerText == "")
    {
      rowNotePreview.style.display='none';
    }
    var rowAddNotes = document.getElementById('rowAddNotes');
    rowAddNotes.style.display='block';
  }
  exportToPDF = () => {
    this.downloading=true;
    const data = document.getElementById('report_container');
    var elem = document.getElementById('btnSave');
    var taNotes = document.getElementById('taNotes');
    var divNotes = document.getElementById('divNotes');
    var notes = document.getElementById('notes');

    notes.innerText = (taNotes as HTMLTextAreaElement).value;
    elem.style.display='none';
    taNotes.style.display='none';
    divNotes.style.display='block';
    notes.style.display='block';

    var rowNotes = document.getElementById('rowNotes');    
    rowNotes.style.display='none';
    var rowNotePreview = document.getElementById('rowNotePreview');    
    rowNotePreview.style.display='block';

    var taNotes = document.getElementById('taNotes');    
    var notes = document.getElementById('notes');
    notes.innerText = (taNotes as HTMLTextAreaElement).value;
    if(notes.innerText == "")
    {
      rowNotePreview.style.display='none';
    }
    var rowAddNotes = document.getElementById('rowAddNotes');
    rowAddNotes.style.display='none';
    
    var rowNotes = document.getElementById('rowNotes');    
    rowNotes.style.display='none';
    var rowNotePreview = document.getElementById('rowNotePreview');    
    rowNotePreview.style.display='block';


    html2canvas(data, {
      allowTaint: false,
      testTaint: true,
      logging: true,
      scale: 1.17,
    }).then((canvas) => {
      const contentDataURL = canvas.toDataURL('image/png', 1.0);
      const pdf = new jspdf('p', 'mm', "a4");
      var width = pdf.internal.pageSize.getWidth();
      var height = pdf.internal.pageSize.getHeight();
      pdf.addImage(contentDataURL, 'JPEG', 0, 0, width, height,'','FAST');
      const fileName = `${this.patient.first_name}_${this.patient.last_name}_Scriptulate_SummaryReport_${this.getCurrentDateTime().date}.pdf`;
      this.store.dispatch(addApprissReport({
          file_name: fileName,
          uploaded_by_user_id: this.doctor.id,
          uploaded_for_user_id: +this.patientId,
          file_category: 'chart_report',
          file_type: 'application/pdf',
          file: pdf.output('blob'),
      }));
      this.downloading=false;
      elem.style.display='block';
      var rowNotes = document.getElementById('rowAddNotes');    
      rowNotes.style.display='block';
      var rowNotePreview = document.getElementById('rowNotePreview');    
      rowNotePreview.style.display='block';
      this.commonService.setPDMPSummaryReportDownloaded(true);
    });
  }

  getCurrentDateTime = () => {
    const date = new Date();
    return {
      date: `${date.getFullYear()}${date.getMonth() +
        1}${date.getDate()}${date.getTime()}`,
      time: date,
    };
  }

  print = (): void => {
    let printContents, popupWin;
    printContents = document.getElementById('report_container').outerHTML;
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
			<html>
				<head>
					<title>Summery Report</title>
					<style>
					//........Customized style.......

					</style>
					<link rel="stylesheet" href="/assets/scss/print.css">
				</head>
				<body onload="window.print();window.close()">${printContents}</body>
			</html>`);
    popupWin.document.close();
  }

  getUserInfo = (id: number, type: string) => {
    let user = null;
    if (!this.doctors_and_pharmacists.entities[id]) {
      return false;
    }
    user = this.doctors_and_pharmacists.entities[id];

    switch (type) {
      case 'first_name': {
        return user.first_name;
      }
      case 'last_name': {
        return user.last_name;
      }
      case 'phone_number': {
        return user.phone_number;
      }
      case 'fax_number': {
        return user.fax_number;
      }
      default: {
        return null;
      }
    }
  }

  ngOnInit() {
    this.hasImage=false;
    this.patientId = this.data.patientId;
    this.patient = this.data.patient;
    this.doctor = this.data.doctor;
    this.doctors_and_pharmacists = this.data.doctors_and_pharmacists;
    this.onReportSave = this.data.onReportSave;
    this.lastFivePrescriptions = this.data.lastFivePrescriptions;
    this.isTakingOrCompletedPrescriptions = this.data.isTakingOrCompletedPrescriptions;
    this.combinedCurrTakingOrCompleted = this.data.combinedCurrTakingOrCompleted;


    this.apprissReports$ = this.doctorService.getApprissReports({
            doctor_id: this.data.doctor.id,
            patient_id: this.data.patient.id,
    }).subscribe(reports=>{
            if (reports.body) {
              this.pastReport = reports.body;
            }
            if(reports.body.createdAt){
              this.lastPDMPSync=reports.body.createdAt;
            }
    });
    const httpOptions={
      responseType: 'arraybuffer' as 'json'
    };
    const x = this.httpClient.post("/api/report",{patientId: this.patientId},httpOptions).subscribe((res: ArrayBuffer) => {
      let arrayBufferView = new Uint8Array( res);
      var blob = new Blob( [ arrayBufferView ], { type: "image/jpeg" } );
      var urlCreator = window.URL;
      var imageUrl = urlCreator.createObjectURL( blob );
      this.image.nativeElement.src = imageUrl;
      this.hasImage=true;
      },(error)=> {
        let err = JSON.parse(String.fromCharCode.apply(null, new Uint8Array(error.error)));
        this.noErrorWhileCreating=err.error;
        console.log(error);
      }
      );
  }

  onNoClick = () => {
    this.activeModal.dismiss(this.data);
    this.apprissReports$.unsubscribe();
  }
}
