import { Component, OnInit, Input } from '@angular/core';
import { ScriptLoaderService } from 'angular-google-charts';
import * as moment from 'moment';
import { Prescription } from '@app/reducers/prescription/prescription.reducer';
import * as lodash from 'lodash';
import { setDrugName } from '@app/helpers';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {
  @Input() drugData: any;
  colors = ['#35bbb0', '#72cad6', '#4c79ba'];
  data: any;
  columnNames: string[];
  options: google.visualization.TimelineOptions;
  type: string;
  dynamicResize: boolean;
  renderTimeline = true;
  dynamicChartHeight: number;
  roles: any;
  constructor(private loaderService: ScriptLoaderService) {
    this.type = 'Timeline';
    this.data = [];
    this.dynamicResize = true;
    this.options = {
      colors: ['#35bbb0', '#72cad6', '#4c79ba'],
      timeline: {
        groupByRowLabel: true,
        rowLabelStyle: {
          color: '#000000',
          fontName: 'Montserrat',
          fontSize: '12'
        },
        barLabelStyle: {
          color: '#000000',
          fontName: 'Montserrat',
          fontSize: '16'
        }
      }
    };
  }

  renderChart = () => {
    if (!this.drugData.length) {
      this.renderTimeline = false;
      return;
    }
    const rows = [];
    const rowsData = [];
    let endDate: moment.Moment;
    const today: moment.Moment = moment(new Date());
    this.drugData.forEach((prescription: Prescription) => {
      const { stop_date, is_taking, last_formatted_filled_date } = prescription;
      const startDate = moment(last_formatted_filled_date, 'MM/DD/YYYY');

      if (stop_date.isSameOrBefore(today)) {
        endDate = moment(stop_date, ['MM/DD/YYYY']);
      } else {
        endDate = today;
      }
      const drugName = setDrugName(`${prescription.drug_name}`).drug_name;
      const labelDrugName = drugName;

      const labelPrescriptionStatus = `${
        is_taking ? '(currently taking)' : '(completed)'
      }`;

      rowsData.push({
        labelDrugName: labelDrugName,
        labelPrescriptionStatus: labelPrescriptionStatus,
        start: startDate.toDate(),
        end: endDate.toDate()
      });
    });

    const sortedRows = lodash.sortBy(rowsData, ['labelDrugName']);

    rows.push([
        sortedRows[0].labelDrugName +
          '\r' +
          sortedRows[0].labelPrescriptionStatus,
        sortedRows[0].start,
        sortedRows[0].end
    ]);
    for (let i = 1; i < sortedRows.length; i++) {
      this.getFilteredRows(i, sortedRows[i], sortedRows, rows);
      rows.push([
        sortedRows[i].labelDrugName +
          '\r' +
          sortedRows[i].labelPrescriptionStatus,
        sortedRows[i].start,
        sortedRows[i].end
      ]);
    }

    this.loaderService.onReady.subscribe(() => {
      this.loaderService.loadChartPackages([this.type]).subscribe(() => {
        this.data = new google.visualization.DataTable();
        this.data.addColumn({ type: 'string', id: 'Medication' });
        this.data.addColumn({ type: 'date', id: 'Start' });
        this.data.addColumn({ type: 'date', id: 'End' });
        this.data.addRows(rows);

        let multiplier = 25;

        if (this.data.getNumberOfRows()) {
          if (this.data.getNumberOfRows() <= 25) {
            multiplier = 85;
          }
          this.dynamicChartHeight =
            this.data.getNumberOfRows() * multiplier + 70;
        } else {
          this.renderTimeline = false;
        }
        this.options.height = this.dynamicChartHeight;
      });
    });
  }

  getFilteredRows = (
    i: number,
    sRow: any,
    sortedRows: any,
    rows: any
  ): void => {
    if (sRow.labelDrugName === sortedRows[i - 1].labelDrugName) {
      if (sortedRows[i - 1].start < sRow.start) {
        sRow.start = sortedRows[i - 1].start;
      }
      if (sortedRows[i - 1].end > sRow.end) {
        sRow.end = sortedRows[i - 1].end;
      }
      rows.pop();
    }
  }

  ngOnInit() {
    this.renderChart();
  }
}
