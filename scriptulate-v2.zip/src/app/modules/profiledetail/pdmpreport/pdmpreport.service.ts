/**
 *  Copyright (c) 2019. Auth by Dmytro Udovytskyi.
 */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root'
})

export class PDMPReportService {

    BASE_URL = EnvironemntConfig.BASE_URL;
    private httpService;
  
    constructor(private httpResourceService: HttpResourceService) {
      this.httpService = httpResourceService
    }
  
    /**
     * @name uploadPDMP
     * @desc upload pdmp pdf file and store name & path & date on database
     * @param params 
     */
    uploadPDMPReport(params){
        const url = this.BASE_URL + RelativeUrlConfig.UPLOAD_SUMMARY_REPORT;
        // const url = 'http://192.168.0.114:3000/api/deal-file/testUpload';
        return this.httpService.formPost(url,params);
    }

    addPDMPReport(params) {
      const url = this.BASE_URL + RelativeUrlConfig.ADD_SUMMARY_REPORT;
      return this.httpResourceService.post(url, params);
    }

    fetchPDMPReports(params) {
      const url = this.BASE_URL + RelativeUrlConfig.FETCH_SUMMARY_REPORTS;
      return this.httpResourceService.get(url, params);
    }

    downloadPDMPReports(params) {
      // const url = EnvironemntConfig.BASE_URL + RelativeUrlConfig.DOWNLOAD_SUMMARY_REPORTS;
      const url = EnvironemntConfig.DOWNLOAD_URL + RelativeUrlConfig.DOWNLOAD_SUMMARY_TEST + '?reportId=' + params.reportId;
      return url; //this.httpResourceService.get(url, params);
    }
}
  