//
//  Created by Dmytro Udovytskyi on 4/26/19.
//  Copyright © 2019 Scriptulate, Inc. All rights reserved.
//

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PDMPReportComponent } from './pdmpreport.component';

describe('PDMPReportComponent', () => {
  let component: PDMPReportComponent;
  let fixture: ComponentFixture<PDMPReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PDMPReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PDMPReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
