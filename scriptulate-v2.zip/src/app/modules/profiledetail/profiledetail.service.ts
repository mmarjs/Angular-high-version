/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../core/config/RelativeUrlConfig';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
/**
 * @author Nishtha Jain
 * @name ProfiledetailService
 * @desc This is a service file. the method in service interacts with the databsse
 */
export class ProfiledetailService {
  BASE_URL_ADD_NOTES = EnvironemntConfig.BASE_URL;
  BASE_URL_GET_NOTES = EnvironemntConfig.BASE_URL;

  ss_event: EventSource;

  constructor(
    private httpResourceService: HttpResourceService,
    private http: HttpClient
  ) {}

  createEventSource(event_name, callback) {
    if (event_name === 'add_new_prescription') {
      const url = `http://192.168.0.114:8085/patient-management/prescription/sse`; //this.BASE_URL_ADD_NOTES + RelativeUrlConfig.ADD_PRESCRIPTION_SSE;
      this.ss_event = new EventSource(url);
      this.ss_event.onmessage = e => {
        console.log('--------- SSE Message ---------', e);
      };
      this.ss_event.addEventListener(event_name, result => {
        callback(result);
      });
      this.ss_event.onerror = e => {
        console.log('EventSource Error: ', e);
      };
    }
  }

  disconnect() {
    this.ss_event.close();
  }
  getPatientInfo(params) {
    const url = this.BASE_URL_ADD_NOTES + RelativeUrlConfig.PATIENT_INFO;
    return this.httpResourceService.get(url, params);
  }
}
