import { TestBed, inject } from '@angular/core/testing';

import { AddPrescriptionService } from './add-prescription.service';

describe('AddPrescriptionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddPrescriptionService]
    });
  });

  it('should be created', inject([AddPrescriptionService], (service: AddPrescriptionService) => {
    expect(service).toBeTruthy();
  }));
});
