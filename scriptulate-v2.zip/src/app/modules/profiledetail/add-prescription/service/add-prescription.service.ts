import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../../core/config/RelativeUrlConfig';
import { Observable } from 'rxjs';
import {Drugs} from '../../drugs';
import {map, tap} from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class AddPrescriptionService {

  BASE_URL_PRESCRIPTION = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) { }

  savePrescription(params){
    const url = this.BASE_URL_PRESCRIPTION + RelativeUrlConfig.ADD_PRESCRIPTION;
    return this.httpResourceService.post(url,params);
  }
  readPrescription(params){
    console.log('from pres service');
    console.log(params);
    const url = this.BASE_URL_PRESCRIPTION + RelativeUrlConfig.GET_PRESCRIPTION;
    return this.httpResourceService.get(url,params)
    /*http.get(this.baseUri+'/read',{headers:this.headers});*/
  }  
  getDrugs(params : any): Observable<any>{
    
    const url = this.BASE_URL_PRESCRIPTION+ RelativeUrlConfig.GET_DRUGLIST;
    return this.httpResourceService.get(url,params);
  }
  
  createNewAlert(params) {
    const url = this.BASE_URL_PRESCRIPTION + RelativeUrlConfig.CREATE_PRES_ALERT;
    return this.httpResourceService.post(url,params);
  }

 /* search(filter: {name: string} = {name: ''}, page = 1): Observable<Drugs> {
    const params={"_id":""},
    
    return this.httpResourceService.get(url,params)
    .pipe(
      tap((response: Drugs) => {
        response.results = response.results
          .map(user => new User(user.id, user.name))
          // Not filtering in the server since in-memory-web-api has somewhat restricted api
          .filter(user => user.name.includes(filter.name))

        return response;
      })
      );
  }*/

  getFrequency(params){
    const url = this.BASE_URL_PRESCRIPTION+ RelativeUrlConfig.GET_FREQUENCY;
    return this.httpResourceService.get(url,params);
  }

  getDrugGroup(params){
    const url = this.BASE_URL_PRESCRIPTION+ RelativeUrlConfig.GET_DRUG_GROUP;
    return this.httpResourceService.get(url,params);
  }
  
}
