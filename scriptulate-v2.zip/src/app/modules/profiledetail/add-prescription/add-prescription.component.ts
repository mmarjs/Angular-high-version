import { Component, Inject, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Messages } from '@app/core/config/messages';
import { setDialogs } from '@app/core/config/setDialogs';
import { CommonService } from '@app/core/services/commonService/common.service';
import * as Reducers from '@app/reducers/index';
import { Store } from '@ngrx/store';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';
import { AddPrescriptionService } from './service/add-prescription.service';
import { createPrescription } from '@app/reducers/doctor/doctor.actions';

@Component({
  selector: 'app-add-prescription',
  templateUrl: './add-prescription.component.html',
  styleUrls: ['./add-prescription.component.css'],
})
export class AddPrescriptionComponent implements OnInit {
  public drugs = [];
  public drug1 = [];
  public freq = [];
  public icd = [];
  public drugGroup = [];
  icdTenCode = null;
  prescription_array = [];
  patientId: string;
  diagnosisLabel = '';
  public patientInfo = [];
  drugList = [];
  options: string[] = ['One', 'Two', 'Three'];
  prescriptionForm: FormGroup;
  quantity = 0;
  count;
  mme;

  drugOptions: Observable<any[]>;
  icdOptions: Observable<any[]>;
  patient$: Observable<object>;
  doctor$: Observable<object>;

  medication$: Observable<object>;
  selectedDrug: any;
  selectedIcd: any;
  patient;
  doctor;

  items: FormArray;

  requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
  countErrorMessage = Messages.COUNT_ERROR_MESSAGE;
  daysErrorMessage = Messages.DAYS_ERROR_MESSAGE;
  refillErrorMessage = Messages.REFILL_ERROR_MESSAGE;
  icdErrorMessage = Messages.ICD_ERROR_MESSAGE;

  prnValidatorPattern = /(^[pP]{1}[rR]{1}[nN]{1}$\b|^\d+$)/gm;
  prnOrNumRegExp = /(^[pP]{1}[rR]{1}[nN]{1}$\b)/gm;

  constructor(
    public commonService: CommonService,
    private prescriptionService: AddPrescriptionService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<CustomDialogComponent>,
    private store: Store<Reducers.State>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    setDialogs.isPrescription = !setDialogs.isPrescription;
    this.patient$ = data.patient;
    this.medication$ = data.medication;
    this.doctor$ = data.doctor;
  }

  ngOnInit() {
    this.medication$.subscribe(medication => {
      this.freq = medication['drug_frequency'];
      this.icd = medication['drug_icd_code'];
      this.drugGroup = medication['drug_groups'];
      this.drugs = medication['drugs'];
    });

    this.patient$.subscribe(patient => {
      this.patient = patient;
    });

    this.doctor$.subscribe(doctor => {
      this.doctor = doctor;
    });

    this.setUpForm();
    this.onValueChange();
  }

  setUpForm() {
    this.prescriptionForm = this.fb.group({
      drug_id: ['', Validators.required],
      frequency: ['', Validators.required],
      tablet: ['Tablet', Validators.required],
      day: ['Day', Validators.required],
      count: ['', [Validators.required]],
      number_of_days: [
        0,
        [Validators.required, Validators.pattern(this.prnValidatorPattern)],
      ],
      number_of_refill: [0, [Validators.required]],
      date_prescribed: [new Date(), Validators.required],
      icd10: ['', Validators.required],
      nalaxone: ['', Validators.required],
      dosage: ['', Validators.required],
      diagnosis: ['', Validators.required],
      comment: [''],
      quantity: new FormControl('', Validators.required),
      mme: ['', Validators.required],
      reason_for_mme: [''],
    });

    const myFormValueChanges$ = this.prescriptionForm.controls['count']
      .valueChanges;
    const myFormValueChanges$1 = this.prescriptionForm.controls[
      'number_of_days'
    ].valueChanges;
    const myFormValueChanges$2 = this.prescriptionForm.controls['dosage']
      .valueChanges;
    const myFormValueChanges$3 = this.prescriptionForm.controls['frequency']
      .valueChanges;
    const myFormValueChanges$4 = this.prescriptionForm.controls['icd10']
      .valueChanges;

    myFormValueChanges$.subscribe(count => this.updateQuantity1(count));
    myFormValueChanges$1.subscribe(numberOfDays => {
      if (new RegExp(this.prnOrNumRegExp).test(numberOfDays)) {
        return this.updateQuantity(numberOfDays.toLowerCase());
      } else {
        return this.updateQuantity(Number(numberOfDays));
      }
    });
    myFormValueChanges$2.subscribe(dosage => this.updateMME(dosage));
    myFormValueChanges$3.subscribe(frequency => this.updateCount(frequency));
    myFormValueChanges$4.subscribe(name => this.updateDiagnosis(name));
  }

  onValueChange() {
    this.drugOptions = this.prescriptionForm.controls.drug_id.valueChanges.pipe(
      startWith(''),
      map(value => this._filterDrug(value))
    );
    this.icdOptions = this.prescriptionForm.controls.icd10.valueChanges.pipe(
      startWith(''),
      map(value => this._filterIcd(value))
    );
  }

  private _filterDrug(value: any): string[] {
    let filterValue = null;
    if (typeof value === 'object') {
      filterValue = value.name.toLowerCase();
    } else {
      filterValue = value.toLowerCase();
    }

    return this.drugs.filter(
      option => option.name.toLowerCase().indexOf(filterValue) === 0
    );
  }

  private _filterIcd(value: string = ''): string[] {
    const filterValue = value.toLowerCase();

    this.icdTenCode = filterValue;
    return this.icd.filter(
      item => item.desc.toLowerCase().indexOf(filterValue) === 0
    );
  }

  private updateQuantity(numberOfDays) {
    this.quantity = 0;
    let totalQuantity = 0;
    if (new RegExp(this.prnOrNumRegExp).test(numberOfDays)) {
      totalQuantity = this.prescriptionForm.controls['count'].value * 30;
    } else {
      totalQuantity =
        this.prescriptionForm.controls['count'].value * numberOfDays;
    }
    this.prescriptionForm.controls['quantity'].setValue(totalQuantity);
  }

  private updateQuantity1(count) {
    this.quantity = 0;
    let totalQuantity: Number;
    if (
      new RegExp(this.prnOrNumRegExp).test(
        this.prescriptionForm.controls['number_of_days'].value
      )
    ) {
      totalQuantity = this.prescriptionForm.controls['count'].value * 30;
    } else {
      totalQuantity =
        count * this.prescriptionForm.controls['number_of_days'].value;
    }
    this.prescriptionForm.controls['quantity'].setValue(totalQuantity);
  }

  private updateMME(dosage) {
    this.mme = 0;
    const drugId = this.selectedDrug.id;

    const mef = this.findMef(drugId);
    const totalmme =
      this.prescriptionForm.controls['count'].value * dosage * mef;
    this.prescriptionForm.controls['mme'].setValue(totalmme);
  }

  private updateCount(frequency) {
    this.count = 0;
    const number_of_tablets = this.findTabletCount(frequency);
    this.prescriptionForm.controls['count'].setValue(number_of_tablets);
  }

  private updateDiagnosis(name) {
    let desc = '';
    for (const item of this.icd) {
      if (item.name == name) {
        desc = item.desc;
      }
    }
    this.diagnosisLabel = desc;
    this.prescriptionForm.controls['diagnosis'].setValue(desc);
  }

  onNoClick() {
    return this.dialogRef.close();
  }

  onSave() {
    const formData = this.prescriptionForm.value;
    const { id: drug_id } = this.selectedDrug;

    formData['date_prescribed'] = moment(
      this.prescriptionForm.controls['date_prescribed'].value
    ).toISOString();
    formData['drug_id'] = drug_id;
    formData['status'] = true;
    formData['icd'] = this.icdTenCode;
    formData['patient_id'] = this.patient.id;
    formData['prescribed_by_user_id'] = this.doctor.id;
    formData['nalaxone'] = Boolean(formData['nalaxone']);

    if (this.prescriptionForm.valid) {
      this.store.dispatch(createPrescription({ formData }));
      this.dialogRef.close();
    } else {
      this.validateAllFormFields(this.prescriptionForm);
    }
  }

  saveForLater() {
    const prescription_element = this.prescriptionForm.value;
    const pdate: string = '' + this.prescriptionForm.value.datePrescribed;
    const presDate = this.commonService.changeDate(pdate);
    prescription_element['datePrescribed'] = presDate;

    const { id: drug_id, is_controlled_substance } = this.selectedDrug;

    prescription_element['patientId'] = this.patientId;
    prescription_element['drug_id'] = drug_id;
    prescription_element['status'] = false;
    prescription_element['remainingPillCount'] = this.prescriptionForm.controls[
      'quantity'
    ].value;
    prescription_element['user_id'] = '5bc42ab915f97c68385026bf';
    prescription_element['is_controlled_substance'] = is_controlled_substance;

    if (this.prescriptionForm.valid) {
      this.prescription_array.push(prescription_element);

      this.prescriptionService
        .savePrescription(this.prescription_array)
        .subscribe(
          response => {
            this.saveForLaterSuccessCallback(response);
          },
          error => {
            console.error(error);
          }
        );
    } else {
      this.validateAllFormFields(this.prescriptionForm);
    }
  }

  private saveForLaterSuccessCallback(response) {
    const params = '';
    this.closeDialog(params);
  }

  closeDialog(params) {
    this.dialogRef.close(params);
  }

  findTabletCount(frequency) {
    for (const item of this.freq) {
      if (frequency === item.abbreviation) {
        return item.no_of_tablets_per_day;
      }
    }
  }

  findMef(drugId) {
    const Obj = this.drugGroup.find(e => e.drug_id === drugId);
    return Obj ? Obj.mef : 0;
  }

  makePrescriptionArray() {
    const prescription_data = this.prescriptionForm.value;

    prescription_data['patient_id'] = this.patient.id;
    prescription_data['prescribed_by_user_id'] = this.doctor.id;
    prescription_data['drug_id'] = this.selectedDrug['id'];
    prescription_data['status'] = true;
    prescription_data['remaining_pill_count'] = this.prescriptionForm.controls[
      'quantity'
    ].value;
    prescription_data['is_controlled_substance'] = this.selectedDrug[
      'is_controlled_substance'
    ];

    if (this.prescriptionForm.valid) {
      this.prescription_array.push(prescription_data);
    } else {
      this.validateAllFormFields(this.prescriptionForm);
    }
  }

  resetForm() {
    this.prescriptionForm.reset();
    this.onValueChange();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  onDrugSelected($event) {
    this.prescriptionForm.patchValue({
      drug_id: $event.option.value.name,
    });
    this.selectedDrug = $event.option.value;
  }
}
