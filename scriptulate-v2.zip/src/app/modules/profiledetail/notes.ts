export interface Notes {
        date:String,
        comments: String;
      }
