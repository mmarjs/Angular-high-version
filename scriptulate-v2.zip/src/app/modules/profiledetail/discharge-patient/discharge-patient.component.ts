import { Component, OnInit,Inject} from '@angular/core';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { setDialogs } from '../../../core/config/setDialogs';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Messages } from '../../../core/config/messages';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import {ActivatedRoute} from '@angular/router';


import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-discharge-patient',
  templateUrl: './discharge-patient.component.html',
  styleUrls: ['./discharge-patient.component.css']
})
export class DischargePatientComponent implements OnInit {
  dischargeForm: FormGroup;
  BASE_URL = EnvironemntConfig.BASE_URL;
  requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
  patientId:string;
  public patientInfo=[];

  constructor(private route:ActivatedRoute,public dialogRef: MatDialogRef<CustomDialogComponent>,@Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder, private httpResourceService: HttpResourceService
  ) {
    setDialogs.isDischarge = !setDialogs.isDischarge;
    this.patientId=data.dataKey;
    this.patientInfo=data.dataKey2;
     console.log(this.patientId);
  }


  ngOnInit() {
    this.dischargeForm = this.fb.group({
      reason: ['', Validators.required],
    
      patientId:this.patientId
    });
  }

  onNoClick() {
    return this.dialogRef.close();
  }

  closeDialog(params) {
    console.log("params",params);
    this.dialogRef.close(params);
   }

  onClick() {

    if (this.dischargeForm.valid) {
      console.log("inside the onclick");
      this.saveDischarge(this.dischargeForm.value).subscribe(
        response => {
          console.log("inside the response");
          console.log(this.dischargeForm.value);
          this.dischargeSuccessCallback(response);
        },
        error => {
          console.log(error);
        }
      )
    } else {
      this.validateAllFormFields(this.dischargeForm);
    }

  }


  saveDischarge(params) {
    const url = this.BASE_URL + RelativeUrlConfig.DISCHARGE;
    return this.httpResourceService.post(url, params);
  }
  private dischargeSuccessCallback(response) {
    //console.log("this is working properly");
    const params= response.body;
    this.closeDialog(params);
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
