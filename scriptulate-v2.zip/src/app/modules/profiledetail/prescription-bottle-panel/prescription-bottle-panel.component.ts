import {
    Component, Input, OnChanges,
    SimpleChanges, Output, EventEmitter,
} from '@angular/core';
import * as _ from 'lodash';
import { MaterialService } from '@app/core/services/materialService';
import { MatDialog } from '@angular/material';
import { DrugInfoComponent } from '../drug-info/drug-info.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-prescription-bottle-panel',
    templateUrl: './prescription-bottle-panel.component.html',
    styleUrls: [
        '../profiledetail.component.scss',
        './prescription-bottle-panel.component.scss'
    ],
})
export class PrescriptionBottlePanelComponent implements OnChanges {
    @Input() role: string;
    @Input() data: any;
    @Input() patient: any;
    @Input() doctorsAndPharmacists: any;
    @Output() syncClick: EventEmitter<any> = new EventEmitter();
    @Output() newPrescriptionClick: EventEmitter<any> = new EventEmitter();
    prescriptions: Array<any> = [];
    doctors_and_pharmacists: any;
    patientInfo: any;
    isCurrentTabActive: boolean;
    pCurrentlyTaking = [];
    pastPrescriptions = [];
    list = [];
    filterOrOrderBy = 'all';

    constructor(
        private matService: MaterialService,
        public matDialog: MatDialog,
        public modal: NgbModal,
    ) {
        this.matService.registerIcon('pill-bottle', 'assets/svgs/icon_medicine_bottle.svg');
        this.matService.registerIcon('tick', 'assets/svgs/tick.svg');
        this.matService.registerIcon('funnel', 'assets/svgs/funnel.svg');
        this.matService.registerIcon('grid-view', 'assets/svgs/grid_view.svg');
    }

    onClickSync = () => {
        this.syncClick.emit();
    }

    onClickNewPrescription = () => {
        this.newPrescriptionClick.emit();
    }

    setupPrescriptions = (currentValue) => {
        const { combinedCurrTakingOrCompleted, combinedFormattedPrescriptions, formattedPrescriptions } = currentValue;
        if (!combinedCurrTakingOrCompleted.length) {
            this.pCurrentlyTaking = [];
        } else {
            this.pCurrentlyTaking = combinedCurrTakingOrCompleted.filter(p => p.is_taking);
        }
        this.prescriptions = formattedPrescriptions;
        this.pastPrescriptions = combinedFormattedPrescriptions;
    }

    displayPrescriptions = (currentOrPast: string) => {
        if (currentOrPast === 'current') {
            this.isCurrentTabActive = true;
            if (this.filterOrOrderBy === 'all') {
                this.list = this.pCurrentlyTaking;
            }
            if (this.filterOrOrderBy === 'controlled') {
                this.list = this.pCurrentlyTaking.filter(p => p.is_controlled_substance);
            }
        }
        if (currentOrPast === 'past') {
            this.isCurrentTabActive = false;
            if (this.filterOrOrderBy === 'all') {
                this.list = this.pastPrescriptions;
            }
            if (this.filterOrOrderBy === 'controlled') {
                this.list = this.pastPrescriptions.filter(p => p.is_controlled_substance);
            }
        }
    }

    showControlledSubstancesOnly = (): void => {
        this.list = this.list.filter(p => p.is_controlled_substance);
        this.filterOrOrderBy = 'controlled';
    }

    showAll = () => {
        this.filterOrOrderBy = 'all';
        if (this.isCurrentTabActive) {
            this.displayPrescriptions('current');
            return;
        }
        this.displayPrescriptions('past');
    }

    showOrder = (order: string) => {
        if (!this.list.length) {
            if (this.isCurrentTabActive) {
                this.displayPrescriptions('current');
            }
            if (!this.isCurrentTabActive) {
                this.displayPrescriptions('past');
            }
        }
        if (order === 'asc') {
            this.filterOrOrderBy = 'oldest';
            this.list = _.orderBy(this.list, 'formatted_date_prescribed', 'asc');
            return;
        }
        this.filterOrOrderBy = 'latest';
        this.list = _.orderBy(this.list, 'formatted_date_prescribed', 'desc');
    }

    openDrugInfo = (prescription: any) => {
        const drugInfoRef = this.modal.open(DrugInfoComponent, { windowClass: 'ngb-modal-size-94rem' });
        drugInfoRef.componentInstance.data = {
            patient: this.patient,
            prescription: prescription,
            formattedPrescriptions: this.prescriptions,
            doctors_and_pharmacists: this.doctors_and_pharmacists,
        };
        drugInfoRef.result.then(res => {
            return;
        }).catch(err => {});
    }

    trackByIndex = (index, item) => index;

    ngOnChanges(changes: SimpleChanges ) {
        if (changes.data) {
            const { currentValue, previousValue } = changes.data;
            if (currentValue && !previousValue) {
                this.setupPrescriptions(currentValue);
                this.displayPrescriptions('current');
            }
            if (currentValue !== previousValue) {
                this.setupPrescriptions(currentValue);
                if (this.isCurrentTabActive) {
                    this.displayPrescriptions('current');
                } else {
                    this.displayPrescriptions('past');
                }
            }
        }
        if (changes.patient) {
            const { currentValue, previousValue, firstChange } = changes.patient;
            if (firstChange) {
                this.patientInfo = currentValue;
            }
            if (currentValue !== previousValue) {
                this.patientInfo = currentValue;
            }
        }
        if (changes.doctorsAndPharmacists) {
            const { currentValue, previousValue, firstChange } = changes.doctorsAndPharmacists;
            if (firstChange) {
                this.doctors_and_pharmacists = currentValue;
            }
            if (currentValue !== previousValue) {
                this.doctors_and_pharmacists = currentValue;
            }
        }
    }
}
