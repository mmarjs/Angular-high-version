import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-notes-panel',
    templateUrl: './notes-panel.component.html',
    styleUrls: ['../profiledetail.component.scss'],
})
export class NotesPanelComponent {
    @Input() notes: any;
    @Input() doctors: any;
    @Output() handleAddNoteClick = new EventEmitter();

    trackByNote = (index, note) => note;

    findDoctorName = (doctorId: number) => {
        const doctor = this.doctors
        if (!doctor) {
          return 'N/A';
        }
        if (!doctor.first_name && doctor.last_name) {
          return `N/A ${doctor.last_name}`;
        }
        if (doctor.first_name && !doctor.last_name) {
          return `${doctor.first_name} N/A `;
        }
        return `${doctor.first_name} ${doctor.last_name}`;
    }

    showNote = (index): void => {
        this.notes[index].show_preview = false;
    }

    showAllNotes = (): void => {
        this.notes.forEach(note => {
            note.show_preview = false;
        });
    }

    openNewNoteModal = (): void => {
        this.handleAddNoteClick.emit();
    }
}
