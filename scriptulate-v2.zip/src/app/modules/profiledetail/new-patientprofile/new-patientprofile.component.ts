import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-mydialog',
  templateUrl: './new-patientprofile.component.html',
  styleUrls: ['./new-patientprofile.component.scss'],
})

export class NewPatientProfileComponent implements OnInit, OnDestroy {
	constructor(
		private activeModal: NgbActiveModal,	
	) {}
	closeModal = () => {
		this.activeModal.dismiss();
	}

	ngOnInit() {

	}

	ngOnDestroy() {

	}
}