import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UploadService } from '@app/core/services';

@Component({
  selector: 'app-init-contract-dialog',
  templateUrl: './init-contract-dialog.component.html',
  styleUrls: ['./init-contract-dialog.component.scss']
})
export class InitContractDialogComponent implements OnInit {
  doctor: any;
  patient: any;

  fileUploaded: File;
  bypass = false;

  @ViewChild('file')
  file: ElementRef;

  filename: string = '';

  constructor(
    public dialogRef: MatDialogRef<InitContractDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private uploadService: UploadService
  ) {}

  ngOnInit() {
    const { doctor, patient } = this.data;
    this.doctor = doctor;
    this.patient = patient;
  }

  async submit() {
    if (!this.fileUploaded) return;
    const { success, result } = await this.uploadService.upload({
      file_name: this.fileUploaded.name,
      uploaded_by_user_id: this.doctor.id,
      uploaded_for_user_id: this.patient.id,
      file_category: 'agreement',
      file_type: this.fileUploaded.type,
      file: this.fileUploaded
    });

    this.dialogRef.close(success ? {
      document_id: result.body.id,
      document: result.body,
      signed_document_id: this.bypass ? result.body.id : null,
      doctor_id: this.doctor.id,
      patient_id: this.patient.id,
      is_ended: false,
      active: this.bypass,
      started_at: this.bypass ? new Date() : null
    } : null);
  }

  cancel() {
    this.dialogRef.close();
  }

  upload() {
    this.file.nativeElement.click();
  }

  onUploaded() {
    const file = this.file.nativeElement.files[0];
    this.fileUploaded = file;
    this.file.nativeElement.files = null;
    this.file.nativeElement.value = null;
    const { name } = this.fileUploaded;
    this.filename = name.length > 30 ? name.substring(0, 30) + '...' : name;
  }
}
