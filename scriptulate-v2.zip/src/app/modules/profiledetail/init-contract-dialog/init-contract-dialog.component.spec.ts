import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitContractDialogComponent } from './init-contract-dialog.component';

describe('InitContractDialogComponent', () => {
  let component: InitContractDialogComponent;
  let fixture: ComponentFixture<InitContractDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitContractDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitContractDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
