export class Prescription {
  //public _id?:string;
  public drug_id: any;
  public frequency: any;
  public po: string;
  public count: number;
  public tablet: string;
  public day: string;
  public number_of_days: number;
  public number_of_refill: number;
  public date_prescribed: Date;
  public icd_code: number;
  public patient_presc_nalaxone: boolean;
  public dosage: number;
  public diagnosis: string;
  public comment: string;
  public patient_id: string;
  public prescribed_by: string;
}
/*
  dosage:req.body.dosage,
        diagnosis:req.body.diagnosis,
        number_of_days:req.body. numberOfDays,
        number_of_refill:req.body. numberOfRefill,
        date_prescribed:req.body.datePrescribed,
        icd_code:req.body.icd10,
        comment:req.body.comment, */
