import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import {RelativeUrlConfig} from '../../../core/config/RelativeUrlConfig';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import {HttpResourceService} from '../../../core/services/httpResourceService/http-resource.service';

@Injectable({
  providedIn: 'root'
})
export class EditPatientProfileService {
  
  BASE_URL = EnvironemntConfig.BASE_URL;
  constructor(private httpResourceService:HttpResourceService,private http:HttpClient) { }
  editProfile(params){
 
    const url = this.BASE_URL + RelativeUrlConfig.PATIENT_PROFILE_DETAIL;
    return this.httpResourceService.get(url,params);
  }
  saveProfile(params){
    const url = this.BASE_URL + RelativeUrlConfig.UPDATE_PATIENT_PROFILE;
    return this.httpResourceService.post(url,params);
  }
}
