import { Component, OnInit,Inject } from '@angular/core';
import {setDialogs} from '../../../core/config/setDialogs';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {CustomDialogComponent} from '../custom-dialog/custom-dialog.component';
import {CreateFieldComponent} from '../../profile/create-field/create-field.component';

@Component({
  selector: 'app-edit-patientprofile',
  templateUrl: './edit-patientprofile.component.html',
  styleUrls: ['./edit-patientprofile.component.css']
})
export class EditPatientprofileComponent implements OnInit {
  patientId:string;
  patientInfo=[];
  constructor(public dialogRef: MatDialogRef<CustomDialogComponent>,@Inject(MAT_DIALOG_DATA) public data: any) {
    setDialogs.isEditPatientProfile=!setDialogs.isEditPatientProfile;
    this.patientId=data.dataKey;
    this.patientInfo=data.dataKey2;
   }

  ngOnInit() {
  }
  onNoClick() {
    this.dialogRef.close();
   }
  
}
