import { TestBed, inject } from '@angular/core/testing';

import { EditPatientProfileService } from './edit-patient-profile.service';

describe('EditPatientProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EditPatientProfileService]
    });
  });

  it('should be created', inject([EditPatientProfileService], (service: EditPatientProfileService) => {
    expect(service).toBeTruthy();
  }));
});
