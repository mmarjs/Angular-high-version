import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPatientprofileComponent } from './edit-patientprofile.component';

describe('EditPatientprofileComponent', () => {
  let component: EditPatientprofileComponent;
  let fixture: ComponentFixture<EditPatientprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPatientprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPatientprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
