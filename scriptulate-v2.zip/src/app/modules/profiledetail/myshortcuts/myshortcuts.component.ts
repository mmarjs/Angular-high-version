import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-myshortcuts',
  templateUrl: './myshortcuts.component.html',
  styleUrls: ['./myshortcuts.component.scss']
})
export class MyshortcutsComponent implements OnInit, OnDestroy {
  shortcutOptions: any[] = [];
  @Input() data: any;
  
  constructor(public activeModal: NgbActiveModal) { 
  }

  ngOnInit() {
    this.shortcutOptions = this.data.shortcut_options;
  }
  ngOnDestroy(){

  }
  closeModal() {
    // var checked_options = this.shortcut_options.filter(option => option.checked);
    // this.activeModal.close(checked_options);
    localStorage.removeItem('options');
    this.activeModal.close();
  }
  onSubmit() {
    localStorage.setItem("options", JSON.stringify(this.shortcutOptions));
    this.activeModal.close();
  }
 }
