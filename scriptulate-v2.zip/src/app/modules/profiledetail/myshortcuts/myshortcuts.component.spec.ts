import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyshortcutsComponent } from './myshortcuts.component';

describe('MyshortcutsComponent', () => {
  let component: MyshortcutsComponent;
  let fixture: ComponentFixture<MyshortcutsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyshortcutsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyshortcutsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
