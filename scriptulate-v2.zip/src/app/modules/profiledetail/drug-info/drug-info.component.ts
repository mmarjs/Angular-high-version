import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AddPrescriptionService } from '../add-prescription/service/add-prescription.service';
import { DrugInfoService } from '../drug-info/drug-info.service';
import { DrugInteractionComponent } from '../drug-interaction/drug-interaction.component';
import { FillprescriptionComponent } from '../fillprescription/fillprescription.component';
import { FillprescriptionService } from '../fillprescription/fillprescription.service';
import { setDrugName } from '@app/helpers';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog, MatSelectChange } from '@angular/material';
import { Prescription } from '@app/reducers/prescription/prescription.reducer';
import * as _ from 'lodash';
import { DoctorsPharmacistsState } from '@app/reducers/doctor/doctor.reducer';

@Component({
  selector: 'app-drug-info',
  templateUrl: './drug-info.component.html',
  styleUrls: ['./drug-info.component.scss']
})
export class DrugInfoComponent implements OnInit {
  @Input() data: any;
  public pres = [];
  patientId;
  drugId;
  public role;
  public drug = [];
  public pres2 = [];
  public prescriptionData = [];
  public filledPrescriptionData = [];
  public patientPres = [];
  public patientInfo = [];
  public drugNameOptions = [];

  public pa = [];
  public resObj = {
    prescriptionDetails: null,
    doctorDetails: null,
    filledData: null,
    pharmacistDetails: {}
  };
  public prescriptionId;
  public index = 0;
  drug_id: string;

  detailForm: FormGroup;

  prescriptionDetails = [];
  prescriptionObjectDetails = [];

  params1;

  drugList: any;
  prescription: any;
  patient: any;
  formattedPrescriptions = [];
  displayedPrescriptions = [];
  sortedAscending = true;

  doctors_and_pharmacists: DoctorsPharmacistsState;

  constructor(
    private activeModal: NgbActiveModal,
    private modal: NgbModal,
    public fillPrescriptionService: FillprescriptionService,
    public prescriptionService: AddPrescriptionService,
    public drugInfoService: DrugInfoService,
    public dialog: MatDialog,
  ) {}

  setPrescriberName = (id: any) => {
    if (!id) {
      return 'N/A';
    }
    const prescriber = this.doctors_and_pharmacists.entities[id];
    if (!prescriber) {
      return 'N/A';
    }
    return `${prescriber.first_name} ${prescriber.last_name}`;
  }

  closeModal = (): void => {
    this.activeModal.dismiss(this.data);
  }

  openDrugInteraction = (): void => {
    const drugInteractionRef = this.modal.open(DrugInteractionComponent, { windowClass: 'ngb-modal-size-1140' });
    drugInteractionRef.componentInstance.data = {
      dataKey1: this.drug,
    };
  }

  onNoClick1(pData, dData, presStatus, fData) {
    this.openDialog2(pData, dData, presStatus, fData);
  }

  openDialog2(pData, dData, presStatus, fData): void {
    const fillModalRef = this.modal.open(FillprescriptionComponent, { windowClass: 'ngb-modal-size-1140 '});

    fillModalRef.componentInstance.data = {
        dataKey: this.patientId,
        dataKey2: this.patientInfo,
        dataKey3: this.pres,
        dataKey1: this.drug,
        dataKey5: pData,
        dataKey6: dData,
        dataKey7: fData,
        dataKey8: presStatus
    };

    fillModalRef.result.then(res => {
      return;
    }).catch(err => {});
  }

  filterPrescriptions = (drugName) => {
    this.displayedPrescriptions = this.formattedPrescriptions
      .filter(p => drugName === 'All' || drugName === p.drug_name);
    this.sortPrescriptions(false);
  }

  onChangeDrugList = (event: MatSelectChange): void => {
    this.filterPrescriptions(event.value);
  }

  sortPrescriptions(changeSort = true) {
    if (changeSort) {
      this.sortedAscending = !this.sortedAscending;
    }
    this.displayedPrescriptions.sort(
      (a, b) => {
        if (!a.filled_orders.length || !b.filled_orders.length) {
          return -1;
        }
        return (this.sortedAscending
          ? a.filled_orders[0].date_filled > b.filled_orders[0].date_filled
          : a.filled_orders[0].date_filled < b.filled_orders[0].date_filled
        ) ? -1 : 1;
      }
    );
  }

  handleFillOrders = (fillOrders) => {
    if (!fillOrders || !fillOrders.length) {
      return 'N/A';
    }
    let ids = '';
    fillOrders.forEach(order => {
      ids += `, ${order.id}`;
    });
    ids = ids.slice(1);
    return ids;
  }

  handleIsPartialFilled = (prescription) => {
    if (!prescription.last_filled_order) {
      return 'N/A';
    }
    if (prescription.last_filled_order.is_partial_filled) {
      return 'Yes';
    }
    return 'No';
  }

  handlePmpState = (prescription) => {
    if (!prescription.last_filled_order) {
      return 'N/A';
    }
    return prescription.last_filled_order.pmp_state;
  }

  handleNumOfDays = (number_of_days) => {
    if (number_of_days === 'PRN' || number_of_days === 'prn') {
      return '30 (PRN)';
    }
    return number_of_days;
  }

  combine = (prescriptions) => {
    if (!prescriptions) {
      return [];
    }

    let c: any, d: any;
    let match = [];
    let notMatched = [];
    for (let i = 0; i < prescriptions.length; i++) {
      if (!prescriptions[i + 1]) {
        break;
      }
      c = prescriptions[i];
      d = prescriptions[i + 1];
      if (
        c.drug_name === d.drug_name &&
        c.dosage === d.dosage &&
        c.formatted_date_prescribed === d.formatted_date_prescribed &&
        c.last_formatted_filled_date === d.last_formatted_filled_date &&
        c.prescribed_by_user_id === d.prescribed_by_user_id &&
        c.pharmacy === d.pharmacy &&
        c.drug_id === d.drug_id &&
        c.payment_type === d.payment_type &&
        c.last_filled_order.is_partial_filled === d.last_filled_order.is_partial_filled &&
        c.last_filled_order.pmp_state === d.last_filled_order.pmp_state
      ) {
        if (!match[c]) {
          match.push(c);
        }
        if (!match[d]) {
          match.push(d);
        }
      }
    }

    match = Array.from(new Set(match));
    notMatched = _.difference(prescriptions, match);

    let listOfSimiarities = [];
    listOfSimiarities = match.map((p) => {
      const { drug_name, dosage } = p;
      return {
        drug_name,
        dosage,
      };
    });
    listOfSimiarities = _.uniqWith(listOfSimiarities, _.isEqual);
    listOfSimiarities.forEach((obj, i) => {
      const { drug_name, dosage } = obj;
      obj.index = i;
      obj.drug_name_and_dosage = `${drug_name} ${dosage}`;
    });

    const normalized = _.keyBy(listOfSimiarities, 'drug_name_and_dosage');
    const jaggedArr = [];
    listOfSimiarities.forEach(() => (jaggedArr.push([])));

    let drugIndex = null;
    match.forEach((p: Prescription) => {
      const { drug_name, dosage } = p;
      if (normalized[`${drug_name} ${dosage}`]) {
        drugIndex = normalized[`${drug_name} ${dosage}`].index;
        jaggedArr[drugIndex].push(p);
      }
    });

    let prescription: Prescription,
      totalQuantity = 0,
      totalFrequency = 0,
      totalNumOfDays = 0,
      totalMme = 0;
    let lastFilledOrders = [];
    const combined = jaggedArr.map((row: Array<any>, i) => {
      totalFrequency = 0;
      totalMme = 0;
      totalNumOfDays = 0;
      totalQuantity = 0;
      lastFilledOrders = [];
      row.forEach((p) => {
        prescription = p;
        if (p.number_of_days === 'PRN') {
          totalNumOfDays += 30;
        } else {
          totalNumOfDays += parseInt(p.number_of_days, 10);
        }
        totalMme += p.mme;
        totalFrequency += +p.frequency;
        totalQuantity += p.quantity;
        lastFilledOrders.push(p.last_filled_order);
      });

      lastFilledOrders = lastFilledOrders.sort((a, b) => (a.date_filled - b.date_filled));

      return {
        drug_name: prescription.drug_name,
        drug_id: prescription.drug_id,
        dosage: prescription.dosage,
        payment_type: prescription.payment_type,
        prescribed_by_user_id: prescription.prescribed_by_user_id,
        pharmacy: prescription.pharmacy,
        filled_orders: lastFilledOrders,
        formatted_date_prescribed: prescription.formatted_date_prescribed,
        last_filled_order: _.last(lastFilledOrders),
        quantity: totalQuantity,
        frequency: totalFrequency.toFixed(2),
        mme: totalMme,
        last_formatted_filled_date: prescription.last_formatted_filled_date,
        number_of_days: totalNumOfDays,
      };
    });

    const completeTableData = _.concat(combined, notMatched);
    return completeTableData;
  }

  trackByIndex = (index, item) => index;

  ngOnInit() {
    this.patient = this.data.patient;
    this.doctors_and_pharmacists = this.data.doctors_and_pharmacists;
    this.prescription = this.data.prescription;
    let numOfDay = null;
    this.formattedPrescriptions = this.data.formattedPrescriptions.map(p => {
      if (p.number_of_days === 'PRN' || p.number_of_days === 'prn') {
        numOfDay = 30;
      } else {
        numOfDay = parseInt(p.number_of_days, 10);
      }
      return {
        ...p,
        ...setDrugName(p.drug_name),
        frequency: (p.quantity / numOfDay).toFixed(2)
      };
    });

    this.formattedPrescriptions = this.formattedPrescriptions
      .sort((
        a: Prescription,
        b: Prescription,
      ) => (a.drug_name.localeCompare(b.drug_name)));

    this.formattedPrescriptions = this.combine(this.formattedPrescriptions);

    this.drugNameOptions = [{
      label: 'All',
      value: 'All'
    }];

    this.formattedPrescriptions.forEach(p => {
      const option = {
        label: p.drug_name,
        value: p.drug_name
      };
      if (this.drugNameOptions.find(op => op.value === option.value)) {
        return;
      }
      this.drugNameOptions.push(option);
    });

    this.detailForm = new FormGroup({
      selectedDrug: new FormControl(setDrugName(this.prescription.drug_name).drug_name, [Validators.required])
    });
    this.filterPrescriptions(this.detailForm.value.selectedDrug);
  }
}
