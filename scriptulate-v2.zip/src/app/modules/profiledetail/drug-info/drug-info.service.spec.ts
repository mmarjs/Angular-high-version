import { TestBed, inject } from '@angular/core/testing';

import { DrugInfoService } from './drug-info.service';

describe('DrugInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DrugInfoService]
    });
  });

  it('should be created', inject([DrugInfoService], (service: DrugInfoService) => {
    expect(service).toBeTruthy();
  }));
});
