import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root'
})
export class DrugInfoService {

  BASE_URL = EnvironemntConfig.BASE_URL;
  constructor(private httpResourceService: HttpResourceService) { }

  getDrugs(params){
    
    const url = this.BASE_URL+ RelativeUrlConfig.GET_DRUGLIST;
    return this.httpResourceService.get(url,params);
    /*http.get(this.baseUri+'/read',{headers:this.headers});*/
  }

}
