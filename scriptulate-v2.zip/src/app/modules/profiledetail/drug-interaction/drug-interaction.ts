export class DrugInteraction {
    name:String;
    rxcui:String;
    description:String;

}
