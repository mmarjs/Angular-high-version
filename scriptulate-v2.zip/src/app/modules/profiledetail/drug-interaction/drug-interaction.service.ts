import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root'
})
export class DrugInteractionService {
  BASE_URL_DRUG = EnvironemntConfig.BASE_URL;
  constructor(private httpResourceService: HttpResourceService, ) { }

  fetchDrugList(params) {
    const url = this.BASE_URL_DRUG + RelativeUrlConfig.DRUG_LIST;
    return this.httpResourceService.get(url, params);
  }

  fetchDrugInteraction(params) {
    const url = this.BASE_URL_DRUG + RelativeUrlConfig.DRUG_INTERACTION;
    return this.httpResourceService.get(url, params);
  }
}
