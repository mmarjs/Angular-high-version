import { Component, OnInit, Input} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Messages } from '../../../core/config/messages';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { DrugInteractionService } from './drug-interaction.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-drug-interaction',
  templateUrl: './drug-interaction.component.html',
  styleUrls: ['./drug-interaction.component.css']
})
export class DrugInteractionComponent implements OnInit {
  @Input() data: any;
  drugInteractionForm: FormGroup;
  BASE_URL_ADD_DIVERSION = EnvironemntConfig.BASE_URL;
  requiredErrorMessage = Messages.REQUIRED_ERROR_MESSAGE;
  public interactions = [];
  public drugs = [];

  constructor(
    private drugInteractionService: DrugInteractionService,
    private fb: FormBuilder,
    private httpResourceService: HttpResourceService,
    private activeModal: NgbActiveModal,
  ) {}

  closeModal = (): void => {
    this.activeModal.dismiss(this.data);
  }

  onClick() {
    if (this.drugInteractionForm.valid) {
      this.drugInteractionService.fetchDrugInteraction(this.drugInteractionForm.value).subscribe(data => {
        this.resultSuccessCallback(data);
      });
    } else {
      this.validateAllFormFields(this.drugInteractionForm);
    }
  }

  resultSuccessCallback(data) {
    this.interactions = data.body;
  }

  drugListSuccessCallback(res) {
    this.drugs = res.body;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnInit() {
    this.drugs = this.data.dataKey1;
    this.drugInteractionForm = this.fb.group({
      firstDrugName: ['', Validators.required],
      secondDrugName: ['', Validators.required]
    });
  }
}
