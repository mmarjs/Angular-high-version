import { Component, Input } from '@angular/core';
import { UrineUpdateModalComponent } from '../modals';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-urine-update-button',
  templateUrl: './urine-update-button.component.html',
  styleUrls: [
    '../../profiledetail.component.scss',
    '../../../../../app/common/modules/styles/dialogs.scss',
  ],
})
class UrineUpdateButtonComponent {
  @Input() entryId: string;
  @Input() comment: string;
  @Input() status: string;

  constructor(private modal: NgbModal) {}

  openUrineUpdateDialog = (): void => {
    const urineUpdateModalRef = this.modal.open(UrineUpdateModalComponent, { size: 'lg' });
    urineUpdateModalRef.componentInstance.data = {
      entryId: this.entryId,
      comment: this.comment,
      status: this.status,
    };
  }
}

export { UrineUpdateButtonComponent };
