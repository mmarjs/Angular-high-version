import { Component, Input } from '@angular/core';
import { trigger, transition, style, animate } from '@angular/animations';
import * as _ from 'lodash';
import { Urine } from 'app/reducers/urine/urine.reducer';
import { UrineCreateModalComponent } from 'app/modules/profiledetail/patient-request/modals';
import { urineColumns } from 'app/modules/profiledetail/patient-request/models';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-urine-table',
  templateUrl: './urine-table.component.html',
  styleUrls: [
    '../../../profiledetail.component.scss',
    '../../../../../../assets/scss/tables.scss',
    '../../../../../../app/common/modules/styles/shared.scss',
    './urine-table.component.scss'
  ],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('300ms', style({ opacity: 1 })),
      ]),
      transition(':leave', [
        style({ opacity: 1 }),
        animate('100ms', style({ opacity: 0 })),
      ]),
    ]),
  ],
})
class UrineTableComponent {
  @Input() patientId: number;
  @Input() doctorId: any;
  @Input() data: Urine[];
  @Input() collectionSize: number;
  displayedColumns = urineColumns;

  page = 1;
  pageSize = 5;
  sortCollectionDateByNewest: Boolean = null;
  sortStatusByNewest: Boolean = null;
  btnText: string = 'Show';
  isShown: boolean = true;

  get urines() {
    return this.data
      .map((urine, i) => ({
        id: i + 1,
        ...urine,
      }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  constructor(public modal: NgbModal) {}

  sortUrineByKey = (key: string, condition: any) => {
    if (condition === null) {
      condition = true;
    }
    if (!condition) {
      this.data = _.orderBy(this.data, key, 'asc');
      return;
    }
    if (condition) {
      this.data = _.orderBy(this.data, key, 'desc');
      return;
    }
  }

  sortByStatus = () => {
    this.sortCollectionDateByNewest = null;
    this.sortUrineByKey('status', this.sortStatusByNewest);
    this.sortStatusByNewest = !this.sortStatusByNewest;
  }

  sortByCollectionDate = () => {
    this.sortStatusByNewest = null;
    this.sortUrineByKey('collection_date', this.sortCollectionDateByNewest);
    this.sortCollectionDateByNewest = !this.sortCollectionDateByNewest;
  }

  openCreateDialog = (): void => {
    const urineCreateRef = this.modal.open(UrineCreateModalComponent, { size: 'lg' });

    urineCreateRef.componentInstance.data = {
      patientId: this.patientId,
      doctorId: this.doctorId,
    };

    urineCreateRef.result
      .then(res => { return; })
      .catch(err => console.error(err));
  }

  trackByIndex = (index, entry) => index;

  showClick = () => {
    this.isShown = !this.isShown;
    this.btnText = (this.isShown) ? "Show" : "Hide";

  }
}

export { UrineTableComponent };
