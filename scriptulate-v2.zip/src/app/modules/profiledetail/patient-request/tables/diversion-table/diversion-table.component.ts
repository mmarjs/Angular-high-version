import { Component, Input, ViewEncapsulation } from '@angular/core';
import { trigger, transition, style, animate } from '@angular/animations';
import * as _ from 'lodash';
import * as moment from 'moment';
import { DiversionEntry } from 'app/reducers/diversion/diversion.reducer';
import {
  DiversionInitiateModalComponent,
  DiversionCompleteModalComponent,
} from 'app/modules/profiledetail/patient-request/modals';
import { diversionColumns } from 'app/modules/profiledetail/patient-request/models';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-diversion-table',
  templateUrl: './diversion-table.component.html',
  styleUrls: [
    '../../../profiledetail.component.scss',
    './diversion-table.component.scss',
    '../../../../../../assets/scss/tables.scss',
    '../../../../../../app/common/modules/styles/shared.scss',
  ],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('300ms', style({ opacity: 1 })),
      ]),
      transition(':leave', [
        style({ opacity: 1 }),
        animate('100ms', style({ opacity: 0 })),
      ]),
    ]),
  ],
  encapsulation: ViewEncapsulation.None,
})
class DiversionTableComponent {
  @Input() patientId: number;
  @Input() doctorId: any;
  @Input() data: DiversionEntry[];
  @Input() collectionSize: number;

  page = 1;
  pageSize = 5;

  displayedColumns = diversionColumns;
  sortDateByNewest: Boolean = null;
  sortTimeByLatest: Boolean = null;
  sortStatusByNewest: Boolean = null;
  btnText: string = 'Show';
  isShown: boolean = true;
  get diversions() {
    this.collectionSize = this.data.length;
    return this.data
      .map((urine, i) => ({
        id: i + 1,
        ...urine,
      }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  constructor(
    private modal: NgbModal,
  ) {}

  sortByDate = () => {
    this.sortDiversionByKey('date', this.sortDateByNewest);
    this.sortDateByNewest = !this.sortDateByNewest;
    this.sortTimeByLatest = null;
    this.sortStatusByNewest = null;
  }

  sortByTime = () => {
    let firstDate = null;
    let secondDate = null;
    this.data = this.data.sort((a, b) => {
      firstDate = moment(a.date).format('hh:mm:ss a').toString();
      secondDate = moment(b.date).format('hh:mm:ss a').toString();
      if (this.sortTimeByLatest) {
        return firstDate.localeCompare(secondDate);
      }
      if (!this.sortTimeByLatest) {
        return secondDate.localeCompare(firstDate);
      }
    });
    this.sortTimeByLatest = !this.sortTimeByLatest;
    this.sortDateByNewest = null;
    this.sortStatusByNewest = null;
  }

  sortByStatus = () => {
    this.sortDiversionByKey('status', this.sortStatusByNewest);
    this.sortStatusByNewest = !this.sortStatusByNewest;
    this.sortDateByNewest = null;
    this.sortTimeByLatest = null;
  }


  sortDiversionByKey = (key: string, condition: any) => {
    if (condition === null) {
      condition = true;
    }
    if (!condition) {
      this.data = _.orderBy(this.data, key, 'asc');
      return;
    }
    if (condition) {
      this.data = _.orderBy(this.data, key, 'desc');
      return;
    }
  }

  openInitiateDialog = (): void => {
    const diversionInitiateModalRef = this.modal.open(DiversionInitiateModalComponent, { size: 'lg' });
    diversionInitiateModalRef.componentInstance.data = {
      patientId: this.patientId,
      doctorId: this.doctorId,
    };

    diversionInitiateModalRef.result
      .then(res => { return; })
      .catch(err => console.error(err));
  }

  openDiversionCompleteModal = (diversion: DiversionEntry): void => {
    const diversionCompleteModalRef = this.modal.open(
      DiversionCompleteModalComponent,
      {
        windowClass: 'ngb-modal-size-1140',
      }
    );
    diversionCompleteModalRef.componentInstance.data = {
      patientId: this.patientId,
      diversionId: diversion.id,
      status: diversion.status,
    };

    diversionCompleteModalRef.result
      .then(res => { return; })
      .catch(err => console.error(err));
  }

  trackByIndex = (index, entry) => index;

  showClick = () => {
    this.isShown = !this.isShown;
    this.btnText = (this.isShown) ? "Show" : "Hide";

  }
}

export { DiversionTableComponent };
