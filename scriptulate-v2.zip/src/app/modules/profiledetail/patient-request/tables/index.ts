import { DiversionTableComponent } from './diversion-table/diversion-table.component';
import { UrineTableComponent } from './urine-table/urine-table.component';

export {
  DiversionTableComponent,
  UrineTableComponent,
};
