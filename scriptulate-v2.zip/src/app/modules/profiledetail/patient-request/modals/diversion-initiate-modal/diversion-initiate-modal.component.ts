import {
	Component,
	OnInit,
	OnDestroy,
	Input,
	ViewEncapsulation
} from '@angular/core';
import {
	FormControl,
	FormGroup,
	FormArray,
	Validators
} from '@angular/forms';
import * as moment from 'moment';
import { Store } from '@ngrx/store';
import { Subject, Observable } from 'rxjs';
import { takeUntil, map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import matchSorter from 'match-sorter';
import * as Reducers from 'app/reducers';
import {
	Doctor,
	Method,
	METHODS,
	Location,
	Comment,
	COMMENT_CODES
} from 'app/modules/profiledetail/patient-request/models';
import { addDiversionEntry } from 'app/reducers/diversion/diversion.actions';
import { combineDateTime, setNgbStructAsMomentObj, setNgbTimeStructAsMomentObj } from 'app/helpers';
import { InitiateParams } from 'app/modules/profiledetail/patient-request/models';
import { doctorIdsAndNames } from 'app/reducers/doctor/doctor.reducer';
import { NgbActiveModal, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';

interface DialogData {
	patientId: string;
}

@Component({
	selector: 'app-diversion-modal',
	templateUrl: './diversion-initiate-modal.component.html',
	styleUrls: [
		'../../../profiledetail.component.scss',
		'../../../../../../app/common/modules/styles/dialogs.scss',
		'../../../../../../app/common/modules/styles/shared.scss',
		'../../../../../../assets/scss/ng-select.scss',
	],
	encapsulation: ViewEncapsulation.None,
})
class DiversionInitiateModalComponent implements OnInit, OnDestroy {
	@Input() data: any;
	doctors$: Observable<any>;

	unsubscribe$: Subject<Boolean> = new Subject<Boolean>();

	methods: Method[] = METHODS;
	locations: Location[];
	commentCodes: Comment[] = COMMENT_CODES;

	protected doctors: Doctor[];
	public filteredDoctors: Array<any>;

	doctorId: any;
	patientId: any;
	params: InitiateParams;

	currentDateTime = moment();
	currentHour = this.currentDateTime.get('hour');
	currentMinute = this.currentDateTime.get('minute');

	initiateForm: FormGroup = new FormGroup({
		rules: new FormArray([new FormControl()]),
		pickedDate: new FormControl(this.ngbCalendar.getToday(), [
			Validators.required
		]),
		pickedTime: new FormControl({
			hour: this.currentHour,
			minute: this.currentMinute,
		}, [
			Validators.required
		]),
		doctorCtrl: new FormControl('', [Validators.required]),
		methodCtrl: new FormControl(),
		locationCtrl: new FormControl(),
		commentCodeCtrl: new FormControl('', [Validators.required]),
		notesCtrl: new FormControl(),
		followUpHistoryCtrl: new FormControl()
	});

	constructor(
		private store: Store<Reducers.State>,
		private activeModal: NgbActiveModal,
		private ngbCalendar: NgbCalendar,
	) {
		this.doctors$ = this.store.pipe(map(doctorIdsAndNames));
		this.doctors$
		.pipe(takeUntil(this.unsubscribe$))
		.subscribe(
			(collection): void => {
				this.doctors = collection;
				this.locations = collection;
			},
		);
	}

	search = (text$: Observable<string>) => {
		return text$.pipe(
			debounceTime(200),
			distinctUntilChanged(),
			map(input => {
			  if (input.length < 2) {
				return [];
			  }
			  const matchedDoctors = matchSorter(this.doctors, input, { keys: ['full_name'] }) as Array<Doctor>;
			  return matchedDoctors.map(doctor => doctor.full_name).slice(0, 10);
			})
		);
	}

	searchLocations = (text$: Observable<string>) => {
		return this.search(text$).pipe(
			map(foundNames => {
				const locations = [];
				for (let i = 0; i < foundNames.length; i++) {
					foundNames[i] = 'Dr. '.concat(foundNames[i], '\'s office');
					locations.push(foundNames[i]);
				}
				return locations;
			}),
		);
	}

	closeDialog = (): void => this.activeModal.close();

	formatDateTimeValue = () => {
		const dateVal = this.initiateForm.get('pickedDate').value;
		const timeVal = this.initiateForm.get('pickedTime').value;
		return combineDateTime(
		  setNgbStructAsMomentObj(dateVal).toISOString(),
		  setNgbTimeStructAsMomentObj(timeVal).toISOString(),
		);
	}

	onSubmit(): void {
		const newDate = this.formatDateTimeValue();
		this.params = {
			date: newDate,
			requested_by_user_id: this.doctorId,
			performed_by: this.initiateForm.get('doctorCtrl').value,
			comment: this.initiateForm.get('commentCodeCtrl').value,
			status: 'Initiated',
			type: '11/11/90',
			patient_id: this.data.patientId
		};

		if (
			this.params.date &&
			this.params.comment &&
			this.params.requested_by_user_id
		) {
			this.store.dispatch(addDiversionEntry({ payload: this.params }));
			this.closeDialog();
		}
	}

	ngOnInit() {
		this.patientId = this.data.patientId;
		this.doctorId = this.data.doctorId;
	}

	ngOnDestroy() {
		this.unsubscribe$.next(true);
		this.unsubscribe$.unsubscribe();
	}
}

export { DiversionInitiateModalComponent, DialogData };
