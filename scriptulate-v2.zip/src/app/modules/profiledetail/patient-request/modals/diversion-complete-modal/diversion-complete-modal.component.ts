import { Component, ViewEncapsulation, OnDestroy, OnInit, Input } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Store, select } from '@ngrx/store';
import * as Reducers from 'app/reducers';
import { FormGroup, FormControl } from '@angular/forms';
import * as moment from 'moment';
import { STATUSES } from 'app/modules/profiledetail/patient-request/models';
import { updateDiversionStatus } from 'app/reducers/diversion/diversion.actions';
import { takeUntil } from 'rxjs/operators';
import { NgbActiveModal, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-diversion-complete-modal',
  templateUrl: './diversion-complete-modal.component.html',
  styleUrls: [
    '../../../profiledetail.component.scss',
    '../../../../../../app/common/modules/styles/dialogs.scss',
    '../../../../../../app/common/modules/styles/shared.scss',
    '../../../../../../assets/scss/ng-select.scss',
  ],
  encapsulation: ViewEncapsulation.None,
})
class DiversionCompleteModalComponent implements OnInit, OnDestroy {
  @Input() data: any;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  entry$: Observable<any>;
  doctors$: Observable<Object>;

  public statuses = STATUSES;

  diversionId: any;
  patientId: any;
  entryData: any;
  doctorName: string;

  currentDateTime = moment();
	currentHour = this.currentDateTime.get('hour');
	currentMinute = this.currentDateTime.get('minute');

  completionForm: FormGroup = new FormGroup({
    pickedDate: new FormControl(this.ngbCalendar.getToday()),
    pickedTime: new FormControl({
      hour: this.currentHour,
      minute: this.currentMinute,
    }),
    medicationNameCtrl: new FormControl(),
    drugNumberCtrl: new FormControl(),
    notesCtrl: new FormControl(),
    matchDescriptionCtrl: new FormControl(),
    expectedQuantityCtrl: new FormControl(),
    actualQuantityCtrl: new FormControl(),
    statusCtrl: new FormControl(),
  });

  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
    private ngbCalendar: NgbCalendar,
  ) {}

  onSubmit() {
    const newStatus = this.completionForm.get('statusCtrl').value;
    this.store.dispatch(
      updateDiversionStatus({
        diversionId: this.diversionId,
        status: newStatus,
      })
    );

    this.closeDialog();
  }

  closeDialog() {
    this.activeModal.close();
  }

  ngOnInit() {
    this.diversionId = this.data.diversionId;
    this.patientId = this.data.patientId;
    this.completionForm.get('statusCtrl').setValue(this.data.status || null);

    this.entry$ = this.store.pipe(
      select(
        (state: Reducers.State) => state.diversion.entities[this.diversionId]
      )
    );
    this.entry$.pipe(takeUntil(this.unsubscribe$)).subscribe((data): void => {
      if (data) {
        this.entryData = data;
      }
    });
    this.doctors$ = this.store.pipe(
      select((state: Reducers.State) => state.doctor.doctors_and_pharmacists.entities)
    );
    this.doctors$.pipe(takeUntil(this.unsubscribe$)).subscribe(response => {
      if (response) {
        const doctor_id = this.entryData.requested_by_user_id;
        const { first_name, last_name } = response[doctor_id];
        this.doctorName = `${first_name} ${last_name}`;
      }
    });
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.unsubscribe();
  }
}

export { DiversionCompleteModalComponent };
