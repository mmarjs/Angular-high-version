import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Store } from '@ngrx/store';
import * as Reducers from 'app/reducers';
import { combineDateTime, setNgbStructAsMomentObj, setNgbTimeStructAsMomentObj } from 'app/helpers';
import { UDT_STATUSES } from '../../models';
import { updateUrineEntry } from '@app/reducers/urine/urine.actions';
import { NgbActiveModal, NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { ngbDateValidator } from 'app/shared/validators/ngb-date.validator';

@Component({
  selector: 'app-urine-update-modal',
  templateUrl: './urine-update-modal.component.html',
  styleUrls: [
    '../../../profiledetail.component.scss',
    '../../../../../../app/common/modules/styles/dialogs.scss',
    '../../../../../../app/common/modules/styles/shared.scss',
    '../../../../../../assets/scss/ng-select.scss',
  ],
  encapsulation: ViewEncapsulation.None,
})
class UrineUpdateModalComponent implements OnInit {
  @Input() data: any;
  params: any;
  statuses = UDT_STATUSES;
  updateForm: FormGroup;

  currentDateTime = moment();
  currentHour = this.currentDateTime.get('hour');
  currentMinute = this.currentDateTime.get('minute');
  datepickerVal: NgbDateStruct = this.ngbCalendar.getToday();

  pickedResultDate: FormControl = new FormControl(this.ngbCalendar.getToday(), [
    Validators.required,
    ngbDateValidator
  ]);

  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
    public ngbCalendar: NgbCalendar,
  ) {}


  closeDialog = (): void => this.activeModal.close();

  getDateTime = () => {
    const resultDate = this.pickedResultDate.value;
    const resultTime = this.updateForm.get('pickedResultTime').value;

    return combineDateTime(
      setNgbStructAsMomentObj(resultDate).toISOString(),
      setNgbTimeStructAsMomentObj(resultTime).toISOString(),
    );
  }

  submitUpdate = (): void => {
    let allowChanges: boolean;
    let resultDate = null;
    const status = this.updateForm.get('statusCtrl').value;
    const comment = this.updateForm.get('commentCtrl').value;
    const newResultDate = this.getDateTime();

    if (status !== 'Initiated') {
      resultDate = newResultDate;
      allowChanges = false;
    }

    if (status) {
      this.store.dispatch(
        updateUrineEntry({
          entryId: this.data.entryId,
          result_date: resultDate,
          comment: comment,
          status: status,
          allow_changes: allowChanges,
        })
      );
      this.closeDialog();
    }
  }

  ngOnInit() {
    this.updateForm = new FormGroup({
      statusCtrl: new FormControl(this.data.status),
      pickedResultTime: new FormControl(
        {
          hour: this.currentHour,
          minute: this.currentMinute,
        },
        [
          Validators.required,
        ]
      ),
      commentCtrl: new FormControl(this.data.comment),
    });
  }
}

export { UrineUpdateModalComponent };
