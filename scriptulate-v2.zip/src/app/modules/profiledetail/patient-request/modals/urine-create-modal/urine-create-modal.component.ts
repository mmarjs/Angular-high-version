import {
  Component,
  OnInit,
  OnDestroy,
  Input,
} from '@angular/core';
import { FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Store } from '@ngrx/store';
import { Subject, Observable } from 'rxjs';
import { takeUntil, map, distinctUntilChanged, debounceTime } from 'rxjs/operators';
import matchSorter from 'match-sorter';
import * as Reducers from 'app/reducers';
import { Doctor } from 'app/modules/profiledetail/patient-request/models';
import { addUrineEntry } from 'app/reducers/urine/urine.actions';
import { combineDateTime, setNgbStructAsMomentObj, setNgbTimeStructAsMomentObj } from 'app/helpers';
import { doctorIdsAndNames } from 'app/reducers/doctor/doctor.reducer';
import { NgbActiveModal, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { ngbDateValidator } from 'app/shared/validators/ngb-date.validator';

interface UrineModalData {
  patientId: string;
  doctorId: string;
}

@Component({
  selector: 'app-urine-create-modal',
  templateUrl: './urine-create-modal.component.html',
  styleUrls: [
    '../../../profiledetail.component.scss',
    '../../../../../../app/common/modules/styles/dialogs.scss',
    '../../../../../../app/common/modules/styles/shared.scss',
  ],
})
class UrineCreateModalComponent implements OnInit, OnDestroy {
  @Input() data: any;
  doctors$: Observable<any>;

  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();

  patientId: any;
  doctorId: any;
  params: any;

  currentDateTime = moment();
  currentHour = this.currentDateTime.get('hour');
  currentMinute = this.currentDateTime.get('minute');

  createForm: FormGroup = new FormGroup({
    rules: new FormArray([new FormControl()]),
    pickedDate: new FormControl(this.ngbCalendar.getToday(), [
      Validators.required,
      ngbDateValidator,
    ]),
    pickedTime: new FormControl({
      hour: this.currentHour,
      minute: this.currentMinute,
    }, [
      Validators.required,
    ]),
    performedByCtrl: new FormControl('', [Validators.required]),
    commentCtrl: new FormControl(),
  });

  protected doctors: Doctor[];
  public matchedDoctors: Doctor[];

  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
    public ngbCalendar: NgbCalendar,
  ) {}

  closeModal = (): void => this.activeModal.close();

  formatDateTimeValue = () => {
    const dateVal = this.createForm.get('pickedDate').value;
    const timeVal = this.createForm.get('pickedTime').value;
    return combineDateTime(
      setNgbStructAsMomentObj(dateVal).toISOString(),
      setNgbTimeStructAsMomentObj(timeVal).toISOString(),
    );
  }

  onSubmit(): void {
    const newDate = this.formatDateTimeValue();
    let performedByValue = '';
    if (this.createForm.get('performedByCtrl').value.doctor_id) {
      performedByValue = this.createForm.get('performedByCtrl').value.full_name;
    }
    if (!this.createForm.get('performedByCtrl').value.doctor_id) {
      performedByValue = this.createForm.get('performedByCtrl').value;
    }

    this.params = {
      date: newDate,
      collection_date: newDate,
      comment: this.createForm.get('commentCtrl').value,
      status: 'Initiated',
      patient_id: this.data.patientId,
      performed_by: performedByValue,
      requested_by_user_id: this.doctorId,
    };

    if (
      this.params.collection_date &&
      this.params.performed_by &&
      this.params.requested_by_user_id
    ) {
      this.store.dispatch(addUrineEntry({ payload: this.params }));
      this.closeModal();
    } else {
      return;
    }
  }

  search = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(input => {
        if (input.length < 2) {
          return [];
        }
        const matchedDoctors = matchSorter(this.doctors, input, { keys: ['full_name'] }) as Array<Doctor>;
        return matchedDoctors.map(doctor => doctor.full_name).slice(0, 10);
      })
    );
  }

  trackByDoctorId = (_index, doctor) => doctor.doctor_id;

  ngOnInit() {
    this.doctorId = this.data.doctorId;
    this.patientId = this.data.patientId;
    this.doctors$ = this.store.pipe(map(doctorIdsAndNames));
    this.doctors$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((collection): void => {
        this.doctors = collection;
      });
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.unsubscribe();
  }
}

export { UrineCreateModalComponent, UrineModalData };
