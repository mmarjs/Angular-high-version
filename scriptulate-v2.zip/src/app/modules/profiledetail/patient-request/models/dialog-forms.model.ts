export interface Doctor {
  doctor_id: number;
  full_name: string;
  first_name: string;
  last_name: string;
}

export interface Method {
  type: string;
}

export const METHODS: Method[] = [
  {
    type: 'Phone call',
  },
  {
    type: 'Text message',
  },
  {
    type: 'Email',
  },
];

export interface Location {
  doctor_id: number;
  full_name: string;
  last_name: string;
}

export interface Comment {
  code: string;
}

export const COMMENT_CODES: Comment[] = [
  { code: 'No Answer' },
  { code: 'Scheduled Visit' },
  { code: 'Pill Counts Did Not Match Prescription' },
];

export interface InitiateParams {
  date: string;
  performed_by?: string;
  requested_by_user_id: string;
  comment: string;
  status: string;
  type: string;
  patient_id: string;
}

export const STATUSES = [
  'Initiated',
  'Completed',
  'Failed',
];

export const UDT_STATUSES = ['Initiated', 'Inconsistent', 'Consistent'];
