export const diversionColumns: String[] = [
  'date',
  'time',
  'type',
  'status',
  'comment',
  'performed_by',
  'entry_id',
];

export const urineColumns: String[] = [
  'collection_date',
  'result_date',
  'status',
  'performed_by',
  'comment',
  'entry_id',
];
