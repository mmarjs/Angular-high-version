import { Injectable } from '@angular/core';
import { RelativeUrlConfig } from 'app/core/config/RelativeUrlConfig';
import { HttpResourceService } from 'app/core/services/httpResourceService/http-resource.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
class PatientRequestService {
  constructor(
    private httpClient: HttpClient,
    private httpResourceService: HttpResourceService
  ) {}

  postNewDiversion(payload: any) {
    const url = RelativeUrlConfig.DIVERSIONS;
    return this.httpResourceService.post(url, payload);
  }

  getAllDiversions(params: object = {}) {
    const url = RelativeUrlConfig.DIVERSIONS;
    return this.httpResourceService.get(url, params);
  }

  updateDiversionStatus(id: string, status) {
    const url = `${RelativeUrlConfig.DIVERSIONS}/${id}`;
    return this.httpResourceService.put(url, {
      status: status,
    });
  }

  deleteDiversionById({ id }) {
    const url = `${RelativeUrlConfig.DIVERSIONS}/${id}`;
    return this.httpClient.delete(url);
  }

  postNewUrine(payload: any) {
    const url = RelativeUrlConfig.URINES;
    return this.httpResourceService.post(url, payload);
  }

  getAllUrines(params: object = {}) {
    const url = RelativeUrlConfig.URINES;
    return this.httpResourceService.get(url, params);
  }

  updateUrineEntry(
    id: any,
    resultDate: string,
    status: string,
    comment: string,
    allowChanges: boolean
  ) {
    const url = `${RelativeUrlConfig.URINES}/${id}`;
    return this.httpResourceService.put(url, {
      result_date: resultDate,
      status,
      comment,
      allow_changes: allowChanges,
    });
  }

  deleteUrineById(id: string) {
    const url = `${RelativeUrlConfig.URINES}/${id}`;
    return this.httpClient.delete(url);
  }
}

export { PatientRequestService };
