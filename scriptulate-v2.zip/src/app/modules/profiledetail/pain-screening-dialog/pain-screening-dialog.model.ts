export interface DialogData {
  patientId: string | number;
  doctorId: string | number;
}

export interface QuestionBlock {
  number: string;
  question: string;
  left_statement: string;
  form_control_name: string;
  right_statement: string;
}

export const SCORES: Number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

export const QUESTIONS: QuestionBlock[] = [
  {
    number: '01',
    question: 'What number best describes your pain on average in the past week?',
    left_statement: 'No pain',
    form_control_name: 'averagePainControl',
    right_statement: 'Pain as bad as you imagine',
  },
  {
    number: '02',
    question: 'What number best describes how, during the past week, pain has interfered with your enjoyment of life?',
    left_statement: 'Does not interfere',
    form_control_name: 'enjoymentControl',
    right_statement: 'Completely interferes',
  },
  {
    number: '03',
    question: 'What number best describes how, during the past week, pain has interfered with your general activity',
    left_statement: 'Does not interfere',
    form_control_name: 'activityControl',
    right_statement: 'Completely interferes',
  },
];