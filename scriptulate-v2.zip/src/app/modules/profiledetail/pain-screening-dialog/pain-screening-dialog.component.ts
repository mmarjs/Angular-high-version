import { Store } from '@ngrx/store';
import { Component, EventEmitter, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import * as moment from 'moment';
import * as Reducers from 'app/reducers/index';
import { addScreening, updateScreening } from 'app/reducers/screening/screening.actions';
import { getScreeningsByIdAndType } from 'app/reducers/screening/screening.reducer';
import { QUESTIONS, SCORES } from './pain-screening-dialog.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Screening } from 'app/reducers/screening/screening.reducer';

@Component({
  selector: 'app-pain-screening-dialog',
  templateUrl: './pain-screening-dialog.component.html',
  styleUrls: [
    '../profiledetail.component.scss',
    '../../../../app/common/modules/styles/shared.scss',
    '../../../../app/common/modules/styles/dialogs.scss',
    './pain-screening-dialog.component.scss',
  ],
})
class PainScreeningDialogComponent implements OnInit {
  @Input() data: any;
  manualRefresh: EventEmitter<void> = new EventEmitter<void>();
  averagePainVal: Number = 0;
  enjoymentVal: Number = 0;
  activityVal: Number = 0;
  scores = SCORES;
  questions = QUESTIONS;

  radioForm: FormGroup = new FormGroup({
    averagePainControl: new FormControl(0),
    enjoymentControl: new FormControl(0),
    activityControl: new FormControl(0)
  });

  painScreenings$: Observable<any>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  last_screening: Screening;

  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
  ) {
  }

  calculatePegScore(radioValOne, radioValTwo, radioValThree) {
    const total = radioValOne + radioValTwo + radioValThree;
    return (total / 3);
  }

  closeDialog() {
    this.activeModal.close();
  }

  onSubmit() {
    const { patientId, doctorId } = this.data;
    const type = 'pain';
    const date = moment().utc();
    const data = {
      patient_id: patientId,
      requested_by_user_id: doctorId,
      type: type,
      score: this.calculatePegScore(
        this.radioForm.get('averagePainControl').value,
        this.radioForm.get('enjoymentControl').value,
        this.radioForm.get('activityControl').value
      ).toFixed(0),
      date: date,
    };

    if(this.last_screening || null){  
      this.store.dispatch(updateScreening({ screeningId: this.last_screening.id, payload: {
          patient_id: patientId,
          requested_by_user_id: doctorId,
          type: type,
          score: this.calculatePegScore(
            this.radioForm.get('averagePainControl').value,
            this.radioForm.get('enjoymentControl').value,
            this.radioForm.get('activityControl').value
          ),
          date: this.last_screening.date,
        }
      }));
    } else {
      this.store.dispatch(addScreening({ payload: data }));
    }

    this.closeDialog();
  }

  ngOnInit() {
    this.manualRefresh.emit();
    const date = moment().utc();
    this.painScreenings$ = this.store.select(state =>
      getScreeningsByIdAndType(state, {
        type: 'pain',
        patient_id: this.data.patientId,
        doctor_id: this.data.doctorId,
      })
    );

    this.last_screening = null;
    this.painScreenings$
      .subscribe(({ painScreenings }): void => {
        if (painScreenings) {
          const last_screening = painScreenings.slice(-1)[0];
          const last_screening_date = last_screening ? moment(last_screening.date).format("YYYY-MM-DD") : '';
          if (last_screening_date == date.format("YYYY-MM-DD")) {
            this.last_screening = last_screening;
          }
        }
      });    
  }
}

export { PainScreeningDialogComponent };
