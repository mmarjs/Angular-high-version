/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  NgbModalModule,
  NgbDatepickerModule,
  NgbTimepickerModule,
  NgbTypeaheadModule,
  NgbPaginationModule,
  NgbRadioGroup,
  NgbRadio,
  NgbButtonsModule,
} from '@ng-bootstrap/ng-bootstrap';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatDatepickerModule,
  MatDialogModule,
  MatIconModule,
  MatInputModule,
  MatFormFieldModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatTableModule,
  MatDividerModule,
  MatPaginatorModule,
  MatSortModule,
  MatSnackBarModule,
  MatMenuModule,
} from '@angular/material';
import { Ng5SliderModule } from 'ng5-slider';
import { MyProgressComponent } from '@app/common/modules/my-progress/my-progress.component';
import { TextMaskModule } from 'angular2-text-mask';
import { ChartsModule } from 'ng2-charts';
import { NgxLoadingModule } from 'ngx-loading';
import { StepProgressComponent } from '../../common/modules/step-progress/step-progress.component';
import { ProfileModule } from '../profile/profile.module';
import { AddPrescriptionComponent } from './add-prescription/add-prescription.component';
import { CustomDialogComponent } from './custom-dialog/custom-dialog.component';
import { DetailedReportComponent } from './detailed-report/detailed-report.component';
import { StatePdmpReportComponent } from './state-pdmp-report/state-pdmp-report.component';
import { DischargePatientComponent } from './discharge-patient/discharge-patient.component';
import { DiversionComponent } from './diversion/diversion.component';
import { DiversionService } from './diversion/diversion.service';
import { DrugInfoComponent } from './drug-info/drug-info.component';
import { DrugInteractionComponent } from './drug-interaction/drug-interaction.component';
import { DrugInteractionService } from './drug-interaction/drug-interaction.service';
import { EditPatientprofileComponent } from './edit-patientprofile/edit-patientprofile.component';
import { FilledPatientComponent } from './filled-patient/filled-patient.component';
import { FillprescriptionComponent } from './fillprescription/fillprescription.component';
import { MydialogComponent } from './mydialog/mydialog.component';
import { NewPatientProfileComponent } from './new-patientprofile/new-patientprofile.component';
import { ImportPatientCsvComponent } from './import-patientcsv/import-patientcsv.component';
import { MyDialogService } from './mydialog/mydialog.service';
import { DischargeFilterPipe } from './mypatient/mydischargepatient.filter';
import { MypatientComponent } from './mypatient/mypatient.component';
import { UserFilterPipe } from './mypatient/mypatient.filter';
import { MyPatientService } from './mypatient/mypatient.service';
import { PastReportsComponent } from './past-reports/past-reports.component';
import { PDMPReportComponent } from './pdmpreport/pdmpreport.component';
import { TimelineComponent } from './pdmpreport/timeline/timeline.component';
import { PillcountComponent } from './pillcount/pillcount.component';
import { ProfiledetailRoutingModule } from './profiledetail-routing.module';
import { ProfiledetailComponent } from './profiledetail.component';
import { ProfiledetailService } from './profiledetail.service';
import { SetAppointmentComponent } from './set-appointment/set-appointment.component';
import {
  DiversionInitiateModalComponent,
  DiversionCompleteModalComponent,
  DiversionTableComponent,
  UrineCreateModalComponent,
  UrineTableComponent,
  UrineUpdateButtonComponent,
  UrineUpdateModalComponent,
} from 'app/modules/profiledetail/patient-request';
import { PainScreeningDialogComponent } from 'app/modules/profiledetail/pain-screening-dialog';
import { PegScoreHistoryComponent } from 'app/modules/profiledetail/peg-score-history/peg-score-history.component';
import { MmeChartComponent } from 'app/modules/profiledetail/mme-chart/mme-chart.component';
import { MmeChartDialogComponent } from 'app/modules/profiledetail/mme-chart-dialog/mme-chart-dialog.component';
import { FilePickerModule } from 'ngx-awesome-uploader';
import { UniquePipe } from './unique.pipe';
import { NgPipesModule } from 'ngx-pipes';
import { GoogleChartsModule } from 'angular-google-charts';

import { EffectsModule } from '@ngrx/effects';
import { MedicationEffects } from '@app/reducers/medication/medication.effects';
import { ChecklistsModule } from '../patient-nav/checklists/checklists.module';
import { DiversionEntryEffects } from 'app/reducers/diversion/diversion.effects';
import { UrineEffects } from 'app/reducers/urine/urine.effects';
import { ScreeningEffects } from 'app/reducers/screening/screening.effects';

import { SharedModule } from 'app/common/modules/shared/shared.module';
import { InitContractDialogComponent } from './init-contract-dialog/init-contract-dialog.component';
import { SendInfoComponent } from './send-info/send-info.component';
import { BypassSecurityUrlPipeModule } from '@app/common/pipes/bypass-security-url/bypass-security-url.module';
import { TextFieldModule } from '@angular/cdk/text-field';
import { NewNoteDialogComponent } from './new-note-dialog/new-note-dialog.component';

import { PrescriptionBottlePanelComponent } from './prescription-bottle-panel/prescription-bottle-panel.component';
import { NotesPanelComponent } from './notes-panel/notes-panel.component';
import { NewSharedModule } from '@app/shared/shared.module';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { NgSelectModule } from '@ng-select/ng-select';
import { StateCheckDialogComponent } from './state-check-dialog/state-check-dialog.component';
import { ReportSaveWarningDialogComponent } from './report-save-warning-dialog/report-save-warning-dialog.component';
import { ContractsDialogComponentComponent } from './contracts-dialog-component/contracts-dialog-component.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MyappointmentComponent } from './myappointment/myappointment.component';
import { MyshortcutsComponent } from './myshortcuts/myshortcuts.component';


@NgModule({
  imports: [
    CommonModule,
    ProfiledetailRoutingModule,
    NgbModalModule,
    NgbDatepickerModule,
    NgbTimepickerModule,
    NgbTypeaheadModule,
    MatDialogModule,
    MatButtonModule,
    MatRadioModule,
    MatIconModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    MatMenuModule,
    MatNativeDateModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatSelectModule,
    ChartsModule,
    NgPipesModule,
    ChecklistsModule,
    MatTableModule,
    MatDividerModule,
    FilePickerModule,
    MatPaginatorModule,
    MatSortModule,
    MatSnackBarModule,
    MatCheckboxModule,
    Ng5SliderModule,
    TextMaskModule,
    ProfileModule,
    NgxLoadingModule.forRoot({
      backdropBackgroundColour: 'rgba(0,0,0,0.4)',
    }),
    GoogleChartsModule,
    EffectsModule.forFeature([
      MedicationEffects,
      DiversionEntryEffects,
      UrineEffects,
      ScreeningEffects,
    ]),
    SharedModule,
    BypassSecurityUrlPipeModule,
    TextFieldModule,
    NewSharedModule,
    NgbPaginationModule,
    AngularSvgIconModule,
    NgSelectModule,
    NgbButtonsModule,
    MatSlideToggleModule
  ],
  exports: [MydialogComponent, MyappointmentComponent, NewPatientProfileComponent, MyshortcutsComponent],
  entryComponents: [
    MydialogComponent,
    MyshortcutsComponent,
    MyappointmentComponent,
    NewPatientProfileComponent,
    PainScreeningDialogComponent,
    PegScoreHistoryComponent,
    AddPrescriptionComponent,
    StatePdmpReportComponent,
    DischargePatientComponent,
    CustomDialogComponent,
    DiversionComponent,
    DrugInteractionComponent,
    PillcountComponent,
    DrugInfoComponent,
    FillprescriptionComponent,
    SetAppointmentComponent,
    MmeChartDialogComponent,
    DiversionInitiateModalComponent,
    DiversionCompleteModalComponent,
    UrineCreateModalComponent,
    UrineUpdateModalComponent,
    NewNoteDialogComponent,
    InitContractDialogComponent,
    SendInfoComponent,
    PDMPReportComponent,
    PastReportsComponent,
    StateCheckDialogComponent,
    ReportSaveWarningDialogComponent,
    ContractsDialogComponentComponent,
  ],
  declarations: [
    ProfiledetailComponent,
    MypatientComponent,
    MydialogComponent,
    NewPatientProfileComponent,
    PainScreeningDialogComponent,
    PegScoreHistoryComponent,
    MmeChartComponent,
    MmeChartDialogComponent,
    AddPrescriptionComponent,
    DischargePatientComponent,
    CustomDialogComponent,
    DrugInfoComponent,
    SetAppointmentComponent,
    DiversionComponent,
    DrugInteractionComponent,
    EditPatientprofileComponent,
    PillcountComponent,

    DiversionInitiateModalComponent,
    DiversionTableComponent,
    DiversionCompleteModalComponent,

    UrineCreateModalComponent,
    UrineUpdateModalComponent,
    UrineTableComponent,
    UrineUpdateButtonComponent,
    NewNoteDialogComponent,
    StateCheckDialogComponent,
    ReportSaveWarningDialogComponent,
    UserFilterPipe,
    DischargeFilterPipe,

    FilledPatientComponent,
    FillprescriptionComponent,
    UniquePipe,
    PDMPReportComponent,
    StepProgressComponent,
    MyProgressComponent,
    TimelineComponent,
    DetailedReportComponent,
    StatePdmpReportComponent,
    PastReportsComponent,
    InitContractDialogComponent,
    SendInfoComponent,

    PrescriptionBottlePanelComponent,
    NotesPanelComponent,    
    ReportSaveWarningDialogComponent, ContractsDialogComponentComponent, MyappointmentComponent, MyshortcutsComponent,
  ],
  providers: [
    ProfiledetailService,
    DiversionService,
    DrugInteractionService,
    MyPatientService,
    MyDialogService,
  ],
})
export class ProfiledetailModule {}
