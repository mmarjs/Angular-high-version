export const dialogSizes = {
  sixtyByHundred: {
    width: '60%',
    height: '100%',
  },
  allSeventyFive: {
    maxWidth: '75vw',
    width: '75%',
    height: '75%',
    maxHeight: '75vh',
  },
  allNinetySeven: {
    maxWidth: '97vw',
    maxHeight: '97vh',
    height: '97%',
    width: '97%',
  },
};
