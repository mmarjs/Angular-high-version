import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'userdischargefilter'
})
export class DischargeFilterPipe implements PipeTransform {
  transform(items: any[], disSearchText: string): any[] {
    if(!items) return [];
    if(!disSearchText) return items;
    disSearchText = disSearchText.toLowerCase();
    return items.filter( it => {
      return it.firstName.toLowerCase().includes(disSearchText) + it.lastName.toLowerCase().includes(disSearchText);
    });
  }
}