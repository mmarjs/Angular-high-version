import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { setDialogs } from '../../../core/config/setDialogs';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  RequiredValidator
} from '@angular/forms';
import { MyPatientService } from './mypatient.service';
import { MyPatient } from './mypatient.model';
import { HttpErrorResponse } from '@angular/common/http';
import { Prescription } from '../../profiledetail/prescription';
import { AddPrescriptionService } from '../add-prescription/service/add-prescription.service';
import { Drugs } from '../../../modules/profiledetail/drugs';
import { DrugInfoService } from '../drug-info/drug-info.service';
import { CommonService } from '../../../core/services/commonService/common.service';
import { ProfiledetailService } from '../profiledetail.service';
import { Router } from '@angular/router';
import { DrugInfoComponent } from '../drug-info/drug-info.component';

import { DischargePatientComponent } from '../discharge-patient/discharge-patient.component';
import { MydialogComponent } from '../mydialog/mydialog.component';
import { not } from '@angular/compiler/src/output/output_ast';
export let browserRefresh = false;
@Component({
  selector: 'app-mypatient',
  templateUrl: './mypatient.component.html',
  styleUrls: [
    '../../dashboard/scss/dashboard.component.scss',
    './mypatient.component.scss'
  ]
})
export class MypatientComponent implements OnInit {
  dataPresent = false;
  SearchForm: FormGroup;
  public myPatient = new MyPatient();
  public userList = [];
  public prescription = new Prescription();
  public pres = [];
  public firstPres = [];
  public remPres = [];
  public drugs = new Drugs();
  public drug = [];
  public userDischargeList = [];
  public patientInfo = [];
  public patient_id_fromdb;
  public selected_patient_data = [];
  public params;
  selectedIndex: number;
  public userActiveList = [];
  public distinctResult = [];
  public array = [];
  inUserList = false;
  inUserDischargeList = false;
  inUserActiveList = false;
  menuName = '';
  noOfDrugs;
  active_new: Boolean;
  isSingleClick: Boolean = true;
  public currentUsers = [];
  dateValue = '';
  searchText = '';

  forDevelop: Boolean = true;

  panelExpanded2 = false;
  width;
  height;
  data;
  showMoreDrugs = false;
  panelExpanded_dropdown_action = false;

  @Input() patientId = this.patient_id_fromdb;

  constructor(
    private profiledetailService: ProfiledetailService,
    private router: Router,
    public commonService: CommonService,
    private fb: FormBuilder,
    public drugInfoService: DrugInfoService,
    public prescriptionService: AddPrescriptionService,
    public dialog: MatDialog,
    public myPatientService: MyPatientService
  ) {
    this.menuName = 'Today\'s Patient';
  }

  setaddPatient() {
    setDialogs.isAddPatient = !setDialogs.isAddPatient;
    setDialogs.isDischarge = false;
    setDialogs.isPrescription = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isDrugInfo = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isDiversion = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isFillPrescription = false;

    this.width = '97%';
    this.height = '600px';
  }
  setDrug() {
    setDialogs.isDrugInfo = !setDialogs.isDrugInfo;
    setDialogs.isDischarge = false;
    setDialogs.isPrescription = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isDiversion = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isFillPrescription = false;
    this.width = '95%';
    this.height = '80%';
  }
  setDischarge() {
    setDialogs.isDischarge = !setDialogs.isDischarge;
    setDialogs.isDrugInfo = false;
    setDialogs.isPrescription = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isDiversion = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isFillPrescription = false;

    this.width = '40%';
    this.height = '50%';
  }
  setEditPatientProfile() {
    setDialogs.isEditPatientProfile = !setDialogs.isEditPatientProfile;
    setDialogs.isDrugInfo = false;
    setDialogs.isPrescription = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isDischarge = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isDiversion = false;
    setDialogs.isFillPrescription = false;

    this.width = '70%';
    this.height = '90%';
  }

  setAppointment() {
    setDialogs.isSetAppointment = !setDialogs.isSetAppointment;
    setDialogs.isDrugInfo = false;
    setDialogs.isPrescription = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isDischarge = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isDiversion = false;
    setDialogs.isFillPrescription = false;

    this.width = '50%';
    this.height = '60%';
  }
  setDiversion() {
    setDialogs.isDiversion = !setDialogs.isDiversion;
    setDialogs.isDrugInfo = false;
    setDialogs.isPrescription = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isDischarge = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isFillPrescription = false;
    this.width = '60%';
    this.height = '50%';
  }
  setPrescription() {
    setDialogs.isPrescription = !setDialogs.isPrescription;
    setDialogs.isDrugInfo = false;
    setDialogs.isDiversion = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isDischarge = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isDrugInteraction = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isFillPrescription = false;
    this.width = '97%';
    this.height = '100%';
  }
  setDrugInteraction() {
    setDialogs.isDrugInteraction = !setDialogs.isDrugInteraction;
    setDialogs.isDrugInfo = false;
    setDialogs.isDiversion = false;
    setDialogs.isEditPatientProfile = false;
    setDialogs.isDischarge = false;
    setDialogs.isAddPatient = false;
    setDialogs.isBurgerMenu = false;
    setDialogs.isEditProfile = false;
    setDialogs.isHeader = false;
    setDialogs.isPillInfo = false;
    setDialogs.isPrescription = false;
    setDialogs.isSetAppointment = false;
    setDialogs.isFillPrescription = false;
    this.width = '90%';
    this.height = '90%';
  }

  ngOnInit() {
    this.SearchForm = this.fb.group({
      firstName: [''],
      middleName: [''],
      lastName: [''],
      dob: [''],
      addressLine1: [''],
      ssn: ['']
    });

    const date = new Date();
    this.dateValue = date.toLocaleDateString();

    //this.getUsers();
    this.getActiveUsers();

    this.drugInfoService.getDrugs(this.params).subscribe(
      res => {
        this.drugSuccessCallback(res);
      },
      error => {
        console.log(error);
      }
    );
  }

  public fetchPrescriptions(id) {
    this.isSingleClick = true;
    setTimeout(() => {
      if (this.isSingleClick) {
        const params1 = { patientId: id, type: 'ALL_PRESCRIPTIONS' };
        this.prescriptionService.readPrescription(params1).subscribe(
          res => {
            this.resultSuccessCallback(res);
          },
          error => {
            console.log(error);
          }
        );
      }
    }, 250);
  }

  /**
   * method to fetch precriptions with controlled substance
   */

  getFormattedNumber(num) {
    return `${num < 10 ? '0' + num : num}`;
  }

  getControlledSubstance() {
    const params2 = {
      patientId: this.patient_id_fromdb,
      type: 'ALL_PRESCRIPTIONS',
      is_controlles_substance: 'YES'
    };
    this.prescriptionService.readPrescription(params2).subscribe(
      res => {
        this.resultSuccessCallback(res);
      },
      error => {
        console.log(error);
      }
    );
  }

  /**
   * method to fetch current medication
   */
  getCurrentMedication() {
    const params2 = {
      patientId: this.patient_id_fromdb,
      type: 'ALL_PRESCRIPTIONS'
    };
    this.prescriptionService.readPrescription(params2).subscribe(
      res => {
        this.resultSuccessCallback(res);
      },
      error => {
        console.log(error);
      }
    );
  }

  public getPatientInfo(id, idx) {
    this.isSingleClick = true;
    setTimeout(() => {
      if (this.isSingleClick) {
        const params1 = { patientId: id };
        this.profiledetailService
          .getPatientInfo(params1)
          .subscribe((res: any) => {
            this.currentUsers[idx] = res.body[0];
            // this.patientSuccessCallback(res);
            console.log(res.body);
          });
      }
    }, 250);
    /*  let params1 = { "patientId": id }
		this.profiledetailService.getPatientInfo(params1).subscribe(res => {
			this.patientSuccessCallback(res);
		});*/
  }

  public setPatientId(id) {
    this.isSingleClick = true;
    setTimeout(() => {
      if (this.isSingleClick) {
        this.patient_id_fromdb = id;

        this.params = { patientId: this.patient_id_fromdb };
        console.log(this.patient_id_fromdb);
      }
    }, 250);

    /*  this.patient_id_fromdb = id;

		this.params = { "patientId": this.patient_id_fromdb };
		console.log(this.patient_id_fromdb);*/
  }

  public routeToProfileDetails() {
    this.router.navigate(['mypatient/profiledetail'], {
      queryParams: { patient_id: this.patient_id_fromdb }
    });
  }

  setIndex(i) {
    this.selectedIndex = i;
    this.active_new = false;
  }

  showdata(id) {
    this.isSingleClick = false;
    this.router.navigate(['patientnav'], {
      queryParams: { patient_id: id },
      skipLocationChange: true
    });
    // localStorage.setItem(StoreKeys.PATIENT_ID, id);
    // this.router.navigate(['mypatient/profiledetail'], { queryParams: { patient_id:id } });
    console.log('show data executed');
  }

  public getUsers() {
    this.active_new = true;
    this.selectedIndex = 0;
    this.menuName = 'Today\'s Patient';
    // debugger
    //const params1 = { "TYPE": "TODAYSPATIENT" };

    this.myPatientService.getMyPatients().subscribe(
      res => {
        this.currentUsers = res.body;
        this.currentUsers.forEach((elem, idx) => {
          this.getPatientInfo(elem._id, idx);
        });
        /*
			if(this.userList.length>0){
				this.patient_id_fromdb = this.userList[0]._id;
				this.fetchPrescriptions(this.patient_id_fromdb);
				this.getPatientInfo(this.patient_id_fromdb);
				console.log("USER DATA:" + this.userList);
				this.inUserList = true;
				this.inUserDischargeList = false;
				this.inUserActiveList = false;
			} */
      },
      (err: HttpErrorResponse) => {
        console.log('error:', err);
      }
    );
  }

  public getAllUsers() {
    this.active_new = true;
    this.selectedIndex = 0;
    this.menuName = 'All patients';
    // debugger
    //const params1 = { "TYPE": "TODAYSPATIENT" };

    this.myPatientService.getAllPatients().subscribe(
      res => {
        console.log('Response from server:', res.body);
        this.currentUsers = res.body;
        this.currentUsers.forEach((elem, idx) => {
          this.getPatientInfo(elem._id, idx);
        });

        /*
			if(this.userList.length>0){
				this.patient_id_fromdb = this.userList[0]._id;
				this.fetchPrescriptions(this.patient_id_fromdb);
				this.getPatientInfo(this.patient_id_fromdb);
				console.log("USER DATA:" + this.userList);
				this.inUserList = true;
				this.inUserDischargeList = false;
				this.inUserActiveList = false;
			} */
      },
      (err: HttpErrorResponse) => {
        console.log('error:', err);
      }
    );
  }

  public getDischargeUsers() {
    this.active_new = true;
    this.selectedIndex = 0;
    this.menuName = 'Discharged Patient';
    const params = { _id: '' };
    // debugger
    this.myPatientService.getMyDischargePatients(params).subscribe(
      res => {
        this.currentUsers = res.body;
        this.currentUsers.forEach((elem, idx) => {
          this.getPatientInfo(elem._id, idx);
        });
      },
      (err: HttpErrorResponse) => {
        console.log('error:', err);
      }
    );
  }

  public getActiveUsers() {
    this.active_new = true;
    this.selectedIndex = 0;
    this.menuName = 'Active Patients';
    const params = { _id: '' };
    // debugger
    this.myPatientService.getMyActivePatients(params).subscribe(
      res => {
        this.currentUsers = res.body;
        this.currentUsers.forEach((elem, idx) => {
          this.getPatientInfo(elem._id, idx);
        });
        /**
			 *     if(this.userList.length>0){
			this.patient_id_fromdb = this.userList[0]._id;
			this.fetchPrescriptions(this.patient_id_fromdb);
			this.getPatientInfo(this.patient_id_fromdb);
			console.log("USER DATA:" + this.userList);
			this.inUserList = true;
			this.inUserDischargeList = false;
			this.inUserActiveList = false;
			}
			 */
      },
      (err: HttpErrorResponse) => {
        console.log('error:', err);
      }
    );
  }

  patientSuccessCallback(detail) {
    this.patientInfo = detail.body;
    console.log('display body');
    console.log(this.patientInfo);
  }

  drugSuccessCallback(res) {
    this.drug = res.body;

    console.log('display body');
    console.log(this.drug);
  }

  resultSuccessCallback(res) {
    console.log(res.body);
    this.pres = res.body;
    console.log('prescriptions', this.pres);

    let distinct = [];
    distinct = this.pres;
    this.distinctResult = this.commonService.getDistinctResults(distinct);
    console.log('distinct data result', this.distinctResult);
    let count = 0;
    this.firstPres.length = 0;
    this.remPres.length = 0;
    //for(let item of res.body){
    for (const item of this.distinctResult) {
      //console.log("item of body",item);
      if (count < 6) {
        console.log('count', count);

        this.firstPres.push(item);
      }
      if (count >= 6) {
        this.remPres.push(item);
      }
      count = count + 1;
    }
    console.log('first six', this.firstPres);
    console.log('next six', this.remPres);
    //this.pres = res.body;
    this.noOfDrugs = this.distinctResult.length;
    console.log('No of drugs', this.noOfDrugs);
    if (this.noOfDrugs > 6) {
      this.showMoreDrugs = true;
      console.log('show drug status', this.showMoreDrugs);
    }
    if (this.noOfDrugs < 6) {
      this.showMoreDrugs = false;
      console.log('show drug status', this.showMoreDrugs);
    }
    console.log(this.pres);
    //var drugId=res.body['drug_id'];
    //console.log(drugId);
    //console.log("display body");
    //console.log(this.pres);
  }

  openDialog(type, p_info): void {
    const reqData = {
      dataKey: this.patient_id_fromdb,
      dataKey2: this.patientInfo,
      dataKey3: this.pres,
      dataKey1: this.drug
    };
    if (type == 'PRES') {
      this.setPrescription();
    } else if (type == 'DIVERSION') {
      this.setDiversion();
    } else if (type == 'DRUG_INTERACTION') {
      this.setDrugInteraction();
    } else if (type == 'APPOINTMENT') {
      this.setAppointment();
      reqData.dataKey = p_info._id;
      reqData.dataKey2 = p_info;
    } else {
      this.setEditPatientProfile();
    }
    const dialogRef = this.dialog.open(CustomDialogComponent, {
      width: this.width,
      height: this.height,
      data: reqData
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('result***', result);
      if (!result) {
        console.log('dialog was closed');
      } else {
        console.log('result after pres push', result);
        console.log('result drugid', result[0].drug_id);
        const obj = this.distinctResult.find(
          e => e.drug_id === result[0].drug_id
        );
        console.log('obj', obj);
        if (obj == undefined) {
          if (result.length == 1) {
            if (this.firstPres.length <= 5) {
              this.firstPres.push(result[0]);
              this.distinctResult.push(result[0]);
              console.log('first pres', this.firstPres);
            } else {
              this.remPres.push(result[0]);
              this.distinctResult.push(result[0]);
              this.showMoreDrugs = true;
            }
          }
        } else {
          console.log('duplicate');
          if (this.firstPres.length <= 6) {
            this.firstPres = this.firstPres.filter(
              order => order.drug_id !== result[0].drug_id
            );
            this.firstPres.push(result[0]);
          } else {
            this.remPres = this.remPres.filter(
              order => order.drug_id !== result[0].drug_id
            );
            this.remPres.push(result[0]);
          }
        }

        /* else{
				for(let item of result)
				{
					console.log("item",item);
					if(this.firstPres.length<=5){

					this.firstPres.push(item);
					}
					else{
						this.remPres.push(item);
					}
				}
			}*/
      }
    });
  }

  openDialog1(id): void {
    const dialogRef = this.dialog.open(DrugInfoComponent, {
      width: '97%',
      height: '80%',
      data: {
        dataKey: this.patient_id_fromdb,
        dataKey2: this.patientInfo,
        dataKey3: this.pres,
        dataKey5: this.drug,
        dataKey4: id
      }
    });
  }

  openDialog2(): void {
    const dialogRef = this.dialog.open(DischargePatientComponent, {
      width: '40%',
      height: '50%',
      data: {
        dataKey: this.patient_id_fromdb,
        dataKey2: this.patientInfo
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('result', result);
      if (!result) {
        console.log('dialog was closed');
      } else {
        this.userActiveList = this.userActiveList.filter(
          order => order._id !== result.patient_id
        );
      }
    });
  }

  openAddPatientDlg(): void {
    const dialogRef = this.dialog.open(MydialogComponent, {
      width: '97%',
      height: '600px'
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('result', result);
      if (!result) {
        console.log('dialog was closed');
      } else {
        this.inUserActiveList = true;
        const userObj = {};
        userObj['_id'] = result[0]._id;
        userObj['firstName'] = result[0].firstName;
        userObj['lastName'] = result[0].lastName;
        console.log('userObj', userObj);
        this.userActiveList.push(userObj);
        console.log('obj pushed');
      }
    });
  }

  getDrugNameFromId(drugId) {
    for (const item of this.drug) {
      if (drugId == item._id) {
        return item.name;
      }
    }
  }
}
