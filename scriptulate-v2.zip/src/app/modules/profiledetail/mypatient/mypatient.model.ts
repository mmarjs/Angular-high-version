export class MyPatient{
    public _id:any;
    public firstName:String;
    public middleName:String;
    public lastName:String;
    
}