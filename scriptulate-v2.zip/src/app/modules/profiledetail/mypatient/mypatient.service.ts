/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { AuthService } from '../../../core/services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
/**
 * @author Rajat Mathur
 * @name MyPatientService
 * @desc This is a configuration file and contains the enviroment specific configuration
 */
export class MyPatientService {
  //BASE_URL_SEARCH_PATIENT = EnvironemntConfig.BASE_URL;
  BASE_URL = EnvironemntConfig.BASE_URL;
  public userList = [];
  constructor(private httpResourceService: HttpResourceService) {}

  /**
   * @name getMyDialog
   * @desc Search Patients
   * @param params
   */
  getMyPatients(): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_PATIENT;
    return this.httpResourceService.get(url, null);
  }
  getAllPatients(): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.ALL_PATIENT;
    return this.httpResourceService.get(url, null);
  }

  getMyDischargePatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_DISCHARGE_PATIENTS;
    return this.httpResourceService.get(url, params);
  }

  getMyActivePatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_ACTIVE_PATIENTS;
    return this.httpResourceService.get(url, params);
  }
}
