import { ProfiledetailModule } from './profiledetail.module';

describe('ProfiledetailModule', () => {
  let profiledetailModule: ProfiledetailModule;

  beforeEach(() => {
    profiledetailModule = new ProfiledetailModule();
  });

  it('should create an instance', () => {
    expect(profiledetailModule).toBeTruthy();
  });
});
