import { Component, OnInit, Inject } from '@angular/core';
import { setDialogs } from '@app/core/config/setDialogs';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDatepickerInputEvent
} from '@angular/material';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FillprescriptionService } from '../fillprescription/fillprescription.service';
import { Observable } from 'rxjs';
import * as lodash from 'lodash';
import * as moment from 'moment';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';

@Component({
  selector: 'app-detailed-report',
  templateUrl: './detailed-report.component.html',
  styleUrls: [
    '../mydialog/mydialog.component.scss',
    './detailed-report.component.scss'
  ]
})
export class DetailedReportComponent implements OnInit {
  m_all_pres = [];
  m_drugs = [];
  m_pres_for_table = [];
  m_patientID = '';
  m_cur_dosage = { opioids: 0, bruprenorhine: 0 };
  m_max_dosage = { opioids: 0, bruprenorhine: 0 };
  m_total_prescribers = { opioids: 0, bruprenorhine: 0 };
  m_complation_date = { opioids: new Date(), bruprenorhine: new Date() };

  m_filter: {
    drug: any;
    from: Date;
    till: Date;
  } = {
    drug: '',
    from: new Date(),
    till: new Date()
  };

  m_prescriptionDetails = [];
  m_prescriptionObjectDetails = [];
  m_buffer_prescriptions = [];

  pdmpForm: FormGroup;

  public mChartData: {
    data: Array<any>;
    labels: Array<any>;
    colors: Array<any>;
  } = {
    data: [
      {
        data: [16, 12, 30, 20, 42, 16, 12, 30, 20, 42],
        label: 'MME'
      }
    ],
    labels: [
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019',
      '5/24/2019'
    ],
    colors: [
      {
        backgroundColor: 'rgba(148,159,177,0.2)',
        borderColor: 'rgba(148,159,177,1)',
        pointBackgroundColor: 'rgba(148,159,177,1)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(148,159,177,0.8)'
      }
    ]
  };

  public mChartOptions: any = {
    maintainAspectRatio: false,
    responsive: true,
    scales: {
      yAxes: [
        {
          ticks: {
            min: 0
          },
          gridLines: {
            color: 'rgba(200,200,200,0.2)'
          },
          scaleLabel: {
            display: false
          },
          scaleShowLabels: false
        }
      ],
      xAxes: [
        {
          display: false,
          scaleLabel: {
            display: false
          }
        }
      ]
    },
    title: {
      display: false
    },
    legend: {
      display: false
    },
    elements: {
      line: {
        borderWidth: 1
      },
      point: {
        radius: 3,
        backgroundColor: 'rgba(255,255,255,1)',
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.1)'
      }
    }
  };

  patient$: Observable<object>;
  prescriptions$: Observable<object>;
  doctor$: Observable<object>;
  medication$: Observable<object>;
  prescriptions: any;

  constructor(
    public dialogRef: MatDialogRef<CustomDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fillPrescriptionService: FillprescriptionService
  ) {
    this.patient$ = data.patient;
    this.prescriptions$ = data.prescriptions;
    this.doctor$ = data.doctor;
    this.medication$ = data.medication;
  }

  ngOnInit() {
    this.prescriptions$.subscribe((prescriptions: any) => {
      this.prescriptions = prescriptions.map(p => {
        p.last_filled_order = lodash.last(p.filled_orders);
        return p;
      });
      this.getMaxDailyDosage(this.prescriptions);
      this.renderChart(this.prescriptions);
    });

    setDialogs.isDetailedReport = !setDialogs.isDetailedReport;

    this.m_all_pres = this.data.prescriptions;
    this.m_patientID = this.data.dataKey;
    this.m_drugs = this.data.drugs;

    const today = new Date();
    this.m_filter.from = new Date();
    this.m_filter.till = new Date(today.setDate(today.getDate() + 1));
    this.m_filter.drug = '-';

    this.pdmpForm = new FormGroup({
      selectedDrug: new FormControl('', [Validators.required])
    });

    this.pdmpForm.controls['selectedDrug'].setValue(this.m_filter.drug);
  }

  onNoClick() {
    this.dialogRef.close();
  }

  onChangeDrugList(e) {
    this.m_prescriptionDetails = [];
    this.getPrescriptionByDrugID(e.value);
  }

  getDrugByID(id: string): any {
    for (let i = 0; i < this.m_drugs.length; i++) {
      if (this.m_drugs[i]._id == id) {
        return this.m_drugs[i];
      }
    }
  }

  onChangeFrom(type: string, event: MatDatepickerInputEvent<Date>) {
    const from = new Date(event.value);
    this.m_filter.from = from;
    if (from > this.m_filter.till) {
      this.m_filter.till = new Date(
        this.m_filter.till.setDate(from.getDate() + 1)
      );
    }
    this.getPeriodsFromTo();
  }

  onChangeTo(type: string, event: MatDatepickerInputEvent<Date>) {
    const to = new Date(event.value);
    this.m_filter.till = to;
    this.getPeriodsFromTo();
  }

  getPeriodsFromTo() {
    this.m_prescriptionDetails = [];
    this.m_buffer_prescriptions.forEach(elem => {
      const preDate = new Date(elem.prescriptionData.date_prescribed);
      if (preDate >= this.m_filter.from && preDate < this.m_filter.till) {
        this.m_prescriptionDetails.push(elem);
      }
    });
  }

  renderChart(pres: Array<any>) {
    const realMMEs: Array<{ mme: number; preDate: string; days: number }> = [];
    pres.forEach(elem => {
      if (elem.mme > 0) {
        const obj = {
          mme: elem.mme,
          preDate: elem.date_prescribed,
          days: elem.number_of_days
        };
        realMMEs.push(obj);
      }
    });

    realMMEs.sort((a, b) => {
      return moment(a.preDate).isBefore(moment(b.preDate)) ? 1 : -1;
    });
    const tmp: { data: Array<string>; labels: Array<string> } = {
      data: [],
      labels: []
    };

    realMMEs.forEach(elem => {
      const mmes = [],
        labels = [];
      for (let i = 0; i < elem.days; i++) {
        mmes.push(elem.mme);
        const d = new Date(elem.preDate);
        d.setDate(d.getDate() + i);
        labels.push(this.getFormattedDate(new Date(d), '/'));
      }
      if (tmp.labels.length === 0) {
        tmp.data = mmes;
        tmp.labels = labels;
      } else {
        const buffLabels: Array<string> = tmp.labels.concat(labels);
        const buffMmes = tmp.data.concat(mmes);
      }
    });
    this.mChartData.data[0].data = tmp.data;
    this.mChartData.labels = tmp.labels;

    this.getCurrentAmounts(tmp.data);
    this.getPrescribersInPeriods(pres);
  }

  getPrescribersInPeriods(pres: Array<any>) {
    const aryPres = [];
    pres.forEach((element, idx) => {
      if (idx == 0) {
        aryPres.push(element.prescribed_by);
      } else {
        let flag = false;
        for (let i = 0; i < aryPres.length; i++) {
          if (aryPres[i] != element.prescribed_by) {
            flag = true;
            break;
          }
        }
        if (flag == true) {
          aryPres.push(element.prescribed_by);
        }
      }
    });
    this.m_total_prescribers.opioids = aryPres.length;
  }

  getCurrentAmounts(data: Array<any>) {
    let mme = 0;
    for (let i = 0; i < data.length; i++) {
      if (data[i] > mme) {
        mme = data[i];
      }
    }
    this.m_cur_dosage.opioids = mme;
  }

  getMaxDailyDosage(precriptions: any) {
    let max = 0;
    const dayAgoSixMonth = moment().subtract(6, 'months');
    precriptions.forEach(elem => {
      if (moment(elem.date_prescribed).isAfter(dayAgoSixMonth)) {
        if (elem.mme > max) {
          max = elem.mme;
        }
      }
    });
    this.m_max_dosage.opioids = max;
  }

  getComplationDate(pres: Array<any>) {
    let maxDate: Date;
    let numOfDays = 0;
    pres.forEach((elem, idx) => {
      if (idx === 0) {
        if (typeof elem.pill_end_date != 'undefined') {
          maxDate = new Date(elem.pill_end_date);
        } else {
          maxDate = new Date(elem.date_prescribed);
        }
        numOfDays = elem.number_of_days;
      } else {
        if (typeof elem.pill_end_date !== 'undefined') {
          if (new Date(elem.pill_end_date) > maxDate) {
            maxDate = new Date(elem.pill_end_date);
            numOfDays = elem.number_of_days;
          }
        } else {
          if (new Date(elem.date_prescribed) > maxDate) {
            maxDate = new Date(elem.date_prescribed);
            numOfDays = elem.number_of_days;
          }
        }
      }
    });
    maxDate =
      pres.length > 0
        ? new Date(maxDate.setDate(maxDate.getDate() + numOfDays))
        : null;
    this.m_complation_date.opioids = maxDate;
  }

  getFormattedDate(date: Date, divider: string): string {
    return `${date.getMonth() +
      1}${divider}${date.getDate()}${divider}${date.getFullYear()}`;
  }

  getPrescriptionByDrugID(drugId: string) {
    const params = { patientId: this.m_patientID, drugId: drugId };

    this.fillPrescriptionService
      .fetchFilledPrescription(params)
      .subscribe(res => {
        this.fetchFilledPrescriptionSuccessCallback(res);
      });
  }

  fetchFilledPrescriptionSuccessCallback(res) {
    const classObj = this;
    res.body.forEach(function(prescription, i) {
      const temp: String = prescription.prescriptionData._id.substring(20);
      prescription.prescriptionData['tempId'] = temp;
      prescription.prescriptionData['drug'] = classObj.getDrugByID(
        prescription.prescriptionData.drug_id
      );
      classObj.m_prescriptionDetails.push(prescription);
      classObj.fetchDoctorData(prescription.prescriptionData.prescribed_by, i);
    });
    this.m_prescriptionDetails.sort((a, b) =>
      a.prescriptionData.drug.name.localeCompare(b.prescriptionData.drug.name)
    );
    this.m_buffer_prescriptions = this.m_prescriptionDetails;
  }

  /**
   * get doctor details for prescription
   * @param resp
   */
  fetchDoctorData(doctorId, index) {
    const params = { prescribed_by: doctorId };
    this.fillPrescriptionService.fetchDoctorData(params).subscribe(response => {
      this.fetchDoctorDataSuccessCallback(response, index);
    });
  }

  fetchFilledData(id, index) {
    const params = { prescriptionId: id };
    this.fillPrescriptionService
      .fetchPrescriptionFilledByPharmacist(params)
      .subscribe(response => {
        this.fetchFilledDataSuccessCallback(response, index);
      });
  }

  fetchPharmacistData(id, filledDataIndex, index) {
    const params = { filledBy: id };

    this.fillPrescriptionService
      .fetchPharmacistData(params)
      .subscribe(response => {
        this.fetchPharmacistDataSuccessCallback(
          response,
          filledDataIndex,
          index
        );
      });
  }

  fetchDoctorDataSuccessCallback(doctorDetails, index) {
    this.m_prescriptionDetails[index]['doctorDetails'] = doctorDetails.body;
    this.fetchFilledData(
      this.m_prescriptionDetails[index].prescriptionData._id,
      index
    );
  }

  fetchFilledDataSuccessCallback(response, index) {
    this.m_prescriptionDetails[index]['filledData'] = response.body;
    const classObj = this;

    if (this.m_prescriptionDetails[index]['filledData'] != null) {
      this.m_prescriptionDetails[index]['filledData'].forEach(function(
        filledData,
        filledDataIndex
      ) {
        classObj.m_prescriptionObjectDetails.push({
          filledData: filledData,
          pData: classObj.m_prescriptionDetails[index]['prescriptionData'],
          presStatus:
            classObj.m_prescriptionDetails[index]['prescriptionStatus'],
          doctorDetails: classObj.m_prescriptionDetails[index]['doctorDetails']
        });
        classObj.fetchPharmacistData(
          filledData.filled_by,
          filledDataIndex,
          index
        );
      });
    } else {
      classObj.m_prescriptionObjectDetails.push({
        filledData: null,
        pData: this.m_prescriptionDetails[index]['prescriptionData'],
        presStatus: classObj.m_prescriptionDetails[index]['prescriptionStatus'],
        doctorDetails: classObj.m_prescriptionDetails[index]['doctorDetails']
      });
    }
  }

  fetchPharmacistDataSuccessCallback(response, filledDataIndex, index) {
    this.m_prescriptionDetails[index]['filledData'][filledDataIndex][
      'pharmacistDetails'
    ] = response.body[0];
  }
}
