export class Drugs {
    public name:string;
    public _id:Number;
    public rxcui:string;
    public is_controlled_substance:string;
}
