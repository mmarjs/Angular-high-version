export class Icd {
    public name:string;
    public _id:Number;
    public desc:string;
  
}
