/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
/**
 * @author Rajat Mathur
 * @name MyDialogService
 * @desc This is a configuration file and contains the enviroment specific configuration
 */
export class MyAppointmentService {
  BASE_URL = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) {}

  /**
   * @name getMyDialog
   * @desc Search Patients
   * @param params
   */
  getMyDialog(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.MY_DIALOG;
    return this.httpResourceService.post(url, params);
  }
  getMyDoctor(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.FETCH_DOCTOR_DETAILS;
    return this.httpResourceService.get(url, params);
  }
  addMyPatients(params: any): Observable<any> {
    const url = this.BASE_URL + RelativeUrlConfig.ADD_MY_PATIENT;
    return this.httpResourceService.post(url, params);
  }
}
