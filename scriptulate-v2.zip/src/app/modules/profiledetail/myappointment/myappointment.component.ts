import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import {
  createAppointment,
} from '@app/reducers/doctor/doctor.actions';
import { MyAppointmentService } from './myappointment.service';
import { Doctor } from '@app/reducers/doctor/doctor.reducer';
import { Patient } from '@app/reducers/patient/patient.reducer';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import * as Reducers from '@app/reducers/index';
import { validateAllFormFields, setNgbStructAsMomentObj } from '@app/helpers';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NewPatientProfileComponent } from '../new-patientprofile/new-patientprofile.component';
import { ngbDateValidator } from 'app/shared/validators/ngb-date.validator';
import { Store, select } from '@ngrx/store';
import { combineDateTime, setNgbTimeStructAsMomentObj } from '@app/helpers';
import { takeUntil } from 'rxjs/operators';
import * as PatientActions from '../../../reducers/patient/patient.actions';
import { ImportPatientCsvComponent } from '../import-patientcsv/import-patientcsv.component';
import * as moment from 'moment';
@Component({
  selector: 'app-myappointment',
  templateUrl: './myappointment.component.html',
  styleUrls: ['./myappointment.component.scss'],
})
export class MyappointmentComponent implements OnInit, OnDestroy {
  @Input() data: any;
  doctor$: Observable<Doctor>;

  // patients$: Observable<Array<Patient>>;
  patients$: Array<Patient> = [];
  checked_patients$: Array<Patient> = [];
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  patientSearchForm: FormGroup;
  minimumDate: NgbDateStruct;
  maximumDate: NgbDateStruct;
  currentDate = new Date();
  doctorId: number;
  showDetail: boolean[] = [];
  time_options: object[] = [
    {value: '0', viewValue: "0:00 AM"},
    {value: '1', viewValue: "1:00 AM"},
    {value: '2', viewValue: "2:00 AM"},
    {value: '3', viewValue: "3:00 AM"},
    {value: '4', viewValue: "4:00 AM"},
    {value: '5', viewValue: "5:00 AM"},
    {value: '6', viewValue: "6:00 AM"},
    {value: '7', viewValue: "7:00 AM"},
    {value: '8', viewValue: "8:00 AM"},
    {value: '9', viewValue: "9:00 AM"},
    {value: '10', viewValue: "10:00 AM"},
    {value: '11', viewValue: "11:00 PM"},
    {value: '12', viewValue: "12:00 PM"},
    {value: '13', viewValue: "1:00 PM"},
    {value: '14', viewValue: "2:00 PM"},
    {value: '15', viewValue: "3:00 PM"},
    {value: '16', viewValue: "4:00 PM"},
    {value: '17', viewValue: "5:00 PM"},
    {value: '18', viewValue: "6:00 PM"},
    {value: '19', viewValue: "7:00 PM"},
    {value: '20', viewValue: "8:00 PM"},
    {value: '21', viewValue: "9:00 PM"},
    {value: '22', viewValue: "10:00 PM"},
    {value: '23', viewValue: "11:00 PM"},
  ]
  dateMask = [
    /[1-9]/,
    /\d/,
		/\d/,
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
	];

  states = [
    {name: 'AL'},
    {name: 'AK'},
    {name: 'AS'},
    {name: 'AZ'},
    {name: 'AR'},
    {name: 'CA'},
    {name: 'CO'},
    {name: 'CT'},
    {name: 'DE'},
    {name: 'DC'},
    {name: 'FM'},
    {name: 'FL'},
    {name: 'GA'},
    {name: 'GU'},
    {name: 'HI'},
    {name: 'ID'},
    {name: 'IL'},
    {name: 'IN'},
    {name: 'IA'},
    {name: 'KS'},
    {name: 'KY'},
    {name: 'LA'},
    {name: 'ME'},
    {name: 'MH'},
    {name: 'MD'},
    {name: 'MA'},
    {name: 'MI'},
    {name: 'MN'},
    {name: 'MS'},
    {name: 'MO'},
    {name: 'MT'},
    {name: 'NE'},
    {name: 'NV'},
    {name: 'NH'},
    {name: 'NJ'},
    {name: 'NM'},
    {name: 'NY'},
    {name: 'NC'},
    {name: 'ND'},
    {name: 'MP'},
    {name: 'OH'},
    {name: 'OK'},
    {name: 'OR'},
    {name: 'PW'},
    {name: 'PA'},
    {name: 'PR'},
    {name: 'RI'},
    {name: 'SC'},
    {name: 'SD'},
    {name: 'TN'},
    {name: 'TX'},
    {name: 'UT'},
    {name: 'VT'},
    {name: 'VI'},
    {name: 'VA'},
    {name: 'WA'},
    {name: 'WV'},
    {name: 'WI'},
    {name: 'WY'},
  ]

  constructor(
    private router: Router,
    public myAppointmentService: MyAppointmentService,
    private formBuilder: FormBuilder,
    private activeModal: NgbActiveModal,
    private store: Store<Reducers.State>,
    public modal: NgbModal,
  ) {}

  onSubmitSearch = () => {
      if (this.patientSearchForm.valid) {
        let dateOfBirth = null;
        const { last_name,first_name, birthdate } = this.patientSearchForm.value;
        dateOfBirth = birthdate.toISOString();
        this.data.patientSearchOnChange({
          first_name,
          last_name,
          birthdate: dateOfBirth,
        });
        return;
      }
      validateAllFormFields(this.patientSearchForm);
  }

  addAllAppointment=()=>{
    let data:{
      payload: [{
          date: string;
          patient_id: number;
          doctor_id: number;
      }];
    }={payload:null};
    for(let i =0;i<this.checked_patients$.length;i++){
     let time = this.checked_patients$[i]['time_option'].viewValue;
     if(!data.payload){
        data.payload=[{
            date: this.getDateTime(moment(this.currentDate).toLocaleString(),time),
            doctor_id:this.doctorId,
            patient_id: this.checked_patients$[i].id
          }];
     }else{
        data.payload.push({
          date: this.getDateTime(moment(this.currentDate).toLocaleString(),time),
          doctor_id:this.doctorId,
          patient_id: this.checked_patients$[i].id
        });
     }
    }
    this.store.dispatch(createAppointment(data));
    this.closeModal();
  }


  getDateTime = (dateValue,timeValue) => {
		return combineDateTime(dateValue,timeValue);
  }
  
  addPatient = (doctorId, patientId) => {
    this.data.addPatient(doctorId, patientId);
    this.closeModal();
  }

  closeModal = () => {
    this.store.dispatch(PatientActions.searchPatientSuccess({payload:[]}));
    this.activeModal.close();
  }

  getLastSSN = (ssn_str: string) => {
    if (!ssn_str) {
      return '';
    }

    const tmp = ssn_str.split('-');
    if (tmp.length) {
      return tmp[tmp.length - 1];
    }
    return ssn_str;
  }

  createPatientProfile = () => {
    this.router.navigate(['createpatientprofile']);
  }

  setMaxAndMinimumDates = (): void => {
    this.minimumDate = {
      year: 1800,
      month: 1,
      day: 1,
    };
    this.maximumDate = {
      year: new Date().getFullYear(),
      month: 12,
      day: 31,
    };
  }

  openNewPatientProfileDialog = (): void => {
    const mydialogRef = this.modal.open(
      NewPatientProfileComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }

  openImportPatientCsvDialog = (): void => {
    const mydialogRef = this.modal.open(
      ImportPatientCsvComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }

  showPatientDetail = (index: number) => {
    this.showDetail[index] = !this.showDetail[index];
  }

  handleRemoveClick = (patient_id: number) => {
    this.checked_patients$ = this.checked_patients$.map((patient) => {
      if(patient.id === patient_id){
        patient.checked = false;
      }
      return patient;
    }).filter(patient => patient.checked)
  }

  handleCheckedChange = (checked: boolean, indexed: number) => {
    this.checked_patients$ = this.patients$.map((patient, index) => {
      if(index === indexed){
        patient.checked = checked;
      } 
      return patient;
    }).filter(patient => patient.checked)
  }

  ngOnInit() {
    this.setMaxAndMinimumDates();
    this.doctor$ = this.data.doctor;
    
    this.store.pipe(
      takeUntil(this.unsubscribe$),
      select(state => state.patient.searchResults),
    ).subscribe((patients) => {
      if(patients){
        this.patients$ = patients;
      }
    });

    this.doctor$.subscribe(doctor => {
      this.doctorId = doctor.id;
    });

    this.patients$ = this.data.patients;
    for(var i = 0; i < Object.keys(this.patients$).length; i++){
      this.showDetail[i] = false;
    }
    this.patients$ = this.data.patients.map((patient, index) => {
      patient.checked = false;
      return patient;
    })
    
    this.patientSearchForm = this.formBuilder.group({
      first_name: [
        '',
        [
          Validators.required, Validators.pattern('^[a-zA-Z\- ]+$'),
          Validators.minLength(2),
        ],
      ],
      last_name: [
        '',
        [
          Validators.required, Validators.pattern('^[a-zA-Z\- ]+$'),
          Validators.minLength(2),
        ],
      ],
      birthdate: [
        null,
        [
          Validators.required,
          ngbDateValidator,
        ],
      ],
    });
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
