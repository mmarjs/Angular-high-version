import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfiledetailComponent } from './profiledetail.component';
import { MypatientComponent } from './mypatient/mypatient.component';
import { FilledPatientComponent } from './filled-patient/filled-patient.component';

const routes: Routes = [
  { 
    path: 'profiledetail', 
    component: ProfiledetailComponent,
    data: {
      breadcrumb: 'Controlled Substance',
    },
   },
  { path: '', component: MypatientComponent },
  { 
    path: 'filledpatient', 
    component: FilledPatientComponent,
    data: {
      breadcrumb: 'Filled',
    },
   },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfiledetailRoutingModule {}
