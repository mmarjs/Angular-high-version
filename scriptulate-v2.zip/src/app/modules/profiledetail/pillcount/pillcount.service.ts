/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { HttpResourceService } from '../../../core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';
import { RelativeUrlConfig } from '../../../core/config/RelativeUrlConfig';

@Injectable({
  providedIn: 'root',
})

/**
 * @author Rajat.Mathur
 * @name PillCount
 * @desc PillCount Service
 */
export class PillCountService {
  BASE_URL = EnvironemntConfig.BASE_URL;

  constructor(private httpResourceService: HttpResourceService) {}

  /**
   * @name registerUser
   * @desc registers a user on database
   * @param params
   */
  setPillCount(params) {
    const url = this.BASE_URL + RelativeUrlConfig.PILL_COUNT;
    return this.httpResourceService.post(url, params);
  }
}
