import { Component, OnInit,Inject } from '@angular/core';
import { CustomDialogComponent } from '../custom-dialog/custom-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { setDialogs } from '../../../core/config/setDialogs';
import { PillCountService } from './pillcount.service';
import {ActivatedRoute} from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Drugs } from '../drugs';
import { DrugInfoService } from '../drug-info/drug-info.service';
import { Messages } from '../../../core/config/messages';
@Component({
  selector: 'app-pillcount',
  templateUrl: './pillcount.component.html',
  styleUrls: ['./pillcount.component.css']
})
export class PillcountComponent implements OnInit {
  pillCountForm: FormGroup;
  radio1:FormGroup;
  public drugs = new Drugs();   // Need to import drug data and boolean value save
  public drug = [];
  public patientInfo=[];
  patientId:string;
  constructor(private route:ActivatedRoute,private drugInfoService: DrugInfoService, private fb: FormBuilder, private pillCountService: PillCountService, public dialogRef: MatDialogRef<CustomDialogComponent>,@Inject(MAT_DIALOG_DATA) public data: any ) {//private pillCountService: PillCountService,
    setDialogs.isPillInfo = !setDialogs.isPillInfo;
    this.patientInfo=data.dataKey2;
    this.patientId=data.dataKey;
  }
  
  requiredErrorMessage=Messages.REQUIRED_ERROR_MESSAGE;
  pillQuantityErrorMessage=Messages.PILL_QUANTITY;
  ngOnInit() {
   
    /*this.route.queryParams.subscribe(params => {
      console.log(params); 

      this.patientId =params.PatientId;
      console.log(this.patientId); 
    });*/
  
    this.pillCountForm = this.fb.group({
      patientId:this.patientId,
      alerted_on: ['',Validators.required],
      alerted_time: ['',Validators.required],
      presented_on: ['',Validators.required],
      presented_time: ['',Validators.required],
     
      compliant: ['',Validators.required],
      drugname: ['',Validators.required],
      pill_match: ['',Validators.required],
      desired: ['',[Validators.required,Validators.pattern('^[0-9]+$')]],
     
      actual_pill_quantity: ['',[Validators.required,Validators.pattern('^[0-9]+$')]],
      comment: ['']
    });


    const params = { "patientId": this.patientId };
    this.drugInfoService.getDrugs(params).subscribe(
      res => {
        this.resultSuccessCallback(res);
      },
      error => {
        console.log(error);
      }
    ) 
  }
   resultSuccessCallback(res) {
  
    this.drug = res.body;
   

  } 
  onSubmit() {
    if (this.pillCountForm.valid) {
      let pillCount_data = this.pillCountForm.value;
      let alertedDate = new Date( this.pillCountForm.value.alerted_on)
      var fields =  this.pillCountForm.value.alerted_time.split(':');
      var hours = fields[0];
      var mins = fields[1];
      alertedDate.setHours(hours, mins);
  
      console.log( this.pillCountForm.value.alerted_time);
  
      console.log(alertedDate);

      let presentDate = new Date( this.pillCountForm.value.presented_on)
      var patientfields = this.pillCountForm.value.presented_time.split(':');
  
      var presenthours = patientfields[0];
      var presentmins = patientfields[1];
      presentDate.setHours(presenthours, presentmins);
      //let appointmentTime = new Date(this.appointmentForm.value.appointed_time)
      // appointmentDate.setHours(appointmentTime.getTime());
      console.log( this.pillCountForm.value.appointed_time);
      var myObj = { "alerted_on": alertedDate , "present_on":  presentDate };

      let drugname = this.pillCountForm.value.drugname;
      let drugId = this.fetchDrugId(drugname);
      //pillCount_data["drug_id"] = drugId;
      pillCount_data["alerted_on"]=myObj.alerted_on;
      pillCount_data["present_on"]=myObj.present_on;
      pillCount_data["drug_id"]=drugId;
      
      console.log(myObj.alerted_on);
      this.pillCountService.setPillCount(pillCount_data).subscribe(
        response => {
          this.pillCountSuccessCallback(response);
        },
        error => {
          console.log(error);
        }
      )
    }else{
      this.validateAllFormFields(this.pillCountForm);
    }
  }
  fetchDrugId(drugname) {
    for (let item of this.drug) {
      if (drugname == item.drug_name) {
        console.log(item.drug_name);
        return item._id;
      }
    }
  }
  private pillCountSuccessCallback(response) {

    console.log(response);
 
    console.log('Pill Count Addedd Sucessfully');
    this.onNoClick();
  }
  onNoClick() {
    return this.dialogRef.close();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

    //let pillCount_data = this.pillCountForm.value;

    

    /* let presentDate = new Date(pillCount_data.presented_on)
    var patientfields =pillCount_data.presented_time.split(':');

    var presenthours = patientfields[0];
    var presentmins = patientfields[1];
    presentDate.setHours(presenthours, presentmins); */
    //let appointmentTime = new Date(this.appointmentForm.value.appointed_time)
    // appointmentDate.setHours(appointmentTime.getTime());
   // console.log(pillCount_data.alerted_time);

   // pillCount_data["present_date"] = presentDate;
   



  /*   let drugname = this.pillCountForm.value.drugname;
    let drugId = this.fetchDrugId(drugname);
    //pillCount_data["drug_id"] = drugId;
    var myObj = { "alerted_date": alertedDate ,  "drug_id": drugId , pillCount_data };
    this.pillCountService.setPillCount(myObj).subscribe(
      response => {
        this.pillCountSuccessCallback(response);
      },
      error => {
        console.log(error);
      }
    )
  }





 */


}
