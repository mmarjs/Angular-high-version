import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PillcountComponent } from './pillcount.component';

describe('PillcountComponent', () => {
  let component: PillcountComponent;
  let fixture: ComponentFixture<PillcountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PillcountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PillcountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
