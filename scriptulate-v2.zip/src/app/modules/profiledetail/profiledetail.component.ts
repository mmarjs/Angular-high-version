import {
    MmeChartDialogComponent
} from 'app/modules/profiledetail/mme-chart-dialog/mme-chart-dialog.component';
import { PainScreeningDialogComponent } from 'app/modules/profiledetail/pain-screening-dialog';
import * as _ from 'lodash';
import { NgxLoadingComponent } from 'ngx-loading';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import {
    TodoCreateModalComponent
} from '@app/common/modules/shared/components/todo-create-modal/todo-create-modal.component';
import { AuthService, PatientLastVisitService } from '@app/core/services';
import { CommonService } from '@app/core/services/commonService/common.service';
import { PusherService } from '@app/core/services/pusherService/pusher.service';
import * as Reducers from '@app/reducers';
import { selectAlerts } from '@app/reducers/alert/alert.reducer';
import { selectRole, selectUser } from '@app/reducers/auth/auth.reducer';
import * as ContractsActions from '@app/reducers/contracts/contracts.actions';
import { selectContracts } from '@app/reducers/contracts/contracts.reducer';
import { fetchDiversionEntries } from '@app/reducers/diversion/diversion.actions';
import {
    DiversionEntry, diversionsFetchedByPatient, selectDiversions
} from '@app/reducers/diversion/diversion.reducer';
import {
    getDoctorsAndPharmacists, getNotesChecklistsCombined, getPrescriptions, syncPrescriptions
} from '@app/reducers/doctor/doctor.actions';
import {
    Doctor, doctorsFetched, DoctorsPharmacistsState, DoctorsState, formatNotesWithPreview,
    notesFetchedByPatient, selectDoctorsAndOrPharmacists
} from '@app/reducers/doctor/doctor.reducer';
import { Patient } from '@app/reducers/patient/patient.reducer';
import {
    getCombinedFormattedPrescriptions, getFormattedPrescriptions, getMmePrescriptionsByIds,
    getPatientPrescriptionsById, getPrescriptionsCurrentlyTaking, Prescription as PrescriptionModel
} from '@app/reducers/prescription/prescription.reducer';
import { fetchScreenings } from '@app/reducers/screening/screening.actions';
import { isPatientScreeningsFetched } from '@app/reducers/screening/screening.reducer';
import { fetchUrineEntries } from '@app/reducers/urine/urine.actions';
import {
    selectUrineEntries, Urine, urinesFetchedByPatient
} from '@app/reducers/urine/urine.reducer';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { select, Store } from '@ngrx/store';

import { AddPrescriptionComponent } from './add-prescription/add-prescription.component';
import { AddPrescriptionService } from './add-prescription/service/add-prescription.service';
import {
    ContractsDialogComponentComponent
} from './contracts-dialog-component/contracts-dialog-component.component';
import { InitContractDialogComponent } from './init-contract-dialog/init-contract-dialog.component';
import { NewNoteDialogComponent } from './new-note-dialog/new-note-dialog.component';
import { PastReportsComponent } from './past-reports/past-reports.component';
import { PDMPReportComponent } from './pdmpreport/pdmpreport.component';
import { SendInfoComponent } from './send-info/send-info.component';
import { StateCheckDialogComponent } from './state-check-dialog/state-check-dialog.component';
import { StatePdmpReportComponent } from './state-pdmp-report';
import { DoctorService } from '@app/modules/dashboard/doctor.service';

@Component({
  selector: 'app-profiledetail',
  templateUrl: './profiledetail.component.html',
  styleUrls: ['./profiledetail.component.scss'],
})
export class ProfiledetailComponent implements OnInit, OnDestroy {
  public loading = false;
  patient$: Observable<Patient>;
  medication$: Observable<object>;
  doctor$: Observable<object>;
  role$: Observable<string>;
  alerts$: Observable<object>;
  patientPrescriptions$: any;
  notes$: Observable<any>;
  mmePrescriptions$: Observable<any>;
  prescriptionsCurrentlyTaking$: Observable<any>;
  formattedPrescriptions$: Observable<any>;
  combinedFormattedPrescriptions$: Observable<any>;
  getPrescriptionsDataForBottlePanel$: Observable<any>;
  urines: Urine[];
  diversions: DiversionEntry[];
  doctorId: number;
  patientId: number;
  contract: any;
  chartMmeData: Array<any> = null;
  prescriptionsCurrentlyTaking: Array<any> = null;
  combinedCurrentlyTaking: Array<any> = null;
  currTakingAndCompleted: Array<any> = null;
  isTakingOrCompletedPrescriptions: Array<any> = null;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  unsubscribeDialogs$: Subject<Boolean> = new Subject<Boolean>();
  bottlePanelData = {
    combinedCurrTakingOrCompleted: [],
    combinedFormattedPrescriptions: [],
    formattedPrescriptions: [],
  };

  reportButtons: Array<any>;
  lastFivePrescriptions = [];
  public customLoadingTemplate: NgxLoadingComponent;
  patient: Object;
  doctor: Doctor;
  doctors: DoctorsState;
  doctors_and_pharmacists: DoctorsPharmacistsState;
  public notes = [];
  lastPDMPSync:any='NA';

  mmeChartForm: FormGroup = new FormGroup({
    startAtDate: new FormControl(),
    endAtDate: new FormControl(),
  });

  constructor(
    private router: Router,
    public commonService: CommonService,
    private route: ActivatedRoute,
    public prescriptionService: AddPrescriptionService,
    public dialog: MatDialog,
    private store: Store<Reducers.State>,
    private pusherService: PusherService,
    private authService: AuthService,
    public bootstrapModal: NgbModal,
    public patientLastVisitService: PatientLastVisitService,
    private modal: NgbModal,
    private doctorService: DoctorService
  ) {
    this.medication$ = this.store.select(
      (state: Reducers.State) => state.medication
    );
    this.mmePrescriptions$ = this.store.select(state => getMmePrescriptionsByIds(state, { patient_id: this.patientId }));
    this.prescriptionsCurrentlyTaking$ = this.store.select(state =>
      getPrescriptionsCurrentlyTaking(state, { patient_id: this.patientId })
    );
    this.formattedPrescriptions$ = this.store.select(state => getFormattedPrescriptions(state, { patient_id: this.patientId }));
    this.combinedFormattedPrescriptions$ = this.store.select(
      state => getCombinedFormattedPrescriptions(
        state, { patient_id: this.patientId },
      )
    );
    // this.getPrescriptionsDataForBottlePanel$ = this.store.select(
    //   state => getPrescriptionsDataForBottlePanel(
    //     state,
    //     { patient_id: this.patientId }
    //   )
    // );
  }

  chartMmes = (): void => {
    this.mmePrescriptions$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((data): void => {
        if (data && data.length) {
          const filteredData = data.filter(
            (prescription: PrescriptionModel) => {
              return prescription.date.isSameOrBefore(new Date());
            }
          );
          this.chartMmeData = filteredData;
          return;
        }
        this.chartMmeData = [];
      });
  }

  openPainSigntedContracts = (): void => {
    const pastReportsRef = this.bootstrapModal.open(
      ContractsDialogComponentComponent,
      { size: 'lg', backdrop: 'static', windowClass: 'ngb-modal-past-reports' },
    );
    pastReportsRef.componentInstance.data = {
      patient_id: this.patientId,
      doctor_id: this.doctorId,
    };

    pastReportsRef.result.then(res => {
      return;
    }).catch(err => console.error(err));
  }


  initContract() {
    const dialogRef = this.dialog.open(InitContractDialogComponent, {
      data: {
        doctor: this.authService.user,
        patient: this.patient,
      },
    });

    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.store.dispatch(ContractsActions.updateContract(this.contract.id, res));
    });
  }

  newOrderClick = (): void => {
    if (this.authService.user && this.authService.user.role == 'Doctor') {
      const urineCreateRef = this.modal.open(TodoCreateModalComponent, { size: 'lg' });

      urineCreateRef.componentInstance.data = {
        patientId: this.patient['id'],
        doctorId: this.authService.user.id,
      };

      urineCreateRef.result
        .then(res => { urineCreateRef.close(); return; })
        .catch(err => console.error(err));
    }
  }

  openAddPrescriptionDialog(): void {
    this.dialog.open(AddPrescriptionComponent, {
      width: '97%',
      height: '100%',
      data: {
        patient: this.patient$,
        medication: this.medication$,
        doctor: this.doctor$,
      },
    });
  }

  openMmeChartDialog() {
    const mmeChartDialogRef = this.bootstrapModal.open(MmeChartDialogComponent, {
      windowClass: 'ngb-modal-size-1140'
    });

    mmeChartDialogRef.componentInstance.data = {
      chartMmeData: this.chartMmeData,
    };

    mmeChartDialogRef.result.then(res => {
      return;
    }).catch(err => { });
  }

  openNewNoteModal = (): void => {
    const newNoteRef = this.bootstrapModal.open(NewNoteDialogComponent, { size: 'lg' });

    newNoteRef.componentInstance.data = {
      patientId: this.patientId,
      doctorId: this.doctorId,
    };

    newNoteRef.result.then(res => {
      return;
    }).catch(err => console.error(err));
  }

  openNewPegPainScreening() {
    const pegPainScreeningModalRef = this.bootstrapModal.open(PainScreeningDialogComponent, { windowClass: 'ngb-modal-size-1140' });

    pegPainScreeningModalRef.componentInstance.data = {
      patientId: this.patientId,
      doctorId: this.doctorId,
    };

    pegPainScreeningModalRef.result.then(res => {
      return;
    }).catch(err => console.error(err));
  }

  openPdmpSummaryReport = () => {
    if (this.patient['reportChecked']) {
      const summaryReportRef = this.bootstrapModal.open(
        PDMPReportComponent,
        {
          windowClass: 'ngb-modal-size-1140',
          backdrop: 'static'
        }
      );

      summaryReportRef.componentInstance.data = {
        patientId: this.patientId,
        patient: this.patient,
        isTakingOrCompletedPrescriptions: this.isTakingOrCompletedPrescriptions,
        combinedCurrTakingOrCompleted: this.combinedCurrentlyTaking,
        doctor: this.doctor,
        doctors_and_pharmacists: this.doctors_and_pharmacists,
        lastFivePrescriptions: this.lastFivePrescriptions,

      };
      summaryReportRef.result.then(res => {
        this.unsubscribeDialogs$.next(true);
        this.unsubscribeDialogs$.complete();
        return;
      }).catch(err => { });
    }
    else {
      console.log("First check the State PDMP");
      this.openStateReportCheckDialog();
    }
  }

  openPdmpPastReport = (): void => {
    const pastReportsRef = this.bootstrapModal.open(
      PastReportsComponent,
      { size: 'lg', backdrop: 'static', windowClass: 'ngb-modal-past-reports' },
    );

    pastReportsRef.componentInstance.data = {
      patient_id: this.patientId,
      doctor_id: this.doctorId,
    };

    pastReportsRef.result.then(res => {
      return;
    }).catch(err => console.error(err));
  }

  openStatePdmpReport = (): void => {
    this.patient['reportChecked'] = true;
    const statePdmpReportRef = this.bootstrapModal.open(
      StatePdmpReportComponent,
      { windowClass: 'ngb-modal-size-94rem', backdrop: 'static' },
    );

    statePdmpReportRef.componentInstance.data = {
      patient: this.patient,
      doctorId: this.doctorId,
    };

    statePdmpReportRef.result.then(res => {
      return;
    }).catch(err => { });
  }

  openNewReports = (): void => {
    this.router.navigate(['pdmp-report'], { state: { patient: this.patient, doctorId: this.doctorId, url: this.router.url } });
  }

  renderReportButtons = (): void => {
    this.reportButtons = [
      {
        text: 'PDMP Report',
        svgPath: 'assets/svgs/document_icon.svg',
        onclick: () => this.openNewReports(),
      },
      {
        text: 'State Report',
        svgPath: 'assets/svgs/document_icon.svg',
        onclick: () => this.openStatePdmpReport(),
      },
      {
        text: 'Past Reports',
        svgPath: 'assets/svgs/clock_rewind_icon.svg',
        onclick: () => this.openPdmpPastReport(),
      },
      {
        text: 'Summary Report',
        svgPath: 'assets/svgs/bar_graph_trend_icon.svg',
        onclick: () => this.openPdmpSummaryReport(),
      },
    ];
  }

  sendInfo() {
    const dialogRef = this.dialog.open(SendInfoComponent, {
      data: {
        doctor: this.authService.user,
        patient: this.patient,
      },
    });

    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
    });
  }

  setBottlePanelData = (): void => {
    this.getPrescriptionsDataForBottlePanel$.subscribe(data => {
      if (data) {
        this.bottlePanelData = data;
      }
    });
  }

  setCurrentlyTakingPrescriptions = (): void => {
    this.prescriptionsCurrentlyTaking$
      .pipe(takeUntil(this.unsubscribeDialogs$))
      .subscribe(data => {
        if (data) {
          this.isTakingOrCompletedPrescriptions = data.isTakingOrCompleted;
          this.combinedCurrentlyTaking = data.combinedCurrTakingOrCompleted;
        }
      });
  }

  setDoctorsAndPharmacists = (): void => {
    this.store
      .pipe(select(doctorsFetched))
      .subscribe(fetched => {
        if (!fetched) {
          this.store.dispatch(getDoctorsAndPharmacists());
        }
      });
    this.store
      .select(selectDoctorsAndOrPharmacists)
      .subscribe(({ doctors, doctors_and_pharmacists }) => {
        this.doctors = doctors;
        this.doctors_and_pharmacists = doctors_and_pharmacists;
      });
  }

  syncPrescriptions() {
    this.store.dispatch(
      syncPrescriptions({ patientId: this.patientId, doctorId: this.doctorId })
    );
  }

  fetchUrines = (props): void => {
    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this.store.select(
      state => urinesFetchedByPatient(
        state, { patient_id: patient_id }
      )).subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(fetchUrineEntries({
            patientId: patient_id,
          }));
        }
        this.store
          .select(state => selectUrineEntries(state, {
            patient_id,
            doctor_id,
          }))
          .subscribe((data: any) => {
            if (data) {
              data = _.orderBy(data, "date", 'desc');
              this.urines = data;
            }
          });
      });
  }

  fetchDiversions = (props): void => {
    if (!props.patient_id || !props.doctor_id) {
      return;
    }
    const { patient_id, doctor_id } = props;
    this.store.select(
      state => diversionsFetchedByPatient(
        state, { patient_id: patient_id }
      )).subscribe(isFetched => {
        if (!isFetched) {
          this.store.dispatch(fetchDiversionEntries({
            patientId: patient_id,
          }));
        }
        this.store
          .select(state => selectDiversions(state, {
            patient_id,
            doctor_id,
          }))
          .subscribe((data: any) => {
            if (data) {
              data = _.orderBy(data, "date", 'desc');
              this.diversions = data;
            }
          });
      });
  }

  fetchScreenings = (props): void => {
    if (!props.patient_id) {
      return;
    }
    const { patient_id } = props;
    this.store.select(state => isPatientScreeningsFetched(state, {
      patient_id: patient_id
    })).subscribe(isFetched => {
      if (!isFetched) {
        this.store.dispatch(fetchScreenings({ patientId: this.patientId }));
      }
    });
  }

  setLastSync(): void {
    this.doctorService.getApprissReports({
      doctor_id: this.doctorId,
      patient_id: this.patientId,
    }).subscribe(reports=>{
        if(reports.body.createdAt){
          this.lastPDMPSync=reports.body.createdAt;
        }
    });
}
  ngOnInit() {
    this.setDoctorsAndPharmacists();
    this.pusherService.alertsSubscribe();
    this.alerts$ = this.store.select(selectAlerts);

    this.route.queryParams.subscribe(params => {
      const { patient_id } = params;

      this.patientId = parseInt(patient_id, 10);

      this.store.dispatch(getPrescriptions({ patient_id }));

      this.pusherService.subscribe(patient_id);
      this.store
        .select(selectContracts)
        .subscribe(contracts => {
          this.contract = contracts.find(
            contract =>
              contract.patient_id === this.patientId &&
              contract.doctor_id === this.authService.user.id
          );
        });
      this.patient$ = this.store.select(
        (state: Reducers.State) => state.patient.entities[patient_id]
      );
      this.role$ = this.store.select(selectRole);
      this.doctor$ = this.store.select(selectUser);

      this.patientPrescriptions$ = this.store.select(state =>
        getPatientPrescriptionsById(state, { patient_id: patient_id })
      );

      this.patientPrescriptions$.subscribe(prescriptions => {
        this.lastFivePrescriptions = _
          .takeRight(prescriptions, 5)
          .reverse();
      });

      this.doctor$.subscribe((user: any) => {
        this.doctorId = user.id;
        this.doctor = user;

        this.store.select(state => notesFetchedByPatient(state, { patient_id }))
          .subscribe(isFetched => {
            if (!isFetched) {
              this.store.dispatch(getNotesChecklistsCombined({ patient_id, doctor_id: this.doctorId }));
            }
          });
        this.fetchUrines({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        });
        this.fetchDiversions({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        });
      });
      this.patient$.subscribe(patient => (this.patient = patient));
    });
    
    this.setLastSync();

    this.store.select(state => formatNotesWithPreview(
      state,
      {
        patient_id: this.patientId,
        doctor_id: this.doctorId,
      }
    )).subscribe(notes => {
      this.notes = notes;
    });
    this.fetchScreenings({
      patient_id: this.patientId,
    });
    // this.setBottlePanelData();
    this.setCurrentlyTakingPrescriptions();
    this.chartMmes();
    this.renderReportButtons();

    const cache = this.patientLastVisitService.isPatientCached(this.patientId);

    if (cache[this.patientId]) {
      const isRecent = this.patientLastVisitService.isPatientVisitRecent(this.patientId);

      if (!isRecent) {
        this.store.dispatch(fetchUrineEntries({
          patientId: this.patientId,
        }));
        this.store.dispatch(fetchDiversionEntries({
          patientId: this.patientId,
        }));
        this.store.dispatch(fetchScreenings({ patientId: this.patientId }));
        this.store.dispatch(getPrescriptions({
          patient_id: this.patientId,
        }));
        this.store.dispatch(getNotesChecklistsCombined({
          patient_id: this.patientId,
          doctor_id: this.doctorId,
        }));
        this.patientLastVisitService.updatePatientTimeStamp(this.patientId);
      }
    }
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
  openStateReportCheckDialog() {
    const dialogRef = this.dialog.open(StateCheckDialogComponent);
    dialogRef.afterClosed().subscribe();
  }
}
