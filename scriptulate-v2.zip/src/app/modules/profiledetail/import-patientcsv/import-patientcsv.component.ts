import { Component, OnInit, Input, OnDestroy, ElementRef, ViewChild, AfterContentInit, Directive } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import {  HttpClient,  HttpEventType,  HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { map, catchError } from "rxjs/operators";
import { throwError, Observable } from "rxjs";
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { saveAs } from 'file-saver';
import * as Reducers from '@app/reducers/index';
import * as moment from 'moment';
import {
	getMyPatients,
	addPatientSuccess
  } from '@app/reducers/doctor/doctor.actions';
import { Store } from '@ngrx/store';
import { fetchAllPatient } from '@app/reducers/patient/patient.actions';
import { AuthService, PusherService } from '@app/core/services';
import { MatDialog } from '@angular/material';
import { AlertPopupComponent } from '@app/common/modules/shared/components/alert-popup/alert-popup.component';
@Component({
  selector: 'app-mydialog',
  templateUrl: './import-patientcsv.component.html',
  styleUrls: ['./import-patientcsv.component.scss'],
})
export class ImportPatientCsvComponent implements OnInit, OnDestroy {
	progress: boolean;
	files: any = [];
	hasError=false;
	me$: Observable<object>;
	doctor: any
	constructor(
		private activeModal: NgbActiveModal,
		private http: HttpClient,
		private store: Store<Reducers.State>,
		private authService: AuthService,
		private dialog: MatDialog,
		@ViewChild('errorBlock') 
		private elementRef:ElementRef
	) {
		this.me$ = store.select(state => state.auth.user);
	}


	closeModal = (): void=> {
		this.activeModal.dismiss();
		this.store.dispatch(fetchAllPatient());
		this.store.dispatch(getMyPatients({ doctorId: this.authService.user.id }));
	}
	uploadFile(event) {
		for (let index = 0; index < event.length; index++) {
		  const element = event[index];
		  if (element.type == 'text/csv'|| element.type=='application/vnd.ms-excel') {
			  this.files.push(element)
		  } else {
		  	console.log("error");
		  	return throwError("please upload csv file!");
		  }
		}  
	}

	upload() {
		let count=0;
		this.progress = true;
		for(let i = 0; i < this.files.length; i++){
		    const formData = new FormData();
		    formData.append("file", this.files[i]);
		    this.http
		      .post(RelativeUrlConfig.UPLOAD_PATIENT, formData).subscribe((response)=>{
				count++;
				if(count>=this.files.length){
					this.closeModal();
					this.dialog.open(AlertPopupComponent, {
						data: {
						  error: false,
						  message:{
							  title: 'File Upload Successfull'
						  } 
						}
					  });
				this.progress=false;
				}},
				(err: HttpErrorResponse) => {
					if(err.headers.get('Content-Type').search("text/csv")>=0){
						const blob = new Blob([err.error], { type: err.headers.get('Content-Type') });
						saveAs(blob, `error_${moment().toISOString()}.csv`);
					}
					this.progress = false;
					this.hasError=true;
					this.elementRef.nativeElement.parentElement.scrollIntoView();
					return throwError(err.message);
				});
		}
	}

	deleteAttachment(index) {
		this.files.splice(index, 1)
	}

	ngOnInit() {
	}

	ngOnDestroy() {

	}
}