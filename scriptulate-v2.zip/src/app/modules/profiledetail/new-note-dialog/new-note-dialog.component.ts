import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import * as Reducers from 'app/reducers';
import { addNote } from 'app/reducers/doctor/doctor.actions';
import { Note } from '@app/reducers/doctor/doctor.reducer';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-new-note-dialog',
  templateUrl: './new-note-dialog.component.html',
  styleUrls: [
    '../profiledetail.component.scss',
    '../../../../app/common/modules/styles/dialogs.scss',
    '../../../../app/common/modules/styles/shared.scss',
  ],
})
class NewNoteDialogComponent implements OnInit {
  @Input() data: any;
  patientId: any;
  doctorId: any;
  constructor(
    private store: Store<Reducers.State>,
    private activeModal: NgbActiveModal,
  ) {}

  noteForm: FormGroup = new FormGroup({
    subjectCtrl: new FormControl(),
    noteCtrl: new FormControl('', [
      Validators.required,
      Validators.minLength(1),
    ]),
  });

  closeDialog = (): void => this.activeModal.close();

  submit = (): void => {
    const body = this.noteForm.get('noteCtrl').value;
    const subject = this.noteForm.get('subjectCtrl').value;
    const params: Note = {
      body,
      subject: subject,
      category: 'note',
      patient_id: this.patientId,
      created_by_user_id: this.doctorId,
    };

    if (body.length) {
      this.store.dispatch(addNote(params));
      this.closeDialog();
    }
  }

  ngOnInit() {
    this.patientId = this.data.patientId;
    this.doctorId = this.data.doctorId;
  }
}

export { NewNoteDialogComponent };
