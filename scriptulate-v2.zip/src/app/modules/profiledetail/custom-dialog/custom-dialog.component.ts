import { Component, OnInit } from '@angular/core';
import { setDialogs } from '../../../core/config/setDialogs';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
	selector: 'app-custom-dialog',
	templateUrl: './custom-dialog.component.html',
	styleUrls: ['./custom-dialog.component.css']
})
export class CustomDialogComponent implements OnInit {
	isDischarge = setDialogs.isDischarge;
	isPrescription = setDialogs.isPrescription;
	isAddPatient = setDialogs.isAddPatient;
	isSetAppointment = setDialogs.isSetAppointment;
	isDiversion = setDialogs.isDiversion;
	isDrugInteraction = setDialogs.isDrugInteraction;
	isDrugInfo = setDialogs.isDrugInfo;
	isEditPatientProfile = setDialogs.isEditPatientProfile;
	isPillInfo = setDialogs.isPillInfo;
	isFillPrescription = setDialogs.isFillPrescription;
	isReportInfo = setDialogs.isReportInfo;
	isDetailedReport = setDialogs.isDetailedReport;
	isPastReport = setDialogs.isPastReport;
	constructor(public dialogRef: MatDialogRef<CustomDialogComponent>) {}

	ngOnInit() {}

	get onNoClick() {
		return this.dialogRef.close();
	}
}
