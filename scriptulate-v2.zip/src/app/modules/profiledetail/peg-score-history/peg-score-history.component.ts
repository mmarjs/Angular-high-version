import {
    defaultScaleLabel, defaultTicks
} from 'app/modules/profiledetail/peg-score-history/peg-score-history.model';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, Input, OnDestroy } from '@angular/core';
import { AppSession } from '@app/core/config/appSession';
import * as Reducers from '@app/reducers';
import { addApprissReport } from '@app/reducers/doctor/doctor.actions';
import { getScreeningsByIdAndType } from '@app/reducers/screening/screening.reducer';
import { Store } from '@ngrx/store';

import { PdfHelperService } from '../../../core/services/pdf-helper/pdf-helper.service';

@Component({
  selector: 'app-peg-score-history',
  templateUrl: './peg-score-history.component.html',
  styleUrls: [
    '../profiledetail.component.scss',
    '../../../../app/common/modules/styles/shared.scss',
    '../../../../app/common/modules/styles/dialogs.scss',
    './peg-score-history.component.scss',
  ],
  styles: [
    `
      :host {
        width: 100%;
        height: 72%;
        background: white;
        border-radius: 8px;
      }
    `,
  ],
})
export class PegScoreHistoryComponent implements OnDestroy {
  @Input() patientId: string | number;
  @Input() doctorId: number;
  painScreenings$: Observable<any>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  dateA: any;
  dateB: any;
  downloading: boolean = false;
  pegscreening: any;


  public lineChartData: ChartDataSets[] = [
    {
      data: [],
      label: 'Score',
      yAxisID: 'peg',
      steppedLine: false,
      borderWidth: 0,
      pointRadius: 10,
      //borderDash: [4, 4],
      fill: false,
    },
  ];
  public lineChartLabels: Label[] = [];
  public lineChartOptions: ChartOptions = {};
  public lineChartColors: Color[] = [
    {
      borderColor: 'hsl(297, 17%, 84%)',
      // backgroundColor: 'hsla(297, 17%, 84%, 0.3)',
      pointBorderColor: 'hsl(297, 17%, 44%)',
    },
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';
  public lineChartPlugins = [];

  constructor(private store: Store<Reducers.State>, private pdfHelperService: PdfHelperService) {
    this.painScreenings$ = this.store.select(state =>
      getScreeningsByIdAndType(state, {
        type: 'pain',
        patient_id: this.patientId,
        doctor_id: this.doctorId,
      })
    );
    this.painScreenings$
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(({ painScreenings }): void => {
        if (undefined !== painScreenings && painScreenings.length) {
          painScreenings = painScreenings.sort(function compare(a, b) {
            return new Date(a.date).getTime() - new Date(b.date).getTime();
          });
          this.lineChartData[0].data = painScreenings.reduce(
            (accum, screening) => {
              accum.push(screening['score']);
              return accum;
            },
            []
          );
          this.lineChartLabels = painScreenings.reduce((accum, screening) => {
            let newDate = new Date(screening['date']);
            accum.push(newDate);
            return accum;
          }, []);
          this.lineChartOptions = {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 16,
            scales: {
              yAxes: [
                {
                  id: 'peg',
                  scaleLabel: { ...defaultScaleLabel, fontSize: 10 },
                  ticks: {
                    fontSize: 10,
                    fontFamily: 'Montserrat',
                    min: 0,
                    max: 10,
                  },
                  position: 'left',
                  gridLines:
                  {
                    display: true,
                  }
                },
              ],
              xAxes: [
                {
                  scaleLabel: {
                    ...defaultScaleLabel,
                    labelString: 'time',
                    fontSize: 10,
                  },
                  ticks: {
                    ...defaultTicks,
                    source: 'labels',
                    min: new Date(painScreenings[0].date).getTime(),
                    max: new Date(painScreenings[painScreenings.length - 1].date).getTime(),
                    fontSize: 10,
                    fontFamily: 'Montserrat',
                  },
                  type: 'time',
                  distribution: 'series',

                  gridLines: {
                    drawBorder: false
                  },
                },
              ],
            },
            layout: {
              padding: {
                left: 8,
                right: 12,
                top: 20,
                bottom: 0,
              },
            },
            tooltips: {
              mode: 'label',
              callbacks: {
                label: function (tooltipItem) {
                  return `Score: ${tooltipItem.value}`;
                },
              },
            },
          };
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

  downloadPdfPEG() {
    this.downloading = true;
    setTimeout(() => (AppSession.loadingSpinner = true), 0);
    const data = document.getElementById('canvasChart');
    const fileName = `Scriptulate_PEGChart_${"graph"}_${new Date().getTime()}.pdf`;

    this.pdfHelperService.generatePdf(data, fileName).subscribe(
      pdf => {
        this.store.dispatch(addApprissReport({
          file_name: fileName,
          uploaded_by_user_id: this.doctorId,
          uploaded_for_user_id: +this.patientId,
          file_category: 'peg_score',
          file_type: 'application/pdf',
          file: pdf.output('blob'),
        }));
        this.downloading = false;
      },
      (() => {
        setTimeout(() => (AppSession.loadingSpinner = false), 0);
        this.downloading = false;
      }));
  }
}
