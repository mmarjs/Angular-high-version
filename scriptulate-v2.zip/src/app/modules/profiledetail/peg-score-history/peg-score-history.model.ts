import { ScaleTitleOptions, TickOptions, TimeDisplayFormat } from 'chart.js';
import { Color } from 'ng2-charts';

export const theme = {
  lightPurple: 'hsla(297, 17%, 84%, 0.7)',
  darkPurple: 'hsl(297, 17%, 44%)',
  lightBlue: 'hsla(213, 42%, 71%, 0.7)',
  darkBlue: 'hsl(213, 42%, 31%)',
};

export const defaultLineChartColors: Color = {
  borderColor: theme.lightPurple,
  backgroundColor: theme.lightPurple,
  pointBackgroundColor: theme.lightPurple,
  pointBorderColor: theme.darkPurple,
  pointHitRadius: 5,
  pointBorderWidth: 5,
  pointHoverBorderWidth: 10,
};

export const defaultScaleLabel: ScaleTitleOptions = {
  display: true,
  labelString: 'PEG Score',
  fontSize: 24,
  fontColor: 'hsl(297, 17%, 44%)',
};

export const defaultTicks: TickOptions = {
  fontSize: 12,
  fontFamily: 'Montserrat',
  min: 0,
};

export const defaultDisplayFormats: TimeDisplayFormat = {
  month: 'DD MMM YYYY',
  second: 'DD MMM YYYY',
  hour: 'DD MMM YYYY',
  millisecond: 'DD MMM YYYY',
  minute: 'DD MMM YYYY',
  quarter: 'DD MMM YYYY',
  year: 'DD MMM YYYY',
  day: 'MMM DD, YYYY',
};
