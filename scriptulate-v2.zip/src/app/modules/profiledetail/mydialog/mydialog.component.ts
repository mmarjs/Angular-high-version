import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { MyDialogService } from './mydialog.service';
import { Doctor } from '@app/reducers/doctor/doctor.reducer';
import { Patient } from '@app/reducers/patient/patient.reducer';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import * as Reducers from '@app/reducers/index';
import { validateAllFormFields, setNgbStructAsMomentObj } from '@app/helpers';
import { NgbActiveModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NewPatientProfileComponent } from '../new-patientprofile/new-patientprofile.component';
import { ngbDateValidator } from 'app/shared/validators/ngb-date.validator';
import { Store, select } from '@ngrx/store';
import { takeUntil } from 'rxjs/operators';
import * as PatientActions from '../../../reducers/patient/patient.actions';
import { ImportPatientCsvComponent } from '../import-patientcsv/import-patientcsv.component';
@Component({
  selector: 'app-mydialog',
  templateUrl: './mydialog.component.html',
  styleUrls: ['./mydialog.component.scss'],
})
export class MydialogComponent implements OnInit, OnDestroy {
  @Input() data: any;
  doctor$: Observable<Doctor>;
  patients$: Observable<Array<Patient>>;
  unsubscribe$: Subject<Boolean> = new Subject<Boolean>();
  patientSearchForm: FormGroup;
  minimumDate: NgbDateStruct;
  maximumDate: NgbDateStruct;
  dateMask = [
    /[1-9]/,
    /\d/,
		/\d/,
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
		'-',
		/\d/,
		/\d/,
	];

  states = [
    {name: 'AL'},
    {name: 'AK'},
    {name: 'AS'},
    {name: 'AZ'},
    {name: 'AR'},
    {name: 'CA'},
    {name: 'CO'},
    {name: 'CT'},
    {name: 'DE'},
    {name: 'DC'},
    {name: 'FM'},
    {name: 'FL'},
    {name: 'GA'},
    {name: 'GU'},
    {name: 'HI'},
    {name: 'ID'},
    {name: 'IL'},
    {name: 'IN'},
    {name: 'IA'},
    {name: 'KS'},
    {name: 'KY'},
    {name: 'LA'},
    {name: 'ME'},
    {name: 'MH'},
    {name: 'MD'},
    {name: 'MA'},
    {name: 'MI'},
    {name: 'MN'},
    {name: 'MS'},
    {name: 'MO'},
    {name: 'MT'},
    {name: 'NE'},
    {name: 'NV'},
    {name: 'NH'},
    {name: 'NJ'},
    {name: 'NM'},
    {name: 'NY'},
    {name: 'NC'},
    {name: 'ND'},
    {name: 'MP'},
    {name: 'OH'},
    {name: 'OK'},
    {name: 'OR'},
    {name: 'PW'},
    {name: 'PA'},
    {name: 'PR'},
    {name: 'RI'},
    {name: 'SC'},
    {name: 'SD'},
    {name: 'TN'},
    {name: 'TX'},
    {name: 'UT'},
    {name: 'VT'},
    {name: 'VI'},
    {name: 'VA'},
    {name: 'WA'},
    {name: 'WV'},
    {name: 'WI'},
    {name: 'WY'},
  ]

  constructor(
    private router: Router,
    public myDialogService: MyDialogService,
    private formBuilder: FormBuilder,
    private activeModal: NgbActiveModal,
    private store: Store<Reducers.State>,
    public modal: NgbModal,
  ) {}

  onSubmitSearch = () => {
      if (this.patientSearchForm.valid) {
        let dateOfBirth = null;
        const { last_name,first_name, birthdate } = this.patientSearchForm.value;
        dateOfBirth = birthdate.toISOString();
        this.data.patientSearchOnChange({
          first_name,
          last_name,
          birthdate: dateOfBirth,
        });
        return;
      }
      validateAllFormFields(this.patientSearchForm);
  }

  addPatient = (doctorId, patientId) => {
    this.data.addPatient(doctorId, patientId);
    this.closeModal();
  }

  closeModal = () => {
    this.store.dispatch(PatientActions.searchPatientSuccess({payload:[]}));
    this.activeModal.dismiss();
  }

  getLastSSN = (ssn_str: string) => {
    if (!ssn_str) {
      return '';
    }

    const tmp = ssn_str.split('-');
    if (tmp.length) {
      return tmp[tmp.length - 1];
    }
    return ssn_str;
  }

  createPatientProfile = () => {
    this.router.navigate(['createpatientprofile']);
  }

  setMaxAndMinimumDates = (): void => {
    this.minimumDate = {
      year: 1800,
      month: 1,
      day: 1,
    };
    this.maximumDate = {
      year: new Date().getFullYear(),
      month: 12,
      day: 31,
    };
  }

  openNewPatientProfileDialog = (): void => {
    const mydialogRef = this.modal.open(
      NewPatientProfileComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }

  openImportPatientCsvDialog = (): void => {
    const mydialogRef = this.modal.open(
      ImportPatientCsvComponent,
      {
        windowClass: 'ngb-modal-size-94rem',
      }
    );

    mydialogRef.result.then(_res => {}).catch(_err => {});
  }

  ngOnInit() {
    this.setMaxAndMinimumDates();
    this.doctor$ = this.data.doctor;
    this.patients$ = this.store.pipe(
      takeUntil(this.unsubscribe$),
      select(state => state.patient.searchResults),
    );

    this.patientSearchForm = this.formBuilder.group({
      first_name: [
        '',
        [
          Validators.required, Validators.pattern('^[a-zA-Z\- ]+$'),
          Validators.minLength(2),
        ],
      ],
      last_name: [
        '',
        [
          Validators.required, Validators.pattern('^[a-zA-Z\- ]+$'),
          Validators.minLength(2),
        ],
      ],
      birthdate: [
        null,
        [
          Validators.required,
          ngbDateValidator,
        ],
      ],
    });
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
