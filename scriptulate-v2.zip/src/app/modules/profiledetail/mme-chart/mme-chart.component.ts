import { Component, Input, OnChanges } from '@angular/core';
import { ChartOptions, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { Prescription } from '@app/reducers/prescription/prescription.reducer';
import * as moment from 'moment';
import { toDateSlashes } from '@app/helpers';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-mme-chart',
  templateUrl: './mme-chart.component.html',
  styleUrls: ['./mme-chart.component.scss'],
})
export class MmeChartComponent implements OnChanges {
  @Input() datasets: Array<any>;
  public chartLabels: Label[];
  public chartOptions: ChartOptions;
  public chartColors: Color[];
  public chartLegend = false;
  public chartType = 'line';
  public chartPlugins = [];
  public chartDatasets: ChartDataSets[];
  mmeChartForm: FormGroup = new FormGroup({
    startAtDate: new FormControl(),
    endAtDate: new FormControl(),
  });
  constructor() {
    this.chartColors = [
      {
        borderColor: 'hsl(297, 17%, 84%)',
        backgroundColor: 'hsla(297, 17%, 84%, 0.3)',
        pointBorderColor: 'hsl(297, 17%, 44%)',
      },
    ];
    this.chartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 16,
      scales: {
        yAxes: [
          {
            id: 'mme',
            scaleLabel: {
              display: true,
              labelString: 'MME',
              fontSize: 11,
              fontColor: 'hsl(297, 17%, 44%)',
            },
            ticks: {
              fontSize: 11,
              fontFamily: 'Montserrat',
              min: 0,
            },
            position: 'left',
            gridLines: { borderDash: [4, 4], color: '#EEEEEE' },
          },
        ],
        xAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: 'Time',
              fontSize: 11,
              fontColor: 'hsl(297, 17%, 44%)',
            },
            ticks: {
              fontSize: 11,
              fontFamily: 'Montserrat',
              source: 'labels',
              minRotation: 90,
              maxRotation: 90,
              autoSkip: true,
            },
            gridLines: { display: false },
          },
        ],
      },
      layout: {
        padding: {
          left: 8,
          right: 12,
          top: 20,
          bottom: 0,
        },
      },
      tooltips: {
        mode: 'label',
        callbacks: {
          label: tooltipItem => `Total MME: ${tooltipItem.value}`,
        },
      },
    };

    this.chartDatasets = [
      {
        data: [],
        label: 'MME',
        // lineTension: 1,
        borderWidth: 1,
        pointStyle: 'circle',
        pointRadius: 1,
        yAxisID: 'mme',
        steppedLine: true,
      },
    ];
  }

  setUpData = yearOrNumOfMonths => {
    const chartData = [];
    const currentDate = new Date();
    const previousMonths = [];
    const newData = [];
    this.chartLabels = [];

    this.datasets.forEach((prescription): void => {
      newData.push(prescription);
    });

    if (!yearOrNumOfMonths) {
      newData.forEach(({ total_mme, date }): void => {
        chartData.push(total_mme);
        this.chartLabels.push(toDateSlashes(date));
      });
      this.chartDatasets[0].data = chartData;
      return;
    }

    if (typeof yearOrNumOfMonths === 'number') {
      for (let i = 0; i < yearOrNumOfMonths; i++) {
        const month = moment(currentDate)
          .subtract(i, 'months')
          .endOf('month')
          .format('MM/YYYY');
        previousMonths.push(month);
      }
    }

    let prescription = null as Prescription;
    let date = null;
    const matchedToPreviousMonths = (
      numberOfMonths: number,
      prescription: Prescription,
    ) => {
      if (!numberOfMonths) {
        chartData.push(prescription.total_mme);
        this.chartLabels.push(toDateSlashes(prescription.date));
        return;
      }
      const formattedDate = prescription.date.format('MM/YYYY');
      for (let m = 0; m < numberOfMonths; m++) {
        if (!previousMonths[m]) {
          break;
        }
        if (formattedDate === previousMonths[m]) {
          chartData.push(prescription.total_mme);
          this.chartLabels.push(toDateSlashes(prescription.date));
        }
      }
    };

    for (let i = 0; i < newData.length; i++) {
      prescription = newData[i];
      date = prescription.date;

      if (yearOrNumOfMonths === 'current') {
        if (date.format('YYYY') === moment(currentDate).format('YYYY')) {
          matchedToPreviousMonths(null, prescription);
        }
      }
      if (typeof yearOrNumOfMonths === 'string') {
        if (date.format('YYYY') === yearOrNumOfMonths) {
          matchedToPreviousMonths(null, prescription);
        }
      }
      if (yearOrNumOfMonths === 3) {
        matchedToPreviousMonths(3, prescription);
      }
      if (yearOrNumOfMonths === 6) {
        matchedToPreviousMonths(6, prescription);
      }
      if (yearOrNumOfMonths === 12) {
        matchedToPreviousMonths(12, prescription);
      }
    }

    this.chartDatasets[0].data = chartData;
  }

  setMmeDateRange = (startAtDate: string, endAtDate: string) => {
    const chartData = [];
    const chartLabels = [];
    const newData = [];
    let startAtIndex: number;
    let endAtIndex: number;
    this.datasets.forEach((prescription): void => {
      const { date, total_mme } = prescription;
      newData.push(prescription);
      chartData.push(total_mme, total_mme);
      chartLabels.push(toDateSlashes(date), toDateSlashes(date));
    });

    if (!startAtDate && !endAtDate) {
      this.chartDatasets[0].data = chartData;
      this.chartLabels = chartLabels;
      return;
    }

    if (startAtDate && endAtDate) {
      startAtIndex = newData
        .map(({ date }) => toDateSlashes(date))
        .indexOf(startAtDate);
      endAtIndex = newData
        .map(({ date }) => toDateSlashes(date))
        .lastIndexOf(endAtDate);
      this.chartDatasets[0].data = chartData.slice(startAtIndex, endAtIndex);
      this.chartLabels = chartLabels.slice(startAtIndex, endAtIndex);
      return;
    }

    if (startAtDate) {
      startAtIndex = newData
        .map(({ date }) => toDateSlashes(date))
        .indexOf(startAtDate);
      this.chartDatasets[0].data = chartData.slice(startAtIndex);
      this.chartLabels = chartLabels.slice(startAtIndex);
      return;
    }

    if (endAtDate) {
      endAtIndex = newData
        .map(({ date }) => toDateSlashes(date))
        .lastIndexOf(endAtDate);

      this.chartDatasets[0].data = chartData.slice(0, endAtIndex);
      this.chartLabels = chartLabels.slice(0, endAtIndex);
      return;
    }
  }

  ngOnChanges(changes) {
    if (changes.datasets) {
      const { currentValue } = changes.datasets;
      if (currentValue.length) {
        this.setUpData(null);
      }
    }
  }
}
