import { Overlay, ScrollStrategy } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatCheckboxModule, MatFormFieldModule, MatIconModule, MatInputModule, MatProgressSpinnerModule,
    MatSortModule, MatTableModule, MatTabsModule
} from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { MAT_MENU_SCROLL_STRATEGY, MatMenuModule } from '@angular/material/menu';

import { AddNoteModalComponent } from './components/add-note-modal/add-note-modal.component';
import { PdmpButtonComponent } from './components/pdmp-button/pdmp-button.component';
import {
    PdmpCombinedReportComponent
} from './components/pdmp-combined-report/pdmp-combined-report.component';
import { PdmpPharmaciesComponent } from './components/pdmp-pharmacies/pdmp-pharmacies.component';
import { PdmpPrescribersComponent } from './components/pdmp-prescribers/pdmp-prescribers.component';
import {
    PdmpPrescriptionsComponent
} from './components/pdmp-prescriptions/pdmp-prescriptions.component';
import { PdmpSidePanelComponent } from './components/pdmp-side-panel/pdmp-side-panel.component';
import {
    PdmpDrugHistoryGraphComponent
} from './components/pdmp-summary/pdmp-drug-history-graph/pdmp-drug-history-graph.component';
import {
    PdmpDrugTypesGraphComponent
} from './components/pdmp-summary/pdmp-drug-types-graph/pdmp-drug-types-graph.component';
import {
    PdmpFullPageGraphComponent
} from './components/pdmp-summary/pdmp-full-page-graph/pdmp-full-page-graph.component';
import {
    PdmpMmeLmeGraphComponent
} from './components/pdmp-summary/pdmp-mme-lme-graph/pdmp-mme-lme-graph.component';
import {
    PdmpPharmsNumberGraphComponent
} from './components/pdmp-summary/pdmp-pharms-number-graph/pdmp-pharms-number-graph.component';
import {
    PdmpRxNumberGraphComponent
} from './components/pdmp-summary/pdmp-rx-number-graph/pdmp-rx-number-graph.component';
import { PdmpSummaryComponent } from './components/pdmp-summary/pdmp-summary.component';
import { PdmpTableComponent } from './components/pdmp-table/pdmp-table.component';
import { PdmpReportDashboardRoutingModule } from './pdmp-report-dashboard-routing.module';
import { PdmpReportDashboardComponent } from './pdmp-report-dashboard.component';
import { SharedModule } from 'app/common/modules/shared/shared.module';

export function MAT_MENU_SCROLL_STRATEGY_FACTORY(overlay: Overlay): () => ScrollStrategy {
    return (): ScrollStrategy => overlay.scrollStrategies.block();
}

@NgModule({
    imports: [
        CommonModule,
        PdmpReportDashboardRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        MatTableModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatTabsModule,
        MatIconModule,
        MatMenuModule,
        MatListModule,
        MatFormFieldModule,
        MatInputModule,
        MatDialogModule,
        MatSortModule,
        SharedModule
    ],
    exports: [PdmpButtonComponent],
    declarations: [
        PdmpReportDashboardComponent,
        PdmpPrescriptionsComponent,
        PdmpSummaryComponent,
        PdmpPharmaciesComponent,
        PdmpCombinedReportComponent,
        PdmpButtonComponent,
        PdmpTableComponent,
        PdmpPrescribersComponent,
        PdmpSidePanelComponent,
        AddNoteModalComponent,
        PdmpMmeLmeGraphComponent,
        PdmpRxNumberGraphComponent,
        PdmpPharmsNumberGraphComponent,
        PdmpFullPageGraphComponent,
        PdmpDrugTypesGraphComponent,
        PdmpDrugHistoryGraphComponent
    ],
    entryComponents: [
        AddNoteModalComponent,
        PdmpFullPageGraphComponent,
    ],
    providers: [{ provide: MAT_MENU_SCROLL_STRATEGY, deps: [Overlay], useFactory: MAT_MENU_SCROLL_STRATEGY_FACTORY }],
})
export class PdmpReportDashboardModule { }
