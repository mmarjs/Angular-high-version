import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';

import { SelectionChange, SelectionModel } from '@angular/cdk/collections';
import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatSnackBar, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';

import { PdfHelperService } from '../../core/services/pdf-helper/pdf-helper.service';
import { PdmpHelperService } from '../../core/services/pdmp-helper/pdmp-helper.service';
import { addApprissReport, syncPrescriptions } from '../../reducers/doctor/doctor.actions';
import { DoctorService } from '../dashboard/doctor.service';
import { HeaderPatient } from './models/header-patient.model';
import { DosageDetail, PdmpPatient } from './models/pdmp-patient.model';

@Component({
    selector: 'app-pdmp-report-dashboard',
    templateUrl: 'pdmp-report-dashboard.component.html',
    styleUrls: ['pdmp-report-dashboard.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class PdmpReportDashboardComponent implements OnInit, OnDestroy {
    headerPatient: HeaderPatient;
    doctorId: number;
    displayedColumns: string[] = ['selected', 'id', 'name', 'dob', 'address'];
    dataSource: MatTableDataSource<PdmpPatient>;
    selection: SelectionModel<PdmpPatient>;
    currentDate: Date = new Date();
    navLinks: any = [
        { location: './combined-report', label: 'Combined Report' },
        { location: './summary', label: 'Summary' },
        { location: './prescriptions', label: 'Prescriptions' },
        { location: './prescribers', label: 'Prescribers' },
        { location: './pharmacies', label: 'Pharmacies' }
    ];
    activeLink: string;
    saveInProgress: boolean;
    downloadInProgress: boolean;
    destroySubject: Subject<void> = new Subject();

    constructor(private pdmpHelperService: PdmpHelperService,
        private pdfHelperService: PdfHelperService,
        private doctorService: DoctorService,
        private snackBar: MatSnackBar,
        private router: Router,
        private store: Store<Reducers.State>) {
        this.pdmpHelperService.navigationState = this.router.getCurrentNavigation().extras.state;
    }

    ngOnInit() {
        this.headerPatient = this.pdmpHelperService.navigationState.patient;
        this.doctorId = this.pdmpHelperService.navigationState.doctorId;

        this.setLastSync();

        this.dataSource = new MatTableDataSource<PdmpPatient>([]);
        this.selection = new SelectionModel<PdmpPatient>(true, []);

        this.pdmpHelperService.getPdmpPatientData(this.headerPatient.id).subscribe(
            (pdmpPatients: PdmpPatient[]) => {
                this.dataSource.data = pdmpPatients;
                this.selection.select(...pdmpPatients);
            },
            () => {
                this.snackBar.open('Failed to load patient data.', null, {
                    verticalPosition: 'bottom',
                    horizontalPosition: 'end'
                });
            });

        this.selection.changed.pipe(takeUntil(this.destroySubject), debounceTime(500))
            .subscribe((selectionChange: SelectionChange<PdmpPatient>) => {
                this.pdmpHelperService.selectedPatients$.next(selectionChange.source.selected);
            });

        this.pdmpHelperService.selectedPatients$.pipe(takeUntil(this.destroySubject)).subscribe(
            (pdmpPatients: PdmpPatient[]) => {
                if (pdmpPatients) {
                    this.pdmpHelperService.getDosageDetails(this.headerPatient.id, pdmpPatients)
                        .subscribe(
                            (dosageDetails: DosageDetail[]) => {
                                this.pdmpHelperService.dosageDetails$.next(dosageDetails);
                            },
                            () => {
                                this.snackBar.open('Failed to load graph data.', null, {
                                    verticalPosition: 'bottom',
                                    horizontalPosition: 'end'
                                });
                            });
                }
            });
    }

    ngOnDestroy(): void {
        this.destroySubject.next();
        this.pdmpHelperService.selectedPatients$.next(undefined);
    }

    back(): void {
        this.router.navigateByUrl(this.pdmpHelperService.navigationState.url);
    }

    setLastSync(): void {
        this.doctorService.getApprissReports({ doctor_id: this.doctorId, patient_id: this.headerPatient.id }).subscribe(report => {
            this.headerPatient.lastPDMPSync = report.body && report.body.createdAt ?
                report.body.createdAt : 'NA';
        });
    }

    sync(): void {
        this.store.dispatch(
            syncPrescriptions({ patientId: this.headerPatient.id, doctorId: this.doctorId })
        );
    }

    save(): void {
        this.saveInProgress = true;

        this.doctorService.getApprissReports({ doctor_id: this.doctorId, patient_id: this.headerPatient.id }).subscribe(report => {
            if (report.body) {
                this.pdmpHelperService.savePdf(report.body.file_location, this.doctorId, this.headerPatient.id,
                    `${this.headerPatient.first_name}_${this.headerPatient.last_name}`)
                    .subscribe(() => this.saveInProgress = false);
            } else {
                this.saveInProgress = false;
            }
        });
    }

    download(): void {
        this.downloadInProgress = true;
        const fileName = `Scriptulate_PDMPReport_${new Date().getTime()}.pdf`;

        this.pdfHelperService.generatePdf(document.body, fileName).subscribe(pdf => {
            this.store.dispatch(addApprissReport({
                file_name: fileName,
                uploaded_by_user_id: this.doctorId,
                uploaded_for_user_id: + this.headerPatient.id,
                file_category: 'pdmp_report',
                file_type: 'application/pdf',
                file: pdf.output('blob'),
            }));

            this.downloadInProgress = false;
        }, (() => this.downloadInProgress = false));
    }

    isAllSelected(): boolean {
        const numSelected: number = this.selection.selected.length;
        const numRows: number = this.dataSource.data.length;

        return numSelected === numRows;
    }

    masterToggle(): void {
        this.isAllSelected() ?
            this.selection.clear() :
            this.dataSource.data.forEach((row: any) => this.selection.select(row));
    }
}
