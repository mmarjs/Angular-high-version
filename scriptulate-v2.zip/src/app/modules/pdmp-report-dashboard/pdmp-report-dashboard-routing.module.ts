import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {
    PdmpCombinedReportComponent
} from './components/pdmp-combined-report/pdmp-combined-report.component';
import { PdmpPharmaciesComponent } from './components/pdmp-pharmacies/pdmp-pharmacies.component';
import { PdmpPrescribersComponent } from './components/pdmp-prescribers/pdmp-prescribers.component';
import {
    PdmpPrescriptionsComponent
} from './components/pdmp-prescriptions/pdmp-prescriptions.component';
import { PdmpSummaryComponent } from './components/pdmp-summary/pdmp-summary.component';
import { PdmpReportDashboardComponent } from './pdmp-report-dashboard.component';

const routes: Routes = [
    {
        path: '',
        component: PdmpReportDashboardComponent,
        children: [
            {
                path: '',
                redirectTo: 'combined-report',
                pathMatch: 'full'
            },
            {
                path: 'prescriptions',
                data: {
                    breadcrumb: 'Prescriptions'
                },
                component: PdmpPrescriptionsComponent
            },
            {
                path: 'prescribers',
                data: {
                    breadcrumb: 'Prescribers'
                },
                component: PdmpPrescribersComponent
            },
            {
                path: 'pharmacies',
                data: {
                    breadcrumb: 'Pharmacies'
                },
                component: PdmpPharmaciesComponent
            },
            {
                path: 'combined-report',
                data: {
                    breadcrumb: 'Combined Report'
                },
                component: PdmpCombinedReportComponent
            },
            {
                path: 'summary',
                data: {
                    breadcrumb: 'Summary'
                },
                component: PdmpSummaryComponent
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PdmpReportDashboardRoutingModule { }
