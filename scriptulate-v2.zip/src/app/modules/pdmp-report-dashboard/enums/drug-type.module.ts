export enum DrugType {
    Narcotic = 'narcotic',
    Sedative = 'sedative',
    Stimulant = 'stimulant',
    Buprenorphine = 'buprenorphine'
}