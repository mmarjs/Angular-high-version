export interface Prescription {
    patientId: number;
    patientDob: string;
    fillDate: string;
    written?: string;
    drugName: string;
    dosage: string;
    qty: number;
    days: number;
    pillsDay: number;
    dailyDosage: string;
    drugClass: string;
    prescriberName: string;
    prescriberContact: string;
    prescriberDeaState: string;
    pharmacyName: string;
    pharmacyCity: string;
    pharmacyContact: string;
    refill: number;
    paymentType: string;
    pmpState: string;
    rx: string;
}
