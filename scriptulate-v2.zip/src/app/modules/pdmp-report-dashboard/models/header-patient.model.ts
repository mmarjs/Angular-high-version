export interface HeaderPatient {
    first_name: string;
    last_name: string;
    age: number;
    gender: 'M' | 'F';
    birthdate: Date;
    address_city: string;
    address_line: string;
    address_line2: string;
    address_state: string;
    address_zip: string;
    id: number;
    provider: string;
    lastPDMPSync: string | Date;
    createdAt: Date;
}
