export interface Pharmacy {
    name: string;
    city: string;
    contactInfo: string;
    narcoticsRx?: number;
    sedativeRx?: number;
    stimulantRx?: number;
    buprenorphineRx?: number;
    otherRx?: number;
    lastRxDate?: Date;
}
