
export interface Column {
    value: string;
    name: string;
    disabled?: boolean;
    default?: boolean;
    allowFilter?: boolean;
    allowSort?: boolean;
}
