import * as moment from 'moment';

export interface LinearGraphDataPoint {
  label: moment.Moment;
  mmeData: number;
  lmeData: number;
  rxNumber: number;
  pharmsNumber: number;
  narcoticsNumber?: number;
  sedativesNumber?: number;
  stimulantNumber?: number;
  buprenorphineNumber?: number;
  othersNumber?: number;
}

export interface DrugHistory {
  name: string;
  dataPoints: DrugHistoryDataPoint[];
}

export interface DrugHistoryDataPoint {
  label: moment.Moment;
  value: number | undefined;
}
