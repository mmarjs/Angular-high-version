import { fromEvent, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, ElementRef, Input, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { MatDialog } from '@angular/material';

import { Note } from '../../../../reducers/doctor/doctor.reducer';
import { AddNoteModalComponent } from '../add-note-modal/add-note-modal.component';

@Component({
  selector: 'app-pdmp-side-panel',
  templateUrl: './pdmp-side-panel.component.html',
  styleUrls: ['./pdmp-side-panel.component.scss']
})
export class PdmpSidePanelComponent implements OnInit, OnDestroy {
  @Input() patientId: number;
  @Input() doctorId: number;
  destroySubject: Subject<void> = new Subject();
  notes: Note[] = [];

  constructor(
    private renderer2: Renderer2,
    private el: ElementRef,
    private matDialog: MatDialog) { }

  ngOnInit() {
    fromEvent(document, 'click').pipe(takeUntil(this.destroySubject)).subscribe((event: any) => {
      const isClickInside = this.el.nativeElement.contains(event.target);
      const isClickOnButton = this.isClickOnElement('app-pdmp-report-dashboard .notes-button', event);
      const isClickOnModal = this.isClickOnElement('app-add-note-modal', event);

      if (!isClickInside && !isClickOnButton && !isClickOnModal) {
        this.close();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroySubject.next();
  }

  open(): void {
    this.setHeight();
    this.renderer2.addClass(this.el.nativeElement, 'expanded');
  }

  close(): void {
    this.setHeight();
    this.renderer2.removeClass(this.el.nativeElement, 'expanded');
  }

  setHeight(): void {
    const dashboard = document.querySelector('app-pdmp-report-dashboard');
    const dashboardHeight = dashboard ? dashboard.getBoundingClientRect().height : 0;

    const title = document.querySelector('app-pdmp-report-dashboard .title');
    const titleHeight = title ? title.getBoundingClientRect().height : 0;

    const header = document.querySelector('app-pdmp-report-dashboard .header');
    const headerHeight = header ? header.getBoundingClientRect().height : 0;

    const navbar = document.querySelector('app-pdmp-report-dashboard .mat-tab-nav-bar');
    const navbarHeight = navbar ? navbar.getBoundingClientRect().height : 0;

    const height = dashboardHeight - titleHeight - headerHeight - navbarHeight;
    this.renderer2.setStyle(this.el.nativeElement, 'height', `${height}px`);
  }

  add(): void {
    const dialog = this.matDialog.open(AddNoteModalComponent, {
      data: {
        patientId: this.patientId,
        doctorId: this.doctorId
      },
      panelClass: 'pdmp-modal'
    });

    dialog.afterClosed().subscribe((newNote => {
      if (newNote) {
        this.notes.push(newNote);
      }
    }));
  }

  isClickOnElement(selector: string, event: any): boolean {
    let isClickOnElement = false;

    const element = document.querySelector(selector);
    if (element) {
      isClickOnElement = element.contains(event.target);
    }

    return isClickOnElement;
  }
}
