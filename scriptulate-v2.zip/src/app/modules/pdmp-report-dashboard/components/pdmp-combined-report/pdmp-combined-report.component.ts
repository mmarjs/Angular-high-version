import { Component, HostBinding } from '@angular/core';

@Component({
  selector: 'app-pdmp-combined-report',
  templateUrl: './pdmp-combined-report.component.html',
  styleUrls: ['./pdmp-combined-report.component.scss']
})
export class PdmpCombinedReportComponent {
  @HostBinding('class') class = 'tab-wrapper';
}
