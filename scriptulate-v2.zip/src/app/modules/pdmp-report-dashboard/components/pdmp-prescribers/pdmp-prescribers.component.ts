import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';

import { PdmpHelperService } from '../../../../core/services/pdmp-helper/pdmp-helper.service';
import { DrugDetail, PdmpPatient } from '../../models/pdmp-patient.model';
import { Prescriber } from '../../models/prescriber.model';
import { Column } from '../../models/table-column.model';

@Component({
  selector: 'app-pdmp-prescribers',
  templateUrl: './pdmp-prescribers.component.html',
  styleUrls: ['./pdmp-prescribers.component.scss']
})
export class PdmpPrescribersComponent implements OnInit, OnDestroy {
  @HostBinding('class') class = 'tab-wrapper';
  columns: Column[] = [
    { name: 'Prescriber Name', value: 'name', default: true, allowFilter: true, allowSort: true },
    { name: 'Prescriber DEA City', value: 'deaCity', default: true, allowFilter: true, allowSort: true },
    { name: 'Clinic Name', value: 'clinicName', default: true, allowFilter: true, allowSort: true },
    { name: 'Contact Info', value: 'contactInfo', default: true },
    { name: 'Narcotics Rx', value: 'narcoticsRx', default: true, allowFilter: true, allowSort: true },
    { name: 'Sedative Rx', value: 'sedativeRx', default: true, allowFilter: true, allowSort: true },
    { name: 'Stimulant Rx', value: 'stimulantRx', default: true, allowFilter: true, allowSort: true },
    { name: 'Buprenorphine Rx', value: 'buprenorphineRx', default: true, allowFilter: true, allowSort: true },
    { name: 'Other Rx', value: 'otherRx', default: true, allowFilter: true, allowSort: true },
    { name: 'Last Rx Date', value: 'lastRxDate', default: true, allowSort: true },
  ];
  prescribers: Prescriber[];
  destroySubject: Subject<void> = new Subject();

  constructor(private pdmpHelperService: PdmpHelperService) { }

  ngOnInit() {
    this.pdmpHelperService.selectedPatients$.pipe(takeUntil(this.destroySubject)).subscribe((pdmpPatients: PdmpPatient[]) => {
      if (pdmpPatients) {
        const groupedPrescribers: DrugDetail[][] = this.pdmpHelperService.groupBy(
          [].concat.apply([], pdmpPatients.map((p: PdmpPatient) => p.drugDetails)), 'prescriberName');

        const prescribers: Prescriber[] = [];

        groupedPrescribers.forEach((gp: DrugDetail[]) => {
          const prescriber: Prescriber = {
            name: gp[0].prescriberName,
            deaCity: gp[0].prescriberAddress.city,
            clinicName: gp[0].prescriberClinic,
            contactInfo: `${gp[0].prescriberAddress.line},
            ${gp[0].prescriberAddress.city}, ${gp[0].prescriberAddress.state}, ${gp[0].prescriberAddress.postalCode}`
          };

          this.pdmpHelperService.setDrugTypeRx(prescriber, gp);

          prescribers.push(prescriber);
        });

        this.prescribers = prescribers;
      } else {
        this.prescribers = [];
      }
    });
  }

  ngOnDestroy() {
    this.destroySubject.next();
  }
}
