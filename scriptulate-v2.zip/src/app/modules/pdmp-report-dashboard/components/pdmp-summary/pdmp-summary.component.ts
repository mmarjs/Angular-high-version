import * as Chart from 'chart.js';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

import {
    PdmpGraphHelperService
} from '../../../../core/services/pdmp-helper/pdmp-graph-helper.service';
import { PdmpHelperService } from '../../../../core/services/pdmp-helper/pdmp-helper.service';
import { DrugType } from '../../enums/drug-type.module';
import { DrugHistory, LinearGraphDataPoint } from '../../models/pdmp-graphs.model';
import { DosageDetail, Drug, DrugDetail, PdmpPatient } from '../../models/pdmp-patient.model';
import { PdmpFullPageGraphComponent } from './pdmp-full-page-graph/pdmp-full-page-graph.component';

@Component({
  selector: 'app-pdmp-summary',
  templateUrl: './pdmp-summary.component.html',
  styleUrls: ['./pdmp-summary.component.scss']
})
export class PdmpSummaryComponent implements OnInit, OnDestroy {
  @HostBinding('class') class = 'tab-wrapper';
  drugTotals: any[] = [
    {
      name: 'Narcotics',
      currentQty: 0,
      currentTag: 'MME/day',
      currentTagValue: 0,
      avg: 0
    },
    {
      name: 'Buprenorphine',
      currentQty: 0,
      currentTag: 'LME/day',
      currentTagValue: 0,
      avg: 0
    },
    {
      name: 'Sedatives',
      currentQty: 0,
      currentTag: 'mg/day',
      currentTagValue: 0,
      avg: 0
    },
    {
      name: 'Stimulants',
      currentQty: 0,
      currentTag: 'LME/day',
      currentTagValue: 0,
      avg: 0
    },
    {
      name: 'Other',
      currentQty: 0,
      currentTag: 'mg/day',
      currentTagValue: 0,
      avg: 0
    }
  ];
  totalPrescriptions = 0;
  totalPrescribers = 0;
  totalPharmacies = 0;
  linearGraphData: LinearGraphDataPoint[] = [];
  drugHistory: DrugHistory[] = [];
  destroySubject: Subject<void> = new Subject();
  dosageDetails: DosageDetail[] | undefined;
  drugTypes: string[] = [];
  prescribers: string[] = [];
  drugTypeMenuOpened: boolean;
  prescribersMenuOpened: boolean;
  selectedDrugType = 'All Drugs';
  selectedPrescriber = 'All Prescribers';

  constructor(private pdmpHelperService: PdmpHelperService,
    private pdmpGraphHelperService: PdmpGraphHelperService,
    private matDialog: MatDialog) { }

  ngOnInit() {
    Chart.defaults.global.defaultFontFamily = 'Montserrat;';

    this.pdmpHelperService.selectedPatients$.pipe(takeUntil(this.destroySubject)).subscribe((pdmpPatients: PdmpPatient[]) => {
      this.clearDosageDetailsData();

      if (pdmpPatients) {
        this.prepareSummaryData(pdmpPatients);
      }
    });

    this.pdmpHelperService.dosageDetails$.pipe(takeUntil(this.destroySubject)).subscribe((dosageDetails: DosageDetail[]) => {
      this.dosageDetails = dosageDetails;

      this.clearDrugDetailsData();

      if (this.dosageDetails) {
        this.prepareGraphData();
      }
    });
  }

  ngOnDestroy() {
    this.destroySubject.next();
  }

  clearDosageDetailsData() {
    this.drugTotals.forEach(total => {
      total.currentQty = 0;
    });

    this.totalPrescriptions = 0;
    this.totalPharmacies = 0;
    this.totalPrescribers = 0;
  }

  clearDrugDetailsData() {
    this.linearGraphData = [];
    this.drugHistory = [];
  }

  prepareSummaryData(pdmpPatients: PdmpPatient[]): void {
    this.totalPharmacies = this.pdmpHelperService.groupBy(
      [].concat.apply([], pdmpPatients.map((p: PdmpPatient) => p.drugDetails)), 'pharmacyName').length;

    this.totalPrescribers = this.pdmpHelperService.groupBy(
      [].concat.apply([], pdmpPatients.map((p: PdmpPatient) => p.drugDetails)), 'prescriberName').length;

    pdmpPatients.forEach((p: PdmpPatient) => {
      p.drugDetails.forEach((drugDetail: DrugDetail) => {
        this.totalPrescriptions++;

        switch (drugDetail.drugType) {
          case DrugType.Narcotic:
            this.drugTotals.find(total => total.name === 'Narcotics').currentQty++;
            break;
          case DrugType.Sedative:
            this.drugTotals.find(total => total.name === 'Sedatives').currentQty++;
            break;
          case DrugType.Stimulant:
            this.drugTotals.find(total => total.name === 'Stimulants').currentQty++;
            break;
          case DrugType.Buprenorphine:
            this.drugTotals.find(total => total.name === 'Buprenorphine').currentQty++;
            break;
          default:
            this.drugTotals.find(total => total.name === 'Other').currentQty++;
            break;
        }
      });
    });
  }

  prepareGraphData(): void {
    this.drugTypes = this.getAllDrugTypes();
    this.prescribers = this.getAllPrescribers();

    this.refreshGraphData();
  }

  refreshGraphData(): void {
    const graphData: { linearGraphData: LinearGraphDataPoint[], drugHistory: DrugHistory[] } =
      this.pdmpGraphHelperService.prepareGraphData(this.dosageDetails, this.selectedDrugType, this.selectedPrescriber);

    if (graphData) {
      this.linearGraphData = graphData.linearGraphData;
      this.drugHistory = graphData.drugHistory;
    }
  }

  fullScreen(graphName: string, graphData: LinearGraphDataPoint[] | DrugHistory[]): void {
    this.matDialog.open(PdmpFullPageGraphComponent, {
      data: { graphName, graphData },
      panelClass: 'full-screen'
    });
  }

  getAllDrugTypes(): string[] {
    const drugTypes: string[] = [];

    this.dosageDetails.forEach((dosageDetail: DosageDetail) => {
      dosageDetail.drugs.forEach((drug: Drug) => {
        if (!drugTypes.includes(drug.drugType)) {
          drugTypes.push(drug.drugType);
        }
      });
    });

    if (drugTypes.length) {
      drugTypes.push('All Drugs');
    }

    return drugTypes;
  }

  getAllPrescribers(): string[] {
    const prescriberNames: string[] = [];

    this.dosageDetails.forEach((dosageDetail: DosageDetail) => {
      dosageDetail.drugs.forEach((drug: Drug) => {
        if (!prescriberNames.includes(drug.prescriberName)) {
          prescriberNames.push(drug.prescriberName);
        }
      });
    });

    if (prescriberNames.length) {
      prescriberNames.push('All Prescribers');
    }

    return prescriberNames;
  }

  selectDrugType(drugType: string): void {
    this.selectedDrugType = drugType;
    this.refreshGraphData();
  }

  selectPrescriber(prescriber: string): void {
    this.selectedPrescriber = prescriber;
    this.refreshGraphData();
  }
}
