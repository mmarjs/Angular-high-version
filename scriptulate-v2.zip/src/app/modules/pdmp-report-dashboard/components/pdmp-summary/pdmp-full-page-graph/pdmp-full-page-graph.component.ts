import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import * as Reducers from '@app/reducers';
import { Store } from '@ngrx/store';

import { PdfHelperService } from '../../../../../core/services/pdf-helper/pdf-helper.service';
import { PdmpHelperService } from '../../../../../core/services/pdmp-helper/pdmp-helper.service';
import { addApprissReport } from '../../../../../reducers/doctor/doctor.actions';
import { DrugHistory, LinearGraphDataPoint } from '../../../models/pdmp-graphs.model';

@Component({
  selector: 'app-pdmp-full-page-graph',
  templateUrl: './pdmp-full-page-graph.component.html',
  styleUrls: ['./pdmp-full-page-graph.component.scss']
})
export class PdmpFullPageGraphComponent {
  downloadInProgress: boolean;

  constructor(@Inject(MAT_DIALOG_DATA) public data: { graphName: string, graphData: LinearGraphDataPoint | DrugHistory },
    public matDialogRef: MatDialogRef<PdmpFullPageGraphComponent>,
    private store: Store<Reducers.State>,
    private pdmpHelperService: PdmpHelperService,
    private pdfHelperService: PdfHelperService) { }

  download(): void {
    this.downloadInProgress = true;
    const fileName = `Scriptulate_PDMP_Graph_${new Date().getTime()}.pdf`;

    this.pdfHelperService.generatePdf(document.querySelector('app-pdmp-full-page-graph .graph-wrapper'), fileName).subscribe(pdf => {
      this.store.dispatch(addApprissReport({
        file_name: fileName,
        uploaded_by_user_id: this.pdmpHelperService.navigationState.doctorId,
        uploaded_for_user_id: + this.pdmpHelperService.navigationState.patient.id,
        file_category: 'pdmp_report',
        file_type: 'application/pdf',
        file: pdf.output('blob'),
      }));

      this.downloadInProgress = false;
    }, (() => this.downloadInProgress = false));
  }
}
