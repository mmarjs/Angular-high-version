
import * as Chart from 'chart.js';

import { AfterViewInit, Component, HostBinding, Input, OnChanges } from '@angular/core';

import { DrugHistory, DrugHistoryDataPoint } from '../../../models/pdmp-graphs.model';

@Component({
  selector: 'app-pdmp-drug-history-graph',
  templateUrl: './pdmp-drug-history-graph.component.html',
  styleUrls: ['./pdmp-drug-history-graph.component.scss']
})
export class PdmpDrugHistoryGraphComponent implements OnChanges, AfterViewInit {
  @HostBinding('class') class = 'pdmp-graph-wrapper';
  @Input() drugHistory: DrugHistory[];
  @Input() canvasId: string;
  chart: Chart;
  colors = ['red', 'black', 'green', 'yellow', 'blue', 'pink'];

  ngOnChanges(): void {
    this.createChart();
  }

  ngAfterViewInit(): void {
    this.createChart();
  }

  createChart(): void {
    if (!this.drugHistory) {
      return;
    }

    const data = this.drugHistory.length ? {
      labels: this.drugHistory[0].dataPoints.map((p: DrugHistoryDataPoint) => p.label),
      datasets: this.drugHistory.map((d: DrugHistory, index: number) => {
        return {
          label: d.name,
          borderColor: this.rainbowStop(index / this.drugHistory.length),
          steppedLine: true,
          backgroundColor: 'white',
          pointBorderWidth: 0,
          pointRadius: 0,
          borderWidth: 15,
          fill: false,
          data: d.dataPoints.map((p: DrugHistoryDataPoint) => p.value)
        };
      })
    } : {};

    const config = {
      type: 'line',
      data,
      options: {
        legend: {
          display: false,
        },
        maintainAspectRatio: false,
        scales: {
          xAxes: [{
            type: 'time',
            distribution: 'linear',
            time: {
              unit: 'month',
              unitStepSize: 2,
              displayFormats: {
                month: 'MM/DD/YY'
              }
            }
          }],
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Drug Name'
            },
            ticks: {
              min: 0,
              max: (this.drugHistory.length + 1) * 10,
              stepSize: 10,
              callback: (_value: any, index: any) => {
                if (this.drugHistory[this.drugHistory.length - index]) {
                  return this.drugHistory[this.drugHistory.length - index].name;
                } else {
                  return '';
                }
              }
            }
          }]
        },
        tooltips: {
          filter: () => {
            return undefined;
          }
        }
      }
    };

    if (document.getElementById(this.canvasId)) {
      const ctx = (document.getElementById(this.canvasId) as any).getContext('2d');
      this.chart = new Chart(ctx, config as any);
    }
  }

  rainbowStop(h: number): any {
    // tslint:disable
    let f = (n: number, k = (n + h * 12) % 12) =>
      0.5 - 0.5 * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    let rgb2hex = (r: number, g: number, b: number) =>
      "#" +
      [r, g, b]
        .map(x =>
          Math.round(x * 255)
            .toString(16)
            .padStart(2, 0 as any)
        )
        .join("");
    return rgb2hex(f(0), f(8), f(4));
  }
}
