import * as Chart from 'chart.js';

import { AfterViewInit, Component, HostBinding, Input, OnChanges } from '@angular/core';

import { LinearGraphDataPoint } from '../../../models/pdmp-graphs.model';

@Component({
  selector: 'app-pdmp-mme-lme-graph',
  templateUrl: './pdmp-mme-lme-graph.component.html',
  styleUrls: ['./pdmp-mme-lme-graph.component.scss']
})
export class PdmpMmeLmeGraphComponent implements OnChanges, AfterViewInit {
  @HostBinding('class') class = 'pdmp-graph-wrapper';
  @Input() linearGraphData: LinearGraphDataPoint[];
  @Input() canvasId: string;
  chart: Chart;

  ngOnChanges(): void {
    this.createChart();
  }

  ngAfterViewInit(): void {
    this.createChart();
  }

  createChart(): void {
    if (!this.linearGraphData) {
      return;
    }

    const data = this.linearGraphData.length ? {
      labels: this.linearGraphData.map(i => i.label),
      datasets: [{
        label: 'MME',
        borderColor: '#5781ca',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderColor: '#f65d65',
        pointBorderWidth: this.linearGraphData.map(i => i.mmeData > 0 ? 2 : 0),
        pointRadius: this.linearGraphData.map(i => i.mmeData > 0 ? 3 : 0),
        fill: false,
        data: this.linearGraphData.map(i => i.mmeData)
      },
      {
        label: 'LME',
        borderColor: '#f09e66',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderColor: '#526382',
        pointBorderWidth: this.linearGraphData.map(i => i.lmeData > 0 ? 2 : 0),
        pointRadius: this.linearGraphData.map(i => i.lmeData > 0 ? 3 : 0),
        fill: false,
        data: this.linearGraphData.map(i => i.lmeData),
      }]
    } : {};

    const config = {
      type: 'line',
      data,
      options: {
        maintainAspectRatio: false,
        scales: {
          xAxes: [{
            type: 'time',
            distribution: 'linear',
            time: {
              unit: 'month',
              unitStepSize: 2,
              displayFormats: {
                month: 'MM/DD/YY'
              }
            }
          }],
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Total MMEs / LMEs Rx\'ed'
            }
          }]
        },
        tooltips: {
          filter: (tooltipItem: any) => {
            return Number(tooltipItem.value) > 0;
          }
        }
      }
    };

    if (document.getElementById(this.canvasId)) {
      const ctx = (document.getElementById(this.canvasId) as any).getContext('2d');
      this.chart = new Chart(ctx, config as any);
    }
  }
}
