
import * as Chart from 'chart.js';

import { AfterViewInit, Component, HostBinding, Input, OnChanges } from '@angular/core';

import { LinearGraphDataPoint } from '../../../models/pdmp-graphs.model';

@Component({
  selector: 'app-pdmp-drug-types-graph',
  templateUrl: './pdmp-drug-types-graph.component.html',
  styleUrls: ['./pdmp-drug-types-graph.component.scss']
})
export class PdmpDrugTypesGraphComponent implements OnChanges, AfterViewInit {
  @HostBinding('class') class = 'pdmp-graph-wrapper';
  @Input() linearGraphData: LinearGraphDataPoint[];
  @Input() canvasId: string;
  chart: Chart;

  ngOnChanges(): void {
    this.createChart();
  }

  ngAfterViewInit(): void {
    this.createChart();
  }

  createChart(): void {
    if (!this.linearGraphData) {
      return;
    }

    const data = this.linearGraphData.length ? {
      labels: this.linearGraphData.map(i => i.label),
      datasets: [{
        label: 'Narcotics',
        borderColor: '#4875c5',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderWidth: 0,
        pointRadius: 0,
        fill: false,
        data: this.linearGraphData.map(i => i.narcoticsNumber)
      },
      {
        label: 'Sedatives',
        borderColor: '#d07172',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderWidth: 0,
        pointRadius: 0,
        fill: false,
        data: this.linearGraphData.map(i => i.sedativesNumber)
      },
      {
        label: 'Stimulants',
        borderColor: '#517c57',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderWidth: 0,
        pointRadius: 0,
        fill: false,
        data: this.linearGraphData.map(i => i.stimulantNumber)
      },
      {
        label: 'Buprenorphine',
        borderColor: '#baaab8',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderWidth: 0,
        pointRadius: 0,
        fill: false,
        data: this.linearGraphData.map(i => i.buprenorphineNumber)
      },
      {
        label: 'Others',
        borderColor: '#a16737',
        steppedLine: true,
        backgroundColor: 'white',
        pointBorderWidth: 0,
        pointRadius: 0,
        fill: false,
        data: this.linearGraphData.map(i => i.othersNumber)
      }]
    } : {};

    const config = {
      type: 'line',
      data,
      options: {
        maintainAspectRatio: false,
        scales: {
          xAxes: [{
            type: 'time',
            distribution: 'linear',
            time: {
              unit: 'month',
              unitStepSize: 2,
              displayFormats: {
                month: 'MM/DD/YY'
              }
            }
          }],
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: '# of Active Rx\'s'
            },
            ticks: {
              stepSize: 1
            }
          }]
        },
        tooltips: {
          filter: (tooltipItem: any) => {
            return Number(tooltipItem.value) > 0;
          }
        }
      }
    };

    if (document.getElementById(this.canvasId)) {
      const ctx = (document.getElementById(this.canvasId) as any).getContext('2d');
      this.chart = new Chart(ctx, config as any);
    }
  }
}

