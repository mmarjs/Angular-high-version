import { Component, ElementRef, Input, OnChanges, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-pdmp-button',
  templateUrl: './pdmp-button.component.html',
  styleUrls: ['./pdmp-button.component.scss']
})
export class PdmpButtonComponent implements OnChanges {
  @Input() icon: string;
  @Input() disabled: boolean;
  @Input() type = 'button';

  constructor(private el: ElementRef, private renderer2: Renderer2) { }

  ngOnChanges(): void {
    if (this.disabled) {
      this.renderer2.addClass(this.el.nativeElement, 'disabled');
    } else {
      this.renderer2.removeClass(this.el.nativeElement, 'disabled');
    }
  }
}
