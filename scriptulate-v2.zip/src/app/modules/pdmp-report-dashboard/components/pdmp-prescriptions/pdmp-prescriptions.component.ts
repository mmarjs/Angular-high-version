import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';

import { PdmpHelperService } from '../../../../core/services/pdmp-helper/pdmp-helper.service';
import { DrugType } from '../../enums/drug-type.module';
import { DrugDetail, PdmpPatient } from '../../models/pdmp-patient.model';
import { Prescription } from '../../models/prescription.model';
import { Column } from '../../models/table-column.model';

@Component({
  selector: 'app-pdmp-prescriptions',
  templateUrl: './pdmp-prescriptions.component.html',
  styleUrls: ['./pdmp-prescriptions.component.scss']
})
export class PdmpPrescriptionsComponent implements OnInit, OnDestroy {
  @HostBinding('class') class = 'tab-wrapper';
  columns: Column[] = [
    { name: 'Patient ID', value: 'patientId', default: true, disabled: true, allowFilter: true, allowSort: true },
    { name: 'Patient DOB', value: 'patientDob', allowFilter: true, allowSort: true },
    { name: 'Fill Date', value: 'fillDate', default: true, disabled: true, allowSort: true },
    { name: 'Written', value: 'written', allowSort: true },
    { name: 'Drug Name', value: 'drugName', default: true, disabled: true, allowFilter: true, allowSort: true },
    { name: 'Dosage', value: 'dosage', default: true, disabled: true },
    { name: 'Qty', value: 'qty', default: true, disabled: true },
    { name: 'Days', value: 'days', default: true, disabled: true },
    { name: '#Pills/day', value: 'pillsDay' },
    { name: 'Daily Dosage', value: 'dailyDosage', default: true },
    { name: 'Drug Class', value: 'drugClass', allowFilter: true, allowSort: true },
    { name: 'Prescriber Name', value: 'prescriberName', default: true, allowFilter: true, allowSort: true },
    { name: 'Prescriber Contact', value: 'prescriberContact' },
    { name: 'Prescriber DEA State', value: 'prescriberDeaState', allowFilter: true, allowSort: true },
    { name: 'Pharmacy Name', value: 'pharmacyName', default: true, allowFilter: true, allowSort: true },
    { name: 'Pharmacy Contact', value: 'pharmacyContact' },
    { name: 'Pharmacy city', value: 'pharmacyCity', allowFilter: true, allowSort: true },
    { name: 'Refill', value: 'refill' },
    { name: 'Payment Type', value: 'paymentType', allowFilter: true, allowSort: true },
    { name: 'PMP State', value: 'pmpState', allowFilter: true, allowSort: true },
    { name: 'Rx#', value: 'rx' }
  ];
  prescriptions: Prescription[];
  destroySubject: Subject<void> = new Subject();

  constructor(private pdmpHelperService: PdmpHelperService) { }

  ngOnInit() {
    this.pdmpHelperService.selectedPatients$.pipe(takeUntil(this.destroySubject)).subscribe((pdmpPatients: PdmpPatient[]) => {
      if (pdmpPatients) {
        const prescriptions: Prescription[] = [];

        pdmpPatients.forEach((p: PdmpPatient) => {
          p.drugDetails.forEach((drugDetail: DrugDetail) => {
            const prescription: Prescription = {
              patientId: p.patientInfo.patientId,
              patientDob: p.patientInfo.patientDOB,
              fillDate: drugDetail.filled,
              drugName: drugDetail.drugName,
              dosage: drugDetail.dosage,
              qty: drugDetail.quantityPrescibed,
              days: drugDetail.daysPrescribed,
              pillsDay: +drugDetail.quantityPrescibed / +drugDetail.daysPrescribed,
              dailyDosage: this.getDailyDosageTag(drugDetail),
              drugClass: drugDetail.drugType ? drugDetail.drugType : 'other',
              prescriberName: drugDetail.prescriberName,
              prescriberContact: `${drugDetail.prescriberAddress.line},
                ${drugDetail.prescriberAddress.city}, ${drugDetail.prescriberAddress.state}, ${drugDetail.prescriberAddress.postalCode}`,
              prescriberDeaState: drugDetail.prescriberAddress.state,
              pharmacyName: drugDetail.pharmacyName,
              pharmacyContact: `${drugDetail.pharmacyAddress.line},
                ${drugDetail.pharmacyAddress.city}, ${drugDetail.pharmacyAddress.state}, ${drugDetail.pharmacyAddress.postalCode}`,
              pharmacyCity: drugDetail.prescriberAddress.city,
              refill: drugDetail.noRefill,
              paymentType: drugDetail.paymentType,
              pmpState: drugDetail.pmpState,
              rx: drugDetail.rxNumber
            };

            prescriptions.push(prescription);
          });
        });

        this.prescriptions = prescriptions;
      } else {
        this.prescriptions = [];
      }
    });
  }

  ngOnDestroy() {
    this.destroySubject.next();
  }

  getDailyDosageTag(drug: any): string {
    if (drug.drugType === DrugType.Narcotic) {
      return `${drug.dailyDose} MME`;
    }

    if (drug.drugType === DrugType.Sedative) {
      return `${drug.dailyDose} LME`;
    }

    return drug.dailyDose;
  }
}
