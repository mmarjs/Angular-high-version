import * as Reducers from 'app/reducers';

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Store } from '@ngrx/store';

import { addNote } from '../../../../reducers/doctor/doctor.actions';

@Component({
  selector: 'app-add-note-modal',
  templateUrl: './add-note-modal.component.html',
  styleUrls: ['./add-note-modal.component.scss']
})
export class AddNoteModalComponent implements OnInit {
  formGroup: FormGroup;
  loading: boolean;

  constructor(@Inject(MAT_DIALOG_DATA) private data: { patientId: number, doctorId: number },
    public dialogRef: MatDialogRef<AddNoteModalComponent>,
    private formBuilder: FormBuilder,
    private store: Store<Reducers.State>) { }

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      subject: [''],
      body: ['', [Validators.required]]
    });
  }

  submit(): void {
    Object.values(this.formGroup.controls).forEach(control => {
      control.markAsTouched();
    });

    if (this.formGroup.invalid) {
      return;
    }

    this.loading = true;

    const note: any = {
      body: this.formGroup.controls.body.value,
      subject: this.formGroup.controls.subject.value,
      category: 'note',
      patient_id: this.data.patientId,
      created_by_user_id: this.data.doctorId,
    };
    this.store.dispatch(addNote(note));

    note.createdAt = new Date();
    this.dialogRef.close(note);
  }
}
