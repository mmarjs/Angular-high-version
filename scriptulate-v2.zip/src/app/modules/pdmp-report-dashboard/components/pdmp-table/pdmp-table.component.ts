import * as _ from 'lodash';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { Component, Input, OnChanges, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatMenuTrigger, MatTableDataSource } from '@angular/material';

import { Column } from '../../models/table-column.model';

@Component({
  selector: 'app-pdmp-table',
  templateUrl: './pdmp-table.component.html',
  styleUrls: ['./pdmp-table.component.scss']
})
export class PdmpTableComponent implements OnChanges, OnInit, OnDestroy {
  @Input() columns: Column[];
  @Input() items: any[];
  @Input() showActions = true;
  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [];
  columnsMenuOpened: boolean;
  filterControl: FormControl = new FormControl('');
  columnsForm: FormGroup = new FormGroup({});
  filterSortForm: FormGroup = new FormGroup({});
  allColumnValues: any[];
  columnValues: any[];
  destroySubject = new Subject();
  filteredColumn: Column;
  @ViewChild('filterSortTrigger') filterSortTrigger: MatMenuTrigger;

  ngOnChanges(): void {
    this.dataSource = new MatTableDataSource(this.items);
    this.filteredColumn = undefined;
  }

  ngOnInit() {
    this.columns.forEach((c: Column) => {
      if (c.default) {
        this.displayedColumns.push(c.value);
      }

      this.columnsForm.addControl(c.value, new FormControl(c.default));

      if (c.disabled) {
        this.columnsForm.controls[c.value].disable({ emitEvent: false });
      }
    });

    this.columnsForm.valueChanges.pipe(takeUntil(this.destroySubject)).subscribe(() => {
      this.displayedColumns = Object.keys(this.columnsForm.getRawValue())
        .filter((columnValue: string) => this.columnsForm.getRawValue()[columnValue])
        .map((columnValue: string) => columnValue);
    });
  }

  ngOnDestroy() {
    this.destroySubject.next();
  }

  prepareFilterSort(column: Column): void {
    if (column.allowFilter || column.allowSort) {
      this.allColumnValues = Array.from(new Set(this.items.map(item => item[column.value])));
      this.columnValues = [...this.allColumnValues];

      this.filterControl.setValue('');
      this.filterSortForm = new FormGroup({});

      this.allColumnValues.forEach(value => {
        this.filterSortForm.addControl(value, new FormControl(this.dataSource.data.find(i => i[column.value] === value)));
      });

      this.filterSortForm.valueChanges.pipe(takeUntil(this.destroySubject)).subscribe(() => {
        this.applyFilter(column);
      });

      this.filterControl.valueChanges.pipe(takeUntil(this.destroySubject)).subscribe(newValue => {
        this.columnValues = this.allColumnValues.filter(value =>
          value.toString().trim().toLowerCase().includes(newValue.trim().toLowerCase()));
      });
    }
  }

  masterToggle(): void {
    const newValue = !this.isAllSelected();
    Object.values(this.filterSortForm.controls).forEach(control => control.setValue(newValue));
  }

  isAllSelected(): boolean {
    return Object.values(this.filterSortForm.controls).every(control => control.value);
  }

  isSomeSelected(): boolean {
    return Object.values(this.filterSortForm.controls).some(control => control.value);
  }

  sort(column: Column, direction: 'asc' | 'desc'): void {
    this.dataSource.data = _.orderBy(this.dataSource.data, [column.value], [direction]);
    this.closeMenu();
  }

  applyFilter(column: Column): void {
    const formValue = this.filterSortForm.getRawValue();
    const filteredValues = Object.keys(formValue)
      .map(key => {
        if (formValue[key]) {
          return key;
        }

        return null;
      }).filter(v => v !== null);

    this.dataSource.data = this.items.filter(i => filteredValues.includes(i[column.value].toString()));

    this.filteredColumn = undefined;
    if (filteredValues.length < Object.keys(formValue).length) {
      this.filteredColumn = column;
    }
  }

  closeMenu(): void {
    this.filterSortTrigger.closeMenu();
  }
}
