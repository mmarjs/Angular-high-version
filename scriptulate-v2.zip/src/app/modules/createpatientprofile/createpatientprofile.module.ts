import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ProfileModule} from '../profile/profile.module';
import { CreatepatientprofileRoutingModule } from './createpatientprofile-routing.module';
import { CreatePatientProfileComponent } from './create-patient-profile.component';

@NgModule({
  imports: [
    CommonModule,
    CreatepatientprofileRoutingModule,
    ProfileModule
  ],
  declarations: [CreatePatientProfileComponent]
})
export class CreatepatientprofileModule { }
