import { CreatepatientprofileModule } from './createpatientprofile.module';

describe('CreatepatientprofileModule', () => {
  let createpatientprofileModule: CreatepatientprofileModule;

  beforeEach(() => {
    createpatientprofileModule = new CreatepatientprofileModule();
  });

  it('should create an instance', () => {
    expect(createpatientprofileModule).toBeTruthy();
  });
});
