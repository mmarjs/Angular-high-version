import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../core/services';
import {Router} from '@angular/router';
import { LoginService } from '../login/service/login.service';

@Component({
  selector: 'app-create-patient-profile',
  templateUrl: './create-patient-profile.component.html',
  styleUrls: ['./create-patient-profile.component.css']
})
export class CreatePatientProfileComponent implements OnInit {

  constructor(public router:Router,private loginService:LoginService) { }

  ngOnInit() {
  }
  logoutUser(){
    this.loginService.logout();
  }

    public routeToDashboard(){
    this.router.navigate(['dashboard']);
  }

}
