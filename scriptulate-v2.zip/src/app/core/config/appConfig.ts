/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */

/**
 * @author boney.dhawan
 * @name AppConfig
 * @desc This is a configuration file contains the application specific configuration
 */
export const AppConfig = {
  APP_NAME: 'Health-App',
  LOGO_IMAGE: 'assets/images/logo_1.jpg',
};
