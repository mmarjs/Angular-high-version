/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { environment } from '../../../environments/environment';
/**
 * @author boney.dhawan
 * @name EnvironemntConfig
 * @desc This is a configuration file and contains the enviroment specific configuration
 */
export const EnvironemntConfig = {
  BASE_URL: environment.production
    ? 'http://3.95.188.101:3002/'
    : 'http://localhost:3000', // ubuntu 18.04 instance 6/2/2019 created
  DOWNLOAD_URL: environment.production
    ? 'http://3.95.188.101:8085/'
    : 'http://localhost:3000',
  HEROKU_URL: 'https://scriptulate-checklist.herokuapp.com/',
};
