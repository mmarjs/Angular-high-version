export const setDialogs = {
  isDischarge: false,
  isPrescription: false,
  isAddPatient: false,
  isSetAppointment: false,
  isDrugInfo: false,
  isBurgerMenu: false,
  isEditProfile: false,
  isHeader: false,
  isDrugInteraction: false,
  isDiversion: false,
  isPillInfo: false,
  isEditPatientProfile: false,
  isFillPrescription: false,
  isReportInfo: false,
  isDetailedReport: false,
  isPastReport: false
};
