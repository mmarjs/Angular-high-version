/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */

/**
 ** @author Nishtha jain
 ** @name Messages
 ** @desc common error messages used inside the app
 */
export const Messages = {
  FIRSTNAME_ERROR_MESSAGE: 'Enter a valid first name.',
  LASTNAME_ERROR_MESSAGE: 'Enter a valid last name.',
  REQUIRED_ERROR_MESSAGE: 'This field is required.',
  EMAIL_ERROR_MESSAGE: 'Enter a valid email address.',
  CITY_ERROR_MESSAGE: 'Enter a valid city name. ',
  STATE_ERROR_MESSAGE: 'Enter a valid state name. ',
  LICENSE_ERROR_MESSAGE: 'Enter valid license number.',
  COUNT_ERROR_MESSAGE: 'Enter valid count number.',
  DAYS_ERROR_MESSAGE: 'Enter valid days count.',
  REFILL_ERROR_MESSAGE: 'Enter valid refill count.',
  ICD_ERROR_MESSAGE: 'Enter valid ICD10 number.',
  PILL_QUANTITY: 'Enter valid pill quantity.',
  PILL_ID: 'Enter valid pill id.',
  FAX_ERROR_MESSAGE: 'Enter a valid fax number.',
  DOB_ERROR_MESSAGE: 'Enter dob as mm/dd/yyyy.',
  SSN_ERROR_MESSAGE: 'Enter a valid SSN.',
  NPI_ERROR_MESSAGE: 'Enter a valid NPI.',
  POSTALCODE_ERROR_MESSAGE: 'Enter a valid postal code.',
  PHONE_ERROR_MESSAGE: 'Enter valid phone number.',
  PASSWORD_ERROR_MESSAGE:
    'password should be 8 characters long and must contain a special character,lowercase and uppercase letter.',
  PASSWORD_MISMATCH_ERROR_MESSAGE:
    'password and confirm password must be same.',
  PROFILE_STATUS:
    'Your email is not yet verified. Please check your registered email or contact nilukundagrami@scriptulate.com.',
  NO_GROUPS_STATUS:
    'Your Account is not yet associated with any Group. Please contact nilukundagrami@scriptulate.com.',
  SEARCH_ERROR_MESSAGE: 'Please enter atleast one parameter for search.',
  MIN_LENGTH: 'userId should contain minimum 5 characters.',
  USER_ID: 'userId can be a combination of alphabets, numbers and underscore.',
  DEA_ERROR_MESSAGE:
    'DEA Number must be start from 2 uppercase letter and end of 7 characters number',
};
