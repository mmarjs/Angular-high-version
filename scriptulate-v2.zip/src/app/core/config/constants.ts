/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */

/**
 * @author boney.dhawan
 * @name Constants
 * @desc common app constants used inside the app
 */
export const Constants = {
  HTTP_REQUEST_TYPE_GET: 'GET',
  HTTP_REQUEST_TYPE_POST: 'POST',
  HTTP_REQUEST_TYPE_PUT: 'PUT',
  SERVER_ERROR: 'invalid_grant',
  SHOW_ERROR: false,
  PRESCRIPTION_BUFFER: 10,
};

export const AnswerValue = {
  yes: 'YES',
  no: 'NO',
  none: 'NONE',
  na: 'NA',
};

export const AppUser = {
  doctor: 'Doctor',
  phamarcy: 'Pharmacist',
  patient: 'Patient',
};
