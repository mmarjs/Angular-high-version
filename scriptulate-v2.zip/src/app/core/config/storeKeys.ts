export const StoreKeys = {
    CHECK_LIST_ITEMS : 'check_list_items',
    PATIENT_INFO : 'current_patient_info',
    PATIENT_ID : 'current_patient_id'
}