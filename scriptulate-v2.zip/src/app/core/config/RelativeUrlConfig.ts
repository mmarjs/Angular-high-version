/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */

/**
 ** @author boney.dhawan
 ** @name RelativeUrlConfig
 ** @desc every API request contains a base url and relative URL, relative will be stored in form of a constants here
 */
export const RelativeUrlConfig = {
  REGISTER: 'api/auth/signup',
  LOGIN: 'api/auth/login',
  LOGOUT: 'api/auth/logout',
  AUTH_CHECK: 'api/auth/check',
  GET_ROLES: 'api/users/roles',
  GET_GROUPS: 'api/groups',

  RESET_PASSWORD: 'api/auth/password/reset',
  REQUEST_RESET_PASSWORD: 'api/auth/password/request_reset',
  PROFILE: 'api/users',
  FETCH_ALL_PATIENTS: 'api/patient/doctor',
  SEARCH_PATIENTS: 'api/patient',
  ADD_MY_PATIENT: 'api/users/doctor/{{doctor_id}}/patient/{{patient_id}}/birthdate/{{birthdate}}/add',
  CREATE_PRESCRIPTION: 'api/prescriptions',
  GET_PRESCRIPTIONS: 'api/prescriptions',
  SYNC_PRESCRIPTIONS: 'api/prescriptions/appriss_sync',
  CREATE_FILE: 'api/files',
  FILES: 'api/files',
  CHECK_LIST_TEMPLATES: 'api/check_list_templates',
  CHECK_LIST_NOTE: 'api/checklist/fetchNote',
  CHECKLISTS: 'api/check_lists',
  APPOINTMENTS: 'api/appointments',

  DIVERSIONS: 'api/diversions',
  URINES: 'api/urines',
  SCREENINGS: 'api/screenings',

  GENERATE_PRESIGNED_URL: 'api/files/generate_presigned_url',

  GET_DRUGLIST: 'api/medication/drugs',
  GET_ICD: 'api/medication/drug_icd_code',
  GET_FREQUENCY: 'api/medication/drug_frequency',
  GET_DRUG_GROUP: 'api/medication/drug_groups',
  ALERTS: 'api/alerts',

  ADD_PRESCRIPTION: 'api/patient-management/prescription/newPrescription',
  ADD_PRESCRIPTION_SSE: 'api/patient-management/prescription/sse',
  GET_PRESCRIPTION: 'api/patient-management/prescription/getPrescription',
  GET_PROFILE: 'api/profile-management/fetchProfileDetails',
  UPDATE_PROFILE: 'api/profile-management/editprofile',
  UPDATE_PATIENT_PROFILE: 'api/profile-management/editpatientprofile',
  DISCHARGE: 'api/patient-management/discharge/dischargeInfo',
  SAVE_DIVERSION: 'api/patient-management/diversion/addDiversion',
  FETCH_DIVERSION: 'api/patient-management/diversion/fetchDiversion',
  DRUG_INTERACTION: 'api/drug/drugInteractions',
  DRUG_LIST: 'api/drug/fetchDrugs',
  PATIENT_INFO: 'api/profile-management/fetchPatientProfileDetails',
  PATIENT_PROFILE_DETAIL: 'api/profile-management/patientsProfileData',
  MY_DIALOG: 'api/profile-management/fetchPatientDetails',
  MY_PATIENT: 'api/profile-management/todayspatient',
  ALL_PATIENT: 'api/profile-management/allPatients',
  MY_DISCHARGE_PATIENTS: 'api/patient-management/discharge/dischargepatient',
  PILL_COUNT: 'api/patient-management/pillcount/addpillcount',
  SET_APPOINTMENT: 'api/profile-management/appointment',

  // must go back and update ID
  MY_ACTIVE_PATIENTS: 'api/users/doctor/{{doctor_id}}/my_patients',
  PATIENT_PROFILE: 'api/profile-management/commonRegister',

  FETCH_DOCTOR_DETAILS: 'api/profile-management/fetchDoctorDetails',
  SAVE_FILLED_PRESCRIPTION:
    'api/patient-management/filledPrescription/saveFilledPrescription',
  FETCH_FILLED_PRESCRIPTION:
    'api/patient-management/filledPrescription/fetchFilledPrescription',
  FETCH_PRESCRIBED_BY_INFO:
    'api/patient-management/filledPrescription/getDoctorDetails',
  FETCH_FILLED_DATA:
    'api/patient-management/filledPrescription/fetchFilledPrescriptionDetails',
  FETCH_FILLED_BY_INFO:
    'api/patient-management/filledPrescription/fetchPharmacistDetails',
  UPLOAD_SUMMARY_REPORT:
    'api/patient-management/pdmpReport/uploadSummaryReport',
  ADD_SUMMARY_REPORT: 'api/patient-management/pdmpReport/addSummaryReport',
  FETCH_SUMMARY_REPORTS:
    'api/patient-management/pdmpReport/fetchSummaryReports',
  // DOWNLOAD_SUMMARY_REPORTS:'api/patient-management/pdmpReport/download'
  DOWNLOAD_SUMMARY_TEST: 'patient-management/pdmpReport/download',  
  CREATE_PRES_ALERT: 'api/patient-management/presAlert/createNewPresAlert',
  GET_ALL_PRES_ALERTS: 'api/patient-management/presAlert/fetchPresAlerts',
  CONTRACTS: 'api/contracts',
  DOWNLOAD_CONTRACT: 'Agreement/',
  TODOS: 'api/todos',
  PDMP_REPORT_PDF: 'api/pdmp-report-pdf',

  NOTE: 'api/notes',
  FETCH_NOTES_CHECKLISTS_COMBINED: 'api/notes/check_lists/combined',
  UPLOAD_PATIENT: 'api/users/upload'
};
