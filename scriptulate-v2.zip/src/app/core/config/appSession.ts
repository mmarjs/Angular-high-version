
export const AppSession = {
    loadingSpinner: false
}