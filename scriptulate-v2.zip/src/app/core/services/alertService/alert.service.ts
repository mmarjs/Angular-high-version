import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { HttpResourceService } from '../httpResourceService/http-resource.service';
import { AuthService } from '../authService/auth.service';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  constructor(private httpResourceService: HttpResourceService, private authService: AuthService) {}

  getAlerts(): Observable<any> {
    return this.httpResourceService.get(RelativeUrlConfig.ALERTS, {}).pipe(
      map(res => {
        const result = res.body || [];
        if (!this.authService.user) {
          return [];
        }
        if (!this.authService.isPatient) {
          return result.filter(alert => (alert.requested_by_user_id === this.authService.user.id && !alert.is_completed)
          );
        } else {
          return result.filter(alert => alert.patient_id === this.authService.user.id && !alert.is_completed);
        }
      })
    );
  }

  updateAlert(alertId: any, params: any): Observable<any> {
    return this.httpResourceService.put(`${RelativeUrlConfig.ALERTS}/${alertId}`, params);
  }

  closeAlert(alertId: any) {
    return this.updateAlert(alertId, { is_completed: true });
  }
}
