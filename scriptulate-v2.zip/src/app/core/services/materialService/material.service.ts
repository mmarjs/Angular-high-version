import { Injectable } from '@angular/core';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class MaterialService {
  constructor(
      private matIconRegistry: MatIconRegistry,
      private domSanitizer: DomSanitizer,
  ) {}

  registerIcon = (name: string, path: string): void => {
    this.matIconRegistry.addSvgIcon(
      name,
      this.domSanitizer.bypassSecurityTrustResourceUrl(path)
    );
  }
}
