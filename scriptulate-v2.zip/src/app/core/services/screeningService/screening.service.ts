import { Injectable } from '@angular/core';
import { RelativeUrlConfig } from 'app/core/config/RelativeUrlConfig';
import { HttpResourceService } from 'app/core/services/httpResourceService/http-resource.service';

@Injectable({
  providedIn: 'root'
})
export class ScreeningService {
  constructor(private httpResourceService: HttpResourceService) {}

  postNewScreening = (payload: any) =>
    this.httpResourceService.post(RelativeUrlConfig.SCREENINGS, payload);

  getAllScreenings = (params: Object = {}) =>
    this.httpResourceService.get(RelativeUrlConfig.SCREENINGS, params);

  updateScreening = (id: string, params: any) =>
    this.httpResourceService.put(
      `${RelativeUrlConfig.SCREENINGS}/${id}`,
      params
    );
}
