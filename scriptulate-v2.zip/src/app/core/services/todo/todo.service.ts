import { Injectable } from '@angular/core';
import { HttpResourceService } from '../httpResourceService/http-resource.service';
import { AuthService } from '../authService/auth.service';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  constructor(private httpResourceService: HttpResourceService, private authService: AuthService) { }

  fetchTodos(userId) {
    return this.httpResourceService.get(RelativeUrlConfig.TODOS,{}).pipe(
      map(res => {
        let result = res.body || [];
        if (!this.authService.user) return [];
        if (!this.authService.isPatient)
          return result.filter(todo => {
                if(!todo.is_completed ){
                 const dueDateMinusX =moment(todo.due_date).subtract(15,'d');
                 if(dueDateMinusX>moment()){
                   return false;
                 }else{
                   return true;
                 }
                }
                return false;
              }
          );
        else return result.filter(todo => todo.patient_id === this.authService.user.id && !todo.is_completed);
      })
    );
  }

  listTodos(userId) {
    return this.httpResourceService.get(RelativeUrlConfig.TODOS,{}).pipe(
      map(res => {
        return res.body;
      })
    );
  }

  createTodo(todo: any) {
    return this.httpResourceService.post(RelativeUrlConfig.TODOS, todo);
  }

  updateTodo(todoId: any, params: any) {
    return this.httpResourceService.put(`${RelativeUrlConfig.TODOS}/${todoId}`, params);
  }

  closeTodo(todoId: any) {
    return this.updateTodo(todoId, { is_completed: true });
  }
}
