import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class PatientLastVisitService {
    patient_timestamps: object;
    constructor() {
        this.patient_timestamps = {};
    }
    isPatientCached = (patient_id) => {
        if (!patient_id) {
            return;
        }
        if (!this.patient_timestamps[patient_id]) {
            this.patient_timestamps[patient_id] = moment().toISOString();
        }
        return this.patient_timestamps;
    }

    isPatientVisitRecent = (patient_id) => {
        if (!patient_id) {
            return;
        }
        const timestamp = moment(this.patient_timestamps[patient_id]).valueOf();
        const now = moment().valueOf();
        const duration = now - timestamp;
        if (duration >= 300000) {
            return false;
        }
        return true;
    }

    updatePatientTimeStamp = (patient_id) => {
        if (!patient_id) {
            return;
        }
        this.patient_timestamps[patient_id] = moment().toISOString();
    }
}
