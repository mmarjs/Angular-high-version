import { Observable } from 'rxjs';

import { HttpClient, HttpHeaders } from '@angular/common/http';
/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Injectable } from '@angular/core';
import { Constants } from '@app/core/config/constants';

@Injectable({
  providedIn: 'root',
})
export class HttpResourceService {
  httpOptions: any;

  constructor(private httpClient: HttpClient) { }

  /**
   * @name get
   * @param url
   * @param params
   */
  get(url, params) {
    if (params) {
      const tempStr = Object.keys(params)
        .map(function (key) {
          if (params[key] != null && params[key] !== 'null') {
            return key + '=' + encodeURIComponent(params[key]);
          }
        })
        .join('&');
      url = url + '?' + tempStr;
    }
    this.httpOptions = this.prepareHttpOptions();
    return this.makeHttpRequest(
      url,
      params,
      this.httpOptions,
      Constants.HTTP_REQUEST_TYPE_GET
    );
  }

  /**
   * @name post
   * @param url
   * @param postData
   */
  post(url, postData): Observable<any> {
    const data = JSON.stringify(postData);
    this.httpOptions = this.prepareHttpOptions();
    return this.makeHttpRequest(
      url,
      data,
      this.httpOptions,
      Constants.HTTP_REQUEST_TYPE_POST
    );
  }

  hero_get(url, params) {
    if (params) {
      const tempStr = Object.keys(params)
        .map(function (key) {
          if (params[key] != null && params[key] != 'null') {
            return key + '=' + encodeURIComponent(params[key]);
          }
        })
        .join('&');
      url = url + '?' + tempStr;
    }
    this.httpOptions = this.restHttpOptions();
    return this.makeHttpRequest(
      url,
      params,
      this.httpOptions,
      Constants.HTTP_REQUEST_TYPE_GET
    );
  }

  /**
   * @name post
   * @param url
   * @param putData
   */
  put(url, putData): Observable<any> {
    const data = JSON.stringify(putData);
    this.httpOptions = this.prepareHttpOptions();
    return this.makeHttpRequest(
      url,
      data,
      this.httpOptions,
      Constants.HTTP_REQUEST_TYPE_PUT
    );
  }

  /**
   * @name post
   * @param url
   * @param postData
   */
  formPost(url, postData): Observable<any> {
    this.httpOptions = this.prepareHttpOptionsFormData();
    return this.makeHttpRequest(
      url,
      postData,
      this.httpOptions,
      Constants.HTTP_REQUEST_TYPE_POST
    );
  }

  /**
   * @name prepareHttpOptions
   * @desc prepares the HttpOptions object
   * @returns httpOptions
   */
  private prepareHttpOptions() {
    const headers = {
      'Content-Type': 'application/json',
    };
    const httpOptions = {
      observe: 'response',
      headers: headers,
    };

    return httpOptions;
  }

  private prepareHttpOptionsFormData() {
    const headers = new HttpHeaders({
      enctype: 'multipart/form-data',
    });
    const httpOptions = {
      observe: 'response',
      headers: headers,
    };
    return httpOptions;
  }

  private restHttpOptions() {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };
    const httpOptions = {
      observe: 'response',
      headers: headers,
    };
    return httpOptions;
  }

  /**
   * @name makeHttpRequest
   * @desc makes Http Request
   * @param url - url to hit
   * @param requestType -request type whether post,get etc
   * @param data - data to be passed with request
   * @param httpOptions
   */
  private makeHttpRequest(
    url,
    data,
    httpOptions,
    requestType
  ): Observable<any> {
    url = `https://scriptulate-dev.herokuapp.com/${url}`;

    if (requestType === Constants.HTTP_REQUEST_TYPE_PUT) {
      return this.httpClient.put(url, data, httpOptions);
    } else if (requestType === Constants.HTTP_REQUEST_TYPE_POST) {
      return this.httpClient.post(url, data, httpOptions);
    } else if (requestType === Constants.HTTP_REQUEST_TYPE_GET) {
      return this.httpClient.get(url, httpOptions);
    } else if (requestType === Constants.HTTP_REQUEST_TYPE_PUT) {
      return this.httpClient.put(url, data, httpOptions);
    }
  }
}
