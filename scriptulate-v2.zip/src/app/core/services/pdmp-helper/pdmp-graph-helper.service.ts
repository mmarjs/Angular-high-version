import * as _ from 'lodash';
import * as moment from 'moment';

import { Injectable } from '@angular/core';

import {
    DrugHistory, LinearGraphDataPoint
} from '../../../modules/pdmp-report-dashboard/models/pdmp-graphs.model';
import {
    DosageDetail, Drug
} from '../../../modules/pdmp-report-dashboard/models/pdmp-patient.model';

@Injectable({
    providedIn: 'root'
})
export class PdmpGraphHelperService {
    prepareGraphData(dosageDetails: DosageDetail[],
        selectedDrugType: string,
        selectedPrescriber: string): { linearGraphData: LinearGraphDataPoint[], drugHistory: DrugHistory[] } {
        if (!dosageDetails) {
            return;
        }

        let linearGraphData: LinearGraphDataPoint[] = [];
        const drugNames: string[] = this.getAllDrugNames(dosageDetails, selectedDrugType, selectedPrescriber);
        const drugHistory: DrugHistory[] = drugNames.map((name: string) => {
            return { name, dataPoints: [] };
        });

        dosageDetails.forEach((dosageDetail: DosageDetail) => {
            const startDate = this.getMomentData(dosageDetail.startDate);
            const endDate = this.getMomentData(dosageDetail.endData);

            this.addToLinearGraphData(linearGraphData, dosageDetail, startDate, endDate);
            this.addToDrugHistory(drugHistory, dosageDetail, drugNames, selectedDrugType, selectedPrescriber, startDate, endDate);
        });

        linearGraphData = _.orderBy(linearGraphData, ['label'], 'asc');
        drugHistory.forEach((d: DrugHistory) => {
            d.dataPoints = _.orderBy(d.dataPoints, ['label'], 'asc');
        });

        return { linearGraphData, drugHistory };
    }

    private getMomentData(dateString: string): moment.Moment {
        return moment(dateString, 'YYYY-MM-DD').hour(5).minutes(30).second(0).milliseconds(0);
    }

    private getAllDrugNames(dosageDetails: DosageDetail[],
        selectedDrugType: string,
        selectedPrescriber: string): string[] {
        const drugNames: string[] = [];

        dosageDetails.forEach((dosageDetail: DosageDetail) => {
            dosageDetail.drugs
                .filter((d: Drug) => {
                    if (selectedPrescriber !== 'All Prescribers') {
                        return d.prescriberName === selectedPrescriber;
                    } else {
                        return true;
                    }
                })
                .filter((d: Drug) => {
                    if (selectedDrugType !== 'All Drugs') {
                        return d.drugType === selectedDrugType;
                    } else {
                        return true;
                    }
                })
                .forEach((drug: Drug) => {
                    if (!drugNames.includes(drug.name)) {
                        drugNames.push(drug.name);
                    }
                });
        });

        return drugNames;
    }

    addToLinearGraphData(
        linearGraphData: LinearGraphDataPoint[],
        dosageDetail: DosageDetail,
        startDate: moment.Moment,
        endDate: moment.Moment): void {
        const drugsDictionary: _.Dictionary<Drug[]> = _.groupBy(dosageDetail.drugs, 'drugType');

        const narcoticsNumber = drugsDictionary.NARCOTIC ? drugsDictionary.NARCOTIC.length : 0;
        const sedativesNumber = drugsDictionary.SEDATIVE ? drugsDictionary.SEDATIVE.length : 0;
        const stimulantNumber = drugsDictionary.STIMULANT ? drugsDictionary.STIMULANT.length : 0;
        const buprenorphineNumber = drugsDictionary.BUPRENORPHINE ? drugsDictionary.BUPRENORPHINE.length : 0;
        const othersNumber = drugsDictionary.OTHERS ? drugsDictionary.OTHERS.length : 0;

        const rxNumber = this.getShopperNumber(drugsDictionary.NARCOTIC ? drugsDictionary.NARCOTIC : [], 'prescriberDEA');
        const pharmsNumber = this.getShopperNumber(drugsDictionary.NARCOTIC ? drugsDictionary.NARCOTIC : [], 'pharmacyDEA');

        linearGraphData.push({
            label: startDate,
            mmeData: dosageDetail.mme,
            lmeData: dosageDetail.lme,
            rxNumber,
            pharmsNumber,
            narcoticsNumber,
            sedativesNumber,
            stimulantNumber,
            buprenorphineNumber,
            othersNumber
        });

        linearGraphData.push({
            label: endDate,
            mmeData: dosageDetail.mme,
            lmeData: dosageDetail.lme,
            rxNumber,
            pharmsNumber,
            narcoticsNumber,
            sedativesNumber,
            stimulantNumber,
            buprenorphineNumber,
            othersNumber
        });
    }

    private getShopperNumber(drugs: Drug[], prop: 'prescriberDEA' | 'pharmacyDEA'): number {
        let result = 0;

        const unique = drugs.map((drug: { [x: string]: any; }) => drug[prop])
            .filter((value: any, index: any, self: string | any[]) => self.indexOf(value) === index).length;

        result = result + unique;

        return result;
    }

    private addToDrugHistory(
        drugHistory: DrugHistory[],
        dosageDetail: DosageDetail,
        drugNames: string[],
        selectedDrugType: string,
        selectedPrescriber: string,
        startDate: moment.Moment,
        endDate: moment.Moment): void {

        drugNames.forEach((drugName: string, index: number) => {
            const drugNameDataPoint = drugHistory.find((d: DrugHistory) => d.name === drugName);

            if (drugNameDataPoint) {
                if (this.findDrug(dosageDetail, drugName, selectedDrugType, selectedPrescriber)) {
                    drugNameDataPoint.dataPoints.push({ label: startDate, value: (index + 1) * 10 });
                    drugNameDataPoint.dataPoints.push({ label: endDate, value: (index + 1) * 10 });
                } else {
                    drugNameDataPoint.dataPoints.push({ label: startDate, value: undefined });
                    drugNameDataPoint.dataPoints.push({ label: endDate, value: undefined });
                }
            }
        });
    }

    findDrug(dosageDetail: DosageDetail,
        drugName: string,
        selectedDrugType: string,
        selectedPrescriber: string): boolean {
        let drugsFound = dosageDetail.drugs.filter((d: Drug) => d.name === drugName);

        if (drugsFound.length && selectedDrugType !== 'All Drugs') {
            drugsFound = drugsFound.filter((d: Drug) => d.drugType === selectedDrugType);
        }

        if (selectedPrescriber !== 'All Prescribers') {
            drugsFound = drugsFound.filter((d: Drug) => d.prescriberName === selectedPrescriber);
        }

        return drugsFound.length > 0;
    }
}
