import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as Reducers from '@app/reducers';
import { addApprissReport } from '@app/reducers/doctor/doctor.actions';
import { Store } from '@ngrx/store';

import { environment } from '../../../../environments/environment';
import { DrugType } from '../../../modules/pdmp-report-dashboard/enums/drug-type.module';
import {
    DosageDetail, DrugDetail, PdmpPatient
} from '../../../modules/pdmp-report-dashboard/models/pdmp-patient.model';
import { Pharmacy } from '../../../modules/pdmp-report-dashboard/models/pharmacy.model';
import { Prescriber } from '../../../modules/pdmp-report-dashboard/models/prescriber.model';
import { RelativeUrlConfig } from '../../config/RelativeUrlConfig';
import { CommonService } from '../commonService/common.service';

@Injectable({
    providedIn: 'root'
})
export class PdmpHelperService {
    selectedPatients$: BehaviorSubject<PdmpPatient[]> = new BehaviorSubject<PdmpPatient[]>(undefined);
    dosageDetails$: BehaviorSubject<DosageDetail[]> = new BehaviorSubject<DosageDetail[]>(undefined);
    navigationState: { [k: string]: any; };

    constructor(private http: HttpClient,
        private commonService: CommonService,
        private store: Store<Reducers.State>) { }

    getPdmpPatientData(patientId: number): Observable<PdmpPatient[]> {
        return this.http.get(`${environment.reportURL}report/info/${patientId}`).pipe(
            map((data: any) => {

                const patients: PdmpPatient[] = [];

                data.patientInfos.forEach(patientInfo => {
                    patients.push({
                        patientInfo,
                        drugDetails: data.drugDetails[patientInfo.patientId]
                    });
                });

                return patients;
            }));
    }

    getDosageDetails(patientId: number, pdmpPatients: PdmpPatient[]): Observable<DosageDetail[]> {
        const patientIndexes = pdmpPatients.map((p: PdmpPatient) => p.patientInfo.patientId);

        return this.http.post<DosageDetail[]>(`${environment.reportURL}report/meta/${patientId}`, { patientIndexes });
    }

    downloadPdf(url: any, doctorId: number, patientId: number, patientName: string){
        const stopLoading = new Subject<void>();

        this.http.post(`${RelativeUrlConfig.PDMP_REPORT_PDF}`, { url }, { responseType: 'blob' }).subscribe(
            res => {
                const fileName = `${patientName}_Scriptulate_PDMPReport_${this.getCurrentDateTime().date}.pdf`;
                saveAs(res,fileName);
                this.store.dispatch(addApprissReport({
                    file_name: fileName,
                    uploaded_by_user_id: doctorId,
                    uploaded_for_user_id: patientId,
                    file_category: 'pdmp_report',
                    file_type: 'application/pdf',
                    file: res,
                }));
                this.commonService.setPDMPStatReportDownloaded(true);
                stopLoading.next();
            },
            () => stopLoading.next());
    return stopLoading.asObservable();
    }


    savePdf(url: any, doctorId: number, patientId: number, patientName: string): Observable<void> {
        const stopLoading = new Subject<void>();

        this.http.post(`${RelativeUrlConfig.PDMP_REPORT_PDF}`, { url }, { responseType: 'blob' }).subscribe(
            res => {
                const fileName = `${patientName}_Scriptulate_PDMPReport_${this.getCurrentDateTime().date}.pdf`;
                this.store.dispatch(addApprissReport({
                    file_name: fileName,
                    uploaded_by_user_id: doctorId,
                    uploaded_for_user_id: patientId,
                    file_category: 'pdmp_report',
                    file_type: 'application/pdf',
                    file: res,
                }));
                this.commonService.setPDMPStatReportDownloaded(true);
                stopLoading.next();
            },
            () => stopLoading.next());

        return stopLoading.asObservable();
    }

    groupBy(objectArray: any[], property: string): any[] {
        return Object.values(objectArray.reduce((acc: any, obj: any) => {
            const key: any = obj[property];
            if (!acc[key]) {
                acc[key] = [];
            }
            acc[key].push(obj);

            return acc;
        }, {}));
    }

    setDrugTypeRx(data: Prescriber | Pharmacy, drugDetails: DrugDetail[]): void {
        data.narcoticsRx = 0;
        data.sedativeRx = 0;
        data.stimulantRx = 0;
        data.buprenorphineRx = 0;
        data.otherRx = 0;
        data.lastRxDate = drugDetails[0].datePrescribed;
        let lastRxDateAsDate = new Date(drugDetails[0].datePrescribed);

        drugDetails.forEach((d: DrugDetail) => {
            if (new Date(d.datePrescribed) > lastRxDateAsDate) {
                data.lastRxDate = d.datePrescribed;
                lastRxDateAsDate = new Date(drugDetails[0].datePrescribed);
            }

            switch (d.drugType) {
                case DrugType.Narcotic:
                    data.narcoticsRx++;
                    break;
                case DrugType.Stimulant:
                    data.sedativeRx++;
                    break;
                case DrugType.Stimulant:
                    data.stimulantRx++;
                    break;
                case DrugType.Buprenorphine:
                    data.buprenorphineRx++;
                    break;
                default:
                    data.otherRx++;
                    break;
            }
        });
    }

    private getCurrentDateTime = () => {
        const date = new Date();
        return {
            date: `${date.getFullYear()}${date.getMonth() + 1}${date.getDate()}${date.getTime()}`,
            time: date,
        };
    }
}
