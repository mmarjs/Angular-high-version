import { Injectable } from '@angular/core';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { HttpClient } from '@angular/common/http';

export interface UploadApprissReportPdf {
	file_name: string;
	uploaded_by_user_id: number;
	uploaded_for_user_id: number;
	file_category: 'pdmp_report' | 'appriss_report' | 'checklist'|'chart_report'|'peg_score';
	file_type: string;
	file: Blob;
}

@Injectable({
	providedIn: 'root'
})
export class UploadService {
	constructor(
		private httpResourceService: HttpResourceService,
		private httpClient: HttpClient
	) {}

	generatePresignedUrl({ file_name, file_category,file_type }) {
		const url = RelativeUrlConfig.GENERATE_PRESIGNED_URL;
		return this.httpResourceService.post(url, { file_name, file_category ,file_type});
	}

	async upload({
		file_name,
		uploaded_by_user_id,
		uploaded_for_user_id,
		file_category,
		file_type,
		file
	}, id?) {
		const {body} = await this.generatePresignedUrl({ file_name, file_category,file_type }).toPromise();
		const result= this.httpClient.put(body.url,file,{
			headers: {
				'Access-Control-Allow-Origin': '*'
			}
		}).toPromise().then( async (response)=>{
			const result = await this.httpResourceService
				.post(RelativeUrlConfig.CREATE_FILE, {
					file_name: file_name,
					uploaded_by_user_id,
					uploaded_for_user_id,
					file_category,
					file_type,
					file
				})
				.toPromise();
			return { success: true, result }
		}).catch(result=>{
			return { success: false, result};
		});
		return result;
	}
}
