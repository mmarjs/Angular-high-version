import { Injectable } from '@angular/core';
import * as Pusher from 'pusher-js';
import { environment } from 'environments/environment';
import * as AlertActions from '@app/reducers/alert/alert.actions';
import * as TodoActions from '@app/reducers/todo/todo.actions';
import { getPrescriptions } from '@app/reducers/doctor/doctor.actions';
import { Store } from '@ngrx/store';
import { AuthService } from '../authService/auth.service';
import { getContracts } from '@app/reducers/contracts/contracts.actions';
import { MatDialog } from '@angular/material';
import { AlertPopupComponent } from '@app/common/modules/shared/components/alert-popup/alert-popup.component';

@Injectable({
  providedIn: 'root'
})
export class PusherService {
  private pusher: Pusher.Pusher;
  private alertChannel: any;
  private todoChannel: any;
  private prescriptionChannel: any;

  Channels = Object.freeze({
    PRESCRIPTION: 'PRESCRIPTION',
    ALERT: 'Alert',
    TODO: 'Todo'
  });

  Events = Object.freeze({
    PRESCRIPTION_SYNC: 'PRESCRIPTION_SYNC',
    PRESCRIPTION_SYNC_FAILED: 'PRESCRIPTION_SYNC_FAILED',
    ALERT_NEW: 'New',
    TODO_NEW: 'New'
  });

  constructor(
    private authService: AuthService,
    private store: Store<any>,
    private dialog: MatDialog
  ) {
    this.pusher = new Pusher(environment.pusher.key, {
      cluster: environment.pusher.cluster,
      forceTLS: true
    });
  }

  public alertsSubscribe() {
    if (this.alertChannel) {
      return;
    }

    this.alertChannel = this.pusher.subscribe(this.Channels.ALERT);

    this.alertChannel.bind(this.Events.ALERT_NEW, payload => {
      if (payload.requested_by_user_id !== this.authService.user.id) {
        return;
      }
      this.store.dispatch(AlertActions.addAlert({ payload }));
    });
  }

  public todosSubscribe() {
    if (this.todoChannel) {
      return;
    }
    this.todoChannel = this.pusher.subscribe(this.Channels.TODO);

    this.todoChannel.bind(this.Events.TODO_NEW, payload => {
      if (payload.patient_id !== this.authService.user.id) {
        return;
      }
      this.store.dispatch(TodoActions.addTodo({ payload }));
      if (payload.name === 'SIGN_CONTRACT') {
        this.store.dispatch(getContracts());
      }
    });
  }

  public subscribe(patientId: number) {
    if (!this.authService.user.id || this.prescriptionChannel)
      return;
    this.prescriptionChannel = this.pusher.subscribe(
      this.Channels.PRESCRIPTION
    );
    this.prescriptionChannel.bind(`${this.Events.PRESCRIPTION_SYNC}_${this.authService.user.id}`, msg => {
      this.store.dispatch(getPrescriptions({ patient_id: patientId }));
      this.dialog.open(AlertPopupComponent, {
        data: {
          error: false,
          message: msg
        }
      });
      this.prescriptionChannel.unbind_all();
      this.prescriptionChannel = null;
    });
    this.prescriptionChannel.bind(`${this.Events.PRESCRIPTION_SYNC_FAILED}_${this.authService.user.id}`, msg => {
      this.dialog.open(AlertPopupComponent, {
        data: {
          error: true,
          message: msg
        }
      });
      this.prescriptionChannel.unbind_all();
      this.prescriptionChannel = null;
    });
  }
}
