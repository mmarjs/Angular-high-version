import html2canvas from 'html2canvas';
import * as jspdf from 'jspdf';
import { Observable, Subject } from 'rxjs';

import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class PdfHelperService {
    generatePdf(target: any, fileName: string): Observable<jspdf> {
        const pdfSubject = new Subject<jspdf>();

        html2canvas(target, {
            allowTaint: false,
            testTaint: true,
            logging: true
        }).then(canvas => {
            const imgWidth = canvas.width;
            const imgHeight = canvas.height;

            const margin = 25;
            const pdf_w = canvas.width;
            const pdf_h = pdf_w * 1.414;

            const total = Math.ceil(canvas.height / pdf_h) - 1;

            const contentDataURL = canvas.toDataURL('image/jpeg', 0.8);
            const pdf = new jspdf('p', 'pt', [pdf_w, pdf_h]);

            const position = 0;
            pdf.addImage(
                contentDataURL,
                'JPEG',
                position + margin,
                position + margin,
                imgWidth - margin * 2,
                imgHeight - margin * 2
            );

            for (let i = 1; i <= total; i++) {
                pdf.addPage([pdf_w, pdf_h], 'p');
                pdf.addImage(
                    contentDataURL,
                    'JPEG',
                    position + margin,
                    -(pdf_h * i) + margin,
                    imgWidth - margin * 2,
                    imgHeight - margin * 2
                );
            }

            pdf.save(fileName);

            pdfSubject.next(pdf);
        }).catch(err => {
            pdfSubject.error(err);
        });

        return pdfSubject.asObservable();
    }
}
