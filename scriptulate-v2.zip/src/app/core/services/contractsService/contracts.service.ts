import { Injectable } from '@angular/core';
import { HttpResourceService } from '../httpResourceService/http-resource.service';
import { AuthService } from '../authService/auth.service';
import { Observable } from 'rxjs';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { map } from 'rxjs/operators';
import { EnvironemntConfig } from '../../../core/config/environmentConfig';

@Injectable({
  providedIn: 'root'
})
export class ContractsService {

  BASE_URL = EnvironemntConfig.BASE_URL;
  private httpService;

  constructor(private httpResourceService: HttpResourceService, private authService: AuthService) {}

  fetchContracts(): Observable<any[]> {
    return this.httpResourceService
      .get(RelativeUrlConfig.CONTRACTS,{})
      .pipe(map(res => res.body || []));
  }

  initContract(contract: any): Observable<any> {
    return this.httpResourceService.post(RelativeUrlConfig.CONTRACTS, contract).pipe(map(res => res.body));
  }

  updateContract(id: number, contract: any): Observable<any> {
    return this.httpResourceService.put(`${RelativeUrlConfig.CONTRACTS}/${id}`, contract).pipe(map(res => res.body));
  }

  getSpecificContract(doctorId: number, patientId: number) {
    return this.httpResourceService.get(`${RelativeUrlConfig.CONTRACTS}/${doctorId}/${patientId}`, {});
  }

  fetchContractsAgreements(params) {
    const url = this.BASE_URL + RelativeUrlConfig.CONTRACTS;
    return this.httpResourceService.get(url, params);
  }

  downloadContractAgreement(params) {    
    const url = EnvironemntConfig.DOWNLOAD_URL + RelativeUrlConfig.DOWNLOAD_CONTRACT + '?contractId=' + params.contractId;
    return url; //this.httpResourceService.get(url, params);
  }
}
