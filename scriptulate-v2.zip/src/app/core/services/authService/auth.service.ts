import { Inject, Injectable, InjectionToken } from '@angular/core';
import { Router } from '@angular/router';
import { reset, setToken } from '@app/reducers/auth/auth.actions';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { Store } from '@ngrx/store';
import { Observable, of, throwError } from 'rxjs';
import { StorageService } from 'ngx-webstorage-service';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { map, catchError } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material';
import { ThemeService } from 'ng2-charts';
import { EditProfileService } from '@app/common/modules/editprofile/edit-profile.service';
import { ProfileService } from '@app/modules/profile/service/profile.service';

export const MY_SESSION_STORAGE = new InjectionToken<StorageService>(
	'MY_SESSION_STORAGE'
);

const ACCESS_TOKEN = 'ACCESS_TOKEN';
const USER = 'USER';
const EXPIRES_AT = 'EXPIRES_AT';
const ID_TOKEN ='ID_TOKEN';
const EMAIL ='EMAIL';

@Injectable({
	providedIn: 'root'
})
export class AuthService {
	// Store authentication data
	expiresAt: number;
	user: any;
	authenticated: boolean;

	private me: Observable<object>;


	constructor(
		@Inject(MY_SESSION_STORAGE) private myStorage: StorageService,
		private router: Router,
		private httpResourceService: HttpResourceService,
		private store: Store<{ auth: any }>,
		private modal: NgbModal,
		private dialog: MatDialog,
		private profileService: ProfileService
	) {
		this.me = this.store.select(state => {
			if(state.auth.access_token){
				this.myStorage.set(ACCESS_TOKEN, state.auth.access_token);
			}
			if(state.auth.expiresAt){
				this.myStorage.set(EXPIRES_AT, state.auth.expiresAt);
			}
			if(state.auth.user){
				this.myStorage.set(USER,state.auth.user);
			}
			if(state.auth.id_token){
				this.myStorage.set(ID_TOKEN, state.auth.id_token);
			}
			return state.auth.user;
		});
		this.me.subscribe((user) => {
			if(user){
				this.user=user;	
				this.myStorage.set(USER,user);
			}
		});
		this.user=this.myStorage.get(USER);
	}

	getToken() {
		return this.myStorage.get(ACCESS_TOKEN);
	}

	getIDToken() {
		return this.myStorage.get(ID_TOKEN);
	}

	getEmail(){
		return this.myStorage.get(EMAIL);
	}

	 async setAuth({ access_token,id_token, expiresAt, user}) {
		this.myStorage.set(ACCESS_TOKEN, access_token);
		this.myStorage.set(EXPIRES_AT, expiresAt);
		this.myStorage.set(ID_TOKEN, id_token);
		this.myStorage.set(EMAIL, user.email);
		return await this.httpResourceService.get(RelativeUrlConfig.PROFILE,{}).toPromise().then(async ({body})=>{
			if(body){
				user=body;
				this.myStorage.set(EMAIL, user.email);
				this.myStorage.set(USER,user);
				this.store.dispatch(setToken({ access_token,id_token, user , expiresAt}));
			}else{
				return this.router.navigate(['profile']);
			}
		}).catch(async rejected=>{
			if(rejected.status==404){
				return this.router.navigate(['profile']);
			}else{
				console.log("Unexpected Error Occured:" , rejected);
				throw Error(rejected);
			}
		});
	}

	checkAuth() {
		const access_token: string = this.myStorage.get(ACCESS_TOKEN);
		const expiresAt = this.myStorage.get(EXPIRES_AT);
		const id_token = this.myStorage.get(ID_TOKEN);
		const user = this.myStorage.get(USER);
		if (!access_token || ( expiresAt && Date.now() > expiresAt) || !user) {
			return false;
		}else{
			this.store.dispatch(setToken({ access_token, id_token, user , expiresAt}));
			return true;
		}
	}

	checkTokenExpiry() {
		const access_token: string = this.myStorage.get(ACCESS_TOKEN);
		const expiresAt = this.myStorage.get(EXPIRES_AT);
		if (!access_token ||( expiresAt && Date.now() > expiresAt)) {
			return false;
		}else{
			return true;
		}
	}

	removeAuth(){
		this.myStorage.clear()
	}

	get myProfile() {
		return this.me;
	}

	get role() {
		if (!this.user) {
			return null;
		}
		return this.user.role;
	}

	get isDoctor() {
		return this.role === 'Doctor';
	}

	get isPatient() {
		return this.role === 'Patient';
	}

	get isPharmacity() {
		return this.role === 'Pharmacist';
	}
}
