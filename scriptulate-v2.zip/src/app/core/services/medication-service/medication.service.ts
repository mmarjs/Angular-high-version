import { Injectable } from '@angular/core';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { updateLoadProgress } from '@app/reducers/medication/medication.actions';
import { Store } from '@ngrx/store';
import * as BBPromise from 'bluebird';

// export const MY_DRUG_STORAGE = new InjectionToken<StorageService>(
//   'MY_DRUG_STORAGE'
// );

@Injectable({
  providedIn: 'root'
})
export class MedicationService {
  constructor(
    // @Inject(MY_DRUG_STORAGE) private myStorage: StorageService,
    private httpResourceService: HttpResourceService,
    private store: Store<any>
  ) {}

  getDrugs() {
    const url = RelativeUrlConfig.GET_DRUGLIST;
    return this.httpResourceService.get(url, {});
  }

  getICD() {
    const url = RelativeUrlConfig.GET_ICD;
    return this.httpResourceService.get(url, {});
  }

  getFrequency() {
    const url = RelativeUrlConfig.GET_FREQUENCY;
    return this.httpResourceService.get(url, {});
  }

  getDrugGroup() {
    const url = RelativeUrlConfig.GET_DRUG_GROUP;
    return this.httpResourceService.get(url, {});
  }

  async fetchAll() {
    /**const drugs = await this.getDrugs().toPromise();
    this.store.dispatch(updateLoadProgress({ progress: 25 }));
    await BBPromise.delay(200);

    const icd = await this.getICD().toPromise();
    this.store.dispatch(updateLoadProgress({ progress: 50 }));
    await BBPromise.delay(200);

    const frequency = await this.getFrequency().toPromise();
    this.store.dispatch(updateLoadProgress({ progress: 75 }));
    await BBPromise.delay(200);

    const drugGroups = await this.getDrugGroup().toPromise();
    this.store.dispatch(updateLoadProgress({ progress: 100 }));
    await BBPromise.delay(200);
    **/
    return {
    drugs: {},
    drug_icd_code: {},
    drug_frequency: {},
    drug_groups: {}
    }
  }
}
