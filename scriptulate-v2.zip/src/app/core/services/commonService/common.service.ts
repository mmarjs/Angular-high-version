import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpResourceService } from '@app/core/services/httpResourceService/http-resource.service';
import { EnvironemntConfig } from '@app/core/config/environmentConfig';
import { RelativeUrlConfig } from '@app/core/config/RelativeUrlConfig';
import { Drugs } from '@app/modules/profiledetail/drugs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  IS_EDITPROFILE: boolean;
  Role: String;
  public Checked = false;
  public DownloadedSum = false;
  public DownloadedStat = false;
  BASE_URL = EnvironemntConfig.BASE_URL;
  public patient_id;
  drugList = [];
  icd = [];
  public userExistError = false;
  public month = [];

  constructor(private httpResourceService: HttpResourceService) {
    this.month['Jan'] = '01';
    this.month['Feb'] = '02';
    this.month['Mar'] = '03';
    this.month['Apr'] = '04';
    this.month['May'] = '05';
    this.month['Jun'] = '06';
    this.month['Jul'] = '07';
    this.month['Aug'] = '08';
    this.month['Sep'] = '09';
    this.month['Oct'] = '10';
    this.month['Nov'] = '11';
    this.month['Dec'] = '12';
  }

  getDrugs(params) {
    /* if(drugList.length != 0){
      return drugList;
    }*/
    const url = this.BASE_URL + RelativeUrlConfig.GET_DRUGLIST;
    return this.httpResourceService.get(url, params);
  }

  public setRole(role) {
    //this.Role=role;
    localStorage.setItem('Role', role);
  }
  public getRole() {
    return localStorage.getItem('Role');
  }

  public setReportChecked(Checked) {    
    localStorage.setItem('summaryreportchecked', Checked);
  }
  public getReportChecked() {
    return localStorage.getItem('summaryreportchecked');    
  }

  public setPDMPSummaryReportDownloaded(DownloadedSum) {    
    localStorage.setItem('pdmpsummaryreportdownloaded', DownloadedSum);
  }
  public getPDMPSummaryReportDownloaded() {
    return localStorage.getItem('pdmpsummaryreportdownloaded');    
  }

  public setPDMPStatReportDownloaded(DownloadedStat) {    
    localStorage.setItem('pdmpstatreportdownloaded', DownloadedStat);
  }
  public getPDMPStatReportDownloaded() {
    return localStorage.getItem('pdmpstateportdownloaded');    
  }

  public changeDate(date) {
    console.log('date recvd', date);
    const fields = date.split(' ');
    // debugger;
    // var breakdate = fields[0];
    //var fields = breakdate.split('-');
    console.log('fields', fields);
    const year = fields[3];
    const month1 = fields[1];
    date = fields[2];

    const date1: string = this.month[month1] + '/' + date + '/' + year;
    return date1;
  }

  public setEditProfile() {
    this.IS_EDITPROFILE = true;
  }

  public getEditProfileValue() {
    return this.IS_EDITPROFILE;
  }

  public getDistinctResults(arr) {
    console.log('get distinct results called');
    /* const result = [];
    const map = new Map();
    for (const item of arr) {
        if(!map.has(item.drug_id)){
            map.set(item.drug_id, true);    // set any value to Map
            result.push({
                item
            });
        }
    }
    return result;*/
    const newArray = [];
    const lookupObject = {};

    for (const i in arr) {
      lookupObject[arr[i]['drug_id']] = arr[i];
    }

    for (const i in lookupObject) {
      newArray.push(lookupObject[i]);
    }
    return newArray;
  }

  getIcd(params) {
    const url = this.BASE_URL + RelativeUrlConfig.GET_ICD;
    const data = this.httpResourceService.get(url, params);
    console.log('data', data);
    return data;
  }
}
