/**
 **  Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved.
 */
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from './common/guards/auth.guard';

/**
 * @author boney.dhawan
 * @name AppRoutingModule
 * @desc contains the information regarding view to display when a user click a link
 */
const routes: Routes = [
  { path: 'login', loadChildren: './modules/login/login.module#LoginModule' },
  {
    path: 'register',
    // data: {
    //   breadcrumb: 'Register',
    // },
    loadChildren: './modules/register/register.module#RegisterModule',
  },
  {
    path: 'profile',
    // data: {
    //   breadcrumb: 'Profile',
    // },
    loadChildren: './modules/profile/profile.module#ProfileModule',
  },
  {
    path: 'createpatientprofile',
    // data: {
    //   breadcrumb: 'Patient Profile',
    // },
    loadChildren:
      './modules/createpatientprofile/createpatientprofile.module#CreatepatientprofileModule',
  },
  {
    path: 'createpharmacistprofile',
    // data: {
    //   breadcrumb: 'Pharmacist Profile',
    // },
    loadChildren:
      './modules/createpharmacistprofile/createpharmacistprofile.module#CreatepharmacistprofileModule',
  },
  {
    path: 'profilestatus',
    // data: {
    //   breadcrumb: 'Profile Status',
    // },
    loadChildren:
      './modules/profilestatus/profilestatus.module#ProfilestatusModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'pdmp-report',
    data: {
      breadcrumb: 'PDMP Report',
    },
    loadChildren: './modules/pdmp-report-dashboard/pdmp-report-dashboard.module#PdmpReportDashboardModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'id-me',
    // data: {
    //   breadcrumb: 'Me',
    // },
    loadChildren: './modules/idme/idme.module#IdmeModule'
  },
  { path: '', loadChildren: './layout/layout/layout.module#LayoutModule' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, initialNavigation: false })],
  exports: [RouterModule],
})
export class AppRoutingModule { }
