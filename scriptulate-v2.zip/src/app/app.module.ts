/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { HashLocationStrategy } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import {
  MatSnackBarModule,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
} from '@angular/material/snack-bar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MY_SESSION_STORAGE } from '@app/core/services/authService/auth.service';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { NgPipesModule } from 'ngx-pipes';
import { ToastrModule } from 'ngx-toastr';
import { SESSION_STORAGE } from 'ngx-webstorage-service';
import {
  MatButtonModule,
  MatIconModule,
} from '../../node_modules/@angular/material';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './common/guards/auth.guard';
import { ReqInterceptor } from './common/interceptors/req-interceptor';
import { ResInterceptor } from './common/interceptors/res-interceptor';
import { AuthService, CommonService } from './core/services';
import { metaReducers, reducers } from './reducers';
import { AlertEffects } from './reducers/alert/alert.effects';
import { NgxLoadingModule } from 'ngx-loading';
import { LocationStrategy } from '@angular/common';
import { ContractsEffects } from './reducers/contracts/contracts.effects';
import { TodoEffects } from './reducers/todo/todo.effects';
import { NgProgressModule } from '@ngx-progressbar/core';
import { SharedModule } from './common/modules/shared/shared.module';
import { UserIdleModule } from 'angular-user-idle';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';

/**
 * @author boney.dhawan
  @name AppModule
  @desc the root Module of application
 */
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatMenuModule,
    MatButtonModule,
    NgProgressModule,
    MatIconModule,
    ToastrModule.forRoot(),
    MatSnackBarModule,
    StoreModule.forRoot(reducers, { metaReducers }),
    EffectsModule.forRoot([AlertEffects, ContractsEffects, TodoEffects]),
    NgPipesModule,
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    NgxLoadingModule.forRoot({
      backdropBackgroundColour: 'rgba(0,0,0,0.4)',
      fullScreenBackdrop: true,
    }),
    SharedModule,
    UserIdleModule.forRoot({
      idle: environment.idle.idle,
      timeout: environment.idle.timeout,
      ping: environment.idle.ping
    }),
    NgbModalModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ReqInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ResInterceptor, multi: true },
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    { provide: MY_SESSION_STORAGE, useExisting: SESSION_STORAGE },
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } },

    AuthGuard,
    AuthService,
    CommonService,
  ],

  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
