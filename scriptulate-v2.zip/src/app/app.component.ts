/* Copyright (c) 2019-2020 Scriptulate, Inc. All rights reserved. */
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AppConfig } from '@app/core/config/appConfig';
import { AuthService } from '@app/core/services';
import { AppSession } from './core/config/appSession';
import { LoginService } from './modules/login/service/login.service';
import {
  Router,
  RouteConfigLoadStart,
  RouteConfigLoadEnd,
  ActivatedRoute,
} from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { core } from '@angular/compiler';
import { HttpParams } from '@angular/common/http';

/**
 * @author boney.dhawan
 * @name AppComponent
 * @desc the root Component of application
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = AppConfig.APP_NAME;
  public loadingRouteConfig: boolean =true;
  public count: number = null;
  public idleModalRef: any;

  @ViewChild('idle')
  idleModal: ElementRef;

  constructor(
    private loginService: LoginService,
    private authService: AuthService,
    private router: Router,
    private modal: NgbModal,
    private route: ActivatedRoute
  ) {
    this.loadingRouteConfig=true;
  }

  ngOnInit() {
    this.count = null;
    this.router.events.subscribe(event => {
      if (event instanceof RouteConfigLoadStart) {
        this.loadingRouteConfig = true;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.loadingRouteConfig = false;
      }
    });
    if(this.authService.checkAuth()){
      AppSession.loadingSpinner=true;
      this.router.navigate(['dashboard']);
    }else{
      this.loginService.initSetupAuth0();
      const httpParams = new HttpParams({ fromString:  window.location.search.split('?')[1] });
      const slientLogin = httpParams.get('silentLogin');
      if(slientLogin){
        this.loginService.login('dashboard');
      }else{
        const code: string = httpParams.get('code');
        const state: string = httpParams.get('state');
        if(!(code&&state)){
          this.router.navigate(['login']);
        }
      }
    }
  }

  getLoading(): boolean {
    return AppSession.loadingSpinner || this.loadingRouteConfig;
  }
}
