const defaultTheme = require('tailwindcss/defaultTheme');
const colors = require('tailwindcss/colors');
module.exports = {
    prefix: '',
    purge: {
      content: [
        './src/**/*.{html,ts}',
      ]
    },
    darkMode: 'class', // or 'media' or 'class'
    theme: {
      extend: {
        colors: {
          gray: colors.trueGray,
        },
        colors: {
          "bg_screen" : "#F1F4F7",
          "disabled" : "#EAEAEA",
          "selected" : "#F9FBFD",
          "sapAccentBlue": "#19ADD9",
          "sapPaleSnow": "#FBFDFE",
          "sapWhite": "#FFFFFF",
          "sapDefaultBlack": "#0E2028",
          "sapPaleGreyBlue": "#A0ACBA",
          "sapSilver": "#BBBFC5",
          "sapPaleSilver": "#DCE0E5",
          "sapGreyBlue": "#627287",
          "sapLightBlack": "#122831",
          "sapSnow": "#F9FAFC",
          "sapBrightRed": "#ff5252",
          "sapReddishOrange": "#F65E18",
          "sapJungleGreen": "#05752B",
          "sapLightGrey": "#F8F8F8",
          "sapBlackTransparent": "rgba(0,0,0, 0.4)",
          "sapBrightRedHover": "#ad0d0d",
          "sapAccentBlueHover": "#1489ab",
          "darkMode-gray-0": "#1B1D23",
          "darkMode-gray-1" : "#272A32",
          "darkMode-gray-2" : "#2F323C",
          "darkMode-gray-3" : "#32353C",
          "darkMode-gray-4" : "#3D414D",          
        },
        fontFamily: {
          sans: ['Inter var', ...defaultTheme.fontFamily.sans],
        },
      },
    },
    variants: {
      extend: {},
    },
    plugins: [require('@tailwindcss/aspect-ratio'),require('@tailwindcss/forms'),require('@tailwindcss/line-clamp'),require('@tailwindcss/typography')],
};
