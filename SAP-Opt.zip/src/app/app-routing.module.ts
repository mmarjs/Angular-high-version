import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginGuardService as LoginGuard } from './guards/login-guard.service';
import { CheckBillingService as BillGuard } from './guards/billing-guard.service';

const routes: Routes = [
  {
    path: 'login',
    canActivate: [LoginGuard],
    loadChildren: () => import('./components/authentication/email-password/email-password.module').then(mod => mod.EmailPasswordModule),
  },
  {
    path: 'folders',
    canActivate: [BillGuard],
    loadChildren: () => import('./screens/folders-projects/folders-projects.module').then(mod => mod.FoldersProjectsModule),
  },
  {
    path: 'folders/:folder_id/projects/:project_id',
    canActivate: [BillGuard],
    loadChildren: () => import('./screens/projects-project-summary/projects-project-summary.module').then(mod => mod.ProjectsProjectSummaryModule),
  },
  {
    path: 'folders/:folder_id/projects/:project_id/summary',
    canActivate: [BillGuard],
    loadChildren: () => import('./screens/project-summary-children/project-summary-children.module').then(mod => mod.ProjectSummaryChildrenModule),
  },
  {
    path: 'folders/:folder_id/projects/:project_id/summary/issues/:issue_id',
    canActivate: [BillGuard],
    loadChildren: () => import('./screens/issues-list-issues-edit/issues-list-issues-edit.module').then(mod => mod.IssuesListIssuesEditModule),
  },
  {
    path: 'folders/:folder_id/projects/:project_id/summary/issues/:issue_id/:image_id',
    canActivate: [BillGuard],
    loadChildren: () => import('./components/issues/annotations/annotations.module').then(mod => mod.AnnotationsModule),
  },
  {
    path: 'folders/:folder_id/projects/:project_id/summary/report',
    canActivate: [BillGuard],
    loadChildren: () => import('./components/reports/report-landing/report-landing.module').then(mod => mod.ReportLandingModule),
  },
  {
    path: 'settings',
    canActivate: [BillGuard],
    loadChildren: () => import('./components/settings/settings.module').then(mod => mod.SettingsModule),
  },
  {
    path: 'account',
    canActivate: [BillGuard],
    loadChildren: () => import('./components/account/account.module').then(mod => mod.AccountModule),
  },
  {
    path: 'resetpassword',
    loadChildren: () => import('./components/authentication/forgot-password/forgot-password.module').then(mod => mod.ForgotPasswordModule),
  },
  { 
    path: 'locked', 
    loadChildren: () => import('./components/billing/billing-locked/billing-locked.module').then(mod => mod.BillingLockedModule),
  },
  { 
    path: 'resubscribe', 
    loadChildren: () => import('./components/billing/billing-resubscribe/billing-resubscribe.module').then(mod => mod.BillingResubscribeModule),
  },


  // User Management
  {
    path: 'usermanagement',
    loadChildren: () => import('./components/authentication/user-management/user-management.module').then(mod => mod.UserManagementModule),
  },

  { path: '', redirectTo: 'login', pathMatch: 'full' },

  {
    path: '',
    redirectTo: 'folders',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
