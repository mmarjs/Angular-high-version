import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { AuthService } from '../services/authentication/auth.service';
import { AuthGuardService } from './auth-guard.service';
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})

export class CheckBillingService implements CanActivate {

  private userBillingDocRef: AngularFirestoreDocument<any>;
  userBilling: Observable<any>;
  userId: any;

  constructor(
    private auth: AngularFireAuth,
    private authService: AuthService,
    private router: Router,
    private _authGuard: AuthGuardService,
    private readonly afs: AngularFirestore
  ) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
    return new Observable(observer => {
      this._authGuard.canActivate(route, state).subscribe((auth: boolean) => {
        if(!auth) {
          observer.next(false);
        } else {
            this.getUserID().then((result) => {
            if(result) this.userId = result;
            this.userBillingDocRef = this.afs.doc(`user_status/${this.userId}`);
            this.userBilling = this.userBillingDocRef.snapshotChanges();
            this.userBilling.subscribe((value) => {
              const data = value.payload.data();
              if(data){
                if (data.account_status === "Active") {
                  observer.next(true);
                }
                if (data.account_status === "Inactive") {
                  this.router.navigate(['resubscribe']);
                  observer.next(false);
                }
                if (data.account_status === "Locked") {
                  this.router.navigate(['locked']);
                  observer.next(false);
                }
              }
            })
          });
        }
      });
    })
    
  }

  async getUserID(){
    const user = await this.authService.getUserID()
    if (user) {
      return user.uid;
    }
  }

}
