import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';


//testing
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/auth';

import { map, take, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class AuthGuardService implements CanActivate {

  authGuardStateURL: string;

  constructor(
    private router: Router,
    private auth: AngularFireAuth
  ) { }


 canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot): Observable<boolean> {

      this.authGuardStateURL = state.url;

      return this.auth.authState.pipe(
        take(1),
        map(authState => !!authState),
        tap(auth => !auth ? this.router.navigate(['/login']) : true)
      )
   }
  
}

