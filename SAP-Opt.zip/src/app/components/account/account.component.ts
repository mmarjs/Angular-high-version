import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from '../../services/authentication/auth.service';
import { AccountService } from '../../services/account/account.service';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs';
import { UserStatistics } from '../../interfaces/user-statistics';
import { UserBilling } from '../../interfaces/user-billing';
import { Router } from '@angular/router';
import { FoldersService } from '../../services/folders/folders.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import axios from 'axios';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit, OnDestroy {

  // Subscriptions
  private _userSubscription: Subscription;
  private _requestDataSubscription: Subscription;

  // Firebase Database
  db = firebase.firestore();

  // Firestore Objects
  userBilling = {};
  userStatistics = {};

  // Request User Data
  dataExport_overlay: boolean = false;

  // User
  user_id: string;

  constructor(
    public authService: AuthService,
    public accountService: AccountService,
    public foldersService: FoldersService,
    private router: Router,
  ) {}

  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * Call "getUserID" to fetch the users id
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.getUserID();
    this.foldersService.storeRoute(this.router.url);
  }



  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Unsubscribe from the "_userSubscription"
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._userSubscription?.unsubscribe();
  }



  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call all functions related to the users account
  -----------------------------------------------------------------------------------------*/
  async getUserID(){
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getUserData(user.uid);
      this.getUserSubscriptionData(user.uid);
      this.getUserStatisticsData(user.uid);
      this.accountService.getExistingDataDump(user.uid);
    }
  }
  
  
  
  /**----------------------------------------------------------------------------------------
  * Get User Date
  * * Call "getUserData" and populate the form and behavior subject
  -----------------------------------------------------------------------------------------*/
  getUserData(user_id){
    this._userSubscription = this.accountService.getUserData(user_id).subscribe(data => {
      if (data) {
        this.accountService.userForm.reset();
        this.accountService.user$.next(data);
        this.accountService.userForm.patchValue(data);
      }
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get User Subscription Data
  * * Update "userSubscriptionData" observable to use in HTML
  -----------------------------------------------------------------------------------------*/
  getUserSubscriptionData(user_id){
    var docRef = this.db.collection('user_billing').doc(`${user_id}`);
    docRef.get().then((doc) => {
      if (doc.exists) {
        const data = doc.data() as UserBilling;
        this.userBilling = data;
      }
    }).catch((error) => {
      console.log("Error getting document:", error);
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get User Statistics Data
  * * Update "userStatistics" observable to use in HTML
  -----------------------------------------------------------------------------------------*/
  getUserStatisticsData(user_id: string) {
    var docRef = this.db.collection('user_stats').doc(`${user_id}`);
    docRef.get().then((doc) => {
      if (doc.exists) {
        const data = doc.data() as UserStatistics;
        this.userStatistics = data;
      }
    }).catch((error) => {
      console.log("Error getting document:", error);
    });
  }



  /**----------------------------------------------------------------------------------------
  * Format Statistics
  * * Called via the HTML to return storage allowance / used stats
  -----------------------------------------------------------------------------------------*/
  formatBytes(bytes, decimals) {
    if (bytes == 0) return '0 Bytes';
    var k = 1024,
      dm = decimals || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }


  



    
  /**----------------------------------------------------------------------------------------
  * Request User Data
  * * Display the overlay and set the in-progress element to true
  * * Update the status before the document is written
  * * Post to the defined URL with the users ID token
  * * Call 'requestUserData' from the Accounts Service and subscribe to the updates
  * * Update the status and apply changes based on the result
  * * If there's an error, call 'assignDataExportErrorMessage' to assign error messages
  * * After completion, unsubscribe
  -----------------------------------------------------------------------------------------*/
  async requestUserData() {

    this.dataExport_overlay = true;
    this.accountService.dataExport_progressElement = true;
    this.accountService.dataExport_status = 'Pending';

    const idToken = await firebase.auth().currentUser.getIdToken(true);

    type Response = {
      exportId: string;
    }

    let cloudServicesURL = environment.production ? "https://main-pwz6sst7ka-ew.a.run.app" : "https://main-wf57supnuq-ew.a.run.app";

     const { data: response } = await axios.request<Response>({
      url: cloudServicesURL + '/v1/export_user_data/' + environment.firebase.projectId,
      method: 'POST',
      headers: {
        Authorization: `Bearer ${idToken}`,
      },
      data: {},
    });    

    const { exportId } = response;


    this._requestDataSubscription = this.accountService.requestUserData(this.user_id, exportId).subscribe(doc => {
      if (doc) {
        var status = doc.status;
        this.accountService.dataExport_status = status;
        switch (doc.status) {
          case 'pending':
            break;
          case 'running':
            break;
          case 'error':
            this.accountService.dataExport_error_message = "Something went wrong while your data was being exported";
            break;
          case 'done':
            this.accountService.dataExport_progressElement = false;
            this.accountService.dataExport_hasRecentExport = true;
            this.accountService.dataExport_dataURL = doc.url;
            this.accountService.dataExport_error_message = '';
            this._requestDataSubscription?.unsubscribe();
            break;       
          default:
            break;
        }
      }
    });
   
  }


  



  
  /**----------------------------------------------------------------------------------------
  * Hide Request Data overlay
  * * Close overlay when the data is downloaded
  -----------------------------------------------------------------------------------------*/
  resetRequestData(){
    this.dataExport_overlay = false;
  }




}
