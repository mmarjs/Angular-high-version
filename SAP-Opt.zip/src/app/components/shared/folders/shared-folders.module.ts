import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoldersComponent } from '../../folders/folders.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [FoldersComponent],
  imports: [ CommonModule, RouterModule, FormsModule, ReactiveFormsModule ],
  exports: [ FoldersComponent, RouterModule, FormsModule, ReactiveFormsModule ]
})

export class SharedFoldersModule { }



