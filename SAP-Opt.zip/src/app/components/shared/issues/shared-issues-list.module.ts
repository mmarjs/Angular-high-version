import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssuesListComponent } from '../../issues/issues-list/issues-list.component';
import { RouterModule } from '@angular/router';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { SharedDropzoneModule } from '../../shared/dropzone/shared-dropzone.module';
import { IssueMultiaddModule } from '../../issues/issue-multiadd/issue-multiadd.module'
import { IncorrectFileTypeModule } from '../../shared/incorrect-file-type/incorrect-file-type.module'
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';

@NgModule({
  declarations: [IssuesListComponent],
  imports: [
    CommonModule,
    RouterModule,
    DragDropModule,
    SharedDropzoneModule,
    IssueMultiaddModule,
    IncorrectFileTypeModule,
    FormsModule,
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatNativeDateModule,
  ],
  exports: [ IssuesListComponent, RouterModule, DragDropModule, FormsModule ]
})

export class SharedIssuesListModule { }








