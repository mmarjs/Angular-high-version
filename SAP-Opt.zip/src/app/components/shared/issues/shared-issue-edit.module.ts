import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssueEditComponent } from '../../issues/issue-edit/issue-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { SharedDropzoneModule } from '../../shared/dropzone/shared-dropzone.module';
import { ImageUploadModule } from '../../../components/image-upload/image-upload.module';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { SortablejsModule } from 'ngx-sortablejs';
import { RouterModule } from '@angular/router';
import { ImageCropperModule } from 'ngx-image-cropper';
import { IncorrectFileTypeModule } from '../../shared/incorrect-file-type/incorrect-file-type.module'

@NgModule({
  declarations: [IssueEditComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatNativeDateModule,
    SharedDropzoneModule,
    ImageUploadModule,
    DragDropModule,
    SortablejsModule,
    RouterModule,
    ImageCropperModule,
    IncorrectFileTypeModule
  ],
  exports: [ 
    IssueEditComponent,
    FormsModule,
    ReactiveFormsModule,
    ImageUploadModule,
    DragDropModule,
    SortablejsModule,
    RouterModule
  ]
})
export class SharedIssueEditModule { }
