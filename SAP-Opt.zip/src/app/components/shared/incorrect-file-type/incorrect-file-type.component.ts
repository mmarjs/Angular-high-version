import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-incorrect-file-type',
  templateUrl: './incorrect-file-type.component.html',
  styleUrls: ['./incorrect-file-type.component.scss']
})
export class IncorrectFileTypeComponent implements OnInit {

  @Input() incorrect_file_type_names

  constructor() { }

  ngOnInit(): void {
  }

}
