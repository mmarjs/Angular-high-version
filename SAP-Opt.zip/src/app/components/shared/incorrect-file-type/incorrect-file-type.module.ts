import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IncorrectFileTypeComponent } from './incorrect-file-type.component';



@NgModule({
  declarations: [IncorrectFileTypeComponent],
  imports: [
    CommonModule
  ],
  exports : [
    IncorrectFileTypeComponent
  ]
})
export class IncorrectFileTypeModule { }
