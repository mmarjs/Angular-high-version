import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportSettingsComponent } from './report-settings.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ColorPickerModule } from 'ngx-color-picker';

@NgModule({
  declarations: [ReportSettingsComponent],
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    ColorPickerModule
  ],
  exports: [ReportSettingsComponent]
})

export class ReportSettingsModule { }
