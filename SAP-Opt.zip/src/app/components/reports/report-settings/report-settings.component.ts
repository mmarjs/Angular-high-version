import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/authentication/auth.service';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { HelperService } from '../../../services/helper/helper.service';
import { Subscription } from 'rxjs';
import { ReportsService } from '../../../services/reports/reports.service';
import { FontsService } from '../../../services/reports/fonts.service';
import { ThemesService } from '../../../services/reports/themes.service';
import { CsvService } from '../../../services/reports/csv.service';
import { ColorPickerService, Rgba } from 'ngx-color-picker';
export class Cmyk {
  constructor(public c: number, public m: number, public y: number, public k: number) { }
}

@Component({
  selector: 'app-report-settings',
  templateUrl: './report-settings.component.html',
  styleUrls: ['./report-settings.component.scss']
})
export class ReportSettingsComponent implements OnInit, OnDestroy {

  // User Settings Subscription
  private _subscription: Subscription;

  // Issues Selection
  issueChoice = ['All Issues', 'Complete Issues Only', 'Incomplete Issues Only'];

  // Colour Plugin
  public cmyk: Cmyk = new Cmyk(0, 0, 0, 0);

  // Colour Toggles
  primaryColourToggle: boolean = false;
  textColourToggle: boolean = false;
  subTextColourToggle: boolean = false;

  // Photo & Text Sizes
  photoSizes = ['Small', 'Regular', 'Large', 'Extra Large'];
  textSizes = ['Small', 'Regular', 'Large', 'Extra Large'];

  // Classic Font Choices
  fonts = ["Default", "Traditional", "Typewriter"];

  // Themes array
  themesArray = [{ order: 0, title: "classic" }, { order: 1, title: "modern & bold" }, { order: 2, title: "bright" }, { order: 3, title: "corporate" }, { order: 4, title: "minimal" }, { order: 5, title: "photographic" }, { order: 6, title: "financial" }, { order: 7, title: "basic" }, { order: 8, title: "backdrop" }, { order: 9, title: "circular" }];

  // User Settings
  userSettings: any = {};

  constructor(
    public router: Router,
    public authService: AuthService,
    public userSettingsService: UserSettingsService,
    private cpService: ColorPickerService,
    public reportsService: ReportsService,
    public helperService: HelperService,
    public fontsService: FontsService,
    public themesService: ThemesService,
    public csvService: CsvService,
  ) {
  }


  /**----------------------------------------------------------------------------------------
* ngOnInIt
* * Call "getUserID" to fetch the users id
-----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.getUserID();
    this.userSettings = this.helperService.getUserSettings();
  }



  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Unsubscribe from the "_userSubscription"
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._subscription.unsubscribe();
  }



  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getUserSettings"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.getUserSettings(user.uid);
    }
  }



  /**----------------------------------------------------------------------------------------
  * Get User Settings
  * * Set the user settings into local storage
  * * Update the user settings form and behaviour subject
  -----------------------------------------------------------------------------------------*/
  getUserSettings(user_id: string) {
    this._subscription = this.userSettingsService.getUserSettings(user_id).subscribe(settings => {
      if (settings) {
        this.userSettingsService.settings$.next(settings);
        this.userSettingsService.allSettingsForm.reset();
        this.userSettingsService.allSettingsForm.patchValue(settings);
        this.setCustomColours(settings.usersetting_primaryColour, settings.usersetting_headerColour, settings.usersetting_subHeaderColour)
        if(settings.usersetting_companylogo){
          this.userSettingsService.getCompanyLogoURL(settings.usersetting_companylogo);
        }
      }
    });
  }


  // Set the global colour variables based on the users saved settings
  setCustomColours(usersetting_primaryColour: string, usersetting_headerColour: string, usersetting_subHeaderColour: string) {
    document.documentElement.style.setProperty('--usersetting_primaryColour', usersetting_primaryColour);
    document.documentElement.style.setProperty('--usersetting_headerColour', usersetting_headerColour);
    document.documentElement.style.setProperty('--usersetting_subHeaderColour', usersetting_subHeaderColour);
  }

  // Update Colour Primary
  updateColourPrimary(primaryColour: string) {
    this.userSettingsService.allSettingsForm.controls['usersetting_primaryColour'].setValue(primaryColour);
    document.documentElement.style.setProperty('--usersetting_primaryColour', primaryColour);
  }

  // Update Colour Secondary
  updateTextPrimary(secondaryColour: string) {
    this.userSettingsService.allSettingsForm.controls['usersetting_headerColour'].setValue(secondaryColour);
    document.documentElement.style.setProperty('--usersetting_headerColour', secondaryColour);
  }

  // Update Colour Tertiary
  updateSubTextColour(tertiaryColour: string) {
    this.userSettingsService.allSettingsForm.controls['usersetting_subHeaderColour'].setValue(tertiaryColour);
    document.documentElement.style.setProperty('--usersetting_subHeaderColour', tertiaryColour);
  }

  // Change Colour conversion
  onChangeColor(color: string): Cmyk {
    return this.rgbaToCmyk(this.cpService.hsvaToRgba(this.cpService.stringToHsva(color)));
  }
  rgbaToCmyk(rgba: Rgba): Cmyk {
    let cmyk: Cmyk = new Cmyk(0, 0, 0, 0), k: number;
    k = 1 - Math.max(rgba.r, rgba.g, rgba.b);
    if (k == 1) return new Cmyk(0, 0, 0, 1);
    cmyk.c = (1 - rgba.r - k) / (1 - k);
    cmyk.m = (1 - rgba.g - k) / (1 - k);
    cmyk.y = (1 - rgba.b - k) / (1 - k);
    cmyk.k = k;

    return cmyk;
  }



}
