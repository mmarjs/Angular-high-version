import { Component, OnDestroy, OnInit } from '@angular/core';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IssuesListService } from '../../../services/issues/issues-list.service';
import { IssueEditService } from '../../../services/issues/issue-edit.service';
import { ProjectDetailService } from '../../../services/projects/project-detail.service';
import { switchMap, tap } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../services/authentication/auth.service';
import { HelperService } from '../../../services/helper/helper.service';
// import { Project } from '../../../interfaces/project';
import { FontsService } from '../../../services/reports/fonts.service';
import { ThemesService } from '../../../services/reports/themes.service';
import { CsvService } from '../../../services/reports/csv.service';
import { environment } from '../../../../environments/environment';
import { ReportsService } from '../../../services/reports/reports.service';
import { AnnotationsService } from '../../../services/issues/annotations.service';
import firebase from 'firebase/app';
import { BehaviorSubject } from 'rxjs';
import { AngularFirestore } from '@angular/fire/firestore';
import { FoldersService } from '../../../services/folders/folders.service';
import axios from 'axios';

@Component({
  selector: 'app-report-landing',
  templateUrl: './report-landing.component.html',
  styleUrls: ['./report-landing.component.scss']
})
export class ReportLandingComponent implements OnInit, OnDestroy {

  // Issues List
  private _issuesSubscription: Subscription;
  // issuesArray = [];

  // Images
  private _imagesSubscription: Subscription;

  // Project
  private _projectSubscription: Subscription;

  private _subscription: Subscription;

  // Commands Subscription
  private _commandSubscription: Subscription

  // User ID
  user_id: string

  // URL Params
  folder_id: string;
  project_id: string;
  issues: any = {};
  images: any = {};


  // Front Cover Values
  project;

  // User Settings
  userSettings: any = {};

  // Loader
  loading: boolean = true;
  loading_issues: boolean = false;

  // Report Generation
  overlay_report: boolean = false;
  reportUrl: string;


  // Theme Fonts
  font_default: string;
  font_PTSansRegular: string;
  font_PTSansBold: string;
  font_RobotoRegular: string;
  font_OpenSans: string;
  font_OpenSansSemibold: string;
  font_Montserrat: string;
  font_CrimsonTextRoman: string;
  font_CrimsonTextRomanSemiBold: string;
  font_MarkerFelt: string;
  font_AvenirNextBold: string;
  font_AvenirNextRegular: string;

  constructor(
    public userSettingsService: UserSettingsService,
    private _activatedRoute: ActivatedRoute,
    public issuesListService: IssuesListService,
    public issueEditService: IssueEditService,
    public projectDetailService: ProjectDetailService,
    public authService: AuthService,
    private helperService: HelperService,
    public fontsService: FontsService,
    public themesService: ThemesService,
    public reportsService: ReportsService,
    public annotationsService: AnnotationsService,
    public csvService: CsvService,
    private afs: AngularFirestore,
    public foldersService: FoldersService,
    private router: Router
  ) { }

  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "getUserID"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.userSettings = this.helperService.getUserSettings();
    
    this.getUserID();
    this.setCustomFonts();
    this.foldersService.storeRoute(this.router.url);
    this.reportsService.incompleteIssues = 0;
    this.setClassicFont();
  }

  
  
  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the issues subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._issuesSubscription?.unsubscribe();
    this._imagesSubscription?.unsubscribe();
    this._projectSubscription?.unsubscribe();
    this._subscription?.unsubscribe();
    this.reportsService.showPDF = true;
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getIssues(user.uid);
      this.getProjectDetail(user.uid);
    }
  }


  
  /**----------------------------------------------------------------------------------------
  * Get Project Detail
  * * Grab the URL params for the folder and project
  * * Call the project service to obtain the selected project data
  * * Update 'project' variable to the returned project
  * * Set the loading indicator to false
  -----------------------------------------------------------------------------------------*/
  getProjectDetail(user_id: string) {
    this._projectSubscription = this._activatedRoute.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.projectDetailService.getProject(user_id, params.project_id)
      })
    ).subscribe(project => {
      this.project = project;
      this.loading = false;
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get Issues
  * * Grab the URL params for the folder and project
  * * Call the issues service to obtain the issues related to the selected project
  * * Update 'issues' variable to the returned issues
  * * For each issue that isn't complete, increment the 'incompleteIssues' value (front cover attribute)
  * * For each issue, call the 'getImagesPerIssue' function to apply the images to each issue
  * * Set 'loading_issues' to false 
  -----------------------------------------------------------------------------------------*/
  getIssues(user_id: string) {
    this._issuesSubscription = this._activatedRoute.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.issuesListService.getIssues(user_id, params.project_id);
      })
    ).subscribe(issues => {
      this.issues = issues;
      this.issues.map((issue) => {
        if (!issue.issue_completed) {
          this.reportsService.incompleteIssues++
        }
        this.getImagesPerIssue(user_id, this.project_id, issue.id).subscribe((result) => {
          issue.images = result;
        });
        return issue;
      })
      this.loading_issues = true;
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get Images Per Issue
  * * Called from the 'Get Issues' function
  * * Call the 'getIssueImages' function and subscribe
  * * Update the 'images' variable to the returned results
  * * Loop through each image to obtain any urls / references for annotations
  -----------------------------------------------------------------------------------------*/
  getImagesPerIssue(userId: string, projectId: string, issueId: string) {
    var subject = new BehaviorSubject<Array<{}>>([]);
    this._imagesSubscription = this.issueEditService.getIssueImages(userId, projectId, issueId).subscribe((images) => {
      this.images = images;
      this.images.map((image) => {
        this.getAnnotationImageURL(userId, projectId, issueId, image.id).subscribe((result) => {
          image.annotationURL = result;
        });
        return image;
      })
      subject.next(this.images);
    })
    return subject.asObservable();
  }



  /**----------------------------------------------------------------------------------------
  * Get Annotation Image URL
  * * Called from the 'getImagesPerIssue' function
  * * Call the 'getPhoto' function from the 'annotationsService' service
  * * If a result is found, update the `annotationURL' variable to return
  -----------------------------------------------------------------------------------------*/
  getAnnotationImageURL(userId: string, projectId: string, issueId: string, imageId: string) {
    var annotationURL = '';
    var subject = new BehaviorSubject<string>('');
    this._subscription = this.annotationsService.getPhoto(userId, projectId, issueId, imageId).subscribe(async (result) => {
      if (result.image_annotations) {
        annotationURL = await this.getAnnotationDownloadURL(result.image_annotations);
      }
      subject.next(annotationURL);
    })
    return subject.asObservable();
  }



  /**----------------------------------------------------------------------------------------
  * Get Annotation Download URL
  * * Called from the 'getAnnotationImageURL' function
  * * A reference is passed into the function
  * * The reference is used to call the 'getDownload' function
  * * The URL is returned for the 'getAnnotationImageURL' function
  -----------------------------------------------------------------------------------------*/
  async getAnnotationDownloadURL(reference) {
    var storage = firebase.storage();
    var annotatedImageReference = reference;
    var annotatedImagePathReference = storage.ref().child(annotatedImageReference);
    const url = await annotatedImagePathReference.getDownloadURL();
    return url;
  }



  /**----------------------------------------------------------------------------------------
  * Set Custom Fonts
  * * For each font variable, call 'fontsService.getCustomFont' with the font name as the param
  -----------------------------------------------------------------------------------------*/
  setCustomFonts() {
    this.font_default = this.fontsService.getCustomFont("font_default");
    this.font_PTSansRegular = this.fontsService.getCustomFont("font_PTSansRegular");
    this.font_PTSansBold = this.fontsService.getCustomFont("font_PTSansBold");
    this.font_RobotoRegular = this.fontsService.getCustomFont("font_RobotoRegular");
    this.font_OpenSans = this.fontsService.getCustomFont("font_OpenSans");
    this.font_OpenSansSemibold = this.fontsService.getCustomFont("font_OpenSans-Semibold");
    this.font_Montserrat = this.fontsService.getCustomFont("font_Montserrat");
    this.font_CrimsonTextRoman = this.fontsService.getCustomFont("font_CrimsonTextRoman");
    this.font_CrimsonTextRomanSemiBold = this.fontsService.getCustomFont("font_CrimsonTextRomanSemiBold");
    this.font_MarkerFelt = this.fontsService.getCustomFont("font_MarkerFelt");
    this.font_AvenirNextBold = this.fontsService.getCustomFont("font_AvenirNextBold");
    this.font_AvenirNextRegular = this.fontsService.getCustomFont("font_AvenirNextRegular");
  }



  /**----------------------------------------------------------------------------------------
  * Set Classic Font
  * * Obtain the users saved setting for report font
  * * Send the value to the fonts service to set the appropriate class name
  -----------------------------------------------------------------------------------------*/
  setClassicFont(){
    const usersetting = this.helperService.getSingleUserSetting('usersetting_reportfont', 0);
    this.fontsService.setClassicCustomFont(usersetting);
  }



  /**----------------------------------------------------------------------------------------
  * Export PDF or Zip
  * * Toggles a value that's used to determine which function should be called when...
  * * ...generating a report (either PDF or CSV)
  -----------------------------------------------------------------------------------------*/
  exportPDFOrZIP(){
    this.reportsService.showPDF ? this.getReportString() : this.csvService.downLoadCSVFile();
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Generate Report String
  * * Ensure the overlay is set to true to display generating loader
  * * Reset the `reportUrl` string
  * * Check the state of the front cover toggle. If it's true:
  * * - Get the cover HTML ID and obtain the inner html and set the cover variable
  * * - Set the 'coverStyles' value by calling 'getCoverStyles' to return cover styles
  * * Get the main report HTML ID, set the inner HTML and obtain selected theme styles
  * * Set all fonts to be loaded (This could probably be optimised to only return necessary ones)
  * * Set values for pageStyles, commonStyles, customStyles, cssVariableStyles, bodyReset
  * * Create a 'coverHTML' html structure that includes all styles and cover HTML string
  * * Create a 'contentHTML' html structure that includes 
  * * set ID token to the signed in user
  * * Request data via URL and project id
  * * The data object contains everything required to generate a report (title, content, cover, page numbers boolean and custom words)
  * * If statement to determine if the URL has returned. If it has, save all the report settings and update the reportUrl variable
  -----------------------------------------------------------------------------------------*/
  async getReportString() {

    this.overlay_report = true;
    this.reportUrl = '';

    // Determine the state of the front cover toggle
    // If true, create a variable for the theme cover HTML
    // Get the cover styles
    if (this.userSettingsService.allSettingsForm.value.usersetting_include_frontcover) {
      var coverPreviewHTML = document.getElementById("themeCover");
      var coverPreviewInnerHTML: string;
      coverPreviewInnerHTML = coverPreviewHTML.innerHTML;
      var coverStyles = this.themesService.getCoverStyles(this.userSettingsService.allSettingsForm.value.usersetting_theme);
    }

    // Theme content HTML amd Content Styles
    var contentPreviewHTML = document.getElementById("themeContent");
    var contentPreviewInnerHTML: string;
    contentPreviewInnerHTML = contentPreviewHTML.innerHTML;
    var contentStyles = this.themesService.getContentStyles(this.userSettingsService.allSettingsForm.value.usersetting_theme);

    // Set the fonts required
    const fonts = this.font_default + this.font_PTSansRegular + this.font_PTSansBold + this.font_RobotoRegular + this.font_OpenSans + this.font_OpenSansSemibold + this.font_Montserrat + this.font_CrimsonTextRoman + this.font_CrimsonTextRomanSemiBold + this.font_MarkerFelt + this.font_AvenirNextBold + this.font_AvenirNextRegular;

    // Set the Page Styles for DocRaptor
    const pageStyles = '@page{padding:0.45in 0 0.20in 0;box-sizing:border-box;@bottom{color:#627287; padding-bottom:60px; padding-right: 60px; text-align:right; font-size: 0.75rem;; font-family: ' + "sans-serif" + '; content: "' + this.helperService.getUserSettings().usersetting_page + '  ' + '"counter(page)"' + '  ' + this.helperService.getUserSettings().usersetting_of + '  ' + '"counter(pages)"' + '" }}@page:first {padding: 0 !important; @bottom {content:normal;}}';

    // Set the Common styles for each theme
    const commonStyles = '.reportWrapper{width:612pt;height:auto;float:left}#issue__content{width:100%;float:left;word-break:break-word}.issue__content__header{page-break-inside:avoid!important;page-break-after:avoid!important}#cover-wrap{height:792pt;width:612pt;position:relative;padding:62pt 50pt 45pt;box-sizing:border-box}#cover-basics-wrap{width:100%;float:left;padding:0;box-sizing:border-box}.issue__container{width:100%;box-sizing:border-box;float:left;padding:0 .75in}.issue__image{page-break-inside:avoid!important;page-break-after:avoid!important}.issue-sep{width:100%;float:left}.issue__wrapper:last-of-type .issue-sep{display:none}.issue__border{width:100%;float:left}.issue__image__number{position:absolute;color:#fff;background:rgba(0,0,0,.4);border-radius:50%;box-sizing:border-box;width:22pt;height:22pt;text-align:center;padding-top:2pt;z-index:2}.issue__image__wrapper{float:left;margin:0 20pt 0 0;overflow:hidden;border:none}.issue__image__wrapper .issue__image{display:inline-block;position:relative;border:none}.issue__image__wrapper img{float:right}.issue__image__wrapper .issue__timestamp{position:absolute;bottom:4px;right:13px;color:#eee;font-size:8pt;font-weight:700;text-shadow:0 1px 0 #111;letter-spacing:-.02em}.issue__image__wrapper .image__annotated{position:absolute;top:0;right:0}.issue__image__wrapper .issue__image__number{right:8pt;top:8pt}.issue__image__wrapper--multi{width:100%;float:left;margin:0 20pt 5pt 0}.issue__image__wrapper--multi .issue__image{width:auto;vertical-align:top;border:none}.issue__image__wrapper--multi .image{float:left;margin:20pt 10pt 5px 0}.issue__image__wrapper--multi .issue__timestamp{bottom:8px;right:26px}.issue__image__wrapper--multi .issue__image__number{right:18pt;top:28pt}.issueSingle{display:table}.issueSingle .issue__content{width:100%;display:table-cell;vertical-align:top}pre{white-space:pre-line;margin:0}.signature{width:100pt;height:46pt}';

    // Set Custom Styles
    const customStyles = '.text_size_0 .issue__title{font-size:10.83pt}.text_size_0 .issue__sub,.text_size_0 .issue__sub>span,.text_size_0 .issue__comments{font-size:10pt}.text_size_1 .issue__title{font-size:12.996pt}.text_size_1 .issue__sub,.text_size_1 .issue__sub>span,.text_size_1 .issue__comments{font-size:12pt}.text_size_2 .issue__title{font-size:15.162pt}.text_size_2 .issue__sub,.text_size_2 .issue__sub>span,.text_size_2 .issue__comments{font-size:14pt}.text_size_3 .issue__title{font-size:17.328pt}.text_size_3 .issue__sub,.text_size_3 .issue__sub>span,.text_size_3 .issue__comments{font-size:16pt}.photo_0{width:90pt}.photo_0 img{width:90pt}.photo_1{width:138pt}.photo_1 img{width:138pt}.photo_2{width:180pt}.photo_2 img{width:180pt}.photo_3{width:225pt}.photo_3 img{width:225pt}';

    // Set the values for the CSS variables
    const cssVariableStyles = '.usersetting_primaryColour { background-color:' + this.userSettingsService.allSettingsForm.value.usersetting_primaryColour + '!important;' + 'color:' + this.userSettingsService.allSettingsForm.value.usersetting_primaryColour + '!important;' + 'border-top-color:' + this.userSettingsService.allSettingsForm.value.usersetting_primaryColour + '!important;' + 'border-bottom-color:' + this.userSettingsService.allSettingsForm.value.usersetting_primaryColour + '!important;' + '}';

    // Body Reset
    const bodyReset = "body{margin:0; padding:0;}";

    // Generate Front Cover HTML
    var coverHtml = 
    '<!DOCTYPE html>' +
    '<html>' + 
      '<head>' +
        '<meta http-equiv=Content-type content=text/html;charset=UTF-8>' +
        '<style media=print,screen type="text/css">' + fonts + pageStyles + commonStyles + cssVariableStyles + coverStyles + bodyReset + '</style>' +
      '</head>' +
      '<body>' + coverPreviewInnerHTML + '</body>' +
    '</html>';

    // Generate Content HTML
    var contentHtml =
    '<!DOCTYPE html>' +
    '<html>' + 
      '<head>' +
        '<meta http-equiv=Content-type content=text/html;charset=UTF-8>' +
        '<style media=print,screen type="text/css">' + fonts + pageStyles + commonStyles + cssVariableStyles + customStyles + contentStyles + bodyReset + '</style>' +
      '</head>' +
      '<body>' + contentPreviewInnerHTML + '</body>' +
    '</html>';



    let cloudServicesURL = environment.production ? "https://main-pwz6sst7ka-ew.a.run.app" : "https://main-wf57supnuq-ew.a.run.app";

    const idToken = await firebase.auth().currentUser.getIdToken(true);
    const { data: response } = await axios.request({
      url: cloudServicesURL + '/v1/pdf/' + environment.firebase.projectId,
      method: 'POST',
      headers: {
        Authorization: `Bearer ${idToken}`,
      },
      data: {
        title: this.project.project_title,
        contentHtml: contentHtml,
        coverHtml: this.userSettingsService.allSettingsForm.value.usersetting_include_frontcover ? coverHtml : null,
        userSettings: {
          showPageNumbers: this.userSettingsService.allSettingsForm.value.usersetting_includepagenumbers,
          customWords: {
            page: this.userSettingsService.allSettingsForm.value.usersetting_page,
            of: this.userSettingsService.allSettingsForm.value.usersetting_of,
          },
        },
      },
    });
    
    if (response.url) {
      this.reportUrl = response?.url;
      this.userSettingsService.setAllSettings();
    }

  }



  /**----------------------------------------------------------------------------------------
  * Close Report Overlay
  * * Called by the HTML to close the overlay and reset the report URL
  -----------------------------------------------------------------------------------------*/
  closeReportOverlay(){
    this.overlay_report = false;
    this.reportUrl = '';
  }


}
