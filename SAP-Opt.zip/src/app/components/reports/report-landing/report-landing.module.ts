import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ReportLandingComponent } from './report-landing.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReportSettingsModule } from '../report-settings/report-settings.module';
import { MinimalComponent } from '../report-covers/minimal/minimal.component';
import { ModernBoldComponent } from '../report-covers/modern-bold/modern-bold.component';
import { BrightComponent } from '../report-covers/bright/bright.component';
import { CorporateComponent } from '../report-covers/corporate/corporate.component';
import { PhotographicComponent } from '../report-covers/photographic/photographic.component';
import { PhotographicBottomComponent } from '../report-covers/photographic/photographic-bottom/photographic-bottom.component';
import { ClassicComponent } from '../report-covers/classic/classic.component';
import { FinancialComponent } from '../report-covers/financial/financial.component';
import { BasicComponent } from '../report-covers/basic/basic.component';
import { BackdropComponent } from '../report-covers/backdrop/backdrop.component';
import { CircularComponent } from '../report-covers/circular/circular.component';
import { ReportCsvModule } from '../report-csv/report-csv.module';

const routes: Routes = [
  {
    path: '',
    component: ReportLandingComponent,
  }
]

@NgModule({
  declarations: [
    ReportLandingComponent,
    MinimalComponent,
    ModernBoldComponent,
    BrightComponent,
    CorporateComponent,
    PhotographicComponent,
    PhotographicBottomComponent,
    ClassicComponent,
    FinancialComponent,
    BasicComponent,
    BackdropComponent,
    CircularComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, 
    ReactiveFormsModule,
    ReportSettingsModule,
    ReportCsvModule
  ]
})

export class ReportLandingModule { }

