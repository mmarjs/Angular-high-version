import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-photographic-bottom',
  templateUrl: './photographic-bottom.component.html',
  styleUrls: ['./photographic-bottom.component.scss']
})
export class PhotographicBottomComponent implements OnInit {

  // Project Values
  @Input() project;

  constructor() { }

  ngOnInit(): void {
  }

}
