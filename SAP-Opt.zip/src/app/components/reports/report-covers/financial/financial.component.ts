import { Component, OnInit, Input } from '@angular/core';
import { UserSettingsService } from '../../../../services/user-settings/user-settings.service';
import { ReportsService } from '../../../../services/reports/reports.service';

@Component({
  selector: 'app-financial',
  templateUrl: './financial.component.html',
  styleUrls: ['./financial.component.scss']
})
export class FinancialComponent implements OnInit {

  // Project Values
  @Input() project;
  @Input() userSettings;

  constructor(
    public userSettingsService: UserSettingsService,
    public reportsService: ReportsService,
  ) { }

  ngOnInit(): void {

  }

  // Return class based on users preference
  setCompanyLogoSize(usersetting_companylogosize: number) {
    switch (usersetting_companylogosize) {
      case -1:
        return "report__logo--xsmall";
      case 0:
        return "report__logo--small";
      case 1:
        return "report__logo--regular";
      case 2:
        return "report__logo--large";
      case 3:
        return "report__logo--xlarge";
      default:
        return "report__logo--xsmall";
    }
  }

}
