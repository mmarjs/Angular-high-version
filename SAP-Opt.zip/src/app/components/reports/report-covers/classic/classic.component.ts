
import { Component, OnInit, Input } from '@angular/core';
import { UserSettingsService } from '../../../../services/user-settings/user-settings.service';
import { FontsService } from '../../../../services/reports/fonts.service';
import { ReportsService } from '../../../../services/reports/reports.service';

@Component({
  selector: 'app-classic',
  templateUrl: './classic.component.html',
  styleUrls: ['./classic.component.scss']
})
export class ClassicComponent implements OnInit {

  // Project Values
  @Input() project;
  @Input() userSettings;
  constructor(
    public userSettingsService: UserSettingsService,
    public fontsService: FontsService,
    public reportsService: ReportsService,
  ) { }

  ngOnInit(): void {

  }
  // Return class based on users preference
  setCompanyLogoSize(usersetting_companylogosize: number) {
    switch (usersetting_companylogosize) {
      case -1:
        return "report__logo--xsmall";
      case 0:
        return "report__logo--small";
      case 1:
        return "report__logo--regular";
      case 2:
        return "report__logo--large";
      case 3:
        return "report__logo--xlarge";
      default:
        return "report__logo--xsmall";
    }
  }

}
