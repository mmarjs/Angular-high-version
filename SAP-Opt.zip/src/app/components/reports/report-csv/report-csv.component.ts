import { Component, OnInit, Input } from '@angular/core';
import { HelperService } from '../../../services/helper/helper.service';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { CsvService } from '../../../services/reports/csv.service';

@Component({
  selector: 'app-report-csv',
  templateUrl: './report-csv.component.html',
  styleUrls: ['./report-csv.component.scss']
})
export class ReportCsvComponent implements OnInit {

  @Input() project;
  @Input() issues;

  // User Settings
  userSettings: any = {};

  csvIssuesArrayHTML = []
  finalCSVString: string;

  constructor(
    private helperService: HelperService,
    private userSettingsService: UserSettingsService,
    public csvService: CsvService,
  ) { }

  ngOnInit(): void {
    this.userSettings = this.helperService.getUserSettings();
    this.csvService.project = this.project;
    this.csvService.issues = this.issues;
    this.csvService.setCSVImageChoice(this.userSettingsService.allSettingsForm.value.usersetting_csv_include_images);
  }
  



}
