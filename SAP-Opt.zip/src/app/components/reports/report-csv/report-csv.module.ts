import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportCsvComponent } from './report-csv.component';



@NgModule({
  declarations: [ReportCsvComponent],
  imports: [
    CommonModule
  ],
  exports: [ ReportCsvComponent ]
})
export class ReportCsvModule { }
