import { Component, OnInit, Input } from '@angular/core';
import { FoldersService } from '../../services/folders/folders.service';

@Component({
  selector: 'app-folders',
  templateUrl: './folders.component.html',
  styleUrls: ['./folders.component.scss']
})

export class FoldersComponent implements OnInit {

  // Folders data received from 'folders-projects' component
  folder_id: string = '';
  @Input() foldersArray;
  @Input() homeIconClick;
  // Folder Colour Selection
  folderColours = ['58330A', 'CF00E5', '006014', 'FFB6D0', 'DCE0E5', '15AA00', 'E5DA00', 'FF6B17', '00E4F2', '6B2CAC', '000000', '676767', 'FFFFFF', 'DC1111', '1255C7'];

  constructor(
    public foldersService: FoldersService,
  ) { }

  ngOnChanges() {
    if(this.foldersService.folder_id){
      this.folder_id = this.foldersService.folder_id;
      setTimeout(() => {
        this.foldersService.folder_id = '';
      }, 1000)
    } else {
      this.folder_id = this.foldersArray[0]?.id;
    }
  }

  ngOnInit(): void {
  }

  handleFolderClick(folderId: string){
    this.folder_id = folderId;
  }

  /**----------------------------------------------------------------------------------------
  * Update Colour Choice
  * * When a colour is chosen, a value in the folders service is update
  * * This value is then used when adding or editing a folder
  -----------------------------------------------------------------------------------------*/
  updateColourChoice(colour: string){
    this.foldersService.folder_colour = colour;
  }



  /**----------------------------------------------------------------------------------------
  * Set Edit Folder Properties
  * * When a folder is edited, the id, new title, and colour are sent to the folders service
  * * These values are used to update the document
  -----------------------------------------------------------------------------------------*/
  setEditFolderProperties(folder_id: string, folder_title: string, folder_colour: string){
    this.foldersService.folder_id_edit = folder_id;
    this.foldersService.folder_title = folder_title;
    this.foldersService.folder_colour = folder_colour;
    this.foldersService.overlay_edit = true;
  }


  
  /**----------------------------------------------------------------------------------------
  * Search Folders
  * * Search through the list of folders
  -----------------------------------------------------------------------------------------*/
  searchFolders(): void {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("folderSearchInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("folders");
    li = ul.getElementsByTagName("li");

    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByClassName("folder-title")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
      } else {
        li[i].style.display = "none";
      }
    }
  }

}
