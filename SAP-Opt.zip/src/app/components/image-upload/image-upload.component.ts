import { Component, OnInit, Input, NgZone, OnDestroy } from '@angular/core';
import { AngularFireStorage, AngularFireUploadTask } from '@angular/fire/storage';
import { AngularFirestore } from '@angular/fire/firestore';
import { switchMap } from 'rxjs/operators';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { IssueEditService } from '../../services/issues/issue-edit.service';
import { IssuesListService } from '../../services/issues/issues-list.service';
import { CountersService } from '../../services/counters/counters.service';
import Compressor from 'compressorjs';
import { combineLatest, Subscription } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-image-upload',
  templateUrl: './image-upload.component.html',
  styleUrls: ['./image-upload.component.scss']
})
export class ImageUploadComponent implements OnInit, OnDestroy{

  @Input() file: File;
  @Input() index: number;
  @Input() project_id;
  @Input() issue_id;
  @Input() user_id;

  // Image metadata for caching
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };
  issueThumbnailNeedsToBeSet: boolean = false;

  _subscription: Subscription;

  thumbnailURL: string;

  constructor(
    private storage: AngularFireStorage,
    private afs: AngularFirestore,
    public issueEditService: IssueEditService,
    public countersService: CountersService,
    public issuesListService: IssuesListService,
    private zone: NgZone,
  ) { }

  ngOnInit(): void {
    this.compressImages();
  }

  ngOnDestroy(): void {
    this._subscription.unsubscribe();
  }

  compressImages() {

    const lastModified = new Date(this.file.lastModified);

    const currentImageCount = this.issueEditService.image_count;

    if (currentImageCount) {
      var currentImageCountPlusIndex = currentImageCount + this.index;
    } else {
      var currentImageCountPlusIndex = 0 + this.index;
    }

    if (currentImageCount == 0) {
      this.issueThumbnailNeedsToBeSet = true;
    }

    const photo_id = this.afs.createId();

    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(this.file, {
        quality: 0.75,
        maxWidth: 1000,
        maxHeight: 1000,
        checkOrientation: true
      });
      const thumb = await this.compressImage(this.file, {
        quality: 0.75,
        maxWidth: 300,
        maxHeight: 300,
        checkOrientation: true,
      });
      return {
        original,
        thumb
      };
    }).then((results) => {

      const thumbPath = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}/${photo_id}_issue_photo_thumbnail_${photo_id}.jpeg`;
      const thumbTaskRef = this.storage.ref(thumbPath);
      const thumbTask = this.storage.upload(thumbPath, results.thumb, this.metadata);

      const largePath = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}/${photo_id}_issue_photo_${photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const db_path = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}`;

      const obs$ = combineLatest([thumbTask, largeTask]);

      this._subscription = obs$.pipe(
        switchMap(async ([thumbTask, largeTask]) => {
          const thumbUrl = await thumbTaskRef.getDownloadURL().toPromise();
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`${db_path}`).set({
            dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
            image_date: lastModified,
            image_order: currentImageCountPlusIndex,
            version: 1,
            image_photo_thumbnail: thumbPath,
            image_photo_thumbnail_url: thumbUrl,
            image_photo: largePath,
            image_photo_url: largeUrl,
          }).then(() => {
            this.thumbnailURL = thumbUrl;
            this.issueEditService.filesUploadedCount++;
            this.countersService.issuePhotoCount(+1, this.user_id, this.project_id, this.issue_id);
            if (this.issueThumbnailNeedsToBeSet) {
              this.issueEditService.setIssueThumbnail(thumbPath, thumbUrl);
            }
          })
        })
      ).subscribe();
    });
  }


  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }

}