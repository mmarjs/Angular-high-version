import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/authentication/auth.service';

@Component({
  selector: 'app-billing-resubscribe',
  templateUrl: './billing-resubscribe.component.html',
  styleUrls: ['./billing-resubscribe.component.scss']
})
export class BillingResubscribeComponent implements OnInit {

  constructor(
    public authService: AuthService
  ) { }

  ngOnInit(): void {
  }

}
