import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-locked',
  templateUrl: './billing-locked.component.html',
  styleUrls: ['./billing-locked.component.scss']
})
export class BillingLockedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
