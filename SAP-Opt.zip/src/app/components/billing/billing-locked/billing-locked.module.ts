import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BillingLockedComponent } from './billing-locked.component';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: BillingLockedComponent,
  }
]

@NgModule({
  declarations: [BillingLockedComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})

export class BillingLockedModule { }







