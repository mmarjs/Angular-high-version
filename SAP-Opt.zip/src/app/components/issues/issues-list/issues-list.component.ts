import { Component, Input, OnInit } from '@angular/core';
import { IssuesListService } from '../../../services/issues/issues-list.service';
import { IssueEditService } from '../../../services/issues/issue-edit.service';
import { HelperService } from '../../../services/helper/helper.service';
import { Router } from '@angular/router';
import { IssuesFileFormatService } from '../../../services/issues/issues-file-format.service';

@Component({
  selector: 'app-issues-list',
  templateUrl: './issues-list.component.html',
  styleUrls: ['./issues-list.component.scss']
})

export class IssuesListComponent implements OnInit {

  // Issues array data received from parent
  @Input() folder_id;
  @Input() project_id;
  @Input() issue_id;
  @Input() user_id;
  @Input() parentComponent;

  // User Settings
  userSettings: any = {};

  // To pass into the multi uploader
  userSettings_issue: string;

    // For photo uploads
    isHovering: boolean;
    files: File[] = [];
    images_uploading: boolean = false;

  constructor(
    public issuesListService: IssuesListService,
    public issueEditService: IssueEditService,
    public helperService: HelperService,
    public issuesFileFormatService: IssuesFileFormatService,
    private router: Router) { }



  ngOnInit(): void {
    this.userSettings = this.helperService.getUserSettings();
    this.userSettings_issue = this.helperService.getSingleUserSetting("usersetting_issuename", "Issue");
  }

  clearDate(){
    this.issuesListService.due_date_batched_value = null;
  }


  /**----------------------------------------------------------------------------------------
  * Navigate To Issue
  * * Resets any values associated to incorrect file type uploads
  * * This is primarily used for the issue list / issue detail screen
  * * If the user clicks on an issue whilst the current form is dirty, display an alert overlay
  * * Pass the path of the clicked issue over to the service
  * * This path is used if the user decides to hit "discard" and carry on 
  * * If the form isn't dirty, progress as usual
  -----------------------------------------------------------------------------------------*/
  navigateToIssue(issue_id: string){
    this.issuesFileFormatService.resetIncorrectFileTypes();
    if (this.issueEditService.issueForm.dirty){
      this.issueEditService.overlay_unsaved_form = true;
      this.issueEditService.routeToNavigateTo = `/folders/${this.folder_id}/projects/${this.project_id}/summary/issues/${issue_id}`;
    } else {
      this.router.navigate(['/', 'folders', this.folder_id, 'projects', this.project_id, 'summary', 'issues', issue_id]);
    }
  }



  /**----------------------------------------------------------------------------------------
  * Toggle Hover
  * * When hovering an image over the drop zone, add a class for the hover state
  -----------------------------------------------------------------------------------------*/
  toggleHover(event: boolean) {
    this.isHovering = event;
  }



  /**----------------------------------------------------------------------------------------
  * Detect Photo Upload
  * * Reset files array
  * * Reset any values associated to incorrect file types on upload
  * * Set the variable "filesUploadedCount" to 0 for each fresh drag and drop session
  * * Set "images_uploading" (this toggles the cancel button / drag and drop zone with uploading images)
  * * For each photo dropped, add an index and push the items into files array
  * * The files array is used in the HTML
  -----------------------------------------------------------------------------------------*/
  detectPhotoUpload(files: FileList) {
    this.files = [];
    this.issuesFileFormatService.resetIncorrectFileTypes();
    this.issuesListService.filesUploadedCount = 0;
    this.images_uploading = true;
    var index = 0;
    for (let i = 0; i < files.length; i++) {
      var file = files.item(i);
      const fileType = file.type;
      const fileName = file.name;
      var fileExtension = fileType.split('/').pop();
      if(!(fileExtension == "jpg" || fileExtension == "jpeg" || fileExtension == "png")) {
        this.issuesFileFormatService.incorrect_file_type = true;
        this.issuesFileFormatService.incorrect_file_type_names.push(fileName);
        if (this.files.length < 1) {
          this.images_uploading = false;
        }
      } else {
        index++
        files.item(i)["index"] = index - 1;
        this.files.push(files.item(i));
      }
    }
  }




  /**----------------------------------------------------------------------------------------
  * Reset Uploads And Close
  * * Close the image uploads overlay
  * * Reset the files array so that the correct overlay buttons are shown next time
  -----------------------------------------------------------------------------------------*/
  resetUploadsAndClose(){
    this.issuesListService.overlay_multiadd = false;
    this.issuesListService.filesUploadedCount = 0;
    this.files = [];
  }

  


}
