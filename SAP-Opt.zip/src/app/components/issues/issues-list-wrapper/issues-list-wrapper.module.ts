import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssuesListWrapperComponent } from './issues-list-wrapper.component';
import { SharedIssuesListModule } from '../../../components/shared/issues/shared-issues-list.module';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: IssuesListWrapperComponent,
  }
]

@NgModule({
  declarations: [IssuesListWrapperComponent],
  imports: [
    CommonModule,
    SharedIssuesListModule,
    RouterModule.forChild(routes),
  ]
})
export class IssuesListWrapperModule { }
