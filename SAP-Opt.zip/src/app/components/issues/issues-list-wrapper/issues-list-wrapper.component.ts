import { Component, OnInit, OnDestroy } from '@angular/core';
import { switchMap, tap } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { IssuesListService } from '../../../services/issues/issues-list.service';
import { AuthService } from '../../../services/authentication/auth.service';
import { HelperService } from '../../../services/helper/helper.service';
import { FoldersService } from '../../../services/folders/folders.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-issues-list-wrapper',
  templateUrl: './issues-list-wrapper.component.html',
  styleUrls: ['./issues-list-wrapper.component.scss']
})
export class IssuesListWrapperComponent implements OnInit, OnDestroy {

  // URL Params
  folder_id: string;
  project_id: string;

  // Issues List
  private _issuesSubscription: Subscription;
  issuesArray = [];

  // User ID
  user_id: string

  // User Settings
  userSettings: any = {};

  // To pass to the issues list
  parentComponent: string = "issuesListWrapper";

  constructor(
    private _activatedRoute: ActivatedRoute,
    public issuesListService: IssuesListService,
    public authService: AuthService,
    public helperService: HelperService,
    public foldersService: FoldersService,
    private router: Router,
  ) { }

  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "getUserID"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.getUserID();
    this.issuesListService.issuesArray = [];
    this.userSettings = this.helperService.getUserSettings();
    this.foldersService.storeRoute(this.router.url);
  }



  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the issues subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._issuesSubscription.unsubscribe();
  }



  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getIssues(user.uid);
    }
  }



  /**----------------------------------------------------------------------------------------
  * Get issues
  * * Update the _issuesSubscription with the query subscription
  * * Update the URL params
  * * Call "getIssues" from the "issuesListService"
  * * Update the local "issuesArray" with the results
  -----------------------------------------------------------------------------------------*/
  getIssues(user_id: string) {
    this._issuesSubscription = this._activatedRoute.parent.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.issuesListService.getIssues(user_id, params.project_id);
      })
    ).subscribe(issues => {
      this.issuesListService.issuesArray = issues;
      this.issuesListService.issue_count = issues.length;
      this.issuesListService.showSpinner = false;
    });
  }
  
}



