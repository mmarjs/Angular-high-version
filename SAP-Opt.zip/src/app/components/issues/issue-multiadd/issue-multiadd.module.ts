import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssueMultiaddComponent } from './issue-multiadd.component';



@NgModule({
  declarations: [IssueMultiaddComponent],
  imports: [
    CommonModule
  ],
  exports: [
    IssueMultiaddComponent
  ]
})
export class IssueMultiaddModule { }
