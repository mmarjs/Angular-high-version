import { Component, OnInit, Input, NgZone } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { AngularFirestore } from '@angular/fire/firestore';
import { IssueEditService } from '../../../services/issues/issue-edit.service';
import { IssuesListService } from '../../../services/issues/issues-list.service';
import { CountersService } from '../../../services/counters/counters.service';
import Compressor from 'compressorjs';
import { switchMap } from 'rxjs/operators';
import { Subscription, combineLatest } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-issue-multiadd',
  templateUrl: './issue-multiadd.component.html',
  styleUrls: ['./issue-multiadd.component.scss']
})
export class IssueMultiaddComponent implements OnInit {

  @Input() file: File;
  @Input() index: number;
  @Input() project_id: string;
  @Input() userSettings_issue: string;
  @Input() user_id: string;

  // To display in the component and overlay
  downloadURL: string;

  // Image metadata for caching
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };

  _issueMultiAddSubscription: Subscription;

  constructor(
    private storage: AngularFireStorage,
    private afs: AngularFirestore,
    public issueEditService: IssueEditService,
    public countersService: CountersService,
    public issuesListService: IssuesListService,
    private zone: NgZone,
  ) { }

  ngOnInit(): void {
    this.saveImage(this.file);
  }

  /**----------------------------------------------------------------------------------------
  *  Resize Large Image
  * * Create new id's for the issues and photos
  * * Determine the "currentIssueCountPlusIndex" for issue ordering
  * * Resize large and thumbnail dimensions
  * * Upload files
  * * Update issue document
  * * Create issue image documents
  -----------------------------------------------------------------------------------------*/
  saveImage(file) {

    // Create new Issue Id
    const issue_id = this.afs.createId();
    const photo_id = this.afs.createId();
    const currentIssueCount = this.issuesListService.issue_count;
    const index = this.index;

    if (currentIssueCount) {
      var currentIssueCountPlusIndex = currentIssueCount + index;
    } else {
      var currentIssueCountPlusIndex = 0 + index;
    }

    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(file, {
        quality: 0.75,
        maxWidth: 1000,
        maxHeight: 1000,
        checkOrientation: true
      });
      const thumb = await this.compressImage(file, {
        quality: 0.75,
        maxWidth: 300,
        maxHeight: 300,
        checkOrientation: true,
      });
      return {
        original,
        thumb
      };
    }).then((results) => {
      const thumbPath = `users/${this.user_id}/projects/${this.project_id}/issues/${issue_id}/images/${photo_id}/${photo_id}_issue_photo_thumbnail_${photo_id}.jpeg`;
      const thumbTaskRef = this.storage.ref(thumbPath);
      const thumbTask = this.storage.upload(thumbPath, results.thumb, this.metadata);

      const largePath = `users/${this.user_id}/projects/${this.project_id}/issues/${issue_id}/images/${photo_id}/${photo_id}_issue_photo_${photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const issue_title = currentIssueCountPlusIndex + 1;

      const obs$ = combineLatest([thumbTask, largeTask]);
      this._issueMultiAddSubscription = obs$.pipe(
        switchMap(async ([thumbTask, largeTask]) => {
          const thumbUrl = await thumbTaskRef.getDownloadURL().toPromise();
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`users/${this.user_id}/projects/${this.project_id}/issues/${issue_id}`).set({
            issue_title: this.userSettings_issue + ' ' + issue_title.toString(),
            issue_order: currentIssueCountPlusIndex,
            issue_image_count: 1,
            issue_due_date: firebase.firestore.FieldValue.serverTimestamp(),
            dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
            version: 1,
            issue_completed: false,
            issue_thumbnail: thumbPath,
            issue_thumbnail_url: thumbUrl,
          }).then(() => {
            this.afs.doc(`users/${this.user_id}/projects/${this.project_id}/issues/${issue_id}/images/${photo_id}`).set({
              dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
              image_date: firebase.firestore.FieldValue.serverTimestamp(),
              image_order: 0,
              image_photo: largePath,
              image_photo_url: largeUrl,
              image_photo_thumbnail: thumbPath,
              image_photo_thumbnail_url: thumbUrl,
              version: 1,
            }).then(() => {
              this.issuesListService.filesUploadedCount++
              this.countersService.projectIssueCount(+1, this.user_id, this.project_id);
              this.downloadURL = thumbUrl;
            })
          })
        })
      ).subscribe();
    });
  }

  /**----------------------------------------------------------------------------------------
  * Compress Image
  * * Used by CompressorJS (saveCroppedImage) to resize images
  -----------------------------------------------------------------------------------------*/
  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }

}
