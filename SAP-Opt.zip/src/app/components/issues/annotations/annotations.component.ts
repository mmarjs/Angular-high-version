import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../services/authentication/auth.service';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import fabric from './annotation-canvas/modules/Fabric'
import { AnnotationsService } from '../../../services/issues/annotations.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { HelperService } from '../../../services/helper/helper.service';
import { FoldersService } from '../../../services/folders/folders.service';
import { Router } from '@angular/router';
import { IssueImage } from '../../../interfaces/issue-image';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-annotations',
  templateUrl: './annotations.component.html',
  styleUrls: ['./annotations.component.scss']
})
export class AnnotationsComponent implements OnInit, OnDestroy{

  folder_id: string;
  project_id: string;
  issue_id: string;
  image_id: string;
  user_id: string;

  // Annotations
  annotationArea: any;
  annotationAction: string = 'selection'
  activeSelection: any = null
  swatchesOpen: boolean = false
  sizeOpen: boolean = false
  SwatchesColor: string = '#00B819'
  shapeSize: string = 'medium'
  swatchesColorOptions = ["#58330A", "#CF00E5","#006014","#FFB6D0","#DCE0E5","#15AA00","#E5DA00","#FF6B17","#00E4F2","#6B2CAC","#000000","#676767","#FFFFFF","#DC1111", "#1255C7"]
  overlay_deleteAnnotation: boolean = false;

  // User Settings
  userSettings: any = {};

  annotationURL: string | firebase.firestore.FieldValue;
  annotationRef: string;
  enableSaveButton: boolean = false;

  _routerSubscription: Subscription;


  // Firebase Database
  db = firebase.firestore();

  constructor(
    private authService: AuthService,
    public userSettingsService: UserSettingsService,
    private _activatedRoute: ActivatedRoute,
    public annotationsService: AnnotationsService,
    public helperService: HelperService,
    public foldersService: FoldersService,
    private router: Router
  ) {
  }


  ngOnInit() {
    this.getuser_id();
    this.foldersService.storeRoute(this.router.url);
    this.userSettings = this.helperService.getUserSettings();
  }

  ngOnDestroy(){
    this._routerSubscription?.unsubscribe();
  }




  /**------------------------------------- 
  * * Get User Info
  * Call Auth Service and check if the user is logged in
  * If yes:
  * Set User ID
  * Call "getIssueImages"
  ------------------------------------- */
  async getuser_id() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getPhoto(user.uid)
    }
  }

 getPhoto(user_id: string){
  this.annotationsService.imageLoadingOverlay = true;
    this._routerSubscription = this._activatedRoute.params.subscribe(params => {
      this.folder_id = params.folder_id;
      this.project_id = params.project_id;
      this.issue_id = params.issue_id;
      this.image_id = params.image_id;
      var docRef = this.db.collection(`users/${user_id}/projects/${params.project_id}/issues/${params.issue_id}/images`).doc(`${params.image_id}`);
       docRef.get().then(async(doc) => {
        if (doc.exists) {
          const data = doc.data() as IssueImage;
          const imageURL = data.image_photo_url;
          var annotationURL: string;
          if (data.image_annotations){
            annotationURL = await this.getAnnotationDownloadURL(data.image_annotations);
          }
          this.initializeAnnotator(imageURL, annotationURL);
          this.annotationURL = annotationURL;
          this.annotationRef = data.image_annotations;
          this.annotationsService.imageLoadingOverlay = false;
        } else {
          this.router.navigate(['/', 'folders']);
        }
      }).catch((error) => {
        console.log("Error getting document:", error);
      });
    });
  }


  async getAnnotationDownloadURL(reference){
    var storage = firebase.storage();
    var annotatedImageReference = reference;
    var annotatedImagePathReference = storage.ref().child(annotatedImageReference);  
    const url = await annotatedImagePathReference.getDownloadURL();
    return url;
  }


  deleteAnnotation() {
    var storage = firebase.storage();
    const refLarge = storage.ref(this.annotationRef);
    refLarge.delete().then(() => {
      var photoDocRef = this.db.collection(`users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images`).doc(`${this.image_id}`).update({
        image_annotations: firebase.firestore.FieldValue.delete(),
      }).then(() => {
        this.overlay_deleteAnnotation = false;
        this.getPhoto(this.user_id);
      });
    });
  }


  initializeAnnotator(imageUrl: any, annotationUrl: any) {
    if (this.annotationArea instanceof fabric.AnnotationArea) {
      this.annotationArea.clear()
      this.annotationArea._objects = []
      this.annotationArea.backgroundImageURL = imageUrl
      this.annotationArea.annotationImageURL = annotationUrl
      this.annotationArea.initializeBackgroundImage()
      return
      //this.annotationArea.dispose()
    }
    this.annotationArea = new fabric.AnnotationArea('annotationArea', {
      backgroundImageURL: imageUrl,
      annotationImageURL: annotationUrl,
      containerId: 'canvas-wrapper'
    })
    
    this.annotationAction = this.annotationArea.getAction()

    fabric.util.addListener(document.body, 'keyup', (options: any) => {
      let key = options.which || options.keyCode
      if ((key === 46 || key === 8)) {
        options.preventDefault()
        options.stopPropagation()
        let activeObjects = this.annotationArea.getActiveObjects()
        if (activeObjects.length > 0) {
          if (!activeObjects[0].isEditing) {
            this.annotationArea.discardActiveObject()
            this.annotationArea.remove(...activeObjects).requestRenderAll()
          }
        }
      }
    })

    this.annotationArea.on('state:changed', () => {
      // this.enableSaveButton = this.annotationArea.getObjects().some(object => object.type !== 'image') ? true : false;
      this.enableSaveButton = this.annotationArea._objects.some(object => object.type !== 'image') ? true : false
      })

    this.annotationArea.on('action:changed', () => {
      this.annotationAction = this.annotationArea.getAction()
    })

    this.annotationArea.on('style:updated', () => {
      this.SwatchesColor = this.annotationArea.styleStroke
      this.shapeSize = this.annotationArea.getShapeThickness()
    })
    this.annotationArea.on('selection:created', (opt: any) => {
      this.activeSelection = opt.target
      if (opt.selected.length === 1) {
        if (opt.target instanceof fabric.Textbox) {
          this.annotationArea.styleStroke = opt.target.fill
          this.annotationArea.styleStrokeWidth = opt.target.fontSize / 4
        }
        this.SwatchesColor = this.annotationArea.styleStroke
        this.shapeSize = this.annotationArea.getShapeThickness()
      }
    })
    this.annotationArea.on('selection:updated', (opt: any) => {
      this.activeSelection = opt.target
      if (opt.selected.length === 1) {
        if (opt.target instanceof fabric.Textbox) {
          this.annotationArea.styleStroke = opt.target.fill
          this.annotationArea.styleStrokeWidth = opt.target.fontSize / 4
        }
        this.SwatchesColor = this.annotationArea.styleStroke
        this.shapeSize = this.annotationArea.getShapeThickness()
      }
    })
    this.annotationArea.on('selection:cleared', () => {
      this.activeSelection = null
    })
  }


  toggleMenuSwatches($event) {
    $event.stopPropagation()
    this.swatchesOpen = !this.swatchesOpen
    this.sizeOpen = false
  }
  toggleMenuSize($event) {
    $event.stopPropagation()
    this.sizeOpen = !this.sizeOpen
    this.swatchesOpen = false
  }
  onOutsideClick() {
    this.swatchesOpen = false
    this.sizeOpen = false
  }
  onBgChange(event) {
    if (this.annotationArea) {
      this.annotationArea.setBackgroundImageURL(event.target.value)
    }
  }
  setAction(action: string) {
    this.annotationArea.setAction(action)
  }
  setSwatchesColor(color: string) {
    this.SwatchesColor = color;
    this.annotationArea.setStyleStroke(this.SwatchesColor);
    this.swatchesOpen = false;
  }
  setShapeSize(size: string) {
    this.shapeSize = size
    this.annotationArea.setStyleSize(this.shapeSize)
  }
  deleteActiveSelection() {
    this.annotationArea.deleteActiveSelection()
  }
  rotateActiveSelection(direction){
    this.annotationArea.rotateActiveSelection(direction);
  }
  rotateTotal(direction){
    this.annotationArea.rotateTotal(direction);
  }
  undo() {
    this.annotationArea.undo();
  }
  redo() {
    this.annotationArea.redo()
  }
  zoomIn() {
    this.annotationArea.zoomIn()
  }
  zoomOut() {
    this.annotationArea.zoomOut()
  }
  fitToScreen() {
    this.annotationArea.fitToScreen()
  }
  downloadImage(event: any) {
    if(this.annotationArea.exportDrawing()){
      this.annotationsService.saveAnnotation(this.user_id, this.folder_id, this.project_id, this.issue_id, this.image_id, { annotation: this.annotationArea.exportDrawing()})
    }
  }

  showDeleteAnnotationOverlay() {
    this.overlay_deleteAnnotation = true;
  }

  overlay_close() {
    this.overlay_deleteAnnotation = false;
  }

}