import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnnotationsComponent } from './annotations.component';
import { Routes, RouterModule } from '@angular/router';
// import { LoadingAnimationModule } from '../../loading-animation/loading-animation.module';
// import { DynamicScriptLoaderService } from '../../../services/dynamic-script-loader.service';


const routes: Routes = [
  { path: '', component: AnnotationsComponent },
]

@NgModule({
  declarations: [AnnotationsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    // LoadingAnimationModule,
  ],
  providers: [
    // DynamicScriptLoaderService
  ]
})
export class AnnotationsModule { }
