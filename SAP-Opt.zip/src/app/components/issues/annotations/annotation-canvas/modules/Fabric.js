import {
    fabric
} from 'fabric'
import Ellipse from './Ellipse'
import Triangle from './Triangle'
import Rectangle from './Rectangle'
import Arrow from './Arrow'
import AnnotationArea from './AnnotationArea'
import Line from './Line';
Ellipse(fabric)
Triangle(fabric)
Rectangle(fabric)
Arrow(fabric)
Line(fabric)
AnnotationArea(fabric)
export default fabric