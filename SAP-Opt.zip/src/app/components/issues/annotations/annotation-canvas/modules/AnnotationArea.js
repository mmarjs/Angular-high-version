let AnnotationArea = (fabric) => {

  fabric.Object.prototype.borderColor = '#3B3D3D'
  fabric.Object.prototype.cornerColor = '#3B3D3D'
  fabric.Object.prototype.cornerStrokeColor = '#3B3D3D'
  fabric.Object.prototype.cornerStyle = 'circle'
  fabric.Object.prototype.transparentCorners = false
  fabric.Object.prototype.objectCaching = false
  fabric.ActiveSelection.prototype.minWidth = 5
  fabric.ActiveSelection.prototype.minHeight = 5
  fabric.ActiveSelection.prototype.strokeWidth = 5
  fabric.ActiveSelection.prototype.lockUniScaling = false
  fabric.ActiveSelection.prototype.hasRotatingPoint = false
  fabric.ActiveSelection.prototype.objectCaching = false
  fabric.Object.prototype.centeredRotation = true
  fabric.ActiveSelection.prototype.setControlsVisibility({
    mt: false,
    mb: false,
    ml: false,
    mr: false,
    tl: false,
    tr: false,
    bl: false,
    br: false
  })
  fabric.Path.prototype.setControlsVisibility({
    mt: false,
    mb: false,
    ml: false,
    mr: false
  })
  fabric.Path.prototype.setStyleFromUI = function (style) {
    this.set(style)
    this.setCoords()
}
  //fabric.Path.prototype.globalCompositeOperation = 'source-atop'

  fabric.AnnotationArea = fabric.util.createClass(fabric.Canvas, {
    action: 'selection',
    styleStroke: '#00B819',
    styleStrokeWidth: 5,
    preserveObjectStacking: true,
    uniScaleKey: null,
    enableRetinaScaling: true,
    backgroundColor: 'transparent',
    backgroundImageURL: null,
    annotationImageURL: null,
    fireMiddleClick: true,
    skipOffscreen: true,
    containerId: null,
    selectionColor: 'rgba(59, 61, 61, 0.3)',
    selectionBorderColor: '#3B3D3D',
    angle: 0,
    initialize(el, options) {
      options || (options = {})
      this.renderAndResetBound = this.renderAndReset.bind(this)
      this.requestRenderAllBound = this.requestRenderAll.bind(this)
      this._initStatic(el, options)
      this._initInteractive()
      this._createCacheCanvas()
      this.freeDrawingBrush = new fabric.PencilBrush(this)
      this.on('mouse:down:before', (opt) => {
        if (this.action !== 'selection' && opt.e.which !== 2) {
          this.selection = false
          let pointer = this.getPointer(opt.e)
          // if(opt.target){
          //   this.setCursor('default');
          // }
          this.drawAction(this.action, pointer)
        } else {
          if (!this.selection) this.selection = true
        }
      })
      this.on('mouse:up:before', (opt) => {
        if (opt.target) {
          opt.target.hasBorders = true
          opt.target.hasControls = true
          delete opt.target.__firstDraw
          delete opt.target.__firstDrawCorner
        }
      })
      if (this.backgroundImageURL) {
        this.initializeBackgroundImage(this.backgroundImageURL)
      }
      // pan zoom
      this.on('mouse:wheel', (opt) => {
        if (opt.e.ctrlKey === true) {
          const delta = Math.sign(opt.e.deltaY)
          let zoom = this.getZoom()
          const step = 12
          zoom = zoom - delta / step
          if (zoom > 1.5) zoom = 1.5
          if (zoom < 0.5) zoom = 0.5
          this.zoomToPoint({
            x: opt.e.offsetX,
            y: opt.e.offsetY
          }, zoom)
          this.fire('zoom:changed')
        } else {
          this.viewportTransform[5] -= opt.e.deltaY / 2
          this.viewportTransform[4] -= opt.e.deltaX / 2
        }
        this.calcOffset()
        this.calcViewportBoundaries()
        this.getObjects().forEach(object => {
          object.setCoords()
        })
        this.requestRenderAll()
        opt.e.preventDefault()
        opt.e.stopPropagation()
      })
      this.on('mouse:down', (opt) => {
        const evt = opt.e
        // if (evt.which === 2) {
        //   this.isDragging = true
        //   this.selection = false
        //   this.requestRenderAll()
        // } else {
        //   console.log("777")
        //   this.isDragging = false
        //   this.selection = true
        // }
        this.calcViewportBoundaries()
        this.lastPosX = evt.clientX
        this.lastPosY = evt.clientY
        this.lastViewportTransform = {
          x: this.viewportTransform[4],
          y: this.viewportTransform[5]
        }
      })
      this.on('mouse:move', (opt) => {
        const e = opt.e
        if (this.isDragging) {
          this.viewportTransform[4] += e.clientX - this.lastPosX
          this.lastPosX = e.clientX
          this.viewportTransform[5] += e.clientY - this.lastPosY
          this.lastPosY = e.clientY
          this.calcViewportBoundaries()
          this.requestRenderAll()
          this.fire('zoom:changed')
          opt.e.preventDefault()
          opt.e.stopPropagation()
        } else {
          // if (this.isDragging) {
            this.isDragging = false
            this.selection = true
          // }
        }
      })

      this.on('mouse:up', () => {
        this.isDragging = false
        this.selection = true
        this.getObjects().forEach(object => {
          object.setCoords()
        })
      })
      if (this.containerId) {
        this.initResponsive()
      }

      this.historyUndo = []
      this.historyRedo = []
      this.historyNextState = this._historyNext()

      this.on(this._historyEvents())
      setInterval(() => {
          this.trigger('state:changed')
      }, 100)
    },
    _historyNext() {
      return JSON.stringify(this)
    },
    _historyEvents() {
      return {
        'object:added': this._historySaveAction,
        'object:removed': this._historySaveAction,
        'object:modified': this._historySaveAction,
        'object:skewing': this._historySaveAction
      }
    },
    _historySaveAction() {
      if (this.historyProcessing)
        return
      const json = this.historyNextState
      this.historyUndo.push(json)
      this.historyNextState = this._historyNext()
      this.fire('history:append', {
        json: json
      })
    },
    undo(callback) {
      this.historyProcessing = true
      const history = this.historyUndo.length > 1 ? this.historyUndo.pop() : null
      if (history) {
        this.historyRedo.push(this._historyNext())
        this.historyNextState = history
        this._loadHistory(history, 'history:undo', callback)
      } else {
        this.historyProcessing = false
      }
    },
    redo(callback) {
      this.historyProcessing = true
      const history = this.historyRedo.pop()
      if (history) {
        this.historyUndo.push(this._historyNext())
        this.historyNextState = history
        this._loadHistory(history, 'history:redo', callback)
      } else {
        this.historyProcessing = false
      }
    },
    _loadHistory(history, event, callback) {
      this.loadFromJSON(history, () => {
        this.renderAll()
        this.fire(event)
        this.getObjects().forEach(object => {
          if (object instanceof fabric.Image) {
            this._bgImageObj = object
            this._bgImageObj.selectable = false
            this._bgImageObj.evented = false
            this.fitToScreen()
          }
        })
        this.historyProcessing = false

        if (callback && typeof callback === 'function')
          callback()
      })
    },
    initResponsive() {
      const container = document.getElementById(this.containerId)
      this.setWidth(Math.floor(container.offsetWidth))
      this.setHeight(Math.floor(container.offsetHeight))
      this.renderAll()
      const step = () => {
        setTimeout(() => {
          if (container) {
            const containerWidth = Math.floor(container.offsetWidth)
            const containerHeight = Math.floor(container.offsetHeight)
            if (Math.abs(containerWidth - this.width) > 2) {
              this.setWidth(containerWidth).renderAll()
            }
            if (Math.abs(containerHeight - this.height) > 2) {
              this.setHeight(containerHeight).renderAll()
            }
          }
          window.requestAnimationFrame(step)
        }, 100)
      }
      window.requestAnimationFrame(step)
    },
    convertStringSizeToInt(size) {
      let intSize = 6
      switch (size) {
        case 'small':
          intSize = 6
          break
        case 'medium':
          intSize = 12
          break
        case 'thick':
          intSize = 17
          break
      }
      return intSize
    },
    getShapeThickness() {
      if (this.styleStrokeWidth < 10) {
        return 'small'
      } else
      if (this.styleStrokeWidth >= 10 && this.styleStrokeWidth < 15) {
        return 'medium'
      } else
      if (this.styleStrokeWidth >= 15) {
        return 'thick'
      } else {
        return 'medium'
      }
    },
    initializeBackgroundImage() {
      fabric.Image.fromURL(this.backgroundImageURL, (image) => {
        let minScaleFactor = Math.min(this.width / image.width * image.scaleX, this.height / image.height * image.scaleY)
        image.set({
          selectable: false,
          evented: false,
          scaleX: minScaleFactor,
          scaleY: minScaleFactor,
        })
        this.centerObject(image)
        this.addImage(image)
        this._originalBgImageSize = {
          width: image.width,
          height: image.height
        }
        this._bgImageObj = image
        if (this.annotationImageURL) {
          this.initializeAnnotationImage()
        }
        this.fitToScreen()
        this.renderAll()
      }, {
        crossOrigin: 'anonymous'
      })
    },
    initializeAnnotationImage() {
      fabric.Image.fromURL(this.annotationImageURL, (image) => {
        let minScaleFactor = Math.min(this.width / image.width * image.scaleX, this.height / image.height * image.scaleY)
        image.set({
          selectable: false,
          evented: false,
          scaleX: minScaleFactor,
          scaleY: minScaleFactor
        })
        this._annotationImageObj = image
        this.centerObject(image)
        this.addImageTop(image)
        this.fitToScreen()
        this.renderAll()
      }, {
        crossOrigin: 'anonymous'
      })
    },
    exportDrawing() {
      let base64 = ''
      // let multVal = this._originalBgImageSize.width;
      if (this._annotationImageObj === undefined) {
        this._objects.filter(object => object !== this._objects[0])
      } 
      if (this._bgImageObj) {
        this.fitToScreen()
        // this._objects.forEach(object => {
        //   if (!object instanceof fabric.Image) {
        //     object.globalCompositeOperation = 'source-over'
        //   }
        // })
        this._bgImageObj.opacity = 0;
        base64 = this.toDataURL({
          // format: 'png',
          // multiplier: multVal / this.width,
          left: this._bgImageObj.left,
          top: this._bgImageObj.top,
          width: this._bgImageObj.width * this._bgImageObj.scaleX,
          height: this._bgImageObj.height * this._bgImageObj.scaleY
        })
        // this.renderAll()
      }
      if(base64) return base64
    },
    zoomIn() {
      if(this.getZoom() <= 1.5) {
        this.zoomToPoint({
          x: this.getCenter().left,
          y: this.getCenter().top
        }, this.getZoom() * 1.1)
      } else {
        this.zoomToPoint({
          x: this.getCenter().left,
          y: this.getCenter().top
        }, this.getZoom())
      }

      this.getObjects().forEach(object => {
        object.trigger('zoom:changed')
        object.setCoords()
      })
      this.requestRenderAll()
      return this
    },
    zoomOut() {
      if(this.getZoom() >= 0.5) {
        this.zoomToPoint({
          x: this.getCenter().left,
          y: this.getCenter().top
        }, this.getZoom() * 0.9)
      } else {
        this.zoomToPoint({
          x: this.getCenter().left,
          y: this.getCenter().top
        }, this.getZoom())
      }

      this.getObjects().forEach(object => {
        object.trigger('zoom:changed')
        object.setCoords()
      })
      this.requestRenderAll()
      return this
    },
    setBackgroundImageURL(url) {
      this.initializeBackgroundImage(url)
    },
    getBackgroundImageBoundaries() {
      let boundaries = {
        left: null,
        right: null,
        top: null,
        bottom: null
      }
      this._objects.forEach(object => {
        boundaries.left = boundaries.left === null ? Math.min(boundaries.left, object.left) : object.left
        boundaries.right = boundaries.right === null ? Math.max(boundaries.right, object.left + object.width * object.scaleX) : object.left + object.width * object.scaleX
        boundaries.top = boundaries.top === null ? Math.min(boundaries.top, object.top) : object.top
        boundaries.bottom = boundaries.bottom === null ? Math.max(boundaries.bottom, object.top + object.height * object.scaleY) : object.top + object.height * object.scaleY
      })
      return {
        left: boundaries.left != null ? boundaries.left * this.getZoom() + this.viewportTransform[4] : 0,
        right: boundaries.right != null ? boundaries.right * this.getZoom() + this.viewportTransform[4] : 0,
        top: boundaries.top != null ? boundaries.top * this.getZoom() + this.viewportTransform[5] : 0,
        bottom: boundaries.bottom != null ? boundaries.bottom * this.getZoom() + this.viewportTransform[5] : 0
      }
    },
    fitToBgImage() {
      let image = this._bgImageObj
      return {
        left: image ? image.left * this.getZoom() + this.viewportTransform[4] : 0,
        right: image ? (image.left + image.width * image.scaleX) * this.getZoom() + this.viewportTransform[4] : 0,
        top: image ? image.top * this.getZoom() + this.viewportTransform[5] : 0,
        bottom: image ? (image.top + image.height * image.scaleY) * this.getZoom() + this.viewportTransform[5] : 0
      }
    },
    fitToScreen() {
      this.setZoom(1)
      this.calcViewportBoundaries()
      let pBoundaries = this.fitToBgImage()
      if (pBoundaries.left !== Infinity) {
        let widthFactor = (this.vptCoords.tr.x - this.vptCoords.tl.x) / (pBoundaries.right - pBoundaries.left)
        let heightFactor = (this.vptCoords.bl.y - this.vptCoords.tl.y) / (pBoundaries.bottom - pBoundaries.top)
        let minFactor = Math.min(widthFactor, heightFactor)
        this.viewportTransform[4] -= pBoundaries.left + ((pBoundaries.right - pBoundaries.left) / 2) - (this.vptCoords.tr.x - this.vptCoords.tl.x) / 2 * this.getZoom()
        this.viewportTransform[5] -= pBoundaries.top + ((pBoundaries.bottom - pBoundaries.top) / 2) - (this.vptCoords.bl.y - this.vptCoords.tl.y) / 2 * this.getZoom()
        this.zoomToPoint(new fabric.Point(this.width / 2, this.height / 2), minFactor)
        this.renderAll()
        this.fire('zoom:changed')
        this.getObjects().forEach(object => {
          object.trigger('zoom:changed')
          object.setCoords()
        })
      }
      return this
    },
    setStyleStroke(color) {
      this.styleStroke = color
      this.setStyleForActiveObject({
        stroke: this.styleStroke
      })
    },
    setStyleSize(size) {
      this.styleStrokeWidth = this.convertStringSizeToInt(size)
      this.setStyleForActiveObject({
        strokeWidth: this.styleStrokeWidth
      })
    },
    deleteActiveSelection() {
      let activeObjects = this.getActiveObjects()
      this.discardActiveObject()
      this.remove(...activeObjects).requestRenderAll()
    },
    rotateActiveSelection(direction){
      let activeObject = this.getActiveObject();
      if(direction){

        activeObject.angle += 15;
      } else {
        activeObject.angle -= 15;
      }
      this.requestRenderAll()
    },
    // rotateTotal(direction){
    //   var activeObject = this.getActiveObject();
    //   if(direction){
    //     this._bgImageObj.angle += 90;
    //     // this.flipAfterRotate();
    //     if(this._annotationImageObj){
    //       this._annotationImageObj.angle += 90;
    //       this.centerObject(this._annotationImageObj)
    //     }
    //     if(activeObject){
    //       activeObject.angle += 90;
    //       this.centerObject(activeObject)
    //     }
    //   } else {
    //     this._bgImageObj.angle -= 90;
    //     if(this._annotationImageObj){
    //       this._annotationImageObj.angle -= 90;
    //       this.centerObject(this._annotationImageObj)
    //     }
    //     if(activeObject){
    //       activeObject.angle -= 90;
    //       this.centerObject(activeObject)
    //     }
    //   }
    //   this.centerObject(this._bgImageObj)
    //   this.renderAll()
    // },
    // flipAfterRotate(){
    //   var temp = this._bgImageObj.width;
    //   this._bgImageObj.width = this._bgImageObj.height; 
    //   this._bgImageObj.height = temp;

    //   var scale = this._bgImageObj.scaleX;
    //   this._bgImageObj.scaleX = this._bgImageObj.scaleY;
    //   this._bgImageObj.scaleY = scale;
    // },
    setStyleForActiveObject(style) {
      if (this.freeDrawingBrush) {
        if (style.strokeWidth) {
          this.freeDrawingBrush.width = Number(style.strokeWidth)
        }
        if (style.stroke) {
          this.freeDrawingBrush.color = style.stroke
        }
      }
      this.trigger('style:updated', {
        target: null
      })
      let object = this.getActiveObject()
      if (object) {
        object.setStyleFromUI(style, this)
        if (object instanceof fabric.Textbox) {
          this.styleStroke = object.fill
          this.styleStrokeWidth = object.fontSize / 4
        }
        this.requestRenderAll()
        this.trigger('style:updated', {
          target: object
        })
      }
      return this
    },
    getAction() {
      return this.action
    },
    setAction(action) {
      this.action = action === this.action ? 'selection' : action
      if(this.action === 'selection'){
        this.hoverCursor = 'move';
      } else {
        this.hoverCursor = 'default';
      }
      this.isDrawingMode = false
      if (this.action === 'freeDrawing') {
        this.freeDrawing()
      }
      this.trigger('action:changed')
      this.discardActiveObject()
      this.requestRenderAll()
      return this
    },
    drawAction(action, pos) {
      switch (action) {
        case 'ellipse':
          this.drawEllipse(pos)
          break
        case 'triangle':
          this.drawTriangle(pos)
          break
        case 'circle':
          this.drawCircle(pos)
          break
        case 'rectangle':
          this.drawRectangle(pos)
          break
        case 'arrow':
          this.drawArrow(pos)
          break
        case 'line':
          this.drawLine(pos)
          break
        case 'range':
          this.drawRange(pos)
          break
        case 'freeDrawing':
          this.freeDrawing(pos)
          break
        case 'text':
          this.drawText(pos)
          break
      }
      return this
    },
    drawEllipse(pos) {
      let ellipse = new fabric.EllipseShape({
        left: pos.x - 15,
        top: pos.y - 15,
        width: 5,
        height: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
        //globalCompositeOperation:'source-atop'
      })
      this.add(ellipse)
      ellipse.setCoords()
      this.setActiveObject(ellipse)
      ellipse.__firstDraw = true
      ellipse.hasBorders = false
      ellipse.hasControls = false
      ellipse.__firstDrawCorner = 'br'
      this._target = ellipse
    },
    drawTriangle(pos) {
      let triangle = new fabric.TriangleShape({
        left: pos.x - 15,
        top: pos.y - 15,
        width: 5,
        height: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
        //globalCompositeOperation:'source-atop'
      })
      this.add(triangle)
      triangle.setCoords()
      this.setActiveObject(triangle)
      triangle.__firstDraw = true
      triangle.hasBorders = false
      triangle.hasControls = false
      triangle.__firstDrawCorner = 'br'
      this._target = triangle
    },
    drawCircle(pos) {
      let circle = new fabric.CircleShape({
        left: pos.x - 10,
        top: pos.y - 10,
        width: 5,
        height: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
        // globalCompositeOperation:'source-atop'
      })
      this.add(circle)
      circle.setCoords()
      this.setActiveObject(circle)
      circle.__firstDraw = true
      circle.hasBorders = false
      circle.hasControls = false
      circle.__firstDrawCorner = 'br'
      this._target = circle
    },
    drawRectangle(pos) {
      let rectangle = new fabric.RectangleShape({
        left: pos.x - 15,
        top: pos.y - 15,
        width: 5,
        height: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
        // globalCompositeOperation:'source-atop'
      })
      this.add(rectangle)
      rectangle.setCoords()
      this.setActiveObject(rectangle)
      rectangle.__firstDraw = true
      rectangle.hasBorders = false
      rectangle.hasControls = false
      rectangle.__firstDrawCorner = 'br'
      this._target = rectangle
    },
    drawArrow(pos) {
      let arrow = new fabric.ArrowShape({
        left: pos.x - 5,
        top: pos.y,
        width: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
        // globalCompositeOperation:'source-atop'
      })
      this.add(arrow)
      arrow.setCoords()
      this.setActiveObject(arrow)
      arrow.__firstDraw = true
      arrow.hasBorders = false
      arrow.hasControls = false
      arrow.__firstDrawCorner = 'mr'
      this._target = arrow
    },
    drawLine(pos) {
      let line = new fabric.LineShape({
        left: pos.x - 5,
        top: pos.y,
        width: 5,
        stroke: this.styleStroke,
        strokeWidth: this.styleStrokeWidth,
      })
      this.add(line)
      line.setCoords()
      this.setActiveObject(line)
      line.__firstDraw = true
      line.hasBorders = false
      line.hasControls = false
      line.__firstDrawCorner = 'mr'
      this._target = line
    },
    freeDrawing() {
      this.isDrawingMode = true
      this.freeDrawingBrush.color = this.styleStroke
      this.freeDrawingBrush.width = this.styleStrokeWidth * 60 / 100
      this.freeDrawingCursor = 'crosshair'
      this.setCursor(this.freeDrawingCursor)
      this.renderAll()
    },
    drawText(pos) {
      let text = new fabric.Textbox('Text here', {
        left: pos.x,
        top: pos.y,
        width: 280,
        stroke: '#fff',
        strokeWidth: 0,
        fontFamily: 'arial',
        fill: this.styleStroke,
        fontSize: 68,
        // globalCompositeOperation:'source-atop'
      })
      this.add(text)
      text.setCoords()
      this.selection = true
      this.setAction('selection')
      text.hasBorders = true
      text.hasControls = true
      this.setActiveObject(text)
      text.setSelectionEnd()
      text.enterEditing()
    },
    addImage(image) {
      //this._objects = this._objects.filter(object => !(object instanceof fabric.Image))
      this._objects.unshift(image)
      if (this._onObjectAdded) {
        this._onObjectAdded(image)
      }
      this.renderOnAddRemove && this.requestRenderAll()
      return this
    },
    addImageTop(image) {
      this._objects.push(image)
      if (this._onObjectAdded) {
        this._onObjectAdded(image)
      }
      this.renderOnAddRemove && this.requestRenderAll()
      return this
    },
    _setupCurrentTransform: function (e, target, alreadySelected) {
      if (!target) {
        return
      }

      let firstDraw = target.__firstDraw

      let pointer = this.getPointer(e),
        corner = firstDraw ? target.__firstDrawCorner : target._findTargetCorner(this.getPointer(e, true)),
        action = this._getActionFromCorner(alreadySelected, corner, e, target),
        origin = this._getOriginFromCorner(target, corner)
      this._currentTransform = {
        target: target,
        action: action,
        corner: corner,
        scaleX: target.scaleX,
        scaleY: target.scaleY,
        skewX: target.skewX,
        skewY: target.skewY,
        offsetX: pointer.x - target.left,
        offsetY: pointer.y - target.top,
        originX: origin.x,
        originY: origin.y,
        ex: pointer.x,
        ey: pointer.y,
        lastX: pointer.x,
        lastY: pointer.y,
        theta: fabric.util.degreesToRadians(target.angle),
        width: target.width * target.scaleX,
        mouseXSign: 1,
        mouseYSign: 1,
        shiftKey: e.shiftKey,
        altKey: e[this.centeredKey],
        original: fabric.util.saveObjectTransform(target),
      }

      this._currentTransform.original.originX = origin.x
      this._currentTransform.original.originY = origin.y

      this._resetCurrentTransform()
      this._beforeTransform(e)
    },
    _setObjectScale: function (localMouse, transform, lockScalingX, lockScalingY, by, lockScalingFlip, _dim) {
      let target = transform.target,
        forbidScalingX = false,
        forbidScalingY = false,
        scaled = false,
        scaleX = localMouse.x * target.scaleX / _dim.x,
        scaleY = localMouse.y * target.scaleY / _dim.y,
        changeX = target.scaleX !== scaleX,
        changeY = target.scaleY !== scaleY

      transform.newScaleX = scaleX
      transform.newScaleY = scaleY
      if (fabric.Textbox && by === 'x' && target instanceof fabric.Textbox) {
        let w = target.width * (localMouse.x / _dim.x)
        if (w >= target.getMinWidth()) {
          scaled = w !== target.width
          target.set('width', w)
          return scaled
        }
        return false
      }

      if (by === 'x') {
        let w = target.width * (localMouse.x / _dim.x)
        scaled = w !== target.width
        target.set('width', Math.max(target.minWidth, w))
        return scaled
      }

      if (by === 'y') {
        let h = target.height * (localMouse.y / _dim.y)
        scaled = h !== target.height
        target.set('height', Math.max(target.minHeight, h))
        return scaled
      }

      if (by === 'equally' && !lockScalingX && !lockScalingY) {
        if (target instanceof fabric.IText || target instanceof fabric.Path) {
          scaled = this._scaleObjectEqually(localMouse, target, transform, _dim)
        } else {
          let w = target.width * (localMouse.x / _dim.x)
          scaled = w !== target.width
          target.set('width', Math.max(target.minWidth, w))
          let h = target.height * (localMouse.y / _dim.y)
          scaled = h !== target.height
          target.set('height', Math.max(target.minHeight, h))
        }
      } else if (!by) {
        forbidScalingX || lockScalingX || (target.set('scaleX', scaleX) && (scaled = scaled || changeX))
        forbidScalingY || lockScalingY || (target.set('scaleY', scaleY) && (scaled = scaled || changeY))
      } else if (by === 'x' && !target.get('lockUniScaling')) {
        forbidScalingX || lockScalingX || (target.set('scaleX', scaleX) && (scaled = changeX))
      } else if (by === 'y' && !target.get('lockUniScaling')) {
        forbidScalingY || lockScalingY || (target.set('scaleY', scaleY) && (scaled = changeY))
      }
      forbidScalingX || forbidScalingY || this._flipObject(transform, by)
      return scaled
    },
    _scaleObjectEqually: function (localMouse, target, transform, _dim) {

      let dist = localMouse.y + localMouse.x,
        lastDist = _dim.y * transform.original.scaleY / target.scaleY +
        _dim.x * transform.original.scaleX / target.scaleX,
        scaled, signX = localMouse.x < 0 ? -1 : 1,
        signY = localMouse.y < 0 ? -1 : 1,
        newScaleX, newScaleY

      newScaleX = signX * Math.abs(transform.original.scaleX * dist / lastDist)
      newScaleY = signY * Math.abs(transform.original.scaleY * dist / lastDist)
      scaled = newScaleX !== target.scaleX || newScaleY !== target.scaleY
      if (target instanceof fabric.IText || target instanceof fabric.Path) {
        target.set('scaleX', newScaleX)
        target.set('scaleY', newScaleY)
      } else {
        target.set('width', Math.max(target.minWidth, target.width * newScaleX))
        target.set('height', Math.max(target.minHeight, target.height * newScaleY))
      }
      return scaled
    },
    _performTransformAction(e, transform, pointer) {
      let x = pointer.x,
        y = pointer.y,
        action = transform.action,
        actionPerformed = false,
        options = {
          target: transform.target,
          e: e,
          transform: transform,
          pointer: pointer
        }
      if (action === 'skewX') {
        action = 'scaleX'
      }
      if (action === 'skewY') {
        action = 'scaleY'
      }
      if ((options.target instanceof fabric.ArrowShape || options.target instanceof fabric.LineShape) && action === 'scale') {
        action = 'scaleX'
      }
      if (action === 'rotate') {
        (actionPerformed = this._rotateObject(x, y)) && this._fire('rotating', options)
      } else if (action === 'scale') {
        (actionPerformed = this._onScale(e, transform, x, y)) && this._fire('scaling', options)
      } else if (action === 'scaleX') {
        if ((options.target instanceof fabric.ArrowShape || options.target instanceof fabric.LineShape)) {
          actionPerformed = this._scaleObject(x, y, 'x')
          this._fire('scaling', options)
          actionPerformed = this._rotateObject(x, y)
          this._fire('rotating', options)
        } else {
          (actionPerformed = this._scaleObject(x, y, 'x')) && this._fire('scaling', options)
        }
      } else if (action === 'scaleY') {
        (actionPerformed = this._scaleObject(x, y, 'y')) && this._fire('scaling', options)
      } else if (action === 'skewX') {
        (actionPerformed = this._skewObject(x, y, 'x')) && this._fire('skewing', options)
      } else if (action === 'skewY') {
        (actionPerformed = this._skewObject(x, y, 'y')) && this._fire('skewing', options)
      } else {
        actionPerformed = this._translateObject(x, y)
        if (actionPerformed) {
          this._fire('moving', options)
          this.setCursor(options.target.moveCursor || this.moveCursor)
        }
      }
      transform.actionPerformed = transform.actionPerformed || actionPerformed
    }
  })
}
export default AnnotationArea