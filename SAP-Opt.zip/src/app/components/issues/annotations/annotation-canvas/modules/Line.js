let Line = (fabric) => {
    fabric.LineShape = fabric.util.createClass(fabric.Object, {
        type: 'LineShape',
        width: 200,
        height: 100,
        minWidth: 5,
        minHeight: 5,
        left: 0,
        top: 0,
        angle: 0,
        strokeWidth: 5,
        lockUniScaling: false,
        hasRotatingPoint: false,
        borderColor: 'transparent',
        cornerColor: '#3B3D3D',
        cornerStrokeColor: '#3B3D3D',
        cornerStyle: 'circle',
        transparentCorners: false,
        originY: 'center',
        originX: 'left',
        objectCaching: false,
        initialize(options) {
            options = options || {}
            this.callSuper('initialize', options)
            this.height = this.strokeWidth
            this.setControlsVisibility({
                mt: false,
                mb: false,
                tl: false,
                bl: false,
                tr: false,
                br: false
            })
            this.on('selected', () => {
                if (this.canvas) {
                    this.canvas.styleStroke = this.stroke
                    this.canvas.styleStrokeWidth = this.strokeWidth
                }
            })
        },
        setStyleFromUI(style) {
            this.set(style)
            this.height = this.strokeWidth
            this.setCoords()
        },
        _render(ctx) {
            ctx.save()
            ctx.lineJoin = 'round'
            ctx.lineCap = 'round'
            ctx.strokeStyle = this.stroke
            let strokeWidth = this.strokeWidth
            ctx.lineWidth = strokeWidth * 60 / 100
            ctx.beginPath()
            ctx.moveTo(-this.width / 2, 0)
            ctx.lineTo(this.width / 2, 0)
            ctx.stroke()
            ctx.restore()
        }
    })
    fabric.LineShape.fromObject = function (object, callback) {
        return fabric.Object._fromObject('LineShape', object, callback)
    }
}
export default Line