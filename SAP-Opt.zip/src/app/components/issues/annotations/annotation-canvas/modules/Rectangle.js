let Rectangle = (fabric) => {
    fabric.RectangleShape = fabric.util.createClass(fabric.Object, {
        type: 'RectangleShape',
        uuid: null,
        width: 200,
        height: 100,
        minWidth: 5,
        minHeight: 5,
        left: 0,
        top: 0,
        angle: 0,
        rx: 4,
        ry: 4,
        strokeWidth: 5,
        lockUniScaling: false,
        hasRotatingPoint: false,
        borderColor: '#3B3D3D',
        cornerColor: '#3B3D3D',
        cornerStrokeColor: '#3B3D3D',
        cornerStyle: 'circle',
        transparentCorners: false,
        objectCaching: false,
        initialize(options) {
            options = options || {}
            this.callSuper('initialize', options)
            this.on('selected', () => {
                if (this.canvas) {
                    this.canvas.styleStroke = this.stroke
                    this.canvas.styleStrokeWidth = this.strokeWidth
                }
            })
        },
        setStyleFromUI(style) {
            this.set(style)
            this.setCoords()
        },
        _render(ctx) {
            ctx.save()
            var rx = this.rx ? Math.min(this.rx, this.width / 2) : 0,
                ry = this.ry ? Math.min(this.ry, this.height / 2) : 0,
                w = this.width,
                h = this.height,
                x = -this.width / 2,
                y = -this.height / 2,
                isRounded = rx !== 0 || ry !== 0,
                k = 1 - 0.5522847498
            ctx.strokeStyle = this.stroke
            let strokeWidth = this.strokeWidth || 0
            ctx.lineWidth = strokeWidth * 60 / 100
            ctx.beginPath()
            ctx.moveTo(x + rx, y)
            ctx.lineTo(x + w - rx, y)
            isRounded && ctx.bezierCurveTo(x + w - k * rx, y, x + w, y + k * ry, x + w, y + ry)
            ctx.lineTo(x + w, y + h - ry)
            isRounded && ctx.bezierCurveTo(x + w, y + h - k * ry, x + w - k * rx, y + h, x + w - rx, y + h)
            ctx.lineTo(x + rx, y + h)
            isRounded && ctx.bezierCurveTo(x + k * rx, y + h, x, y + h - k * ry, x, y + h - ry)
            ctx.lineTo(x, y + ry)
            isRounded && ctx.bezierCurveTo(x, y + k * ry, x + k * rx, y, x + rx, y)
            ctx.closePath()
            ctx.stroke()
            ctx.restore()
        }
    })
    fabric.RectangleShape.fromObject = function (object, callback) {
        return fabric.Object._fromObject('RectangleShape', object, callback)
    }
}
export default Rectangle