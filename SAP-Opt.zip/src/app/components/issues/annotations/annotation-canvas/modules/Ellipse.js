let Ellipse = (fabric) => {
    fabric.EllipseShape = fabric.util.createClass(fabric.Object, {
        type: 'EllipseShape',
        width: 200,
        height: 100,
        minWidth: 5,
        minHeight: 5,
        left: 0,
        top: 0,
        angle: 0,
        strokeWidth: 5,
        stroke: '#FF6A00',
        lockUniScaling: false,
        hasRotatingPoint: false,
        borderColor: '#3B3D3D',
        cornerColor: '#3B3D3D',
        cornerStrokeColor: '#3B3D3D',
        cornerStyle: 'circle',
        transparentCorners: false,
        objectCaching: false,
        initialize(options) {
            options = options || {}
            this.callSuper('initialize', options)
            this.on('selected', () => {
                if (this.canvas) {
                    this.canvas.styleStroke = this.stroke
                    this.canvas.styleStrokeWidth = this.strokeWidth
                }
            })
        },
        setStyleFromUI(style) {
            this.set(style)
            this.setCoords()
        },
        _render(ctx) {
            ctx.save()
            ctx.strokeStyle = this.stroke || '#000000'
            let strokeWidth = this.strokeWidth || 0
            ctx.lineWidth = strokeWidth * 60 / 100
            ctx.beginPath()
            ctx.ellipse(0, 0, this.width / 2, this.height / 2, 0, Math.PI * 2, false)
            ctx.stroke()
            ctx.restore()
        }
    })
    fabric.EllipseShape.fromObject = function (object, callback) {
        return fabric.Object._fromObject('EllipseShape', object, callback)
    }
}
export default Ellipse