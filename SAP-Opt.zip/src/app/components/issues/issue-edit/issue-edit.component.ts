import { Component, OnInit, Input, NgZone, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { IssueEditService } from '../../../services/issues/issue-edit.service';
import { ControlContainer, FormGroup } from '@angular/forms';
import { HelperService } from '../../../services/helper/helper.service';
import { AngularFirestore } from '@angular/fire/firestore';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { Dimensions, ImageCroppedEvent, ImageTransform } from 'ngx-image-cropper';
import { AngularFireStorage } from '@angular/fire/storage';
import Compressor from 'compressorjs';
import { combineLatest, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { CountersService } from '../../../services/counters/counters.service';
import { IssuesFileFormatService } from '../../../services/issues/issues-file-format.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-issue-edit',
  templateUrl: './issue-edit.component.html',
  styleUrls: ['./issue-edit.component.scss']
})
export class IssueEditComponent implements OnInit, OnDestroy {

  // Inputs from parent containers
  @Input() folder_id;
  @Input() project_id;
  @Input() issue_id;
  @Input() user_id;

  // Square Image Functionality
  imageUploadDate: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  canvasRotation = 0;
  rotation = 0;
  scale = 1;
  showCropper = false;
  containWithinAspectRatio = false;
  transform: ImageTransform = {};
  _subscription: Subscription;
  issueThumbnailNeedsToBeSet: boolean = false;
  square_image_selected: boolean = false;
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };
  generating_square_image: boolean = false;

  // Form
  public form: FormGroup;

  // User Settings
  userSettings: any = {};

  // For photo uploads
  isHovering: boolean;
  files: File[] = [];

  // Image Ordering
  sortablejsOptions = {};

  // For Resetting the File Input
  @ViewChild('imageUploadInputFile')
  imageUploadInputFile: ElementRef;

  constructor(
    public issueEditService: IssueEditService,
    private controlContainer: ControlContainer,
    public helperService: HelperService,
    private afs: AngularFirestore,
    private zone: NgZone,
    private storage: AngularFireStorage,
    public countersService: CountersService,
    public issuesFileFormatService: IssuesFileFormatService
  ) {
    this.setPhotoSortableJsOptions();
  }

  resetFileInput() {
    this.imageUploadInputFile.nativeElement.value = "";
  }

  ngOnInit(): void {
    this.form = <FormGroup>this.controlContainer.control;
    this.userSettings = this.helperService.getUserSettings();
    this.issuesFileFormatService.incorrect_file_type_names = [];
    this.issuesFileFormatService.incorrect_file_type = false;
  }

  ngOnDestroy(): void {
    this._subscription?.unsubscribe();
  }


  /**----------------------------------------------------------------------------------------
  * Toggle Hover
  * * When hovering an image over the drop zone, add a class for the hover state
  -----------------------------------------------------------------------------------------*/
  toggleHover(event: boolean) {
    this.isHovering = event;
  }



  /**----------------------------------------------------------------------------------------
  * Clear Date
  * * When clicking the 'x' inside the issue due date input, the form value will be reset
  * * The form status will be marked as dirty
  -----------------------------------------------------------------------------------------*/
  clearDate(event) {
    event.stopPropagation();
    this.issueEditService.issueForm.controls['issue_due_date'].setValue(null);
    this.issueEditService.issueForm.markAsDirty();
  }



  /**----------------------------------------------------------------------------------------
  * Detect Photos
  * * Empty the files array
  * * Reset any values associated to incorrect file types on upload
  * * Set the "filesUploadedCount" value to 0;
  * * Display the image upload overlay
  * * Push all incoming files into the files array
  * * The HTML will pick this up for the app-image-upload component
  -----------------------------------------------------------------------------------------*/
  detectPhotoUpload(files: FileList) {
    this.files = [];
    var index = 0;
    this.issuesFileFormatService.resetIncorrectFileTypes();
    if (this.issueEditService.issueForm.dirty) {
      this.issueEditService.setIssueDetail();
    }
    for (let i = 0; i < files.length; i++) {
      var file = files.item(i);
      const fileType = file.type;
      const fileName = file.name;
      var fileExtension = fileType.split('/').pop();
      if(!(fileExtension == "jpg" || fileExtension == "jpeg" || fileExtension == "png")) {
        this.issuesFileFormatService.incorrect_file_type = true;
        this.issuesFileFormatService.incorrect_file_type_names.push(fileName);
      } else {
        index++
        files.item(i)["index"] = index - 1;
        this.issueEditService.filesUploadedCount = 0;
        this.issueEditService.overlay_uploading = true;
        this.files.push(files.item(i));
        this.issueEditService.filesCount = this.files.length;
      }
    }
  }





  /**----------------------------------------------------------------------------------------
  * Set Photo Sortable JS Options
  * * When images are sorted, batch them
  * * For each image, create a reference with the image ID
  * * Update update and increase the index by 1
  -----------------------------------------------------------------------------------------*/
  setPhotoSortableJsOptions() {
    this.sortablejsOptions = {
      onEnd: (event: any) => {
        let batch = this.afs.firestore.batch();
        let index = 0
        this.issueEditService.imagesArray.forEach((photo) => {
          const issueRef = this.afs.collection(`users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images`).doc(`${photo.id}`).ref;
          batch.update(issueRef, { image_order: index });
          // Set the Issue thumbnail to the first image for this issue
          var image = this.issueEditService.imagesArray[0];

          var imageThumbnailPath = image.image_photo_thumbnail;
          var imageThumbnailURL = image.image_photo_thumbnail_url;
          this.issueEditService.updateIssueThumbnailAfterReorderOrDelete(imageThumbnailPath, imageThumbnailURL);
          index = index + 1
        });
        batch.commit();
      }
    }
  }


  
  /**----------------------------------------------------------------------------------------
  * Convert Base64 To Blob
  * * CompressorJS requires a file or blob
  * * When the user saves a cropped image, this function is called
  * * The base64 file will be converted to a blob
  * * Upon completion, it will call "saveCroppedImage"
  -----------------------------------------------------------------------------------------*/
  convertBase64ToBlob() {

    var byteString = atob(this.croppedImage.split(',')[1]);
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    var croppedImage = new Blob([ab], { type: "image/jpeg" });
    this.saveCroppedImage(croppedImage)
  }



  /**----------------------------------------------------------------------------------------
  * Save Cropped Image
  * * Receives a blob from "convertBase64ToBlob"
  * * "generating_square_image" set to true to display the square image editing overlay
  * * "currentImageCount" sets the current count of images for this issue
  * * If "currentImageCount" exists, set "currentImageCountPlusIndex" to the value +1
  * * If "currentImageCount" doesn't exist, set the value to 1
  * * Create a new "photo_id" for the incoming image
  * * Use Compressor JS to create the size of the large and thumbnail images
  * * Upload both images
  * * Set the image document
  * * Update the issue image count
  * * Hide overlays
  * * Set the issue thumbnail if it doesn't already have one
  -----------------------------------------------------------------------------------------*/
  saveCroppedImage(blob: Blob){

    this.generating_square_image= true;

    const currentImageCount = this.issueEditService.image_count;

    if (currentImageCount) {
      var currentImageCountPlusIndex = currentImageCount + 1;
    } else {
      var currentImageCountPlusIndex = 1;
    }

    if (currentImageCount == 0) {
      this.issueThumbnailNeedsToBeSet = true;
      
    }

    const photo_id = this.afs.createId();

    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(blob, {
        quality: 0.75,
        maxWidth: 1000,
        maxHeight: 1000,
        checkOrientation: true
      });
      const thumb = await this.compressImage(blob, {
        quality: 0.75,
        maxWidth: 300,
        maxHeight: 300,
        checkOrientation: true,
      });
      return {
        original,
        thumb
      };
    }).then((results) => {

      const thumbPath = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}/${photo_id}_issue_photo_thumbnail_${photo_id}.jpeg`;
      const thumbTaskRef = this.storage.ref(thumbPath);
      const thumbTask = this.storage.upload(thumbPath, results.thumb, this.metadata);

      const largePath = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}/${photo_id}_issue_photo_${photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const db_path = `users/${this.user_id}/projects/${this.project_id}/issues/${this.issue_id}/images/${photo_id}`;

      const obs$ = combineLatest([thumbTask, largeTask]);

      this._subscription = obs$.pipe(
        switchMap(async ([thumbTask, largeTask]) => {
          const thumbUrl = await thumbTaskRef.getDownloadURL().toPromise();
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`${db_path}`).set({
            dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
            // image_date: firebase.firestore.FieldValue.serverTimestamp(),
            image_date: new Date(this.imageUploadDate),
            image_order: currentImageCountPlusIndex,
            version: 1,
            image_photo_thumbnail: thumbPath,
            image_photo_thumbnail_url: thumbUrl,
            image_photo: largePath,
            image_photo_url: largeUrl,
          }).then(() => {
            this.generating_square_image= false;
            this.square_image_selected = false;
            this.issueEditService.filesUploadedCount++;
            this.countersService.issuePhotoCount(+1, this.user_id, this.project_id, this.issue_id);
            if (this.issueThumbnailNeedsToBeSet) {
              this.issueEditService.setIssueThumbnail(thumbPath, thumbUrl);
            }
          })
        })
      ).subscribe();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Compress Image
  * * Used by CompressorJS (saveCroppedImage) to resize images
  -----------------------------------------------------------------------------------------*/
  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Square Image Functionality
  * * All functions below are part of ngx-image-cropper
  -----------------------------------------------------------------------------------------*/
  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageUploadDate = event.target.files[0].lastModified;
    this.square_image_selected = true;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
 
  imageLoaded() {
    this.showCropper = true;
    this.generating_square_image= false;
  }

  cropperReady(sourceImageDimensions: Dimensions) {
    // console.log('Cropper ready', sourceImageDimensions);
  }

  loadImageFailed() {
    // console.log('Load failed');
  }

  rotateLeft() {
    this.generating_square_image= true;
    setTimeout(() => {
      this.canvasRotation--;
      this.flipAfterRotate();
    }, 500);

  }

  rotateRight() {
    this.generating_square_image= true;
    setTimeout(() => {
      this.canvasRotation++;
      this.flipAfterRotate();
    }, 500);
  }

  private flipAfterRotate() {
    const flippedH = this.transform.flipH;
    const flippedV = this.transform.flipV;
    this.transform = {
      ...this.transform,
      flipH: flippedV,
      flipV: flippedH
    };
  }


  flipHorizontal() {
    this.transform = {
      ...this.transform,
      flipH: !this.transform.flipH
    };
  }

  flipVertical() {
    this.transform = {
      ...this.transform,
      flipV: !this.transform.flipV
    };
  }

  resetImage() {
    this.scale = 1;
    this.rotation = 0;
    this.canvasRotation = 0;
    this.transform = {};
  }

  zoomOut() {
    this.scale -= .1;
    this.transform = {
      ...this.transform,
      scale: this.scale
    };
  }

  zoomIn() {
    this.scale += .1;
    this.transform = {
      ...this.transform,
      scale: this.scale
    };
  }

  toggleContainWithinAspectRatio() {
    this.containWithinAspectRatio = !this.containWithinAspectRatio;
  }

  updateRotation() {
    this.transform = {
      ...this.transform,
      rotate: this.rotation
    };
  }



}
