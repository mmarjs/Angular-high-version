import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ProjectsListService } from '../../../services/projects/projects-list.service';
import { HelperService } from '../../../services/helper/helper.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { switchMap, tap } from 'rxjs/operators';
import { AuthService } from '../../../services/authentication/auth.service';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
@Component({
  selector: 'app-projects-list',
  templateUrl: './projects-list.component.html',
  styleUrls: ['./projects-list.component.scss']
})

export class ProjectsListComponent implements OnInit, OnDestroy {

  // User Settings
  userSettings: any = {};

  // URL Params
  folder_id: string;
  project_id: string;
  user_id: string;
  // Projects List
  private _projectsSubscription: Subscription;
  private _userSettingSubscription: Subscription;

  constructor(
    public projectsListService: ProjectsListService,
    public helperService: HelperService,
    private _activatedRoute: ActivatedRoute,
    public authService: AuthService,
    public userSettingsService: UserSettingsService,
  ) { }

  ngOnInit(): void {
    this.getUserID();
  }

  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the projects subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._projectsSubscription.unsubscribe();
  }

  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects"
  *   -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.getUserSettings(user.uid);
      this.getProjects(user.uid);
    }
  }

  getUserSettings(user_id: string){
    this._userSettingSubscription = this.userSettingsService.getUserSettings(user_id).subscribe(settings => {
      if (settings) {
        this.userSettings = settings;
      }
    });
  }

  
  /**----------------------------------------------------------------------------------------
  * Get Projects
  * * Update the _projectsSubscription with the query subscription
  * * Update the "folder_id" variable with the "folder_id" from the URL params
  * * Call "getProjects" from the "projectsListService"
  * * Update the local "projectsArray" with the results
  -----------------------------------------------------------------------------------------*/
  getProjects(user_id: string) {
    this._projectsSubscription = this._activatedRoute.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.projectsListService.getProjects(user_id, params.folder_id);
      })
    ).subscribe(projects => {
      this.projectsListService.projectsArray = projects;
      this.projectsListService.showSpinner = false;
    });
  }


  /**----------------------------------------------------------------------------------------
  * Set New Project
  * * Call the 'setNewProject' function in the 'projectsListService'
  * * Required params is the folder id and the user settings for auditor and company name
  -----------------------------------------------------------------------------------------*/
  setNewProject() {
    this.projectsListService.setNewProject(this.folder_id, this.userSettings.usersetting_auditorname, this.userSettings.usersetting_companyname, this.userSettings.usersetting_dateformat)
  }



  /**----------------------------------------------------------------------------------------
  * Search Projects
  * * Search through the list of projects
  -----------------------------------------------------------------------------------------*/
  searchProjects(): void {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("projectSearchInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("projects");
    li = ul.getElementsByTagName("li");

    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByClassName("project-title")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
      } else {
        li[i].style.display = "none";
      }
    }
  }


}