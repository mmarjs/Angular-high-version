import { Component, OnInit, Input } from '@angular/core';
import { HelperService } from '../../../services/helper/helper.service';
import { switchMap, tap } from 'rxjs/operators';
import { ProjectDetailService } from '../../../services/projects/project-detail.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../services/authentication/auth.service';
import { Observable, Subscription } from 'rxjs';
import { Project } from '../../../interfaces/project';
import { AngularFirestore } from '@angular/fire/firestore';
import { CountersService } from '../../../services/counters/counters.service';
import { ProjectsListService } from '../../../services/projects/projects-list.service';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { FoldersService } from '../../../services/folders/folders.service';

@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.scss']
})

export class ProjectDetailComponent implements OnInit {

  @Input() summaryLayoutToggle;

  // URL Params
  folder_id: string;
  project_id: string;

  // User
  user_id: string;

  // User Settings
  userSettings: any = {};

  // Project Document
  project$: Observable<Project>;
  operation$: Observable<any>;

  public duplication_stepOne: boolean = true;
  public duplication_stepTwo: boolean = false;
  public duplication_stepThree: boolean = false;
  public duplication_status_text: string;
  public duplication_status: string;
  public duplication_code: string;
  public duplication_error_title: string;
  public duplication_error_msg: string;
  duplication_project_id: string;
  _operationSubscription: Subscription;
  overlay_duplicate_project: boolean = false;
  isFirst = false;

  constructor(
    public foldersService: FoldersService,
    public helperService: HelperService,
    private _activatedRoute: ActivatedRoute,
    public projectDetailService: ProjectDetailService,
    public authService: AuthService,
    private afs: AngularFirestore,
    private router: Router,
    private countersService: CountersService,
    private projectsListService: ProjectsListService,
    public userSettingsService: UserSettingsService,
  ) { }

  ngOnInit(): void {
    this.userSettings = this.helperService.getUserSettings();
    this.getUserID();
  }
  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID(){
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      // this.getUserSettings(user.uid);
      this.getProjectDetail(user.uid);
    }
  }


  /**----------------------------------------------------------------------------------------
  * Get Project Detail
  * * Fetch the document matching the product_id from the URL params
  -----------------------------------------------------------------------------------------*/
  getProjectDetail(user_id: string) {
    this.project$ = this._activatedRoute.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.projectDetailService.getProject(user_id, params.project_id).pipe(
          tap(data => {
            if (data) {
              this.isFirst = true;
              return data;
            } else if(!this.isFirst) {
              this.router.navigate(['/', 'folders']);
            }            
          })
        );
      })
    )
  }

  /**----------------------------------------------------------------------------------------
  * Delete Project
  * * Delete project
  * * Hide the overlay
  * * Decrease the project count on the folder
  * * Return to the folder/folder_id screen
  -----------------------------------------------------------------------------------------*/
  deleteProject(user_id: string, folder_id: string){
    this.projectsListService.deleteProjectClick = true;
    this.foldersService.folder_id = folder_id;
    this.projectDetailService.projectDoc.delete().then(() => {
      this.projectDetailService.overlay_delete_project = false;
      this.countersService.folderProjectCount(-1, user_id, folder_id)
    }).then(() => {
     if (this.projectsListService.projectsArray.length <= 0) {
        this.router.navigate(['/', 'folders', folder_id]);
      } else {
        this.router.navigate(['/', 'folders', folder_id, 'projects', this.projectsListService.projectsArray[0].id]);
      }
    })
  }


  /**----------------------------------------------------------------------------------------
   * Set User Operation for duplication
   * * Create a new project id
   * * Create a new document in the operations colletion for the user
   * * Upon completion, call "subscribeToNewOperation"
   -----------------------------------------------------------------------------------------*/
  setUserOperation(){
    const project_id = this.afs.createId();
    this.afs.collection(`users/${this.user_id}/operations`).doc(`${project_id}`).set({
      type: 'duplicate-project',
      status: 'pending',
      created_at: firebase.firestore.FieldValue.serverTimestamp(),
      request: {
        id: `${this.project_id}`
      }
    }).then(() => {
      this.subscribeToNewOperation(project_id);
    })
  }



  /**----------------------------------------------------------------------------------------
  * Subscribe to new duplication / operation document
  * * Subscribe to the changes in the document (primarily the status)
  * * Update the duplication booleans for presentation
  * * Watch the operation status to determine what to display on the UI
  * * If it passes / fails, call "finishedDuplicationWithSuccess" with true / false
  -----------------------------------------------------------------------------------------*/
  subscribeToNewOperation(project_id: string){   

    this.duplication_stepOne = false;
    this.duplication_stepTwo = true;

    this._operationSubscription = this.projectDetailService.getOperation(this.user_id, project_id).subscribe(operation => {
      const status = operation.status;
      const code = operation.response?.code;
      const display_title = operation.response?.display_title;
      const display_message = operation.response?.display_message;
      switch (status) {
        case "pending":
          this.duplication_status_text = "Queuing Duplication";
          break;
        case "running":
          this.duplication_status_text = "Duplicating Project";
          break;
        case "success":
          this.duplication_status_text = "Success!";
          this.finishedDuplicationWithSuccess(true, display_title, display_message);
          this.duplication_project_id = operation.response.id;
          break;
        case "failed":
          this.duplication_status_text = "Duplication Failed!";
          this.finishedDuplicationWithSuccess(false, display_title, display_message);
          this.duplication_status = 'failed';
          break;
        default:
          break;
      }
    });
  }



  /**----------------------------------------------------------------------------------------
  * Finished Duplication
  * * Update the duplication booleans for presentation
  -----------------------------------------------------------------------------------------*/
  finishedDuplicationWithSuccess(status: boolean, display_title: string, display_message: string){
    switch (status) {
      case true:
        this.duplication_stepTwo = false;
        this.duplication_stepThree = true;
        this.countersService.folderProjectCount(+1, this.user_id, this.folder_id);
        break;
      case false:
        this.duplication_error_msg = display_message;
        this.duplication_stepTwo = false;
        this.duplication_error_title = display_title;
        break;    
      default:
        break;
    }
  }



  /**----------------------------------------------------------------------------------------
  * Go to New Duplicated Project
  * * Once a project has successfully duplicated, this link will allow the user to...
  * * ...navigate to the new project
  -----------------------------------------------------------------------------------------*/
  goToProject(folder_id: string){
    this.resetDuplicationBooleans();
    this.router.navigate(['/', 'folders', folder_id, 'projects', this.duplication_project_id]);  
  }



  /**----------------------------------------------------------------------------------------
  * Reset Duplication Booleans
  * * This function will reset all duplicatio booleans so that the functionality can be...
  * * ...repeated
  -----------------------------------------------------------------------------------------*/
  resetDuplicationBooleans(){
    this.overlay_duplicate_project = false;
    this.duplication_stepOne = true;
    this.duplication_stepThree = false;
    this.duplication_code = "";
    this.duplication_status_text = "";
    this.duplication_status = "";
  }


}
