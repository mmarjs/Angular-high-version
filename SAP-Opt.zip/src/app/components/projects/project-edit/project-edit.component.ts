import { Component, OnDestroy, OnInit, Input } from '@angular/core';
import { HelperService } from '../../../services/helper/helper.service';
import { switchMap, tap } from 'rxjs/operators';
import { ProjectDetailService } from '../../../services/projects/project-detail.service';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../services/authentication/auth.service';
import { Subscription } from 'rxjs';
import { FoldersService } from '../../../services/folders/folders.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-project-edit',
  templateUrl: './project-edit.component.html',
  styleUrls: ['./project-edit.component.scss']
})
export class ProjectEditComponent implements OnInit, OnDestroy {

  // URL Params
  folder_id: string;
  project_id: string;

  // User Settings
  userSettings: any = {};

  // Project Document
  _subscription: Subscription;

  // Folders
  private _foldersSubscription: Subscription;
  foldersArray = [];

  // For photo uploads
  isHovering: boolean;

  // User
  user_id: string;

  disabled: boolean = false;
  showSpinners: boolean = true;
  showSeconds: boolean = false;
  disableMinute: boolean = false;
  stepHour: number = 1;
  stepMinute: number = 1;
  stepSecond: number = 1;
  enableMeridian: boolean = true;
  hideTime: boolean = true;

  constructor(
    public helperService: HelperService,
    private _activatedRoute: ActivatedRoute,
    public projectDetailService: ProjectDetailService,
    public authService: AuthService,
    public foldersService: FoldersService,
    public router: Router
  ) {
   }

   
  ngOnInit(): void {
    this.userSettings = this.helperService.getUserSettings();
    this.getUserID();
    this.foldersService.storeRoute(this.router.url);
  }


  
  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the issues subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._subscription?.unsubscribe();
    this._foldersSubscription?.unsubscribe();
  }


  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getProjectDetail(user.uid);
      this.getFolders(user.uid);
    }
  }



  /**----------------------------------------------------------------------------------------
  * Get Project Detail
  * * Fetch the document matching the product_id from the URL params
  -----------------------------------------------------------------------------------------*/
  getProjectDetail(user_id: string) {
    this._subscription = this._activatedRoute.parent.parent.params.pipe(
      tap(params => {
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.projectDetailService.getProject(user_id, params.project_id)
      })
    ).subscribe(project => {
      if (project) {
        this.projectDetailService.projectForm.reset();
        this.projectDetailService.project$.next(project);
        this.projectDetailService.projectForm.patchValue(project);
      }
    });
  }


  /**----------------------------------------------------------------------------------------
 * Get Folders
 * * Update the _foldersSubscription with the query subscription
 * * Call "getFolders" from the "foldersService"
 * * Update the local "foldersArray" with the results
 * * This will be used for the folder selection dropdown
 -----------------------------------------------------------------------------------------*/
  getFolders(user_id: string) {
    this._foldersSubscription = this.foldersService.getFolders(user_id).subscribe(folders => {
      this.foldersArray = folders;
    });
  }
  


  /**----------------------------------------------------------------------------------------
  * Toggle Hover
  * * When hovering an image over the drop zone, add a class for the hover state
  -----------------------------------------------------------------------------------------*/
  toggleHover(event: boolean) {
    this.isHovering = event;
  }

}


