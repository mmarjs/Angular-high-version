import { Component, OnDestroy, OnInit } from '@angular/core';
import { ProjectDetailService } from '../../../services/projects/project-detail.service';
import { AuthService } from '../../../services/authentication/auth.service';
import { ProjectSignatureService } from '../../../services/projects/project-signature.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { FoldersService } from '../../../services/folders/folders.service';

@Component({
  selector: 'app-project-signature',
  templateUrl: './project-signature.component.html',
  styleUrls: ['./project-signature.component.scss']
})
export class ProjectSignatureComponent implements OnInit, OnDestroy {

  // User
  user_id: string;

  // URL Params
  folder_id: string;
  project_id: string;

  // Project Document
  _subscription: Subscription;

  // For photo uploads
  isHovering: boolean;



  constructor(
    public projectDetailService: ProjectDetailService,
    public authService: AuthService,
    public projectSignatureService: ProjectSignatureService,
    private _activatedRoute: ActivatedRoute,
    public foldersService: FoldersService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getUserID();
    this.foldersService.storeRoute(this.router.url);
    this.projectSignatureService.incorrect_file_type = false;
  }


  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the project subscription
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._subscription.unsubscribe();
    this.projectSignatureService._projectSignatureSubscription?.unsubscribe();
  }


  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Get the users ID
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getProjectDetail(user.uid);
    }
  }


  /**----------------------------------------------------------------------------------------
  * Get Project Detail
  * * Fetch the document matching the product_id from the URL params
  -----------------------------------------------------------------------------------------*/
  getProjectDetail(user_id: string) {
    this._subscription = this._activatedRoute.parent.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
      }),
      switchMap(params => {
        return this.projectDetailService.getProject(user_id, params.project_id)
      })
    ).subscribe(project => {
      if (project) {
        this.projectDetailService.projectForm.reset();
        this.projectDetailService.project$.next(project);
        this.projectDetailService.projectForm.patchValue(project);
        project.project_signature_image_url ? this.projectSignatureService.getSignatureImage(project.project_signature_image) : this.projectSignatureService.project_signature_image_url = null;
      }
    });
  }



  /**----------------------------------------------------------------------------------------
  * Toggle Hover
  * * When hovering an image over the drop zone, add a class for the hover state
  -----------------------------------------------------------------------------------------*/
  toggleHover(event: boolean) {
    this.isHovering = event;
  }




}
