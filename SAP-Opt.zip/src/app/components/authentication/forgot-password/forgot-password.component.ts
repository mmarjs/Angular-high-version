import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/authentication/auth.service';
import { HelperService } from '../../../services/helper/helper.service';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {



  constructor(
    public authService: AuthService,
    public helperService: HelperService
  ) { 
  }

  ngOnInit(): void {
    this.authService.password_reset = false;
    this.authService.password_error_message = '';
  }


  signOut(){
    this.authService.signOut();
  }


}
