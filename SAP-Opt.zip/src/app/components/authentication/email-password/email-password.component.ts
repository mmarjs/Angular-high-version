import { Component, OnInit, NgZone } from '@angular/core';
import { AuthService } from '../../../services/authentication/auth.service';
import { Subscription } from 'rxjs';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ErrorMessages } from '../../../services/errors/errors.service';
import { HelperService } from '../../../services/helper/helper.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-email-password',
  templateUrl: './email-password.component.html',
  styleUrls: ['./email-password.component.scss']
})
export class EmailPasswordComponent implements OnInit {

  private _subscription: Subscription;

  // Login Errors
  error_message: string;

  constructor(
    public authService: AuthService, 
    private userSettingsService: UserSettingsService, 
    public ngZone: NgZone, 
    public router: Router,
    public helperService: HelperService
    ) { }

  ngOnInit(): void {
  }

 login(email: string, password: string){
    this.authService.signIn(email, password).then((result) => {
      if(result){
        this.getUserID();
        this.ngZone.run(() => {
          setTimeout(() => {
            this.router.navigate(['folders']);
          }, 500);
          this.error_message = '';
        });
      }
    }).catch((error) => {
      this.error_message = ErrorMessages.convertMessage(error.code);
    })
  }

  async getUserID(){
    const user = await this.authService.getUserID()
    if (user) {
      this.getUserSettings(user.uid);
    }
  }  

  getUserSettings(user_id: string){
    this._subscription = this.userSettingsService.getUserSettings(user_id).subscribe(settings => {
      // localStorage.removeItem('user_settings');
      if (settings) {
        localStorage.setItem('user_settings', JSON.stringify(settings));
        // this.userSettingsService.allSettingsForm.reset();
        // this.userSettingsService.settings$.next(settings);
        // this.userSettingsService.allSettingsForm.patchValue(settings);
        // this.userSettingsService.generalSettingsForm.patchValue(settings);
        // this.userSettingsService.companySettingsForm.patchValue(settings);
        // this.userSettingsService.customWordingsForm.patchValue(settings);
      }
    });
  }
}
