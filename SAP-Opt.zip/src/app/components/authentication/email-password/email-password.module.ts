import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailPasswordComponent } from './email-password.component';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: EmailPasswordComponent,
  }
]

@NgModule({
  declarations: [EmailPasswordComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class EmailPasswordModule { }



