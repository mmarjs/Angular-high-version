import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationComponent } from './authentication.component';
import { Routes, RouterModule } from '@angular/router';

import { LoggedInGuard } from '../../guards/logged-in.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('../authentication/email-password/email-password.module').then(mod => mod.EmailPasswordModule),
    children:[
      { 
        path: 'sign-in-password', 
        loadChildren: () => import('../authentication/email-password/email-password.module').then(mod => mod.EmailPasswordModule),
      },
      { 
        path: 'forgot-password', 
        loadChildren: () => import('../authentication/forgot-password/forgot-password.module').then(mod => mod.ForgotPasswordModule),
      },
      { path: '', redirectTo: 'sign-in-password', pathMatch: 'full' },
    ],
  }
]

@NgModule({
  declarations: [AuthenticationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})

export class AuthenticationModule { }
