import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/authentication/auth.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {

  mode: string;
  actionCode: string;
  continueUrl: string;
  lang: string;

  showResetPassword: boolean = false;
  showSuccessfulPasswordReset: boolean = false;
  showErrorPanel: boolean = false;

  passwordForm: FormGroup;

  constructor(
    public authService: AuthService,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder
  ) { 
    this.passwordForm = this.formBuilder.group({
      password: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this._activatedRoute.queryParamMap.subscribe(queryParams => {
      this.mode = queryParams.get("mode");
      this.actionCode = queryParams.get("oobCode");
      this.continueUrl = queryParams.get("continueUrl");
      this.lang = queryParams.get("lang");
      // Handle the user management action.
      switch (this.mode) {
        case 'resetPassword':
          // Display reset password handler and UI.
          this.handleResetPassword(this.actionCode, this.continueUrl, this.lang);
          break;
        case 'recoverEmail':
          // Display email recovery handler and UI.
          // handleRecoverEmail(auth, actionCode, lang);
          break;
        case 'verifyEmail':
          // Display email verification handler and UI.
          // handleVerifyEmail(auth, actionCode, continueUrl, lang);
          break;
        default:
        // Error: invalid mode.
      }
    })
  }

     /**-------------------------------------------------------------------------------------------
  * * Handle Reset Password
  * Verify the password reset code is valid
  * If it's valid show the reset password panel in the html
  --------------------------------------------------------------------------------------------*/
  handleResetPassword(actionCode, continueUrl, lang) {
    var accountEmail;
    firebase.auth().verifyPasswordResetCode(actionCode).then((email) => {
      var accountEmail = email;
      this.showResetPassword = true;
    }).catch((error) => {
      if (error.code = "auth/invalid-action-code") {
        this.showResetPassword = false;
        this.showErrorPanel = true;
      }
    });
  }



  /**-------------------------------------------------------------------------------------------
  * * Handle Reset Password
  * This is called once the user has entered a new password and has submitted it
  * Once completed, hide the reset password panel and show the completion panel
  --------------------------------------------------------------------------------------------*/
  confirmPasswordReset() {
    const newPassword = this.passwordForm.value.password;
    firebase.auth().confirmPasswordReset(this.actionCode, newPassword).then((resp) => {
      this.showResetPassword = false;
      this.showSuccessfulPasswordReset = true;
    }).catch((error) => {
      // Error occurred during confirmation. The code might have expired or the
      // password is too weak.
    });
  }

}
