import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/authentication/auth.service';
import { HelperService } from '../../services/helper/helper.service';
@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {

  menuMinimised: string = "false";
  homeIconClick: boolean = false;
  constructor(
    public authService: AuthService,
    private helperService: HelperService
  ) { }

  ngOnInit(): void {
    this.setSubMenuSetting();
  }

  setSubMenuSetting(){
    const subMenuSetting = this.helperService.getSubmenuSetting();
    if (subMenuSetting) {
      this.menuMinimised = subMenuSetting;
    }
  }

  handleHomeIconClick() {
    this.homeIconClick = !this.homeIconClick;
  }

  toggleSubMenu(){
    localStorage.removeItem('submenuSetting');
    if (this.menuMinimised === "true") {
      // if currently true, set to false
      localStorage.setItem('submenuSetting', "false");
      this.menuMinimised = "false";
    } else {
      // if currently false, set to true
      localStorage.setItem('submenuSetting', "true");
      this.menuMinimised = "true";
    }
  }

}
