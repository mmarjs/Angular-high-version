import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from '../../services/authentication/auth.service';
import { UserSettingsService } from '../../services/user-settings/user-settings.service';
import { HelperService } from '../../services/helper/helper.service';
import { Subscription } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/storage';
import { Router } from '@angular/router';
import { FoldersService } from '../../services/folders/folders.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit, OnDestroy {

  // User
  user_id: string;
  userSettings: any = {};

  // Settings Subscription
  _subscription: Subscription;

  // Company logo 
  isHovering: boolean;
  storage = firebase.storage();

  logoSizes = ["Extra Small", "Small", "Regular", "Large", "Extra Large"];


  constructor(
    public authService: AuthService,
    public helperService: HelperService,
    public userSettingsService: UserSettingsService,
    public foldersService: FoldersService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.getUserID();
    this.helperService.sapThemeMode = this.helperService.getThemeMode();
    this.foldersService.storeRoute(this.router.url);
    this.userSettings = this.helperService.getUserSettings();
    this.userSettingsService.incorrect_file_type = false;
  }

  ngOnDestroy(): void {
    this._subscription?.unsubscribe();
  }

  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getUserSettings(user.uid);
    }
  }

  /**----------------------------------------------------------------------------------------
  * Toggle Hover
  * * When hovering an image over the drop zone, add a class for the hover state
  -----------------------------------------------------------------------------------------*/
  toggleHover(event: boolean) {
    this.isHovering = event;
  }

  getUserSettings(user_id: string) {
    this._subscription = this.userSettingsService.getUserSettings(user_id).subscribe(settings => {
      localStorage.removeItem('user_settings');
      if (settings) {
        localStorage.setItem('user_settings', JSON.stringify(settings));
        this.userSettingsService.allSettingsForm.reset();
        this.userSettingsService.settings$.next(settings);
        this.userSettingsService.allSettingsForm.patchValue(settings);
        this.userSettingsService.generalSettingsForm.patchValue(settings);
        this.userSettingsService.companySettingsForm.patchValue(settings);
        this.userSettingsService.customWordingsForm.patchValue(settings);
        if (settings.usersetting_companylogo) {
          this.userSettingsService.getCompanyLogoURL(settings.usersetting_companylogo);
        }
      }
    });
  }


  setTheme(mode: string) {
    localStorage.removeItem('sapThemeMode');
    switch (mode) {
      case "dark":
        localStorage.setItem('sapThemeMode', "dark");
        this.helperService.sapThemeMode = "dark";
        break;
      case "light":
        localStorage.setItem('sapThemeMode', "light");
        this.helperService.sapThemeMode = "light";
        break;

      default:
        localStorage.setItem('sapThemeMode', "light");
        this.helperService.sapThemeMode = "light";
        break;
    }
  }


}
