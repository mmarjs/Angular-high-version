import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingsComponent } from './settings.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedDropzoneModule } from '../shared/dropzone/shared-dropzone.module';
import { IncorrectFileTypeModule } from '../shared/incorrect-file-type/incorrect-file-type.module'
const routes: Routes = [
  {
    path: '',
    component: SettingsComponent,
  }
]

@NgModule({
  declarations: [SettingsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, 
    ReactiveFormsModule,
    SharedDropzoneModule,
    IncorrectFileTypeModule
  ]
})

export class SettingsModule { }




