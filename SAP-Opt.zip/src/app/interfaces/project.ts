import firebase from 'firebase/app';
import 'firebase/firestore';

export interface Project {
    project_title: string;
    project_issue_count: number;
    project_folder: string;
    project_date: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    version?: number;
    dateCreated: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    document_owner: string;
    project_reference?: string;
    project_photo?: string;
    project_photo_url?: string;
    project_photo_thumbnail?: string;
    project_photo_thumbnail_url?: string;
    project_signature_image?: string;
    project_signature_image_url?: string;
    project_client?: string;
    project_auditor_name?: string;
    project_auditor_company?: string;
    project_address?: string;
    project_completed?: boolean;
}
