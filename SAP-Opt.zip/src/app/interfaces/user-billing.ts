import firebase from 'firebase/app';
import 'firebase/firestore';

export interface UserBilling {
    currency: string;
    expires_date: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    is_trial_period: string;
    latest_event: string;
    original_app_user_id: string;
    original_transaction_id: string;
    period_type: string;
    price_on_signup: number;
    product: string
    purchase_date: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    receipt_data: Blob;
    signup_date:firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    signup_method: string;
}
