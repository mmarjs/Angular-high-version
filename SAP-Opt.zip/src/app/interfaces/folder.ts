import firebase from 'firebase/app';
import 'firebase/firestore';

export interface Folder {
    folder_title: string;
    folder_colour: string;
    folder_project_count: number;
    document_owner: string;
    version?: number;
    dateCreated: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
}
