import firebase from 'firebase/app';
import 'firebase/firestore';

export interface Error {
    code: string;
    message: string;
}

export interface Exports {
    created_at: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    done_at: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    path: string;
    status: string;
    url: string;
    error: Error
}
