export interface User {
    user_name: string;
    user_lastname?: string;
    user_email: string;
 }