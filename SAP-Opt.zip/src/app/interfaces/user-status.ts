import firebase from 'firebase/app';
import 'firebase/firestore';

export interface AccountStatus {
    Active: "Active",
    Inactive: "Inactive",
    Locked: "Locked"
}

export interface UserStatus {
    account_status: AccountStatus; 
    expires_date?: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    is_on_revenuecat?: boolean;
    original_transaction_id?: string;
}
