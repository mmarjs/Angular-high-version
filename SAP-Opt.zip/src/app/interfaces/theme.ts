export interface Theme {
    class: string;
    css: string;
    html: string;
    order:number;
    published: boolean;
    thumbnail?: string;
    title: string;
}
