export interface UserStatistics {
    folder_count?: number;
    image_count?: number;
    issue_count?: number;
    project_count?: number;
    storage_allowance?: number;
    storage_used?: number;
}
