import firebase from 'firebase/app';
import 'firebase/firestore';

export interface Issue {
    issue_title: string;
    issue_order: number;
    issue_image_count: number;
    issue_due_date?: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    dateCreated: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    version?: number;
    issue_completed: boolean;
    issue_comments?: string;
    issue_assignee?: string;
    issue_thumbnail_url?: string | firebase.firestore.FieldValue; 
    issue_thumbnail?: string | firebase.firestore.FieldValue; 
}
