import firebase from 'firebase/app';
import 'firebase/firestore';

export interface PendingUploads {
    image_photo_thumbnail: boolean;
    image_photo: boolean,
}

export interface IssueImage {
    dateCreated: firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    image_date:firebase.firestore.FieldValue | firebase.firestore.Timestamp | Date;
    image_order: number;
    image_annotations?: string;
    image_annotations_url?: string;
    image_photo?: string;
    image_photo_url?: string;
    image_photo_thumbnail?: string;
    image_photo_thumbnail_url?: string;
    version?: number;
    pending_uploads: PendingUploads;
}
