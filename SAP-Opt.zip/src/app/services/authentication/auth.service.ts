import { Injectable, NgZone } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { first } from 'rxjs/operators';
import { ErrorMessages } from '../../services/errors/errors.service';
import firebase from 'firebase/app';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  userData: any; // Save logged in user data
  password_reset: boolean = false;
  overlay_signout: boolean = false;
  password_error_message: string;
  overlay_delete_account: boolean = false;
  delete_loader: boolean = false;
  delete_account_confirm: boolean = false;
  delete_error: boolean = false;
  delete_error_msg: string = '';

  constructor(
    public afs: AngularFirestore, // Inject Firestore service
    public afAuth: AngularFireAuth, // Inject Firebase auth service
    public router: Router,
    public ngZone: NgZone,  // NgZone service to remove outside scope warning,
  ) {
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.userData = user;
        localStorage.setItem('user', JSON.stringify(this.userData));
        JSON.parse(localStorage.getItem('user'));
      } else {
        localStorage.setItem('user', null);
        JSON.parse(localStorage.getItem('user'));
      }
    })
  }

  // Sign in with email/password
  signIn(email, password) {
    return this.afAuth.signInWithEmailAndPassword(email, password)
      // .then((result) => {
      //   this.ngZone.run(() => {
      //     setTimeout(() => {
      //       this.router.navigate(['folders']);
      //       // this.setUserData(this.userData);
      //     }, 500);
      //   });
      // }).catch((error) => {
      //   window.alert(error.message)
      // })
  }


  signInWithLink() {
    if (this.afAuth.isSignInWithEmailLink(window.location.href)) {
      let email = window.localStorage.getItem('emailForSignIn');
      if (!email) {
        email = window.prompt('Please provide the email you\'d like to sign-in with for confirmation.');
      }
      if (email) {
        this.afAuth.signInWithEmailLink(email, window.location.href).then(async (result) => {
          if (history && history.replaceState) {
            window.history.replaceState({}, document.title, window.location.href.split('?')[0]);
          }
          window.localStorage.removeItem('emailForSignIn');
          if (result.user) {
            setTimeout(() => {
              this.router.navigate(['dashboard']);
            }, 3000);
          }

        }).catch((error) => {
          alert(error);
        });
      }
    }
  }

  sendEmailLink(email) {
    this.afAuth.fetchSignInMethodsForEmail(email).then((signInMethods) => {
      let url = 'http://localhost:4200/auth/verify-email-address';
      if (environment.appUrl) {
        url = environment.appUrl + '/auth/verify-email-address';
      }

      // if user exists
      if (signInMethods.length) {

        if (this.afAuth.currentUser) {
          this.afAuth.signOut()
            .then(mess => {
              // console.log("mess", mess)
            })
            .catch((error) => {
              alert(error);
            });
        }
        //else {
        var actionCodeSettings = {
          'url': url,
          'handleCodeInApp': true
        };
        this.afAuth.sendSignInLinkToEmail(email, actionCodeSettings).then((response) => {
          this.router.navigate(['auth/verify-email-address']);
          window.localStorage.setItem('emailForSignIn', email);
          //this.emailSent = true;
        }).catch((error) => {
          alert(error);
          //this.handleError(error);
        });
        //}
      }
      else {
        alert('user does not exist');
      }
    });
  }

  // Sign up with email/password
  signUp(email, password) {
    return this.afAuth.createUserWithEmailAndPassword(email, password)
      .then((userData) => {
        userData.user.sendEmailVerification().then(() => {
          this.router.navigate(['auth/verify-email-address']);
        });
      }).catch((error) => {
        window.alert(error.message)
      })
  }

  // Send email verfificaiton when new user sign up
  sendVerificationMail(user) {
    return user.sendEmailVerification()
      .then(() => {
        this.router.navigate(['auth/verify-email-address']);
      })
  }

  // Reset Forggot password
  forgotPassword(passwordResetEmail) {
    let url = 'http://localhost:4200/auth/verify-email-address';
    if (environment.appUrl) {
      url = environment.appUrl + '/auth/sign-in';
    }

    // Redirection Settings
    let actionCodeSettings = {
      url: url,
      handleCodeInApp: false
    };
    return this.afAuth.sendPasswordResetEmail(passwordResetEmail, actionCodeSettings)
      .then(() => {
        this.password_reset = true;
        this.password_error_message = "";
      }).catch((error) => {
        this.password_error_message = ErrorMessages.convertMessage(error.code);
      })
  }

  // Returns true when user is looged in and email is verified
  get isLoggedIn(): boolean {
    const user = JSON.parse(localStorage.getItem('user'));
    return (user !== null && user.emailVerified !== false) ? true : false;
  }


  getUserID() {
    return this.afAuth.authState.pipe(first()).toPromise();
  }

  // Auth logic to run auth providers
  authLogin(provider) {
    return this.afAuth.signInWithPopup(provider)
      .then((result) => {
        this.ngZone.run(() => {
          this.router.navigate(['folders']);
        })
        // this.setUserData(result.user);
      }).catch((error) => {
        window.alert(error)
      })
  }


  // Sign out 
  signOut() {
    return this.afAuth.signOut().then(() => {
      this.router.navigate(['login']);
      localStorage.removeItem('user_settings');
      this.overlay_signout = false;
    })
  }


  deleteAccount(){
    var user = firebase.auth().currentUser;

    // Show the loading icon and hide deletion text
    this.delete_loader = true;

    user.delete().then(() => {
      this.delete_loader = false;
      this.overlay_delete_account = false;
      this.delete_error = true
      this.router.navigate(['/login'])
    }).catch((error) => {
      this.delete_loader = false;
      this.delete_error = true;
      this.delete_error_msg = error;
    });
  }


  cancelAccountDeletion(){
    this.overlay_delete_account = false;
    this.delete_account_confirm = false;
    this.delete_loader = false;
    this.delete_error = false;
    this.delete_error_msg = '';
  }



}
