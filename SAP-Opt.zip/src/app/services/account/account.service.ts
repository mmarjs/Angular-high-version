import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { shareReplay, map } from "rxjs/operators";
import { User } from '../../interfaces/user';
import firebase from 'firebase/app';
import 'firebase/auth';
import { ErrorMessages } from '../../services/errors/errors.service';
import { Exports } from '../../interfaces/exports';


@Injectable({
  providedIn: 'root'
})
export class AccountService {

  // Form and BS
  userForm = new FormGroup({});
  user$: BehaviorSubject<User>;

  // Email Form
  emailForm = new FormGroup({});
  email_error: boolean = false;
  email_error_message: string;

  // Email update form
  new_email: string = '';
  current_password: string = '';
  overlay_email_loader: boolean = false;
  overlay_reauthenticate: boolean = false;
  email_reauthenticate_panel: boolean = true;
  overlay_email_success: boolean = false;
  new_email_password: boolean = false;
  overlay_email_error: boolean = false;

  // Password Reset
  password_reset_success: boolean = false;
  password_reset_failure: boolean = false;
  password_reset_error: string;

  // Firestore User reference
  private userCollection: AngularFirestoreCollection<User>;
  private userDoc: AngularFirestoreDocument<User>;

  // Firestore Exports reference
  private exportsCollection: AngularFirestoreCollection<Exports>;
  private exportDoc: AngularFirestoreDocument<Exports>;

  dataExport_hasRecentExport: boolean = false;
  dataExport_status: string;
  dataExport_progressElement: boolean = false;
  dataExport_dataURL: string;
  dataExport_error_message: string;


  constructor(
    public formBuilder: FormBuilder,
    private afs: AngularFirestore,
  ) {
    this.userForm = formBuilder.group({
      user_name: [' '],
      user_lastname: [' '],
      user_email: [' '],
    });
    this.user$ = new BehaviorSubject({
      user_name: '',
      user_lastname: '',
      user_email: '',
    });
    this.emailForm = formBuilder.group({
      user_email: ['', Validators.required],
      user_password: ['', Validators.required],
    })
  }



  /**----------------------------------------------------------------------------------------
  * Get User Data
  * * Return the user document
  -----------------------------------------------------------------------------------------*/
  public getUserData(user_id: string): Observable<User> {
    this.userCollection = this.afs.collection<User>(`users`);
    this.userDoc = this.userCollection.doc<User>(`${user_id}`);
    return this.userDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        return {
          ...data,
        }
      }),
        shareReplay()
      );
  }



  /**----------------------------------------------------------------------------------------
  * Set User Name
  * * If the user changes their first or last name, update the document
  -----------------------------------------------------------------------------------------*/
  setUserName() {
    let formValue = { ...this.userForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }
    this.userDoc.update(formValue).then(() => {
      this.userForm.markAsPristine();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Reauthenticate the user
  * * Used in the Accounts Component when attempting to change the email address
  * * Changing the email requires the user have recently logged in
  -----------------------------------------------------------------------------------------*/
  reauthenticate() {
    const user = firebase.auth().currentUser;
    const credential = firebase.auth.EmailAuthProvider.credential(this.emailForm.value.user_email, this.emailForm.value.user_password);
    user.reauthenticateWithCredential(credential).then(() => {
      this.emailForm.reset();
      this.overlay_reauthenticate = false;
      this.email_reauthenticate_panel = false;
      this.new_email_password = true;
    }).catch((error) => {
      this.email_error = true;
      this.email_error_message = ErrorMessages.convertMessage(error.code);
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Update Users Email
  * * Updates the users email address
  * * Once updated, update the firestore document
  * * If it fails, display the error message
  -----------------------------------------------------------------------------------------*/
  updateUsersEmail() {
    this.overlay_email_loader = true;
    var user = firebase.auth().currentUser;
    user.updateEmail(this.emailForm.value.user_email).then(() => {
      // Update successful.
      this.updateUserDocWithEmail();
    }).catch((error) => {
      // An error happened.
      this.overlay_email_loader = false;
      this.overlay_email_error = true;
      this.email_error_message = ErrorMessages.convertMessage(error.code);
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Update User Doc with Email
  * * Called from 'updateUsersEmail' upon a successful email reset
  -----------------------------------------------------------------------------------------*/
  updateUserDocWithEmail() {
    this.userDoc.update({
      user_email: this.emailForm.value.user_email
    }).then(() => {
      this.overlay_email_loader = false;
      this.overlay_email_success = true;
      this.overlay_email_error = false;
      this.email_error_message = '';
      setTimeout(() => {
        this.overlay_email_success = false;
        this.new_email_password = false;
        this.email_reauthenticate_panel = true;
      }, 3000);
    })
  }


  
  /**----------------------------------------------------------------------------------------
  * Reset Password
  * * Update the users password
  * * If successful, display a success message
  * * If it fails, display an error message
  -----------------------------------------------------------------------------------------*/
  resetPassword(email: string) {
    var auth = firebase.auth();
    auth.sendPasswordResetEmail(email).then(() => {
      this.password_reset_success = true;
      this.password_reset_failure = false;
      setTimeout(() => {
        this.password_reset_success = false;
      }, 3000);
    }).catch((error) => {
      this.password_reset_failure = true;
      this.password_reset_error = ErrorMessages.convertMessage(error.code);
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get Existing Data Dump
  * * Checks whether an existing data dump has been requested within the last 24 hours
  * * Update the the `dataExport_hasRecentExport` based on the result
  * * This will determine the initial state of the `request data` or `download` button...
  * * ...in the UI
  -----------------------------------------------------------------------------------------*/
  async getExistingDataDump(user_id){
    var db = firebase.firestore();
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const { docs: exportDocs } = await db.collection(`users/${user_id}/exports`).where("created_at", ">", yesterday).get();
    const [exportDoc] = exportDocs;
    if (exportDoc) {
      const data = exportDoc.data();
      this.dataExport_status = data.status;
      if (data.status === 'running' || data.status === 'pending') {
        this.dataExport_progressElement = true;
      }
      if (data.status === 'done') {      
        this.dataExport_dataURL = data.url;
      }
      if (data.status === 'error') {
        this.dataExport_error_message = "Something went wrong while your data was being exported";
      }
    }
    this.dataExport_hasRecentExport = !!exportDoc;

    
  }



  /**----------------------------------------------------------------------------------------
  * Request User Data
  * * Called from the Account component when a new document is posted as a user export
  * * Return the changes to the document
  -----------------------------------------------------------------------------------------*/
  requestUserData(user_id: string, export_id: string): Observable<Exports>  {
    this.exportsCollection = this.afs.collection<Exports>(`users/${user_id}/exports`);
    this.exportDoc = this.exportsCollection.doc<Exports>(`${export_id}`);
    return this.exportDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        if (data){
          return {
            ...data,
          } as Exports;
        }
      }),
        shareReplay()
      );
  }




}
