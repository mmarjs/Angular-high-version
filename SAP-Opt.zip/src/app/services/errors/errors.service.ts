export namespace ErrorMessages {
  var email: string;
  export function convertMessage(code: string): string {
      switch (code) {
          case 'auth/user-disabled': {
              return 'Sorry your user account is disabled.';
          }
          case 'auth/user-not-found': {
              return 'Sorry, it looks as though that email account does not exist.';
          }
          case 'auth/wrong-password': {
              return 'Sorry, incorrect password entered. Please try again.';
          }
          case 'auth/email-already-in-use': {
              return 'Oops! It looks as though this email address is already in use. Please try another address.';
          }
          case 'auth/invalid-email': {
              return 'Sorry, an invalid email was entered.';
          }
          case 'auth/user-mismatch' : {
              return 'The supplied credentials do not correspond to the previously signed in user.';
          }
          default: {
              return 'Login error try again later.';
          }
      }
  }
}