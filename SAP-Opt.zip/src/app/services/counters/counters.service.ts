import { Injectable } from '@angular/core';
import firebase from 'firebase/app';
import 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})

export class CountersService {

  // Firestore
  db = firebase.firestore();
    
  constructor() { }


  /**----------------------------------------------------------------------------------------
  * Folder Project Count
  * * Increase / Decrease the 'folder_project_count' value on the folder document
  -----------------------------------------------------------------------------------------*/
  folderProjectCount(modifier, user_id: string, folder_id: string) {
    var sfDocRef = this.db.collection(`users/${user_id}/folders`).doc(`${folder_id}`);
    sfDocRef.update({
      folder_project_count: firebase.firestore.FieldValue.increment(modifier)
    })
  }



  /**----------------------------------------------------------------------------------------
  * Project Issue Count
  * * Increase / Decrease the 'project_issue_count' value on the project document
  -----------------------------------------------------------------------------------------*/
  projectIssueCount(modifier, user_id: string, project_id: string) {
    var sfDocRef = this.db.collection(`users/${user_id}/projects`).doc(`${project_id}`);
    sfDocRef.update({
      project_issue_count: firebase.firestore.FieldValue.increment(modifier)
    })
  }



  /**----------------------------------------------------------------------------------------
  * Issue Photo Count
  * * Increase / Decrease the 'issue_image_count' value on the issue document
  -----------------------------------------------------------------------------------------*/
  issuePhotoCount(modifier, user_id: string, project_id: string, issue_id: string) {
    var sfDocRef = this.db.collection(`users/${user_id}/projects/${project_id}/issues`).doc(`${issue_id}`);
    sfDocRef.update({
      issue_image_count: firebase.firestore.FieldValue.increment(modifier)
    })
  }


}
