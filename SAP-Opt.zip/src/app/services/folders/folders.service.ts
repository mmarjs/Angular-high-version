import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { shareReplay } from "rxjs/operators";
import { Observable } from 'rxjs';
import { Folder } from '../../interfaces/folder';
import { AuthService } from '../../services/authentication/auth.service';
import { Router } from '@angular/router';
import firebase from 'firebase/app';
import 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class FoldersService {

  // Firestore Collection & Document References
  private foldersCollection: AngularFirestoreCollection<Folder>;
  private folderDoc: AngularFirestoreDocument<Folder>;

  // New & Edit Folder Variables
  folder_id: string;
  folder_title: string;
  folder_colour: string;
  folder_id_edit: string;
  folder_delete: string;
  folder_search: string;

  // Folder Overlays
  overlay_new: boolean = false;
  overlay_edit: boolean = false;
  overlay_delete: boolean = false;
  newFolderClick: boolean = false;
  breadCrumbFoldersClick: boolean = false;
  // Loading
  showSpinner: boolean = true;
  historyRoutes: string [] = [];
  constructor(
    private afs: AngularFirestore,
    private authService: AuthService,
    private router: Router,
  ) { }


  /**----------------------------------------------------------------------------------------
  * Get Folders
  * * Return the users folders and order by "folder_title"
  -----------------------------------------------------------------------------------------*/
  public getFolders(user_id: string): Observable<Folder[]> {
    this.foldersCollection = this.afs.collection<Folder>(`users/${user_id}/folders`, ref => ref.orderBy('folder_title'));
    return this.foldersCollection.valueChanges({ idField: 'id' })
      .pipe(shareReplay());
  }


  showNewFolderOverlay(){
    this.overlay_new = true;
    this.folder_title = '';
  }
  storeRoute(route: string){
    this.historyRoutes.push(route);
  }

  /**----------------------------------------------------------------------------------------
  * Set New Folder
  * * Create a new folder document
  * * Upon completion, close the overlay
  -----------------------------------------------------------------------------------------*/
  async setNewFolder() {
    const folderID = this.afs.createId();
    const user = await this.authService.getUserID();
    if (user) {
      this.folderDoc = this.foldersCollection.doc<Folder>(`${folderID}`);
      this.folderDoc.set({
        folder_title: this.folder_title,
        folder_colour: this.folder_colour ? this.folder_colour : 'DCE0E5',
        folder_project_count: 0,
        document_owner: user.uid,
        version: 1,
        dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
      }).then(() => {
        this.overlay_new = false;
        this.newFolderClick = true;
        this.folder_id = folderID;
        this.folder_title = '';
        this.router.navigate(['/', 'folders', folderID]);
        this.folder_search = "";
      })
    }
  }



  /**----------------------------------------------------------------------------------------
  * Edit Folder
  * * Update a modified folder, either the title, or colour, or both
  * * Upon compmletion, close the overlay
  -----------------------------------------------------------------------------------------*/
  editFolder() {
    this.folderDoc = this.foldersCollection.doc<Folder>(`${this.folder_id_edit}`);
    this.folderDoc.update({
      folder_title: this.folder_title,
      folder_colour: this.folder_colour,
    }).then(() => {
      this.overlay_edit = false;
      this.folder_title = '';
    })
  }


  
  /**----------------------------------------------------------------------------------------
  * Delete Folder
  * * Delete the selected folder
  * * Upon compleition, hide the overlay
  * * If the folder deleted is the last one, return to the root 'folders' url
  -----------------------------------------------------------------------------------------*/
  async deleteFolder(folderCount: number) {
    const user = await this.authService.getUserID();
    if (user) {
      this.afs.doc<Folder>(`users/${user.uid}/folders/${this.folder_id_edit}`).delete().then(() => {
        this.overlay_delete = false;
        if (folderCount === 1) {
          this.router.navigate(['/', 'folders']);
        }
        this.folder_delete = "";
      })
    }
  }


  cancelDeleteFolder(){
    this.overlay_delete = false; 
    this.overlay_edit = true;
    this.folder_delete = "";
  }


}
