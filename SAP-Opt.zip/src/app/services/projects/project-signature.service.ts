import { Injectable, NgZone } from '@angular/core';
import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/storage';
import { ProjectDetailService } from '../../services/projects/project-detail.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import Compressor from 'compressorjs';
import { switchMap } from 'rxjs/operators';
import { Observable, Subscription, combineLatest } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class ProjectSignatureService {

  // Signature Image
  project_signature_image_url: string;
  overlay_delete_photo: boolean = false;
  uploadComplete: boolean = false;
  public incorrect_file_type: boolean = false;
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };
  overlay_photo_upload: boolean = false;
  _projectSignatureSubscription: Subscription;

  constructor(
    private projectDetailService: ProjectDetailService,
    private afs: AngularFirestore,
    private zone: NgZone,
    private storage: AngularFireStorage,
    private router: Router,
  ) { }

  /**----------------------------------------------------------------------------------------
  * Get Signature Imgae
  * * If a signature reference exists, `project-signature.component.ts` will call this function
  * * Use the value as a reference and obtain the download URL
  -----------------------------------------------------------------------------------------*/
  getSignatureImage(project_signature_image: string) {
    var storageRef = firebase.storage().ref();
    var signatureRef = storageRef.child(project_signature_image);
    signatureRef.getDownloadURL().then((url) => {
      this.project_signature_image_url = url;
    })
  }



  /**----------------------------------------------------------------------------------------
  * Set Signature Detail
  * * If any of the signature information is changed, update the project form
  * * This function is used instead of the 'setProjectDetail', as that function has...
  * * ... router configs on completion.
  -----------------------------------------------------------------------------------------*/
  setSignatureDetail(folder_id: string, project_id: string) {
    let formValue = { ...this.projectDetailService.projectForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }
    this.projectDetailService.projectDoc.update(formValue).then(() => {
      this.projectDetailService.projectForm.markAsPristine();
      this.router.navigate(['/', 'folders', folder_id, 'projects', project_id]);
    });
  }



  /**----------------------------------------------------------------------------------------
  * Delete Project Signature
  * * Show deletion loader
  * * If the form has changed, update it
  * * Delete image and update firestore document
  * * Set the url variable to null
  -----------------------------------------------------------------------------------------*/
  deleteProjectSignature(user_id: string, folder_id: string, project_id: string) {
    // if (this.projectDetailService.projectForm.dirty) {
    //   this.setSignatureDetail(folder_id, project_id);
    // }
    const companyLogo = this.projectDetailService.project$.value.project_signature_image;
    this.storage.storage.ref(companyLogo).delete().then(() => {
      this.afs.doc(`users/${user_id}/projects/${project_id}`).update({
        project_signature_image: firebase.firestore.FieldValue.delete(),
        project_signature_image_url: firebase.firestore.FieldValue.delete(),
      }).then(() => {
        this.project_signature_image_url = null;
        this.overlay_delete_photo = false;
      })
    })
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Detect Files
  * * Set the image overlay to true
  * * If the image was dragged into the dropzone, check that it's the correct file type
  * * If it is, continue. If it isn't, close the overlay and show and error message
  * * Create new id
  * * If the form has been changed, but not saved, save it
  * * Call the resize image function
  -----------------------------------------------------------------------------------------*/
  detectFiles(files: FileList, user_id: string, folder_id: string, project_id: string) {
    this.overlay_photo_upload = true;
    this.incorrect_file_type = false;
    const new_photo_id = this.afs.createId();
    const file = files[0];
    const fileType = file.type;
    var fileExtension = fileType.split('/').pop();
    if (fileExtension == "jpg" || fileExtension == "jpeg" || fileExtension == "png") {
      if (file && files.length > 0) {
        // if (this.projectDetailService.projectForm.dirty) {
        //   this.setSignatureDetail(folder_id, project_id);
        // }
        this.saveImage(file, user_id, project_id, new_photo_id)
      }
    } else {
      this.incorrect_file_type = true;
      this.overlay_photo_upload = false;
    }
  }

   /**----------------------------------------------------------------------------------------
  * Save Image
  * * Use Compressor JS to create the size of the signature
  * * Upload image
  * * Update the project document
  * * Hide overlays
  -----------------------------------------------------------------------------------------*/
  saveImage(file, user_id, project_id, new_photo_id){
    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(file, {
        quality: 0.75,
        maxWidth: 400,
        maxHeight: 400,
        checkOrientation: true
      });
      return {
        original,
      };
    }).then((results) => {
      const largePath = `users/${user_id}/projects/${project_id}/${project_id}_project_signature_image_${new_photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const obs$ = combineLatest([largeTask]);
      this._projectSignatureSubscription = obs$.pipe(
        switchMap(async ([largeTask]) => {
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`users/${user_id}/projects/${project_id}`).update({
            project_signature_image: largePath,
            project_signature_image_url: largeUrl,
          }).then(() => {
            this.uploadComplete = true;
            this.overlay_delete_photo = false;
          })
        })
      ).subscribe();
    });
  }


  /**----------------------------------------------------------------------------------------
  * Compress Image
  * * Used by CompressorJS (saveCroppedImage) to resize images
  -----------------------------------------------------------------------------------------*/
  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }





}
