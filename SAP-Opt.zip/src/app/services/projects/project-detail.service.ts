import { Injectable, NgZone} from '@angular/core';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable, Subscription, combineLatest } from 'rxjs';
import { shareReplay, map } from "rxjs/operators";
import { Project } from '../../interfaces/project';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import { BehaviorSubject } from 'rxjs';
import { CountersService } from '../counters/counters.service';
import { Router } from '@angular/router';
import Compressor from 'compressorjs';
import { switchMap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProjectDetailService {

  // Firestore projects reference
  private projectsCollection: AngularFirestoreCollection<Project>;
  public projectDoc: AngularFirestoreDocument<Project>;

  private operationsCollection: AngularFirestoreCollection<any>;
  public operationDoc: AngularFirestoreDocument<any>;

  // Form
  projectForm = new FormGroup({});
  project$: BehaviorSubject<Project>;

  // Images
  uploadComplete: boolean = false;
  overlay_delete_photo: boolean = false;
  incorrect_file_type: boolean = false;
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };
  _projectImageSubscription: Subscription;

  // Overlays
  overlay_photo_upload: boolean = false;
  overlay_delete_project: boolean = false;

  // Firestore
  db = firebase.firestore();



  constructor(
    private afs: AngularFirestore,
    public formBuilder: FormBuilder,
    private countersService: CountersService,
    private router: Router,
    private zone: NgZone,
    private storage: AngularFireStorage,
  ) {
    this.projectForm = formBuilder.group({
      project_title: ['', Validators.required],
      project_issue_count: [],
      project_folder: [''],
      project_date: [new Date, Validators.required],
      version: [],
      dateCreated: [new Date],
      document_owner: [''],
      project_reference: [''],
      project_photo: [''],
      project_photo_url: [''],
      project_photo_thumbnail: [''],
      project_photo_thumbnail_url: [''],
      project_signature_image: [''],
      project_signature_image_url: [''],
      project_client: [''],
      project_auditor_name: [''],
      project_auditor_company: [''],
      project_address: [''],
      project_completed: [],
    });
    this.project$ = new BehaviorSubject({
      project_title: '',
      project_issue_count: 0,
      project_folder: '',
      project_date: null,
      version: 1,
      dateCreated: null,
      document_owner: '',
      project_reference: '',
      project_photo: '',
      project_photo_url: '',
      project_photo_thumbnail: '',
      project_photo_thumbnail_url: '',
      project_signature_image: '',
      project_signature_image_url: '',
      project_client: '',
      project_auditor_name: '',
      project_auditor_company: '',
      project_address: '',
      project_completed: null,
    });
  }


  /**----------------------------------------------------------------------------------------
  * Get Project
  * * Return the project document
  -----------------------------------------------------------------------------------------*/
  public getProject(user_id: string, project_id: string): Observable<Project> {
    this.projectsCollection = this.afs.collection<Project>(`users/${user_id}/projects`);
    this.projectDoc = this.projectsCollection.doc<Project>(`${project_id}`);
    return this.projectDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        var formattedDate;
        if (data){
          if (data.project_date) {
            formattedDate = (data.project_date as firebase.firestore.Timestamp).toDate()
          }
          return {
            ...data,
            project_date: formattedDate,
            id: collectionDoc.payload.id
          } as Project;
        }
      }),
        shareReplay()
      );
  }



  /**----------------------------------------------------------------------------------------
  * Set Project Detail
  * * Obtain the current folder id, and a new folder id if one has been selected
  * * Strip out empty fields in the form
  * * Update the firestore document
  * * Mark the form as pristine
  * * If a new folder was selected, increase the project count on the associated folders
  * * Navigate to the new route
  * * If the folder didn't change, navigate back to the summary
  -----------------------------------------------------------------------------------------*/
  setProjectDetail(user_id: string, project_id: string) {

    var currentFolder = this.project$.getValue().project_folder;;
    var newFolder = this.projectForm.controls.project_folder.value;

    let formValue = { ...this.projectForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }

    this.projectDoc.update(formValue).then(() => {
      this.projectForm.markAsPristine();
      if (newFolder !== currentFolder) {
        this.countersService.folderProjectCount(-1, user_id, currentFolder);
        this.countersService.folderProjectCount(+1, user_id, newFolder);
        this.router.navigate(['/', 'folders', newFolder, 'projects', project_id]);
      } else {
        this.router.navigate(['/', 'folders', currentFolder, 'projects', project_id]);
      }
    });
  }



  /**----------------------------------------------------------------------------------------
  * Set Project Complete
  * * Toggle True / False when clicking 'Mark as Complete / Incomplete'
  -----------------------------------------------------------------------------------------*/
  setProjectComplete(project_completed: boolean){
    this.projectDoc.update({
      project_completed: project_completed
    })
  }



  /**----------------------------------------------------------------------------------------
  * Detect Files
  * * Set the image overlay to true
  * * If the image was dragged into the dropzone, check that it's the correct file type
  * * If it is, continue. If it isn't, close the overlay and show and error message
  * * Create a new photo id
  * * If the form has been changed, update it
  * * Call "saveImage" to resize both the large and thumbnail images
  -----------------------------------------------------------------------------------------*/
  detectFiles(files: FileList, user_id: string, project_id: string) {
    this.overlay_photo_upload = true;
    const file = files[0];
    const fileType = file.type;
    var fileExtension = fileType.split('/').pop();

    if (fileExtension == "jpg" || fileExtension == "jpeg" || fileExtension == "png") {
      const new_photo_id = this.afs.createId();
      this.incorrect_file_type = false;
      if (file && files.length > 0) {
        if (this.projectForm.dirty) {
          this.setProjectDetail(user_id, project_id);
        }
        this.saveImage(file, user_id, project_id, new_photo_id)
      }
    } else {
      this.incorrect_file_type = true;
      this.overlay_photo_upload = false;
    }



  }



  /**----------------------------------------------------------------------------------------
  * Save Image
  * * Use Compressor JS to create the size of the large and thumbnail images
  * * Upload both images
  * * Update the project document
  * * Hide overlays
  -----------------------------------------------------------------------------------------*/
  saveImage(file, user_id, project_id, new_photo_id){
    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(file, {
        quality: 0.8,
        maxWidth: 2000,
        maxHeight: 2000,
        checkOrientation: true
      });
      const thumb = await this.compressImage(file, {
        quality: 0.8,
        maxWidth: 300,
        maxHeight: 300,
        checkOrientation: true,
      });
      return {
        original,
        thumb
      };
    }).then((results) => {
      const thumbPath = `users/${user_id}/projects/${project_id}/${project_id}_project_photo_thumbnail_${new_photo_id}.jpeg`;
      const thumbTaskRef = this.storage.ref(thumbPath);
      const thumbTask = this.storage.upload(thumbPath, results.thumb, this.metadata);

      const largePath = `users/${user_id}/projects/${project_id}/${project_id}_project_photo_${new_photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const obs$ = combineLatest([thumbTask, largeTask]);
      this._projectImageSubscription = obs$.pipe(
        switchMap(async ([thumbTask, largeTask]) => {
          const thumbUrl = await thumbTaskRef.getDownloadURL().toPromise();
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`users/${user_id}/projects/${project_id}`).update({
            project_photo_thumbnail: thumbPath,
            project_photo_thumbnail_url: thumbUrl,
            project_photo: largePath,
            project_photo_url: largeUrl,
          }).then(() => {
            this.uploadComplete = true;
          })
        })
      ).subscribe();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Compress Image
  * * Used by CompressorJS (saveCroppedImage) to resize images
  -----------------------------------------------------------------------------------------*/
  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }



  clearPhotoUpload(){
    this.overlay_photo_upload = false; 
    this.uploadComplete = false;
  }



  /**----------------------------------------------------------------------------------------
   * Delete Large Photo
   * * Set the image spinner to true
   * * If changes were made to the form, write them to the database
   * * Delete the photo
   * * Upon completion, remove photo fields from the firestore document
   * * Upon completion, repeat the process for the thumbnail image
   -----------------------------------------------------------------------------------------*/
  deleteProjectImageLarge(user_id: string, project_id: string) {

   if (this.projectForm.dirty) {
      this.setProjectDetail(user_id, project_id);
    }

    const largeImageRef = this.project$.value.project_photo;
    this.storage.storage.ref(largeImageRef).delete().then(() => {
      this.afs.doc(`users/${user_id}/projects/${project_id}`).update({
        project_photo: firebase.firestore.FieldValue.delete(),
        project_photo_url: firebase.firestore.FieldValue.delete()
      }).then(() => {
        this.deleteProjectImageThumbnail(user_id, project_id);
      })
    })
  }



  /**----------------------------------------------------------------------------------------
   * Delete Thumbnail Photo
   * * Delete the photo
   * * Upon completion, remove photo fields from the firestore document
   * * Upon completion, set the spinner to false
   -----------------------------------------------------------------------------------------*/
  deleteProjectImageThumbnail(user_id: string, project_id: string) {
    const largeImageRef = this.project$.value.project_photo_thumbnail;
    this.storage.storage.ref(largeImageRef).delete().then(() => {
      this.afs.doc(`users/${user_id}/projects/${project_id}`).update({
        project_photo_thumbnail: firebase.firestore.FieldValue.delete(),
        project_photo_thumbnail_url: firebase.firestore.FieldValue.delete()
      }).then(() => {
        this.overlay_delete_photo = false;
      })
    })
  }


  
  /**----------------------------------------------------------------------------------------
   * Get Operation (duplication)
   * * When a user duplicates a project, it will create a new document and then subscribe
   * * The subscription calls this function with the new document / project ID
   -----------------------------------------------------------------------------------------*/
  getOperation(user_id: string, project_id: string){
    this.operationsCollection = this.afs.collection<any>(`users/${user_id}/operations`);
    this.operationDoc = this.operationsCollection.doc<any>(`${project_id}`);
    return this.operationDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        return {
          ...data,
        } 
      }),
        shareReplay()
      );
  }



}

