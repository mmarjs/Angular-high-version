import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { shareReplay } from "rxjs/operators";
import { Observable } from 'rxjs';
import { Project } from '../../interfaces/project';
import { AuthService } from '../../services/authentication/auth.service';
import { CountersService } from '../../services/counters/counters.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProjectsListService {


  // Firestore Collection and Doc reference
  private projectsCollection: AngularFirestoreCollection<Project>;
  private projectDoc: AngularFirestoreDocument<Project>;

  // User Settings
  userSettings: any = {};

  // Loading
  showSpinner: boolean = true;

  // Projects
  projectsArray = [];
  newProjectClick: boolean = false;
  project_search: string;
  deleteProjectClick: boolean = false;
  
  constructor(
    private afs: AngularFirestore,
    private authService: AuthService,
    private countersService: CountersService,
    private router: Router
  ) { }


  /**----------------------------------------------------------------------------------------
  * Get Projects
  * * Return all projects that have a "project_folder" id matching the incoming folder
  * * Order by "project_date"
  -----------------------------------------------------------------------------------------*/
  public getProjects(user_id: string, folder_id: string): Observable<Project[]> {
    this.projectsCollection = this.afs.collection<Project>(`users/${user_id}/projects`, ref => ref.where('project_folder', "==", folder_id).orderBy("project_date", "desc"));
    return this.projectsCollection.valueChanges({ idField: 'id' })
      .pipe(shareReplay());
  }



  /**----------------------------------------------------------------------------------------
  * Get Project Date for Title
  * * Called by `setNewProject` to return the format of the project title that includes the date
  -----------------------------------------------------------------------------------------*/
  getProjectTitleWithDate(usersetting_dateformat: string): string{
    var now = new Date();
    var year = now.getUTCFullYear();
    var month = now.getUTCMonth() + 1;
    var date = now.getUTCDate();
    var hours = now.getUTCHours();
    var minutes = now.getUTCMinutes();
    var projectDate = '';
    var projectTitle = '';
    if(usersetting_dateformat === "DD/MM/YYYY"){
      projectDate = date.toString().padStart(2, '0') + '/' + month + '/' + year + ', ' + hours + ':' + minutes.toString().padStart(2, '0');
    } else {
      projectDate = month + '/' + date.toString().padStart(2, '0') + '/' + year + ', ' + hours + ':' + minutes.toString().padStart(2, '0');
    }
    return projectDate
  }



  /**----------------------------------------------------------------------------------------
  * Set New Project
  * * Get the User ID
  * * Write a new project document
  * * project_folder = the folder the user is currently in
  * * Upon completion, call the "folderProjectCount" function to increment by +1
  -----------------------------------------------------------------------------------------*/
  async setNewProject(folder_id: string, usersetting_auditorname: string, usersetting_companyname: string, usersetting_dateformat: string) {
    var projectDate = this.getProjectTitleWithDate(usersetting_dateformat);
    const newProjectID = this.afs.createId();
    const user = await this.authService.getUserID();
    if (user) {
      this.projectDoc = this.projectsCollection.doc<Project>(`${newProjectID}`);
      this.projectDoc.set({
        project_title: "Project" + " " + projectDate,
        project_issue_count: 0,
        project_folder: folder_id,
        project_auditor_name: usersetting_auditorname ? usersetting_auditorname : '',
        project_auditor_company: usersetting_companyname ? usersetting_companyname : '',
        project_date: firebase.firestore.FieldValue.serverTimestamp(),
        dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
        document_owner: user.uid,
        version: 1,
      }).then(() => {
        this.newProjectClick = true;
        this.countersService.folderProjectCount(+1, user.uid, folder_id);
        this.router.navigate(['/', 'folders', folder_id, 'projects', newProjectID]);
        this.project_search = "";
      })
    }
  }
}


