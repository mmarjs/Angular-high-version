import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { shareReplay, map } from "rxjs/operators";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Issue } from '../../interfaces/issue';
import { BehaviorSubject } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/storage';
import { Router } from '@angular/router';
import { CountersService } from '../../services/counters/counters.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { IssueImage } from '../../interfaces/issue-image';

@Injectable({
  providedIn: 'root'
})

export class IssueEditService {

  // Firestore issues reference
  private issuesCollection: AngularFirestoreCollection<Issue>;
  private issueDoc: AngularFirestoreDocument<Issue>;


  private imagesCollection: AngularFirestoreCollection<IssueImage>;
  private imagesDoc: AngularFirestoreDocument<IssueImage>;

  // Form
  issueForm = new FormGroup({});
  issue$: BehaviorSubject<Issue>;

  // Used from the issue list component
  // If a form is not saved whilst navigating to another issue, alert the user
  // If discard is chosen, use the "routeToNavigateTo" property to navigate to the issue clicked on
  overlay_unsaved_form: boolean = false;
  routeToNavigateTo: string;

  // Image Uploads
  files: File[] = [];

  // Images
  imagesArray = [];
  image_count: number;
  filesUploadedCount: number;
  filesCount: number;
  overlay_uploading: boolean = false;
  photo_id: string;
  overlay_delete_photo: boolean = false;
  pendingImages: boolean = false;

  constructor(
    private afs: AngularFirestore,
    public formBuilder: FormBuilder,
    private router: Router,
    private countersService: CountersService) {
    this.issueForm = formBuilder.group({
      issue_title: ['', Validators.required],
      issue_order: [],
      issue_image_count: [],
      issue_due_date: [new Date],
      dateCreated: [new Date],
      version: [],
      issue_completed: [],
      issue_comments: [''],
      issue_assignee: [''],
      issue_thumbnail_url: [''],
      issue_thumbnail: [''],
    });
    this.issue$ = new BehaviorSubject({
      issue_title: '',
      issue_order: 0,
      issue_image_count: 0,
      issue_due_date: null,
      dateCreated: null,
      version: 0,
      issue_completed: false,
      issue_comments: '',
      issue_assignee: '',
      issue_thumbnail_url: '',
      issue_thumbnail: '',
    });

  }


  /**----------------------------------------------------------------------------------------
  * Get Issue Detail
  * * Return the issue document based on the incoming ID's
  -----------------------------------------------------------------------------------------*/
  public getIssueDetail(user_id: string, folder_id: string, project_id: string, issue_id: string): Observable<Issue> {
    this.issuesCollection = this.afs.collection<Issue>(`users/${user_id}/projects/${project_id}/issues`);
    this.issueDoc = this.issuesCollection.doc<Issue>(`${issue_id}`);
    return this.issueDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        if (data) {
          var formattedDate;
          if (data.issue_due_date) {
            formattedDate = (data.issue_due_date as firebase.firestore.Timestamp).toDate()
          }
          return {
            ...data,
            issue_due_date: formattedDate
          } as Issue;
        }
      }),
        shareReplay()
      );
  }



  /**----------------------------------------------------------------------------------------
  * Get Issue Images 
  * * Get all images within an issue, ordered by "image_order"
  -----------------------------------------------------------------------------------------*/
  public getIssueImages(user_id: string, project_id: string, issue_id: string): Observable<IssueImage[]> {
    this.imagesCollection = this.afs.collection<IssueImage>(`users/${user_id}/projects/${project_id}/issues/${issue_id}/images`, ref => ref.orderBy('image_order'));
    return this.imagesCollection.valueChanges({ idField: 'id' })
      .pipe(shareReplay());
  }
 


  /**----------------------------------------------------------------------------------------
  * Set Issue Detail
  * * Strip out empty fields in the form
  * * Update the firestore document
  * * Mark the form as pristine
  * * "overlay_unsaved_form" is used when the unsaved changes overlay appears
  * * NOTE: Using old method which allows date to be stripped away instead of 'formValue'
  -----------------------------------------------------------------------------------------*/
  setIssueDetail() {
    this.issueDoc.update({
      issue_title: this.issueForm.controls.issue_title.value,
      issue_due_date: this.issueForm.controls.issue_due_date.value == null ? firebase.firestore.FieldValue.delete() : this.issueForm.controls.issue_due_date.value,
      issue_assignee: this.issueForm.controls.issue_assignee.value ? this.issueForm.controls.issue_assignee.value : firebase.firestore.FieldValue.delete(),
      issue_completed: this.issueForm.controls.issue_completed.value,
      issue_comments: this.issueForm.controls.issue_comments.value ? this.issueForm.controls.issue_comments.value : firebase.firestore.FieldValue.delete(),
    }).then(() => {
        this.issueForm.markAsPristine();
        this.overlay_unsaved_form = false;
      });
  }



  /**----------------------------------------------------------------------------------------
  * Discard Issue Detail
  * * When navigating through the issues list, if the issue form is dirty, an overlay appears
  * * The overlay has two options: To Save, or To Discard
  * * When discard is chosen, the original form will be marked back to pristine
  * * The overlay will close
  * * The component will route to next issue clicked on
  -----------------------------------------------------------------------------------------*/
  discardIssueDetail() {
    this.issueForm.markAsPristine()
    this.overlay_unsaved_form = false;
    this.router.navigate([this.routeToNavigateTo]);
  }



  /**----------------------------------------------------------------------------------------
  * Delete Photo Overlay
  * * Set "overlay_delete_photo" to true
  * * Set "photo_id" to the incoming photo id
  -----------------------------------------------------------------------------------------*/
  deletePhotoOverlay(photo_id: string) {
    this.overlay_delete_photo = true;
    this.photo_id = photo_id;
  }



  /**----------------------------------------------------------------------------------------
  * Delete Photo 
  * * Delete Photo
  * * Update the photo count on the issue
  * * Hide the overlay
  * * If the image_count is 0, we know to delete the issue thumbnail value 
  * * If it's more than zero, we know to update the issue thumbnail value with the next image
  -----------------------------------------------------------------------------------------*/
  deletePhoto(user_id: string, project_id: string, issue_id: string) {
    this.issueDoc.collection('images').doc(this.photo_id).delete().then(() => {
      this.countersService.issuePhotoCount(-1, user_id, project_id, issue_id);
      this.overlay_delete_photo = false;
    }).then(() => {
      if (this.image_count == 0) {
        this.issueDoc.update({
          issue_thumbnail: firebase.firestore.FieldValue.delete(),
          issue_thumbnail_url: firebase.firestore.FieldValue.delete()
        });
      } else {
        const image = this.imagesArray[0];
        this.updateIssueThumbnailAfterReorderOrDelete(image.image_photo_thumbnail, image.image_photo_thumbnail_url);
      }
    })
  }



  /**----------------------------------------------------------------------------------------
  * Set Issue Thumbnail
  * * Called from the image upload component
  * * If an image(s) are uploaded, take the first one and set it as the thumbnail...
  * * ...(if one hasn't been already)
  -----------------------------------------------------------------------------------------*/
  setIssueThumbnail(thumnmail: string, thumbnail_url: string) {
    this.issueDoc.update({
      issue_thumbnail: thumnmail,
      issue_thumbnail_url: thumbnail_url,
    });
  }



  /**----------------------------------------------------------------------------------------
  * Update the issue thumbnail after a reorder or delete
  * * If the images were reordered or deleted, call this function
  * * This will update the issue thumbnail or delete it
  -----------------------------------------------------------------------------------------*/
  updateIssueThumbnailAfterReorderOrDelete(thumnmail, thumbnail_url) {

    var issueDetails: any = {};

    if (thumnmail != undefined && thumbnail_url != undefined) {
      issueDetails["issue_thumbnail"] = thumnmail;
      issueDetails["issue_thumbnail_url"] = thumbnail_url;
    } else {
      issueDetails["issue_thumbnail"] = firebase.firestore.FieldValue.delete();
      issueDetails["issue_thumbnail_url"] = firebase.firestore.FieldValue.delete();;
    }
    this.issueDoc.update(issueDetails);
  }




}

