import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { shareReplay } from "rxjs/operators";
import { Observable } from 'rxjs';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Issue } from '../../interfaces/issue';
import { AuthService } from '../../services/authentication/auth.service';
import { CountersService } from '../../services/counters/counters.service';
import { HelperService } from '../../services/helper/helper.service';
import firebase from 'firebase/app';
import 'firebase/firestore';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class IssuesListService {

  // Firestore issues reference
  private issuesCollection: AngularFirestoreCollection<Issue>;
  private issuesDoc: AngularFirestoreDocument<Issue>;

  // Issues Array
  issuesArray = [];
  issue_count: number;
  issue_button_state = true;

  // Edit Mode
  isInEditMode: boolean = false;
  editOptions: boolean = false;

  // Toggle completed issues
  hide_completed: boolean = false;

  // Overlay
  overlay_delete: boolean = false;
  overlay_multiadd: boolean = false;
  issue_id_delete: string;

  filesUploadedCount: number = 0;

  // Loading
  showSpinner: boolean = true;

  // Batch Edit
  issuesToBatch = [];
  overlay_delete_batched_issues: boolean = false;
  overlay_assignee_batched_issues: boolean = false;
  overlay_due_date_batched_issues: boolean = false;
  overlay_complete_batched_issues: boolean = false;
  assignee_batched_value: string = '';
  due_date_batched_value;
  issuesDeletedCount: number = 0;

  constructor(
    private afs: AngularFirestore,
    private authService: AuthService,
    private countersService: CountersService,
    private helperService: HelperService,
    private router: Router,
  ) { }



  /**----------------------------------------------------------------------------------------
  * Get Issues 
  * * Get all issues within a project, ordered by "issue_order"
  -----------------------------------------------------------------------------------------*/
  public getIssues(user_id: string, project_id: string): Observable<Issue[]> {
    this.issuesCollection = this.afs.collection<Issue>(`users/${user_id}/projects/${project_id}/issues`, ref => ref.orderBy('issue_order'));
    return this.issuesCollection.valueChanges({ idField: 'id' })
      .pipe(shareReplay());
  }



  /**----------------------------------------------------------------------------------------
  * Set New Issue
  * * Set "issue_button_state" to false to prevent spamming
  * * Set "editOptions" to avoid the drop down lingering if it was previously open
  * * Create new issue id
  * * Create a reference to the users settings for "usersetting_issuename"
  * * Create reference to the current issue count
  * * Get the user ID
  * * Create new issue document
  * * Upon completion update the project issue count
  * * Set the "issue_button_state" back to true
  -----------------------------------------------------------------------------------------*/
  async setNewIssue(folder_id: string, project_id: string) {
    this.issue_button_state = false;
    this.editOptions = false;
    const newIssueID = this.afs.createId();
    const usersetting_issuename = this.helperService.getUserSettings().usersetting_issuename;
    const issue_count = this.issue_count;
    const issue_title = this.issue_count + 1;
    const user = await this.authService.getUserID();
    if (user) {
      this.issuesDoc = this.issuesCollection.doc<Issue>(`${newIssueID}`);
      this.issuesDoc.set({
        issue_title: usersetting_issuename + ' ' + issue_title.toString(),
        issue_order: issue_count,
        issue_image_count: 0,
        dateCreated: firebase.firestore.FieldValue.serverTimestamp(),
        version: 1,
        issue_completed: false,
      }).then(() => {
        this.countersService.projectIssueCount(+1, user.uid, project_id);
        this.issue_button_state = true;
        this.router.navigate(['/', 'folders', folder_id, 'projects', project_id, 'summary', 'issues', newIssueID]);
      })
    }
  }




  /**----------------------------------------------------------------------------------------
  * Reorder Issues
  * * Updates the "issue_order" based on the new position of an issue after reordering
  -----------------------------------------------------------------------------------------*/
  async drop(event: CdkDragDrop<string[]>, user_id: string, project_id: string) {
    moveItemInArray(this.issuesArray, event.previousIndex, event.currentIndex);
    let batch = this.afs.firestore.batch();
    let index = 0;
    this.issuesArray.forEach((issue) => {
      const issueRef = this.afs.collection(`users/${user_id}/projects/${project_id}/issues`).doc(`${issue.id}`).ref;
      batch.update(issueRef, { issue_order: index });
      index = index + 1
    });
    await batch.commit();
  }



  /**----------------------------------------------------------------------------------------
  * Delete Issue
  * * Delete the selected issue
  * * Upon compleition, hide the overlay and update the project issue count
  * * If the issues array is empty, set edit mode back to being complete
  * * Additional check to determine which screen the user is on:
  * * - If the user is on the "issuesListIssuesEdit" screen, and it's the last issue being...
  * * ...deleted, then navigate back to the issues list on the project summary page
  * * If the issue being deleted isn't the last issue:
  * * - And the user is on the "issuesListIssuesEdit" screen, navigate to the first item in the array
  * * - Otherwise, navigate back to the issues list screen on the project summary page
  -----------------------------------------------------------------------------------------*/
  deleteIssue(user_id: string, folder_id: string, project_id: string, parentComponent: string) {
    this.afs.doc<Issue>(`users/${user_id}/projects/${project_id}/issues/${this.issue_id_delete}`).delete().then(() => {
      this.overlay_delete = false;
      this.countersService.projectIssueCount(-1, user_id, project_id);

      if (this.issuesArray.length <= 0) {
        this.completeEditMode();
        if (parentComponent == "issuesListIssuesEdit") {
          this.router.navigate(['/', 'folders', folder_id, 'projects', project_id, 'summary', 'issues']);
        }
      } else {
        if (parentComponent == "issuesListIssuesEdit") {
          this.router.navigate(['/', 'folders', folder_id, 'projects', project_id, 'summary', 'issues', this.issuesArray[0].id]);
        } else {
          this.router.navigate(['/', 'folders', folder_id, 'projects', project_id, 'summary', 'issues']);
        }
      }

    });
  }



  /**----------------------------------------------------------------------------------------
  * Toggle Edit Options
  * * Toggle "editOptions"
  -----------------------------------------------------------------------------------------*/
  toggleEditOptions() {
    this.editOptions = !this.editOptions
  }



  /**----------------------------------------------------------------------------------------
  * Toggle Edit Mode
  * * Set "editOptions" to false to hide the drop down
  * * Set "isInEditMode" to true to show list item edit options
  -----------------------------------------------------------------------------------------*/
  toggleEditMode() {
    this.editOptions = false;
    this.isInEditMode = true;
  }



  /**----------------------------------------------------------------------------------------
  * Complete Edit Mode
  * * Set "isInEditMode" to false to hide list item edit options
  -----------------------------------------------------------------------------------------*/
  completeEditMode() {
    this.isInEditMode = false;
    this.issuesToBatch = [];
  }



  /**----------------------------------------------------------------------------------------
  * Toggle Completed Issues
  * * Toggle "hide_completed"
  * * Set "editOptions" to false to hide the drop down
  -----------------------------------------------------------------------------------------*/
  toggleCompletedIssues() {
    this.hide_completed = !this.hide_completed
    this.editOptions = false;
  }



  /**----------------------------------------------------------------------------------------
  * Create Batched Array
  * * When a checkbox is checked from an issue, or multiple, this function is called
  * * It checks to see if the selected issue ID exists in the "issuesToBatch" array
  * * If it does, call 'removeFromBatchArray' to remove the ID from the array
  * * If it doesn't exist, call 'addToBatchArray' to add the ID to the array
  * * Toggle 'issuesToBatchTools' to true to display the edit tools
  -----------------------------------------------------------------------------------------*/
  createBatchEdit(issue_id: string) {
    this.issuesToBatch.includes(issue_id) ? this.removeFromBatchArray(issue_id) : this.addToBatchArray(issue_id);
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Add To Batch Array
  * * This function is called from the 'createBatchEdit' function if an ID doesn't exist...
  * * ...in the array
  -----------------------------------------------------------------------------------------*/
  addToBatchArray(issue_id: string) {
    this.issuesToBatch.push(issue_id);
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Remove From Batch Array
  * * This function is called from the 'createBatchEdit' function if an ID exists
  -----------------------------------------------------------------------------------------*/
  removeFromBatchArray(issue_id: string) {
    for (var i = 0; i < this.issuesToBatch.length; i++) {
      if (this.issuesToBatch[i] === issue_id) {
        this.issuesToBatch.splice(i, 1);
        i--;
      }
    }
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Delete Batched Issues Overlay
  * * Displays the overlay specific to batch deletes
  -----------------------------------------------------------------------------------------*/
  deleteBatchedIssuesOverlay() {
    this.overlay_delete_batched_issues = true;
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Assignee Batched Issues Overlay
  * * Displays the overlay specific to batch assignees
  -----------------------------------------------------------------------------------------*/
  assigneeBatchedOverlay() {
    this.overlay_assignee_batched_issues = true;
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Due Date Batched Issues Overlay
  * * Displays the overlay specific to batch due dates
  -----------------------------------------------------------------------------------------*/
  dueDateBatchedOverlay() {
    this.overlay_due_date_batched_issues = true;
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Complete Batched Issues Overlay
  * * Displays the overlay specific to batch due dates
  -----------------------------------------------------------------------------------------*/
  completeBatchedOverlay() {
    this.overlay_complete_batched_issues = true;
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Delete Batched Issues
  * * Loop through the 'issuesToBatch' array
  * * Use the incoming parameters to form the path to the firestore documents
  * * Once successfully deleted, reduce the issue count on the project
  * * Perform a check that the length of the array is equal to the amount of issues deleted...
  * * ...If it is, the issues array can be reset and the overlay closed
  -----------------------------------------------------------------------------------------*/
  deleteBatchedIssues(user_id: string, project_id: string) {
    this.issuesToBatch.forEach(issue_id => {
      this.afs.doc<Issue>(`users/${user_id}/projects/${project_id}/issues/${issue_id}`).delete().then(() => {

        // Reduce Issue Count on Project
        this.countersService.projectIssueCount(-1, user_id, project_id);

        // Increment Issues Deleted Count
        this.issuesDeletedCount++;

        // Check if the amount of selected items is equal to the amount deleted
        // If it is, the overlay can be closed the the deleted count reset
        if (this.issuesToBatch.length == this.issuesDeletedCount) {
          this.overlay_delete_batched_issues = false;
          this.issuesToBatch = [];
          this.issuesDeletedCount = 0;
        }

      });
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Assignee Batch
  * * Loop through the 'issuesToBatch' array
  * * Use the incoming parameters to form the path to the firestore documents
  * * Update each document with the new 'assignee_batched_value' which is populataed by....
  * * ...an input in the html (ngModel)
  * * Upon completion, close the overlay, reset the assignee value and reset the array
  -----------------------------------------------------------------------------------------*/
  assigneeBatchedIssues(user_id: string, project_id: string) {
    this.issuesToBatch.forEach(element => {
      this.issuesDoc = this.afs.doc<Issue>(`/users/${user_id}/projects/${project_id}/issues/${element}`);
      this.issuesDoc.update({
        issue_assignee: this.assignee_batched_value
      }).then(() => {
        this.overlay_assignee_batched_issues = false;
        this.assignee_batched_value = '';
        this.issuesToBatch = [];
      })
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Due Date Batch
  * * Loop through the 'issuesToBatch' array
  * * Use the incoming parameters to form the path to the firestore documents
  * * Update each document with the new 'due_date_batched_value' which is populataed by....
  * * ...an input in the html (ngModel)
  * * Upon completion, close the overlay, reset the due date value and reset the array
  -----------------------------------------------------------------------------------------*/
  dueDateBatchedIssues(user_id: string, project_id: string) {
    this.issuesToBatch.forEach(element => {
      this.issuesDoc = this.afs.doc<Issue>(`/users/${user_id}/projects/${project_id}/issues/${element}`);
      this.issuesDoc.update({
        issue_due_date: this.due_date_batched_value,
      }).then(() => {
        this.overlay_due_date_batched_issues = false;
        this.due_date_batched_value = null;
        this.issuesToBatch = [];
      })
    });
  }



  /**----------------------------------------------------------------------------------------
  * Incomplete Batch
  * * Loop through the 'issuesToBatch' array
  * * Use the incoming parameters to form the path to the firestore documents
  * * Update each document with the issue_completed = false
  * * Upon completion, close the overlay, and reset the array
  -----------------------------------------------------------------------------------------*/ 
  incompleteBatchedIssues(user_id: string, project_id: string) {
    this.issuesToBatch.forEach(element => {
      this.issuesDoc = this.afs.doc<Issue>(`/users/${user_id}/projects/${project_id}/issues/${element}`);
      this.issuesDoc.update({
        issue_completed: false
      }).then(() => {
        this.overlay_complete_batched_issues = false;
        this.issuesToBatch = [];
      })
    });
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Complete Batch
  * * Loop through the 'issuesToBatch' array
  * * Use the incoming parameters to form the path to the firestore documents
  * * Update each document with the issue_completed = true
  * * Upon completion, close the overlay, and reset the array
  -----------------------------------------------------------------------------------------*/   
  completeBatchedIssues(user_id: string, project_id: string) {
    this.issuesToBatch.forEach(element => {
      this.issuesDoc = this.afs.doc<Issue>(`/users/${user_id}/projects/${project_id}/issues/${element}`);
      this.issuesDoc.update({
        issue_completed: true
      }).then(() => {
        this.overlay_complete_batched_issues = false;
        this.issuesToBatch = [];
      })
    });
  }


}


