import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IssuesFileFormatService {

  incorrect_file_type: boolean = false;
  incorrect_file_type_names = [];

  constructor() { }


  resetIncorrectFileTypes(){
    this.incorrect_file_type = false;
    this.incorrect_file_type_names = [];
  }
}
