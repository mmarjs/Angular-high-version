import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { shareReplay, map } from "rxjs/operators";
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/storage';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class AnnotationsService {

  private photoDoc: AngularFirestoreDocument<any>;
  imageLoadingOverlay: boolean = false;

  metadata = { 
    contentType: 'image/png', cacheControl: "public, max-age=31536000", type: 'image/png', 
    customMetadata: {
      platform: environment.appVersion
    }
  };

    // Firebase Database
    db = firebase.firestore();

  constructor(
    private afs: AngularFirestore,
    private router: Router
  ) { }



  public getPhoto(user_id: string, project_id: string, issue_id: string, image_id: string): Observable<any> {
    this.photoDoc = this.afs.doc(`users/${user_id}/projects/${project_id}/issues/${issue_id}/images/${image_id}`);
    return this.photoDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        if (data) {
          return {
            ...data,
          };
        }
      }),
        shareReplay()
      );
  }


  // Save
  saveAnnotation(user_id: string, folder_id: string, project_id: string, issue_id: string, image_id: string, base64: any) {
    this.imageLoadingOverlay = true;
    const storage = firebase.storage();
    const newUniqueImageIDForEditedAnnotation = this.afs.createId();
    const filePathLarge = (`users/${user_id}/projects/${project_id}/issues/${issue_id}/images/${image_id}/${image_id}_image_annotations_${newUniqueImageIDForEditedAnnotation}.png`)
    const refLarge = storage.ref(filePathLarge);
    fetch(base64.annotation).then(res => res.blob()).then(blob => {
      refLarge.put(blob, this.metadata).then(() => {
        var photoDocRef = this.db.collection(`users/${user_id}/projects/${project_id}/issues/${issue_id}/images`).doc(`${image_id}`).update({
          image_annotations: filePathLarge,
        }).then(() => {
          this.imageLoadingOverlay = false;
          this.router.navigate(['folders', folder_id, 'projects', project_id, 'summary', 'issues', issue_id]);
        });      
      });
    });
  }





}