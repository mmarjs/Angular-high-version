import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HelperService {

  public sapThemeMode: string;

  constructor() { }


  /**----------------------------------------------------------------------------------------
  * Get User Settings
  * * Returns all of the users "user_settings" from local storage
  -----------------------------------------------------------------------------------------*/
  public getUserSettings() {
    const user_settings = localStorage.getItem('user_settings');
    if (user_settings) {
      return JSON.parse(user_settings);
    }
    return null;
  }


  
  /**----------------------------------------------------------------------------------------
  * Get Single User Setting Value
  * * This will return a single value, opposed to the entire settings
  -----------------------------------------------------------------------------------------*/
  public getSingleUserSetting(key, default_value = null) {
    let user_settings = localStorage.getItem('user_settings');
    if (user_settings) {
      user_settings = JSON.parse(user_settings);
      if (user_settings[key]) {
        return user_settings[key];
      }
      return null;
    }
    if (default_value) {
      return default_value;
    }
    return null;
  }



  /**----------------------------------------------------------------------------------------
  * Get Submenu Setting
  * * This function will return the users menu state preference
  -----------------------------------------------------------------------------------------*/
  getSubmenuSetting(){
    const submenuSetting = localStorage.getItem('submenuSetting');
    if (submenuSetting) {
      return submenuSetting
    }
    return null;
  }



  getThemeMode(){
    const sapThemeMode = localStorage.getItem('sapThemeMode');
    if (sapThemeMode) {
      this.sapThemeMode = sapThemeMode;
      return sapThemeMode
    }
    this.sapThemeMode = sapThemeMode;
    return "light";
  }



}
