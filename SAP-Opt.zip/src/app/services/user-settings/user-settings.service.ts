import { Injectable, NgZone } from '@angular/core';
import { AngularFirestore, AngularFirestoreDocument, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable, Subscription, combineLatest } from 'rxjs';
import { shareReplay, map } from "rxjs/operators";
import { BehaviorSubject } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Settings } from '../../interfaces/settings';
import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/storage';
import { AuthService } from '../../services/authentication/auth.service';
import { HelperService } from '../../services/helper/helper.service';
import Compressor from 'compressorjs';
import { switchMap } from 'rxjs/operators';
import { AngularFireStorage } from '@angular/fire/storage';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class UserSettingsService {

  // Firestore settings reference
  private settingsCollection: AngularFirestoreCollection<Settings>;
  private settingsDoc: AngularFirestoreDocument<Settings>;
  user_id: string;
  // Form
  allSettingsForm = new FormGroup({});
  generalSettingsForm = new FormGroup({});
  companySettingsForm = new FormGroup({});
  customWordingsForm = new FormGroup({});
  settings$: BehaviorSubject<Settings>;

  // Company Logo Size
  company_logoSize = [
    { order: -1, title: "Extra Small"},
    { order: 0, title: "Small"},
    { order: 1, title: "Regular"},
    { order: 2, title: "Large"},
    { order: 3, title: "Extra Large"}
  ];

  // For photo uploads
  uploadComplete: boolean = false;
  overlay_delete_photo: boolean = false;
  incorrect_file_type: boolean = false;
  metadata = { 
    contentType: 'image/jpeg', cacheControl: "public, max-age=31536000", type: 'image/jpeg', 
    customMetadata: {
      platform: environment.appVersion
    }
  };
  usersetting_companylogo_url: string;
  profileUrl: Observable<string | null>;
  _companyLogoSubScription: Subscription;

  // Overlays
  overlay_photo_upload: boolean = false;
  overlay_custom_wordings: boolean = false;

  constructor(
    private afs: AngularFirestore,
    public formBuilder: FormBuilder,
    public authService: AuthService,
    public helperService: HelperService,
    private storage: AngularFireStorage,
    private zone: NgZone,
  ) {
    this.allSettingsForm = formBuilder.group({
      usersetting_annotationcolour: 0,
      usersetting_annotationtool: 0,
      usersetting_assignedTo: [' '],
      usersetting_annotationlinewidth: 0,
      usersetting_auditorname: [' '],
      usersetting_companylogosize: 0,
      usersetting_companyname: [' '],
      usersetting_csv_include_images: [],
      usersetting_dateformat: [' '],
      usersetting_dueby: [' '],
      usersetting_emailprefs_send_guides: [],
      usersetting_emailprefs_send_marketing: [],
      usersetting_emailprefs_send_warnings: [],
      usersetting_headerColour: [' '],
      usersetting_identified: [' '],
      usersetting_include_frontcover: [],
      usersetting_include_photos: [],
      usersetting_includecompletedissues: [],
      usersetting_includedissues: 0,
      usersetting_includepagenumbers: [],
      usersetting_includetimestamps: [],
      usersetting_issuename: [' '],
      usersetting_issuenameplural: [' '],
      usersetting_of: [' '],
      usersetting_page: [' '],
      usersetting_photo_size: 0,
      usersetting_preparedfor: [' '],
      usersetting_primaryColour: [' '],
      usersetting_reportfont: 0,
      usersetting_reportquality: 0,
      usersetting_savetocameraroll: [],
      usersetting_subHeaderColour: [' '],
      usersetting_text_size: 0,
      usersetting_theme: 0,
      usersetting_usesquareimages: [],
      usersetting_companylogo: [''],
      usersetting_companylogo_url: ['']
    });
    this.generalSettingsForm = formBuilder.group({
      usersetting_savetocameraroll: [],
      usersetting_usesquareimages: [],
    });
    this.companySettingsForm = formBuilder.group({
      usersetting_auditorname: [' '],
      usersetting_companylogosize: 0,
      usersetting_companyname: [' '],
      usersetting_companylogo: [''],
      usersetting_companylogo_url: ['']
    });
    this.customWordingsForm = formBuilder.group({
      usersetting_assignedTo: [' '],
      usersetting_dueby: [' '],
      usersetting_identified: [' '],
      usersetting_issuename: [' '],
      usersetting_issuenameplural: [' '],
      usersetting_of: [' '],
      usersetting_page: [' '],
      usersetting_preparedfor: [' '],
    });
    this.settings$ = new BehaviorSubject({
      usersetting_annotationcolour: 0,
      usersetting_annotationtool: 0,
      usersetting_annotationlinewidth: 0,
      usersetting_assignedTo: '',
      usersetting_auditorname: '',
      usersetting_companylogosize: 0,
      usersetting_companyname: '',
      usersetting_csv_include_images: false,
      usersetting_dateformat: '',
      usersetting_dueby: '',
      usersetting_emailprefs_send_guides: false,
      usersetting_emailprefs_send_marketing: false,
      usersetting_emailprefs_send_warnings: false,
      usersetting_headerColour: '',
      usersetting_identified: '',
      usersetting_include_frontcover: false,
      usersetting_include_photos: false,
      usersetting_includecompletedissues: false,
      usersetting_includedissues: 0,
      usersetting_includepagenumbers: false,
      usersetting_includetimestamps: false,
      usersetting_issuename: '',
      usersetting_issuenameplural: '',
      usersetting_of: '',
      usersetting_page: '',
      usersetting_photo_size: 0,
      usersetting_preparedfor: '',
      usersetting_primaryColour: '',
      usersetting_reportfont: 0,
      usersetting_reportquality: 0,
      usersetting_savetocameraroll: false,
      usersetting_subHeaderColour: '',
      usersetting_text_size: 0,
      usersetting_theme: 0,
      usersetting_usesquareimages: false,
      usersetting_companylogo: '',
      usersetting_companylogo_url: '',
    });
  }
  /**----------------------------------------------------------------------------------------
  * Get User Settings
  * * // TODO - https://github.com/VeamStudios/SiteAuditPro-Optimisation/issues/21
  * * This function is called from the app.component to collect the user settings
  -----------------------------------------------------------------------------------------*/
  public getUserSettings(user_id: string): Observable<any> {
    this.settingsCollection = this.afs.collection<any>(`user_settings`);
    this.settingsDoc = this.settingsCollection.doc<any>(`${user_id}`);
    return this.settingsDoc.snapshotChanges()
      .pipe(map(collectionDoc => {
        const data = collectionDoc.payload.data();
        return {
          ...data,
        }
      }),
        shareReplay()
      );
  }

  
  
  /**----------------------------------------------------------------------------------------
  * Set All Settings
  * * Strip the form of only the necessary values
  * * Update the form
  * * Upon completion, mark as complete
  * * This is used by the report generator to save the users choices
  -----------------------------------------------------------------------------------------*/
  setAllSettings(){
    let formValue = { ...this.allSettingsForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }
    this.settingsDoc.update(formValue).then(() => {
      this.allSettingsForm.markAsPristine();
      this.setValuesToLocalStorage();
    });
  }


  
  /**----------------------------------------------------------------------------------------
  * Set General Settings
  * * Strip the form of only the necessary values
  * * Update the form
  * * Upon completion, mark as complete
  -----------------------------------------------------------------------------------------*/
  setGeneralSettings(){
    let formValue = { ...this.generalSettingsForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }
    this.settingsDoc.update(formValue).then(() => {
      this.generalSettingsForm.markAsPristine();
      this.setValuesToLocalStorage();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Set Company Settings
  * * Update the company settings form
  * * Make sure the company logo is a number using "+"
  * * Upon completion, mark the form as pristine
  * * Save the new values to storage
  -----------------------------------------------------------------------------------------*/
  setCompanySettings(){
    this.settingsDoc.update({
      usersetting_auditorname: this.companySettingsForm.value.usersetting_auditorname,
      usersetting_companylogosize: +this.companySettingsForm.value.usersetting_companylogosize,
      usersetting_companyname: this.companySettingsForm.value.usersetting_companyname,
      usersetting_companylogo: this.companySettingsForm.value.usersetting_companylogo,
      usersetting_companylogo_url: this.companySettingsForm.value.usersetting_companylogo_url,
    }).then(() => {
      this.companySettingsForm.markAsPristine();
      this.setValuesToLocalStorage();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Set Custom Wordings
  * * Strip the form of only the necessary values
  * * Update the form
  * * Upon completion, mark as complete
  -----------------------------------------------------------------------------------------*/
  setCustomWordings(){
    let formValue = { ...this.customWordingsForm.value };
    for (let prop in formValue) {
      if (!formValue[prop] && formValue[prop] != 0) {
        delete formValue[prop];
      }
    }
    this.settingsDoc.update(formValue).then(() => {
      this.customWordingsForm.markAsPristine();
      this.setValuesToLocalStorage();
    });
  }

  setValuesToLocalStorage(){
    localStorage.removeItem('user_settings');
    localStorage.setItem('user_settings', JSON.stringify(this.allSettingsForm.value));
  }



  /**----------------------------------------------------------------------------------------
  * Restore Custom Wordings
  * * Set the custom wordings back to default
  -----------------------------------------------------------------------------------------*/
  restoreCustomWordingsValues(){
    this.settingsDoc.update({
      usersetting_assignedTo: "Assigned To",
      usersetting_dueby: "Due By",
      usersetting_identified: "Identified",
      usersetting_issuename: "Issue",
      usersetting_issuenameplural: "Issues",
      usersetting_of: "of",
      usersetting_page: "Page",
      usersetting_preparedfor: "Prepared For"
    }).then(() => {
      this.overlay_custom_wordings = false;
    })
  }



  /**----------------------------------------------------------------------------------------
  * Get Company Logo URL
  * * Get Company logo url using the "usersetting_companylogo" in local storage
  -----------------------------------------------------------------------------------------*/
  async getCompanyLogoURLOLD() {
    const usersetting_companylogo = await  this.helperService.getUserSettings().usersetting_companylogo;
    var storage = firebase.storage();
    var annotatedImageReference = usersetting_companylogo;
    var annotatedImagePathReference = storage.ref().child(annotatedImageReference);  
    this.usersetting_companylogo_url = await annotatedImagePathReference.getDownloadURL();
    
  }


  async getCompanyLogoURL(ref: string){
    var storage = firebase.storage();
    var logoRef = storage.ref().child(ref);  
    this.usersetting_companylogo_url = await logoRef.getDownloadURL();
  }



  /**----------------------------------------------------------------------------------------
  * Detect Files
  * * Set the image overlay to true
  * * If the image was dragged into the dropzone, check that it's the correct file type
  * * If it is, continue. If it isn't, close the overlay and show and error message
  * * Create a new photo id
  * * If the form has been changed, update it
  * * Call functions to resize both the large and thumbnail images
  -----------------------------------------------------------------------------------------*/
  async detectFiles(files: FileList) {
    const user = await this.authService.getUserID()
    if (user) {
      this.overlay_photo_upload = true;
      const file = files[0];
      const fileType = file.type;
      var fileExtension = fileType.split('/').pop();
      if (fileExtension == "jpg" || fileExtension == "jpeg" || fileExtension == "png") {
        this.incorrect_file_type = false;
        const new_photo_id = this.afs.createId();
        if (file && files.length > 0) {
          this.saveImage(file, user.uid, new_photo_id)
        }
      } else {
        this.incorrect_file_type = true;
        this.overlay_photo_upload = false;
      }

    }
  }

  saveImage(file, user_id, new_photo_id){
    this.zone.runOutsideAngular(async () => {
      const original = await this.compressImage(file, {
        quality: 0.75,
        maxWidth: 400,
        maxHeight: 400,
        checkOrientation: true
      });
      return {
        original,
      };
    }).then((results) => {
      const largePath = `user_settings/${user_id}/${new_photo_id}_company_logo_${new_photo_id}.jpeg`;
      const largeTaskRef = this.storage.ref(largePath);
      const largeTask = this.storage.upload(largePath, results.original, this.metadata);

      const obs$ = combineLatest([largeTask]);
      this._companyLogoSubScription = obs$.pipe(
        switchMap(async ([largeTask]) => {
          const largeUrl = await largeTaskRef.getDownloadURL().toPromise();
          return this.afs.doc(`user_settings/${user_id}`).update({
            usersetting_companylogo: largePath,
            usersetting_companylogo_url: largeUrl,
          }).then(() => {
            this.usersetting_companylogo_url = largeUrl;
            this.overlay_delete_photo = false;
            this.uploadComplete = true;
          })
        })
      ).subscribe();
    });
  }



  /**----------------------------------------------------------------------------------------
  * Compress Image
  * * Used by CompressorJS (saveCroppedImage) to resize images
  -----------------------------------------------------------------------------------------*/
  compressImage(file, options) {
    return new Promise((resolve, reject) => {
      return new Compressor(file, {
        ...options,
        success: resolve,
        error: reject,
      });
    });
  }



  /**----------------------------------------------------------------------------------------
   * Delete Large Photo
   * * Set the image spinner to true
   * * If changes were made to the form, write them to the database
   * * Delete the photo
   * * Upon completion, remove photo fields from the firestore document
   * * Upon completion, repeat the process for the thumbnail image
   -----------------------------------------------------------------------------------------*/
  deleteCompanyLogo(user_id: string) {
    if (this.companySettingsForm.dirty) {
      this.setCompanySettings();
    }
    const companyLogo = this.settings$.value.usersetting_companylogo;
    this.storage.storage.ref(companyLogo).delete().then(() => {
      this.afs.doc(`user_settings/${user_id}`).update({
        usersetting_companylogo: firebase.firestore.FieldValue.delete(),
        usersetting_companylogo_url: firebase.firestore.FieldValue.delete()
      }).then(() => {
        this.usersetting_companylogo_url = null;
        this.overlay_delete_photo = false;
      })
    })
  }

}
