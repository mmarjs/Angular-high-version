import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FontsService {

  // Classic Custom Font Class
  classicCustomFont: string;

  constructor() { }


  getCustomFont(font: string) {
    const environment = "https://" + window.location.host;
    switch (font) {
      case "font_default":
        return '@font-face {' + 'font-family: Helvetica' + '}';
      case "font_PTSansRegular":
        return '@font-face {' + 'font-family: PTSans-Regular;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/PT_Sans-Regular.ttf);' + '}';
      case "font_PTSansBold":
        return '@font-face {' + 'font-family: PTSans-Bold;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/PT_Sans-Bold.ttf);' + '}';
      case "font_RobotoRegular":
        return '@font-face {' + 'font-family: Roboto-Regular;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/Roboto-Regular.ttf);' + '}';
      case "font_OpenSans":
        return '@font-face {' + 'font-family: OpenSans;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/OpenSans-Regular.ttf);' + '}';
        case "font_OpenSans-Semibold":
          return '@font-face {' + 'font-family: OpenSans-Semibold;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/OpenSans-Semibold.ttf);' + '}';
      case "font_Montserrat":
        return '@font-face {' + 'font-family: Montserrat;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/Montserrat-Regular.ttf);' + '}';
      case "font_CrimsonTextRoman":
        return '@font-face {' + 'font-family: CrimsonText-Roman;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/CrimsonText-Roman.ttf);' + '}';
      case "font_CrimsonTextRomanSemiBold":
        return '@font-face {' + 'font-family: CrimsonText-Semibold;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/CrimsonText-Semibold.ttf);' + '}';
      case "font_MarkerFelt":
        return '@font-face {' + 'font-family: Marker-Felt;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/Marker-Felt.ttf);' + '}';
      case "font_AvenirNextBold":
        return '@font-face {' + 'font-family: AvenirNext-Bold;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/AvenirNext-Bold.ttf);' + '}';
      case "font_AvenirNextRegular":
        return '@font-face {' + 'font-family: AvenirNext-Regular;' + 'font-weight: normal;' + 'font-style: normal;' + 'src: url(' + environment + '/assets/fonts/AvenirNext-Regular.ttf);' + '}';
      default:
        break;
    }
  }


  setClassicCustomFont(i: number){
    switch (i) {
      case 0:
        this.classicCustomFont = "theme_0";
        break;
      case 1:
        this.classicCustomFont = "theme_0 theme_0-traditional";
        break;
      case 2:
        this.classicCustomFont = "theme_0 theme_0-typewriter";
        break;
      default:
        this.classicCustomFont = "theme_0";
        break;
    }

  }
}
