import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  public incompleteIssues: number = 0;

  // PDF / CSV Toggle
  showPDF: boolean = true;
  

  constructor(
  ) { }


}
