import { Injectable } from '@angular/core';
import { HelperService } from '../../services/helper/helper.service';
import { saveAs } from 'file-saver';
import * as JSZip from 'jszip';
import * as JSZipUtils from 'jszip-utils';
var dayjs = require('dayjs');
var customParseFormat = require('dayjs/plugin/customParseFormat')
dayjs.extend(customParseFormat)

@Injectable({
  providedIn: 'root'
})
export class CsvService {

  csvIssuesArrayHTML = []
  finalCSVString: string;
  project;
  issues;
  usersetting_csv_include_images: boolean;


    // User Settings
    userSettings: any = {};

  constructor(
    public helperService: HelperService,
  ) { 
    this.userSettings = this.helperService.getUserSettings();
  }


  setCSVImageChoice(usersetting_csv_include_images) {
    if (usersetting_csv_include_images === undefined) {
      this.usersetting_csv_include_images = false;
      this.generateCSV(this.project, this.issues);
    } else {
      this.usersetting_csv_include_images = usersetting_csv_include_images;
      this.generateCSV(this.project, this.issues);
    }
  }


  /**-------------------------------------------------------------------
* * Add CSV Project Information
* 1. Convert the current project date into a sensible format
* 2. Create a string called 'projectString'
* 3. Create CSV style formatting inside the string
* 4. `,` seperates the cells inside the CSV
* 5. "\""" escapes
* 6. "\n" creates a new line
* 7. Return the string for when the function is called
* Note: The empty values are for creating empty rows & cells in...
* ...the exported CSV file
------------------------------------------------------------------- */
  addProject(project) {

    // const formattedProjectDate = moment(project.project_date).format('dddd, MMMM Do YYYY');

    // const project_date = project.project_date?;
    const project_date = project.project_date ? project.project_date : null;
    const formattedProjectDate = dayjs(project_date).format("YYYY/MM/DD, HH:mm:ss");
    const project_complete = project.project_completed ? 'True' : 'False';
    const project_reference = project.project_reference ? project.project_reference : '';
    const project_client = project.project_client ? project.project_client : '';
    const project_address = project.project_address ? project.project_address : '';
    const project_auditor_company = project.project_auditor_company ? project.project_auditor_company : '';
    const project_auditor_name = project.project_auditor_name ? project.project_auditor_name : '';

    var projectString =
      "1," + "PROJECT INFO" + "" + "," + "\n" +
      "2," + "Title," + "\"" + project.project_title + "\"" + "\n" +
      "3," + "Date," + "\"" + formattedProjectDate + "\"" + "\n" +
      "4," + "Ref," + "\"" + project_reference + "\"" + "\n" +
      "5," + "" + "\n" +
      "6," + "" + "\n" +
      "7," + "Client," + "\"" + project_client + "\"" + "\n" +
      "8," + "Address," + "\"" + project_address + "\"" + "\n" +
      "9," + "Company," + "\"" + project_auditor_company + "\"" + "\n" +
      "10," + "" + "\n" +
      "11," + "Auditor," + "\"" + project_auditor_name  + "\"" + "\n" +
      "12," + "" + "\n" +
      "13," + "Project Complete," + "\"" + project_complete + "\"" + "\n" +
      "14," + "" + "\n" +
      "15," + "" + "\n" +
      "16," + "" + "\n" +
      "17," + "" + "\n" +
      "18," + "" + "\n";

    return projectString;

  }


  /**-------------------------------------------------------------------
  * * Add CSV Issue User Setting Information
  * 1. Create a string called 'issueNamePlural'
  * 2. This string will include:
  *   - "19" represents the row number that the "ISSUES" text will appear
  *   - The "ISSUES" header, or whatever the user has renamed issues to
  * 3. Return the string for when the function is called
  ------------------------------------------------------------------- */
  addIssueTextHeader() {
    // return "19," + this.userSettings.usersetting_issuenameplural.toUpperCase() + "\n";
    return "19," + this.userSettings.usersetting_issuenameplural.toUpperCase() + "\n";
  }



  /**-------------------------------------------------------------------
  * * Add CSV Issue Headers
  * 1. Create a string called 'headers'
  * 2. This string will include:
  *   - "20" represents the row number that the headers text will appear
  *   - The titles of the headers of the columns
  * 3. Return the string for when the function is called
  ------------------------------------------------------------------- */
  addIssueHeaders() {
    return "20,Order,Item,Title,,Assignee,Comments,Image Path,Timestamp,Due Date,Completed" + "\n";
  }



  /**-------------------------------------------------------------------
 * * Add CSV Issues
 * 1. Create a variable called 'order'
 *   - This will appear in the 2nd column and will be the 'order' of ...
 *   - ...the issue
 * 2. Check the existence of the date
 *   - If it doesn't exist, leave string empty
 *   - If it does exist, populate the string
 * 3. Create a string called 'issue' which contains all populated data
 * 4. Push all the data into the 'csvIssuesArrayHTML' variable
 *   - This is used for the HTML preview
 * 5. Populate an object for preview
 * 6. Return the 'issue' string for the 'generateCSV' function
 *   - This will populate the final string for export
 ------------------------------------------------------------------- */
  addIssue(issueData, row: number, index: number) {

    const issueDueDate = issueData.issue_due_date?.toDate();
    const formattedIssueDueDate = dayjs(issueDueDate).format("YYYY/MM/DD");

    if (issueData.dateCreated){
      const issueCreatedDate = issueData.dateCreated.toDate();
      var formattedIssueCreatedDate= dayjs(issueCreatedDate).format("YYYY/MM/DD, HH:mm:ss");
    }

    if (issueData.dateCreatedOnDevice){
      const dateCreatedOnDevice = issueData.dateCreatedOnDevice.toDate();
      var formattedIssueCreatedDate= dayjs(dateCreatedOnDevice).format("YYYY/MM/DD, HH:mm:ss");
    }

    const issue_comments = issueData.issue_comments ? issueData.issue_comments : '';
    const issue_assignee = issueData.issue_assignee ? issueData.issue_assignee : '';

    var order: number = index - 1;

    var issue =
      row + "," + order + "," + index + "," +
      "\"" + issueData.issue_title + "\"" + "," +
      "" + "," +
      "\"" + issue_assignee + "\"" + "," +
      "\"" + issue_comments + "\"" + "," +
      "" + "," +
      "\"" + formattedIssueCreatedDate + "\"" + "," +
      "\"" + formattedIssueDueDate + "\"" + "," +
      "\"" + issueData.issue_completed + "\"" + "\n";

    this.csvIssuesArrayHTML.push(
      {
        row: row,
        order: order,
        index: index,
        issue_title: issueData.issue_title,
        issue_assignee: issueData.issue_assignee ? issueData.issue_assignee : '',
        issue_comments: issueData.issue_comments ? issueData.issue_comments : '',
        dateCreated: issueData.dateCreated || issueData.dateCreatedOnDevice ? formattedIssueCreatedDate : '',
        issue_due_date: issueData.issue_due_date ? formattedIssueDueDate : '',
        issue_completed: issueData.issue_completed ? issueData.issue_completed : '',
      }
    );

    return issue;

  }



  /**-------------------------------------------------------------------
* * Add CSV Issue Images
* 1. Create a variable called 'path'
*   - If the user decides not to include images, display "path"
*   - Otherwise, display the trimmed 'image_photo_reference'
* 2. Create two consts values to format:
*   - 'image_date'
* 3. The 'if' statement will check whether the local variable...
* ...of 'usersetting_csv_include_images' is set to true.
* ...If it is, update the path variable, otherwise leave it alone
* 4. item:
*   - This is the integer that's assigned to each issue
*   - e.g issue 1 will be 1, issue 2 will be 2
* 5. subItem:
*   - This is the integer that's assigned to issue images
*   - e.g image 1 will be 0.001 (allowing room for 100's of images)
* 6. itemAndSubItem variable
*   - This is 'item' and 'subItem' combined
*   - This allows the issue image integer to relate to the issue
*   - e.g if the issue is 2, the image number will be 2.00*
* 7. Create a string called 'imageString'
* 8. Empty values represent empty cells in the CSV
* 9. Create and populate an object for the HTML preview
* 10. If statement to determine what to return
*   - Export will return the imageString
*   - Preview will return image object
------------------------------------------------------------------- */
  addImage(location, imageData, row, index, item, subItem) {

    const imageDate = imageData.image_date.toDate();
    const formattedImageDate = dayjs(imageDate).format("YYYY/MM/DD, HH:mm:ss");
  
    var image_photo = imageData.image_photo;
    var image_photo_substring = image_photo.substring(image_photo.lastIndexOf('/') + 1);
    var path = this.usersetting_csv_include_images ? image_photo_substring : '-';


    var imageString =
      row + "," + "" + "," + parseInt(item) + parseFloat(subItem) + "," +
      " ," +
      " ," +
      " ," +
      " ," +
      path + "," +
      "\"" + formattedImageDate + "\"" + "\n";

    var imageObject = {};
    imageObject["row"] = row;
    imageObject["itemAndSubItem"] = parseInt(item) + parseFloat(subItem);
    imageObject["path"] = path;
    imageObject["formattedImageDate"] = formattedImageDate;

    if (location === "forExport") {
      return imageString;
    } else {
      return imageObject;
    }

  }


  /**-------------------------------------------------------------------
  * * Generate CSV
  ------------------------------------------------------------------- */
  async generateCSV(project, issues) {

    // Empty the array otherwise duplications will appear when toggling 'Include Images In Export'
    this.csvIssuesArrayHTML = [];

    // Add the Project Data string to the csvText variable
    var csvText = this.addProject(project);

    // Add the 'Issues' user setting and the issue list headers to the csvText variable
    csvText = csvText + this.addIssueTextHeader() + this.addIssueHeaders();

    // Issue row number starts at 21
    var row = 21;

    // Issue row index starts at 1
    var index = 1;

    // Loop through all issues
    // For each issue, create an 'imagesArray'
    // Add the issues to the csvText variable
    // Increase the row number by 1
    // If any of the issues have images, loop through them
    // Add the images to the csvText cariable
    // Add the images to the csvIssuesArrayHTML array for HTML previewing
    // Increase the row and subitem by 1
    await issues.forEach(element => {

      var imagesArray = [];

      csvText = csvText + this.addIssue(element, row, index);

      row += 1;

      if (element.images) {
        let item = index;
        var subitem = 0.001;
        element.images.forEach(element => {
          csvText = csvText + this.addImage("forExport", element, row, index, item, subitem);
          imagesArray.push(this.addImage("forPreview", element, row, index, item, subitem));
          this.csvIssuesArrayHTML[index - 1]["images"] = imagesArray;
          subitem += 0.001;
          row += 1;
        })
      }
      index += 1;

    });

    // Once the above is complete, add the final csvText variable to a global variable
    // ...this can then be used in the JSZip download
    this.finalCSVString = csvText;

  }


  async downLoadCSVFile() {

    // 1
    const csvFile = new File([this.finalCSVString], this.project.project_title + '.csv', {
      type: 'text/plain;charset=utf-8'
    });

    // 2
    var zip = new JSZip();

    // 3
    var projectTitle = this.project.project_title.replace(/\//g, '_') + '.csv';

    // 4
    zip.file(projectTitle, csvFile);

    if (this.usersetting_csv_include_images) {
      var urls = [];
      var count = 0;
      var image_photo = '';
      var imageFileName = '';
      var projectTitle = '';
      projectTitle = this.project.project_title;
      this.issues.forEach(issue => {
        if (issue.images) {
          issue.images.forEach(image => {
            urls.push(image)
          })
        }
      });
      urls.forEach(function (url) {
        JSZipUtils.getBinaryContent(url.image_photo_thumbnail_url, function (err, data) {
            image_photo = url.image_photo;
            imageFileName = image_photo.substring(image_photo.lastIndexOf('/') + 1);
            if (err) {
                throw err; 
            }
            try {
                zip.file(imageFileName, data, { binary: true });
                count++;
                if (count == urls.length) {
                    zip.generateAsync({ type: "blob" }).then(function (content) {
                        saveAs(content, projectTitle + ".zip");
                    });
                }
            } catch (e) {
                // console.log("error", e)
            }
        });
      });
      
    } else {
     // 7
     const project_title = this.project.project_title.toLowerCase()
      zip.generateAsync({ type: "blob" }).then((blob) => {
        saveAs(blob, project_title + ".zip");
      });
    }
    // 6
    // this.settingsService.setCSVUserSettings(this.usersetting_csv_include_images);
    
  }

}
