import { Component, OnInit, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { ProjectDetailService } from '../../services/projects/project-detail.service';
import { AuthService } from '../../services/authentication/auth.service';
import { IssuesListService } from '../../services/issues/issues-list.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HelperService } from '../../services/helper/helper.service';
import { FoldersService } from '../../services/folders/folders.service';
@Component({
  selector: 'app-project-summary-children',
  templateUrl: './project-summary-children.component.html',
  styleUrls: ['./project-summary-children.component.scss'],
  // changeDetection: ChangeDetectionStrategy.Default,
})
export class ProjectSummaryChildrenComponent implements OnInit, OnDestroy {

  // URL Params
  folder_id: string;
  project_id: string;

  // Breadcrumb label
  breadcrumb_current: string;

  // Styles to be handed down
  summaryLayoutToggle: string = "flex-col flex-col-reverse";

  // User ID
  user_id: string;

    // User Settings
    userSettings: any = {};

  constructor(
    public projectDetailService: ProjectDetailService,
    public authService: AuthService,
    public issuesListService: IssuesListService,
    private _activatedRoute: ActivatedRoute,
    private router: Router,
    public helperService: HelperService,
    public foldersService: FoldersService,
  ) {
    this.userSettings = this.helperService.getUserSettings();
    this.router.events.subscribe((val) => {      
      this.setBreadcrumbCurrentPage();
    });
   }

  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "setURLParams"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.setURLParams();
    this.setBreadcrumbCurrentPage();
  }

  handleFoldersClick(){
    this.foldersService.breadCrumbFoldersClick = true;
    this.foldersService.folder_id = this.folder_id;
  }

  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the issues subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void { }



  /**----------------------------------------------------------------------------------------
  * Set URL Params
  * * Fetch URL Params and update local variables
  -----------------------------------------------------------------------------------------*/
  setURLParams() {
    this._activatedRoute.params.subscribe((urlParameters) => {
      this.folder_id = urlParameters['folder_id'];
      this.project_id = urlParameters['project_id'];
    });
  }



  /**----------------------------------------------------------------------------------------
  * Set Current Page Breadcrumb
  * * Subscribe to route changes
  * * Do checks to determine what's present in the url
  * * Update the "breadcrumb_current" to represent current page
  -----------------------------------------------------------------------------------------*/
  setBreadcrumbCurrentPage() {
    if (this.router.url.includes('summary/edit')) {
      this.breadcrumb_current = "Project Summary: Edit"
    } 
    if (this.router.url.includes('summary/issues')) {
      this.breadcrumb_current = "Project Summary: " + this.userSettings.usersetting_issuenameplural;
    } 
    if (this.router.url.includes('summary/signature')) {
      this.breadcrumb_current = "Project Summary: Signature"
    } 
  }


  



}
