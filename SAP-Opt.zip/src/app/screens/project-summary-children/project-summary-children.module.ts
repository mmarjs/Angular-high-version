import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectSummaryChildrenComponent } from './project-summary-children.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedProjectSummaryModule } from '../../components/shared/projects/shared-project-summary.module';
import { SharedIssuesListModule } from '../../components/shared/issues/shared-issues-list.module';

const routes: Routes = [
  {
    path: '',
    component: ProjectSummaryChildrenComponent,
    children: [
      {
        path: 'issues',
        loadChildren: () => import('../../components/issues/issues-list-wrapper/issues-list-wrapper.module').then(mod => mod.IssuesListWrapperModule),
      },
      {
        path: 'edit',
        loadChildren: () => import('../../components/projects/project-edit/project-edit.module').then(mod => mod.ProjectEditModule),
      },
      {
        path: 'signature',
        loadChildren: () => import('../../components/projects/project-signature/project-signature.module').then(mod => mod.ProjectSignatureModule),
      }
    ]
  }
]

@NgModule({
  declarations: [ProjectSummaryChildrenComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedProjectSummaryModule,
    SharedIssuesListModule
  ]
})

export class ProjectSummaryChildrenModule { }




