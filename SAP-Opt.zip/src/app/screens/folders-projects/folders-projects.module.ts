import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoldersProjectsComponent } from './folders-projects.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedFoldersModule } from '../../components/shared/folders/shared-folders.module';
import { SharedProjectsListModule } from '../../components/shared/projects/shared-projects-list.module';

const routes: Routes = [
  {
    path: '',
    component: FoldersProjectsComponent,
    children : [
      {
        path: ':folder_id',
        loadChildren: () => import('../../components/projects/projects-list/projects-list.module').then(mod => mod.ProjectsListModule),
      }
    ]
  }
]

@NgModule({
  declarations: [FoldersProjectsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedFoldersModule,
    SharedProjectsListModule,
  ]
})

export class FoldersProjectsModule { }
