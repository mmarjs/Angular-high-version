import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectsListService } from '../../services/projects/projects-list.service';
import { FoldersService } from '../../services/folders/folders.service';
import { AuthService } from '../../services/authentication/auth.service';
import { last, switchMap, tap } from 'rxjs/operators';

@Component({
  selector: 'app-folders-projects',
  templateUrl: './folders-projects.component.html',
  styleUrls: ['./folders-projects.component.scss']
})
export class FoldersProjectsComponent implements OnInit, OnDestroy {

  // URL Params
  folder_id: string;
  lastRoute: string;
  homeIconClick: boolean = false;
  // Folders
  private _foldersSubscription: Subscription;
  foldersArray = [];


  constructor(
    public projectsListService: ProjectsListService,
    public foldersService: FoldersService,
    public authService: AuthService,
    private _activatedRoute: ActivatedRoute,
    private router: Router
  ) { }


  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "getUserID"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    // this.setURLParams();
    this.lastRoute = this.foldersService.historyRoutes.pop();
    if(this.router.url === '/folders'){
      if(this.lastRoute === '/settings' || this.lastRoute === '/account'){
        var indexOfLastRoute = this.foldersService.historyRoutes.indexOf('/settings');
        if(indexOfLastRoute > -1){
          this.foldersService.historyRoutes.splice(indexOfLastRoute, 1)
        }
        var indexOfLastRoute = this.foldersService.historyRoutes.indexOf('/account');
        if(indexOfLastRoute > -1){
          this.foldersService.historyRoutes.splice(indexOfLastRoute, 1)
        }
        var lastRoute = this.foldersService.historyRoutes.pop();
        this.router.navigateByUrl(lastRoute);
      } 
    }
    this.getUserID();
  }

  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from both the folders & projects subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._foldersSubscription?.unsubscribe();
  }


  
  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getFolders" & "getProjects"
  -----------------------------------------------------------------------------------------*/
  async getUserID(){
    const user = await this.authService.getUserID()
    if (user) {
      this.getFolders(user.uid);
    }
  }



  /**----------------------------------------------------------------------------------------
  * Get Folders
  * * Update the _foldersSubscription with the query subscription
  * * Call "getFolders" from the "foldersService"
  * * Update the local "foldersArray" with the results
  * * The "foldersArray" will then be based down to the imported folders component HTML
  -----------------------------------------------------------------------------------------*/
  getFolders(user_id: string){
    this._foldersSubscription = this.foldersService.getFolders(user_id).subscribe(folders => {
      this.foldersArray = folders;
      if(this.foldersArray.length > 0){
        this.folder_id = this.foldersArray[0].id;
        if(!this.projectsListService.deleteProjectClick && !this.projectsListService.newProjectClick && !this.foldersService.newFolderClick && !this.foldersService.breadCrumbFoldersClick){
          if(this.foldersService.historyRoutes.length === 0 || (this.lastRoute !== '/settings' && this.lastRoute !== '/account')){
            this.router.navigateByUrl('/folders/' + this.folder_id);
          }
        }
      } 
      this.foldersService.showSpinner = false;
      this.foldersService.breadCrumbFoldersClick = false;
      this.foldersService.newFolderClick = false;
      this.projectsListService.newProjectClick = false;
    });
  }

  handleHomeIconClick() {
    this.homeIconClick = !this.homeIconClick;
  }

  /**----------------------------------------------------------------------------------------
  * Set URL Params
  * * Fetch URL Params and update local variables
  -----------------------------------------------------------------------------------------*/
  setURLParams() {
    this._activatedRoute.params.subscribe((urlParameters) => {
      this.folder_id = urlParameters['folder_id'];
    });    
  }

}
