import { Component, OnInit, OnDestroy } from '@angular/core';
import { switchMap, tap } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { IssuesListService } from '../../services/issues/issues-list.service';
import { IssueEditService } from '../../services/issues/issue-edit.service';
import { AuthService } from '../../services/authentication/auth.service';
import { HelperService } from '../../services/helper/helper.service';
import { FoldersService } from '../../services/folders/folders.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-issues-list-issues-edit',
  templateUrl: './issues-list-issues-edit.component.html',
  styleUrls: ['./issues-list-issues-edit.component.scss']
})
export class IssuesListIssuesEditComponent implements OnInit, OnDestroy {

  // URL Params
  folder_id: string;
  project_id: string;
  issue_id: string;

  // Issues List
  private _issuesSubscription: Subscription;

  // Images
  private _imagesSubscription: Subscription;
  
  // Issue Document
  private _issueSubscription: Subscription;

  // User
  user_id: string;

  // Styles to pass down
  editOptionsPosition: string = "left-0";

  // To pass to the issues list
  parentComponent: string = "issuesListIssuesEdit";

  // User Settings
  userSettings: any = {};

  constructor(
    private _activatedRoute: ActivatedRoute,
    public issuesListService: IssuesListService,
    public issueEditService: IssueEditService,
    public authService: AuthService,
    public helperService: HelperService,
    public foldersService: FoldersService,
    private router: Router
  ) { }

  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "getUserID"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.getUserID();
    this.foldersService.storeRoute(this.router.url);
    this.userSettings = this.helperService.getUserSettings();
  }

  /**----------------------------------------------------------------------------------------
  * ngOnDestroy
  * * Upon leaving this component, unsubscribe from the issues subscriptions
  -----------------------------------------------------------------------------------------*/
  ngOnDestroy(): void {
    this._issuesSubscription.unsubscribe();
    this._issueSubscription.unsubscribe();
    this._imagesSubscription.unsubscribe();
  }



  /**----------------------------------------------------------------------------------------
  * Get User ID
  * * Upon retrieving the user ID, call "getProjects" & "getProjectDetail"
  -----------------------------------------------------------------------------------------*/
  async getUserID() {
    const user = await this.authService.getUserID()
    if (user) {
      this.user_id = user.uid;
      this.getIssues(user.uid);
      this.getIssueDetail(user.uid);
      this.getIssueImages(user.uid)
    }
  }



  /**----------------------------------------------------------------------------------------
  * Get issues
  * * Update the _issuesSubscription with the query subscription
  * * Update the URL params
  * * Call "getIssues" from the "issuesListService"
  * * Update the local "issuesArray" with the results
  -----------------------------------------------------------------------------------------*/
  getIssues(user_id: string) {
    this._issuesSubscription = this._activatedRoute.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
        this.issue_id = params.issue_id;
      }),
      switchMap(params => {
        return this.issuesListService.getIssues(user_id, params.project_id);
      })
    ).subscribe(issues => {
      this.issuesListService.issuesArray = issues;
      this.issuesListService.issue_count = issues.length;
      this.issuesListService.showSpinner = false;
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get Issue Detail
  * * Update the _issueSubscription with the result
  * * Call the "getIssueDetail" function from "issueEditService"
  * * Subscribe and patch form
  -----------------------------------------------------------------------------------------*/
  getIssueDetail(user_id: string){
    this._issueSubscription = this._activatedRoute.params.pipe(
      switchMap(params => {
        return this.issueEditService.getIssueDetail(user_id, params.folder_id, params.project_id, params.issue_id);
      })
    ).subscribe(issue => {
      if (issue) {
        this.issueEditService.issueForm.reset();
        this.issueEditService.issue$.next(issue);
        this.issueEditService.issueForm.patchValue(issue);
      } else {
        this.router.navigate(['/', 'folders', this.folder_id, 'projects', this.project_id, 'summary', 'issues']);
      }
    });
  }



  /**----------------------------------------------------------------------------------------
  * Get Issue Images
  * * Update the local variables with url params
  * * Call "getIssueImages"
  * * Update the "imagesArray";
  * * Update the "image_count" to match the amount of images returned from the query
  -----------------------------------------------------------------------------------------*/
  getIssueImages(user_id: string) {
    this._imagesSubscription = this._activatedRoute.parent.params.pipe(
      tap(params => {
        this.folder_id = params.folder_id;
        this.project_id = params.project_id;
        this.issue_id = params.issue_id;
      }),
      switchMap(params => {
        return this.issueEditService.getIssueImages(user_id, params.project_id, params.issue_id);
      })
    ).subscribe(images => {
      this.issueEditService.imagesArray = images;
      this.issueEditService.image_count = images.length;
    });
  }



  /**----------------------------------------------------------------------------------------
  * Does Issue Need Saving?
  * * This function will check whether the issue form is dirty when clicking any links...
  * * ...within the breadcrumbs
  * * If that's true, show the save or discard overlay
  * * If that's false, navigate to the selected link
  -----------------------------------------------------------------------------------------*/
  doesIssueNeedSaving(path: string){    
    if (this.issueEditService.issueForm.dirty){
      this.issueEditService.overlay_unsaved_form = true;
      this.issueEditService.routeToNavigateTo = path;
    } else {
      this.router.navigateByUrl(path);
    }
  }

  

}
