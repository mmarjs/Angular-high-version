import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssuesListIssuesEditComponent } from './issues-list-issues-edit.component';
import { SharedIssuesListModule } from '../../components/shared/issues/shared-issues-list.module';
import { SharedIssueEditModule } from '../../components/shared/issues/shared-issue-edit.module';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: IssuesListIssuesEditComponent,
  }
]


@NgModule({
  declarations: [IssuesListIssuesEditComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    SharedIssuesListModule,
    SharedIssueEditModule,
  ]
})
export class IssuesListIssuesEditModule { }
