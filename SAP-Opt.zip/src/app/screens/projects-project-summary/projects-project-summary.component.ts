import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ProjectsListService } from '../../services/projects/projects-list.service';
import { FoldersService } from '../../services/folders/folders.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-projects-project-summary',
  templateUrl: './projects-project-summary.component.html',
  styleUrls: ['./projects-project-summary.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
})

export class ProjectsProjectSummaryComponent implements OnInit {

  // URL Params
  folder_id: string;
  project_id: string;

  // Styles to be handed down
  summaryLayoutToggle: string = "sm:flex-col md:flex-row";

  constructor(
    public projectsListService: ProjectsListService,
    public foldersService: FoldersService,
    private _activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }



  /**----------------------------------------------------------------------------------------
  * ngOnInIt
  * * On component load, call "getUserID"
  -----------------------------------------------------------------------------------------*/
  ngOnInit(): void {
    this.setURLParams();
    this.foldersService.storeRoute(this.router.url);
  }

  handleFoldersClick(){
    this.foldersService.breadCrumbFoldersClick = true;
    this.foldersService.folder_id = this.folder_id;
  }

  /**----------------------------------------------------------------------------------------
  * Set URL Params
  * * Fetch URL Params and update local variables
  -----------------------------------------------------------------------------------------*/
  setURLParams() {
    this._activatedRoute.params.subscribe((urlParameters) => {
      this.folder_id = urlParameters['folder_id'];
      this.project_id = urlParameters['project_id'];
    });
  }





}
