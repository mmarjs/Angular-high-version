import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectsProjectSummaryComponent } from './projects-project-summary.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedProjectsListModule } from '../../components/shared/projects/shared-projects-list.module';
import { SharedProjectSummaryModule } from '../../components/shared/projects/shared-project-summary.module';

const routes: Routes = [
  {
    path: '',
    component: ProjectsProjectSummaryComponent,
  }
]


@NgModule({
  declarations: [ProjectsProjectSummaryComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedProjectsListModule,
    SharedProjectSummaryModule
  ]
})

export class ProjectsProjectSummaryModule { }



