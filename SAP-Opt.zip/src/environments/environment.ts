// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  appVersion: "web_4.0.0",
  production: false,
  envName: 'dev',
  firebase: {
    apiKey: "AIzaSyD2OLwJgMBUCE9dETVqq7Lu9BX1uVXh9Gk",
    authDomain: "site-audit-pro-dev.firebaseapp.com",
    databaseURL: "https://site-audit-pro-dev.firebaseio.com",
    projectId: "site-audit-pro-dev",
    storageBucket: "site-audit-pro-dev.appspot.com",
    messagingSenderId: "851027748606",
    appId: "1:851027748606:web:5815f29fc490d663"
  },
  appUrl:"http://localhost:4200"
};